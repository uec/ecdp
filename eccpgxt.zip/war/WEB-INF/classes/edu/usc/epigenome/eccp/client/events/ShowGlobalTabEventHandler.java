package edu.usc.epigenome.eccp.client.events;

import com.google.gwt.event.shared.EventHandler;

public interface ShowGlobalTabEventHandler extends EventHandler
{
	public void onShowWidgetInTab(ShowGlobalTabEvent event);

}

