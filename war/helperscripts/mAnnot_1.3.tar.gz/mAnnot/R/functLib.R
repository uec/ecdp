# TODO: Add comment
# 
# Author: feipan
###############################################################################


findNN.5b<-function(data1,data2){
	name.1<-names(data1)
	if(substr(name.1[1],1,1)!="c"){
		name.1<-paste("chr",name.1,sep="")
		names(data1)<-name.1
	}
	nn<-names(data2)
	if(substr(nn[1],1,1)!="c"){
		nn<-paste("chr",nn,sep="")
		names(data2)<-nn
	}
	rst.all<-NULL
	for(k in 1:length(name.1)){
		chr<-name.1[k]
		data1.chr<-data1[[chr]]
		data2.chr<-data2[[chr]]
		if(is.null(data2.chr))next;
		data1.chr<-data1.chr[order(data1.chr$mapInfo,decreasing=FALSE),]
		data2.chr<-data2.chr[order(data2.chr$mapInfo,decreasing=FALSE),]
		len1<-1:nrow(data1.chr)
		rst<-data.frame(data2.chr[len1,],dist=NA,isWithin=NA,nearestDist=NA)
		pos<-1
		for(i in 1:nrow(data1.chr)){
			dist.cur<-999999999;
			dist.cur1<-dist.cur
			dist.pre<-dist.cur1
			isWithinSeq<-FALSE
			#init probe.cur
			probe.cur<-data2.chr[1,]
			probe.cur$dist<-dist.cur
			probe.cur$isWithin<-FALSE
			probe.cur$nearestDist<-dist.cur
			ml_id<-NULL
			if(is.na(data1.chr$start[i])|is.na(data1.chr$end[i])){
				next
			}
			for(j in pos:nrow(data2.chr)){
				pos<-j
				if(is.na(data2.chr$start[j]) | is.na(data2.chr$end[j])){
					next
				}
				d1<-abs(data2.chr$mapInfo[j]-data1.chr$mapInfo[i])
				
				isCheck<-data1.chr$end[i]>=data2.chr$start[j] & data1.chr$start[i]<=data2.chr$end[j]
				if(isCheck){
					isWithinSeq<-TRUE
					d<-abs(data2.chr$mapInfo[j]-data1.chr$mapInfo[i])
					if(!is.na(d) & d<dist.cur){
						dist.cur<-d
						probe.cur<-data2.chr[j,] 
						probe.cur$dist<-dist.cur
						probe.cur$isWithin<-isWithinSeq
						probe.cur$nearestDist<-dist.cur
					}
				}
				dist.cur1<-d1
				if(dist.cur1>dist.pre){
					#dist.pre<-999999999
					#cat("dist.cur1: ",dist.cur1,"\t dist.pre: ",dist.pre,"\t data1.mapInfo: ",data1.chr$mapInfo[i],"\n")
					pos<-ifelse(pos>1,pos-1,pos)
					break
				}
				dist.pre<-dist.cur1
				probe.cur$nearestDist<-dist.cur1
			}
			rst[i,]<-probe.cur
		}
		rst<-cbind(data1.chr,rst)
		if(is.null(rst.all)){
			rst.all<-rst
		}else{
			rst.all<-rbind(rst.all,rst)
		}
	}
	return(rst.all)
}
test_findNN.5b<-function(){
	#load(file=file.path("C://feipan//manifests//test","snp.chr14.rdata"))
	chr1.rmsk<-read.table(file=file.path("C:\\feipan\\database\\ucsc\\rmsk","chr1_rmsk.txt"),
			sep="\t",header=F)
	rsmp.chr<-chr1.rmsk[,c(12,6,7,8,11,13)]
	names(rsmp.chr)<-c("Class","Chr","start","end","Name","Family")
	rsmp.chr["mapInfo"]<-rsmp.chr$start+(rsmp.chr$end-rsmp.chr$start)/2
	rsmp.chr<-split(rsmp.chr,as.factor(rsmp.chr$Chr))
	
	##
	load(file=file.path("C:\\feipan\\database\\ucsc\\rmsk","rsmp.all.rdata"))
	rsmp.chr<-split(rsmp.all,as.factor(rsmp.all$Chr))
	library(mLab)
	library(mAnnot)
	getData("OMA02")
	oma2<-getMapInfo("OMA02")
	oma2.chr<-split(oma2,as.factor(oma2$Chr))
	system.time(rst<-findNN.5b(oma2.chr,rsmp.chr))
	system.time(rst1<-findNN.5(oma2.chr,rsmp.chr))
	setwd("c:\\temp")
	stamp<-unclass(Sys.time())
	save(rst,file=paste("rst",stamp,".rdata"))
	write.table(rst,file=paste("rst.m",stamp,".csv",sep=""),sep=",",row.names=F)
	write.table(rst1,file=paste("rst1",stamp,".csv",sep=""),sep=",",row.names=F)
}

#############################
#
#############################


###############################
#
################################
#findNN.5a<-function(data1,data2){
#	name.1<-names(data1)
#	if(substr(name.1[1],1,1)!="c"){
#		name.1<-paste("chr",name.1,sep="")
#		names(data1)<-name.1
#	}
#	nn<-names(data2)
#	if(substr(nn[1],1,1)!="c"){
#		nn<-paste("chr",nn,sep="")
#		names(data2)<-nn
#	}
#	#rst.all<-NULL
#	run<-function(chr.1){
#		#for(k in 1:length(name.1)){
#			#chr<-name.1[k]
#			rst.all<-NULL
#			chr<-chr.1
#			data1.chr<-data1[[chr]]
#			data2.chr<-data2[[chr]]
#			if(!is.null(data2.chr)) #return(rst.all);
#			{
#				data1.chr<-data1.chr[order(data1.chr$start,decreasing=FALSE),]
#			data2.chr<-data2.chr[order(data2.chr$start,decreasing=FALSE),]
#			len1<-1:nrow(data1.chr)
#			rst<-data.frame(data2.chr[len1,],dist=NA,isWithin=NA)
#			pos<-1
#			
#			for(i in 1:nrow(data1.chr)){
#				#cat(">>>>>>>:",i,"\n")
#				dist.cur<-999999999;
#				isWithinSeq<-FALSE
#				#init probe.cur
#				probe.cur<-data2.chr[1,]
#				probe.cur$dist<-dist.cur
#				probe.cur$isWithin<-FALSE
#				ml_id<-NULL
#				if(is.na(data1.chr$start[i])|is.na(data1.chr$end[i])){
#					next
#				}
#				len2<-nrow(data2.chr)
#				for(j in pos:len2){
#					#cat("========: ",j,"\n")
#					pos<-j
#					if(is.na(data2.chr$start[j]) | is.na(data2.chr$end[j])){
#						next
#					}
#					isCheck<-data1.chr$end[i]>data2.chr$start[j] & data1.chr$start[i]<data2.chr$end[j]
#					check2<-data1.chr$end[i]<data2.chr$start[j]
#					#cat("+++++++++: ",check2,"\n")
#					if(isCheck){
#						isWithinSeq<-TRUE
##						probe.cur<-data2.chr[j,]
##						probe.cur$dist<-dist.cur
##						probe.cur$isWithin<-isWithinSeq
#						
#						d<-abs(data2.chr$mapInfo[j]-data1.chr$mapInfo[i])
#						if(!is.na(d) & d<dist.cur){
#							dist.cur<-d
#							#probe.cur$dist<-dist.cur
#							probe.cur<-data2.chr[j,]
#							probe.cur$dist<-dist.cur
#							probe.cur$isWithin<-isWithinSeq
#						}
#					}else if( check2==TRUE){
#						#cat("------: ",j,"\n")
#						break
#					}
#				}
#				rst[i,]<-probe.cur
#			}
#			rst<-cbind(data1.chr,rst)
#			if(is.null(rst.all)){
#				rst.all<-rst
#			}else{
#				rst.all<-rbind(rst.all,rst)
#			}
#		}
#		return(rst.all)
#	}
#	#rst<-sapply(name.1,run)
#	rst.all<-NULL
#	for(i in 1:length(name.1)){
#		rst<-run(name.1[i])
#		if(is.null(rst.all)){
#			rst.all<-rst
#		}else{
#			rst.all<-rbind(rst.all,rst)
#		}
#	}
#	return(rst.all)
#}

findNN.5<-function(data1,data2){
	name.1<-names(data1)
	if(substr(name.1[1],1,1)!="c"){
		name.1<-paste("chr",name.1,sep="")
		names(data1)<-name.1
	}
	nn<-names(data2)
	if(substr(nn[1],1,1)!="c"){
		nn<-paste("chr",nn,sep="")
		names(data2)<-nn
	}
	rst.all<-NULL
	for(k in 1:length(name.1)){
		chr<-name.1[k]
		data1.chr<-data1[[chr]]
		data2.chr<-data2[[chr]]
		if(is.null(data2.chr))next;
		if((nrow(data2.chr))==0)next;
		data1.chr<-data1.chr[order(data1.chr$start,decreasing=FALSE),]
		data2.chr<-data2.chr[order(data2.chr$start,decreasing=FALSE),]
		len1<-1:nrow(data1.chr)
		rst<-data.frame(data2.chr[len1,],dist=NA,isWithin=NA)
		pos<-1
		for(i in 1:nrow(data1.chr)){
			dist.cur<-999999999;
			isWithinSeq<-FALSE
			probe.cur<-data2.chr[1,]
			probe.cur$dist<-dist.cur
			probe.cur$isWithin<-FALSE
			ml_id<-NULL
			if(is.na(data1.chr$start[i])|is.na(data1.chr$end[i])){
				next
			}
			for(j in pos:nrow(data2.chr)){
				pos<-j
				if(is.na(data2.chr$start[j]) | is.na(data2.chr$end[j])){
					next
				}
				isCheck<-data1.chr$end[i]>=data2.chr$start[j] & data1.chr$start[i]<=data2.chr$end[j]
			
				if(isCheck){
					isWithinSeq<-TRUE
					d<-abs(data2.chr$mapInfo[j]-data1.chr$mapInfo[i])
					if(!is.na(d) & d<dist.cur){
						dist.cur<-d
						probe.cur<-data2.chr[j,] 
						probe.cur$dist<-dist.cur
						probe.cur$isWithin<-isWithinSeq
					}
				}else if( data1.chr$end[i]<data2.chr$start[j]){
					pos<-ifelse(pos>1,pos-1,pos)  ## May3
					break
				}
			}
			rst[i,]<-probe.cur
		}
		rst<-cbind(data1.chr,rst)
		if(is.null(rst.all)){
			rst.all<-rst
		}else{
			rst.all<-rbind(rst.all,rst)
		}
	}
	return(rst.all)
}
#
#findNN.5<-function(data1,data2){
#	name.1<-names(data1)
#	if(substr(name.1[1],1,1)!="c"){
#		name.1<-paste("chr",name.1,sep="")
#		names(data1)<-name.1
#	}
#	nn<-names(data2)
#	if(substr(nn[1],1,1)!="c"){
#		nn<-paste("chr",nn,sep="")
#		names(data2)<-nn
#	}
#	rst.all<-NULL
#	for(k in 1:length(name.1)){
#		chr<-name.1[k]
#		data1.chr<-data1[[chr]]
#		data2.chr<-data2[[chr]]
#		if(is.null(data2.chr))next;
#		data1.chr<-data1.chr[order(data1.chr$start,decreasing=FALSE),]
#		data2.chr<-data2.chr[order(data2.chr$start,decreasing=FALSE),]
#		len1<-1:nrow(data1.chr)
#		rst<-data.frame(data2.chr[len1,],dist=NA,isWithin=NA)
#		pos<-1
#		for(i in 1:nrow(data1.chr)){
#			dist.cur<-999999999;
#			isWithinSeq<-FALSE
#			#init probe.cur
#			probe.cur<-data2.chr[1,]
#			probe.cur$dist<-dist.cur
#			probe.cur$isWithin<-FALSE
#			ml_id<-NULL
#			for(j in pos:nrow(data2.chr)){
#				pos<-pos+1
#				isCheck<-data1.chr$mapInfo[i]>data2.chr$start[j] & data1.chr$mapInfo[i]<data2.chr$end[j]
#				isIn<-FALSE
#				if(!is.na(isCheck) & isCheck){
#					isWithinSeq<-TRUE
#					probe.cur<-data2.chr[j,]
#					probe.cur$isWithin<-isWithinSeq
#					probe.cur$dist<-dist.cur
#					d<-abs(data2.chr$mapInfo[j]-data1.chr$mapInfo[i])
#					if(!is.na(d) & d<dist.cur){
#						dist.cur<-d
#						#probe.cur<-data2.chr[j,] 
#						#probe.cur$dist<-dist.cur
#					}
#					isIn<-TRUE
#				}else if(isIn & !is.na(isCheck) & data1.chr$mapInfo[i]>data2.chr$end[j]){
##					pos.new<-pos-bk
##					pos<-ifelse(pos.new>1,pos.new,1)
#					#next
#					break
#				}
#			}
#			rst[i,]<-probe.cur
#		}
#		rst<-cbind(data1.chr,rst)
#		if(is.null(rst.all)){
#			rst.all<-rst
#		}else{
#			rst.all<-rbind(rst.all,rst)
#		}
#	}
#	return(rst.all)
#}
#findNN.5<-function(data1,data2){
#	name.1<-names(data1)
#	if(substr(name.1[1],1,1)!="c"){
#		name.1<-paste("chr",name.1,sep="")
#		names(data1)<-name.1
#	}
#	nn<-names(data2)
#	if(substr(nn[1],1,1)!="c"){
#		nn<-paste("chr",nn,sep="")
#		names(data2)<-nn
#	}
#	rst.all<-NULL
#	for(k in 1:length(name.1)){
#		chr<-name.1[k]
#		data1.chr<-data1[[chr]]
#		data2.chr<-data2[[chr]]
#		if(is.null(data2.chr))next;
#		data1.chr<-data1.chr[order(data1.chr$start,decreasing=FALSE),]
#		data2.chr<-data2.chr[order(data2.chr$start,decreasing=FALSE),]
#		len1<-1:nrow(data1.chr)
#		rst<-data.frame(data2.chr[len1,],dist=NA,isWithin=NA)
#		for(i in 1:nrow(data1.chr)){
#			dist.cur<-999999999;
#			probe.cur<-NULL
#			ml_id<-NULL
#			isWithinSeq<-FALSE
#			for(j in 1:nrow(data2.chr)){
#				if(data1.chr$mapInfo[i]>data2.chr$start[j] & data1.chr$mapInfo[i]<data2.chr$end[j]){
#					isWithinSeq<-TRUE
#					probe.cur<-data2.chr[j,]
#					probe.cur$isWithin<-isWithinSeq
#					probe.cur$dist<-dist.cur
#					d<-abs(data2.chr$mapInfo[j]-data1.chr$mapInfo[i])
#					if(!is.na(d) & d<dist.cur){
#						dist.cur<-d
#						probe.cur<-data2.chr[j,] 
#						probe.cur$dist<-dist.cur
#						
#					}
#				}else if(data1.chr$mapInfo[i]>data2.chr$end[j]){
#					next
#				}
#			}
#			rst[i,]<-probe.cur
#		}
#		rst<-cbind(data1.chr,rst)
#		if(is.null(rst.all)){
#			rst.all<-rst
#		}else{
#			rst.all<-rbind(rst.all,rst)
#		}
#		
#		rst<-cbind(data1.chr,rst)
#		if(is.null(rst.all)){
#			rst.all<-rst
#		}else{
#			rst.all<-rbind(rst.all,rst)
#		}
#	}
#	return(rst.all)
#}
findNN.4<-function(data1,data2,bk=5){
	# for oma only
	name.1<-names(data1)
	if(substr(name.1[1],1,1)!="c"){
		name.1<-paste("chr",name.1,sep="")
		names(data1)<-name.1
	}
	nn<-names(data2)
	if(substr(nn[1],1,1)!="c"){
		nn<-paste("chr",nn,sep="")
		names(data2)<-nn
	}
	rst.all<-NULL
	for(k in 1:length(name.1)){
		chr<-name.1[k]
		data1.chr<-data1[[chr]]
		data2.chr<-data2[[chr]]
		if(is.null(data2.chr))next;
		data1.chr<-data1.chr[order(data1.chr$start,decreasing=FALSE),]
		data2.chr<-data2.chr[order(data2.chr$start,decreasing=FALSE),]
		len1<-1:nrow(data1.chr)
		rst<-data.frame(data2.chr[len1,],dist=NA,isWitin=NA)
		pos<-1
		for(i in 1:nrow(data1.chr)){
			dist.cur<-999999999;
			isWithinSourceSeq<-FALSE
			probe.cur<-NULL
			ml_id<-NULL
			for(j in pos:nrow(data2.chr)){
				pos<-pos+1
				d<-abs(data2.chr$mapInfo[j]-data1.chr$mapInfo[i])
				if(!is.na(d) & d<dist.cur){
					dist.cur<-d
					probe.cur<-data2.chr[j,] 
					probe.cur$dist<-dist.cur
					if(data1.chr$mapInfo[i]>data2.chr$start[j] & data1.chr$mapInfo[i]<data2.chr$end[j]){
						isWithinSourceSeq<-TRUE
					}
					probe.cur$isWitin<-isWithinSourceSeq
				}else if(!is.na(d)){
					pos.new<-pos-bk
					pos<-ifelse(pos.new>1,pos.new,1)
					next
				}
			}
			rst[i,]<-probe.cur
		}
		rst<-cbind(data1.chr,rst)
		if(is.null(rst.all)){
			rst.all<-rst
		}else{
			rst.all<-rbind(rst.all,rst)
		}
	}
	return(rst.all)
}
Rpg_test<-function(){
	library(mAnnot)
	oma02<-getMapInfo("OMA02")
	dat1<-split(oma02,oma02$Chr)
	Rpg(dat1,dat1,logFn="c:\\temp\\log.txt")
}
Rpg<-function(data1,dat2,logFn=NULL,logPath=NULL,parallel=T,max.node=8,max.time=20,R=NULL,func="findNN.3a"){
	if(parallel==T){
		proc<-c();p.n<-1
		if(is.null(R))R<-"/auto/uec-00/shared/production/software/R/bin/Rscript"
		if(is.null(logPath))logPath<-filedir(logFn)
		pid<-as.integer(unclass(Sys.time()))
		datFn2<-paste("dat2.",pid,".rda",sep="")
		if(!file.exists(logPath))dir.create(logPath);
		setwd(logPath);save(dat2,file=datFn2)
		for(i in 1:length(data1)){
			Sys.sleep(2);pid<-as.integer(unclass(Sys.time()))
			datFn1<-paste("dat1.",pid,".rda",sep="")
			dat1<-list(data1[[i]]);names(dat1)<-names(data1)[i]
			save(dat1,file=datFn1)
			write(paste("library(mAnnot);setwd(\"",logPath,"\");load(file=\"",datFn1,"\");load(file=\"",datFn2,"\");",func,"(dat1,dat2,\"",logFn,"\",",pid,")",sep=""),file=paste(pid,".R",sep=""))
			write(paste("#PBS -N annot -q laird -l walltime=",max.time,":00:00 -l nodes=1:ppn=8\n",R," ",logPath,"/",pid,".R",sep=""),file=paste(pid,".sh",sep=""))
			proc<-c(proc,pid)
		}
		if(!file.exists(logFn))close(file(logFn,"w"))
		logFn2<-paste(logFn,".out",sep="")
		if(!file.exists(logFn2))close(file(logFn2,"w"))
		while(p.n <= length(proc)){
			if(length(readLines(logFn))<=max.node){
				pid<-proc[p.n]
				write(pid,file=logFn,append=T)
				system(paste("qsub",file.path(logPath,paste(pid,".sh",sep=""))),wait=F)
				p.n<-p.n+1
			}else{
				Sys.sleep(600)
			}
		}
	}else{
		do.call(func,dat1,dat2)
	}
	return(proc)
}
Rpg.1<-function(data1,dat2,logFn=NULL,logPath=NULL,parallel=T,max.node=8,R=NULL,func="findNN.3a"){
	if(parallel==T){
		proc<-c();p.n<-1
		if(is.null(R))R<-"/auto/uec-00/shared/production/software/R/bin/Rscript"
		if(is.null(logPath))logPath<-filedir(logFn)
		pid<-as.integer(unclass(Sys.time()))
		datFn2<-paste("dat2.",pid,".rda",sep="")
		if(!file.exists(logPath))dir.create(logPath);
		setwd(logPath);save(dat2,file=datFn2)
		for(i in 1:length(data1)){
			Sys.sleep(2);pid<-as.integer(unclass(Sys.time()))
			datFn1<-paste("dat1.",pid,".rda",sep="")
			dat1<-list(data1[[i]]);names(dat1)<-names(data1)[i]
			save(dat1,file=datFn1)
			write(paste("library(mAnnot);setwd(\"",logPath,"\");load(file=\"",datFn1,"\");load(file=\"",datFn2,"\");",func,"(dat1,dat2,\"",logFn,"\",",pid,")",sep=""),file=paste(pid,".R",sep=""))
			write(paste("#PBS -N annot -q laird -l walltime=20:00:00 -l nodes=1:ppn=1\n",R," ",logPath,"/",pid,".R",sep=""),file=paste(pid,".sh",sep=""))
			proc<-c(proc,pid)
		}
		if(!file.exists(logFn))close(file(logFn,"w"))
		logFn2<-paste(logFn,".out",sep="")
		if(!file.exists(logFn2))close(file(logFn2,"w"))
		while(p.n <= length(proc)){
			if(length(readLines(logFn))<=max.node){
				pid<-proc[p.n]
				write(pid,file=logFn,append=T)
				system(paste("qsub",file.path(logPath,paste(pid,".sh",sep=""))),wait=F)
				p.n<-p.n+1
			}else{
				Sys.sleep(600)
			}
		}
	}else{
		do.call(func,dat1,dat2)
	}
	return(proc)
}
#Rpg<-function(data1,dat2,logFn=NULL,logPath=NULL,parallel=T,max.node=8,R=NULL,func="findNN.3a"){
#	if(parallel==T){
#		proc<-c();p.n<-1
#		if(is.null(R))R<-"/auto/uec-00/shared/production/software/R/bin/Rscript"
#		if(is.null(logPath))logPath<-filedir(logFn)
#		pid<-as.integer(unclass(Sys.time()))
#		datFn2<-paste("dat2.",pid,".rda",sep="")
#		setwd(logPath);save(dat2,file=datFn2)
#		for(i in 1:length(data1)){
#				Sys.sleep(2);pid<-as.integer(unclass(Sys.time()))
#				datFn1<-paste("dat1.",pid,".rda",sep="")
#				dat1<-list(data1[[i]]);names(dat1)<-names(data1)[i]
#				save(dat1,file=datFn1)
#				write(paste("library(mAnnot);setwd(\"",logPath,"\");load(file=\"",datFn1,"\");load(file=\"",datFn2,"\");",func,"(dat1,dat2,\"",logFn,"\",",pid,")",sep=""),file=paste(pid,".R",sep=""))
#				write(paste("qsub -N annot -q laird -l walltime=10:00:00 -l nodes=1:ppn=1 ",R," ",logPath,"/",pid,".R",sep=""),file=paste(pid,".sh",sep=""))
#				proc<-c(proc,pid)
#		}
#		if(!file.exists(logFn))close(file(logFn,"w"))
#		logFn2<-paste(logFn,".out",sep="")
#		if(!file.exists(logFn2))close(file(logFn2,"w"))
#		while(p.n <= length(proc)){
#			if(length(readLines(logFn))<=max.node){
#				pid<-proc[p.n]
#				write(pid,file=logFn,append=T)
#				system(file.path(logPath,paste(pid,".sh",sep="")),wait=F)
#				p.n<-p.n+1
#			}else{
#				Sys.sleep(600)
#			}
#		}
#	}else{
#		do.call(func,dat1,dat2)
#	}
#	return(proc)
#}

findNN.3a<-function(dat1,dat2,logFn=NULL,pid=NULL,logFn2=NULL){
	rst<-findNN.3(dat1,dat2)
	setwd(filedir(logFn))
	if(!is.null(pid)){
		dat<-readLines(logFn)
		ind<-grep(pid,dat)
		if(length(ind>0))write(dat[-ind],file=logFn)
		if(is.null(logFn2))logFn2<-paste(logFn,".out",sep="")
		write(pid,file=logFn2,append=T)
	}
	save(rst,file=paste(pid,".out.rdata",sep=""))
}
Rpg2_test<-function(){
	logFn<-"/auto/uec-02/shared/production/methylation/database/meth450k/recombRate/log"
	proc<-readLines(paste(logFn,".out",sep=""))
	annot<-Rpg2(proc,logFn)
}
Rpg2<-function(proc,logFn,logPath=NULL,toSave=T){
	rst<-NULL
	logFn2<-paste(logFn,".out",sep="")
	pj<-readLines(logFn2)
	if(is.null(logPath))logPath<-filedir(logFn)
	setwd(logPath)
	while(all(is.element(proc,pj))!=T){
		Sys.sleep(200)
		pj<-readLines(logFn)
	}
	for(pid in proc){
		dat<-get(print(load(file=paste(pid,".out.rdata",sep=""))))
		if(is.null(rst))rst<-dat
		else rst<-rbind(rst,dat)
	}
	if(toSave==T)save(rst,file=file.path(logPath,"annot.all.rdata"))
	return(rst)
}
findNN.3<-function(data1,data2,bk=5){
	name.1<-names(data1)
	if(substr(name.1[1],1,1)!="c"){
		name.1<-paste("chr",name.1,sep="")
		names(data1)<-name.1
	}
	nn<-names(data2)
	if(substr(nn[1],1,1)!="c"){
		nn<-paste("chr",nn,sep="")
		names(data2)<-nn
	}
	rst.all<-NULL
	for(k in 1:length(name.1)){
		chr<-name.1[k]
		cat("work on ", chr,"\n")
		data1.chr<-data1[[chr]]
		data2.chr<-data2[[chr]]
		if(is.null(data2.chr))next;
		data1.chr<-data1.chr[order(data1.chr$start,decreasing=FALSE),]
		data2.chr<-data2.chr[order(data2.chr$start,decreasing=FALSE),]
		len1<-1:nrow(data1.chr)
		rst<-data.frame(data2.chr[len1,],dist=NA)
		pos<-1
		for(i in 1:nrow(data1.chr)){
			dist.cur<-999999999;
			probe.cur<-NULL
			ml_id<-NULL
			for(j in pos:nrow(data2.chr)){
				pos<-pos+1
				d<-abs(data2.chr$mapInfo[j]-data1.chr$mapInfo[i])
				if(!is.na(d) & d<dist.cur){
					dist.cur<-d
					probe.cur<-data2.chr[j,] 
					probe.cur$dist<-dist.cur
				}else if(!is.na(d)){
					pos.new<-pos-bk
					pos<-ifelse(pos.new>1,pos.new,1)
					next
				}
			}
			rst[i,]<-probe.cur
		}
		rst<-cbind(data1.chr,rst)
		if(is.null(rst.all)){
			rst.all<-rst
		}else{
			rst.all<-rbind(rst.all,rst)
		}
	}
	return(rst.all)
}

implode<-function(datVect){
	rst=c();
	for(i in 1:length(datVect)){
		rst = paste(rst,datVect[i],sep=",")		
	}
	rst <- substr(rst,2,nchar(rst))
	rst <- paste("(",rst,")",sep="")
	return(rst)
}
#
##stderr <- function(x) sqrt(var(x)/length(x))
#heatmap_hc<-function(data,dendr="both",colv=NA,rowv=NA,labRow=NA,labCol=NA,
#		hc_method="ward",dist_method="euclidean",main=NA){
#	require(matlab)
#	require(gplots)
#	X11()
#	heatmap.2(as.matrix(data),key=TRUE,dendrogram=dendr,
#			trace="none",col=jet.colors(75),Colv=colv,Rowv=rowv,
#			scale="n", hclustfun=function(d)hclust(d,method=hc_method),
#			density.info="none",xlab=NULL,ylab=NULL,labRow=labRow,labCol=labCol,main=main)
#}
#heatmap_hc2<-function(data,dendr="both",colv=NA,rowv=NA,labRow=NA,labCol=NA,
#		hc_method="ward",dist_method="euclidean",main=NA){
#	require(matlab)
#	require(gplots)
#	X11()
#	data<-as.matrix(data)
#	heatmap.2(data,key=TRUE,dendrogram=dendr,
#			trace="none",col=jet.colors(75),Colv=colv,Rowv=rowv,scale="n", 
#			hclustfun=function(d)hclust(d=dist(data,method=dist_method),method=hc_method),
#			density.info="none",xlab=NULL,ylab=NULL,labRow=labRow,labCol=labCol,main=main)
#
#}
#heatmap_hc_test<-function(){
#	data<-matrix(rnorm(100),10,10)
#	heatmap_hc(data,colv=TRUE,rowv=TRUE,dendr="col",labRow=NA)
#}
######################
# paste duplicate rows into one row
#####################
pasteDups<-function(data,colShap){
	dim(data)
	unique(data[,colShap])
	fac<-data[colShap]
	fac <- factor(fac)
	data1 <- split(data,fac)
	data.new <- lapply(data1,paste,sep=";")
	unsplit(data.new,fac)
}
pasteDups.new<-function(data1,data2){
#	fac<-unique(data1)
#	for(i in 1:length(data1)){
#		if(is.element(data1[i],fac)){
#			
#		}
#	}
	dat<-table(data1,data2)
	# then concatecate the cols exception the first
	
}
test<-function(){
	data<-data.frame()
}
calMW<-function(x, v1,v2, alt = "two.sided", paired = FALSE){
	#browser()
	x1 = as.numeric(x[v1]);
	x2 = as.numeric(x[v2]);
	pv = wilcox.test(x1,x2,alternative=alt,paired=paired);
	fd = mean(x1,na.rm=T)/mean(x2,na.rm=T);
	fdd= mean(x1,na.rm=T)-mean(x2,na.rm=T)
	rst = cbind(pv=pv$p.value,fd=fd,mdif=fdd);
	return(rst);
}
calTTest<-function(x,v1,v2,alt="two.sided",paired=F){
	pv<-t.test(as.numeric(x[v1]),as.numeric(x[v2]),alternative=alt,paired=paired)
	fd<-mean(as.numeric(x[v1]))/mean(as.numeric(x[v2]))
	return(c(pv=pv$p.value,fd=fd))
}
FDR <-function(x){
	#ords = order(x, decreasing = F);
	#len = length(x);
	#rst = x/ords*len;
	#rst1 = ifelse(rst>1,1,rst);
	#return(rst1);
	p.adjust(x,method="fdr") 
}
#
#meth_expn_plot_s_noFDRExp <- function(pv,legend1,sig_cutoff,xlimv,ylimv){
#	sig_cutoff_line = -log10(sig_cutoff);
#	meth_pv = abs(pv[,1]);
#	meth_fd = pv[,2];
#	expn_pv = abs(pv[,3]);
#	expn_fd = pv[,4];
#	pcolor  = pv[,5]
#	# note: here fd is ctr/case
#	hypo_down = meth_fd>=1 & expn_fd>=1;
#	hypo_down = hypo_down & !is.na(hypo_down)
#	logpv1 = cbind(meth=log10(meth_pv[hypo_down]),log10(expn=expn_pv[hypo_down]),pcolor[hypo_down])
#	hypo_up = meth_fd>1 & expn_fd<1;
#	hypo_up = hypo_up & !is.na(hypo_up)
#	logpv2 = cbind(meth=log10(meth_pv[hypo_up]),-log10(expn=expn_pv[hypo_up]),pcolor[hypo_up])
#	hyper_down = meth_fd<1 & expn_fd>1;
#	hyper_down = hyper_down & !is.na(hyper_down)
#	logpv3 = cbind(-log10(meth=meth_pv[hyper_down]),expn=log10(expn_pv[hyper_down]),pcolor[hyper_down])
#	hyper_up = meth_fd<1 & expn_fd<1;
#	hyper_up = hyper_up & !is.na(hyper_up)
#	logpv4 = cbind(meth=-log10(meth_pv[hyper_up]),-log10(expn=expn_pv[hyper_up]),pcolor[hyper_up])
#	logpv = rbind(logpv1,logpv2,logpv3,logpv4);
#	
#	
#	
#	#plot
#	opar2 <-par(mar=c(5,5,5,5),las=0);
#	plot(logpv[,1],logpv[,2],type="n",axes = FALSE, xlab = "", ylab = "", xlim=c(-xlimv,xlimv),ylim=c(-ylimv,ylimv));
#	#points(logpv[,1],logpv[,2],col=c("darkgreen","darkred")[logpv[,3]],pch=c(1,5)[pcolor],cex=0.5); 
#	points(logpv[,1],logpv[,2],col=c("darkgreen","darkred")[logpv[,3]],pch=c(1,5)[logpv[,3]],cex=0.5);
#	box();
#	axis(1,pos=0, label=T)
#	mtext("GENE EXPRESSION",cex=1.0,, side = 2, line = 4)
#	mtext("IF UP EXPRESSION, -1*Log10 (Wilcoxon Pvalue),\n ELSE Log10 (Wilcoxon Pvalue)", cex=0.8, side = 2, line = 2)
#	opar2 <- par(las = 3)
#	xpos = xlimv -1;
#	ypos = ylimv -1;
#	#text(x=-xpos,y=ypos, "Up Expression",col="red",srt=90);
#	#text(x=-xpos,y=-ypos, "Down Expression",col="green",srt =90);
#	opar2 <- par(las = 1)
#	axis(2,pos=0, label=T)
#	mtext("DNA METHYLATION",cex=0.8,side = 1, line = 1)
#	mtext("IF HYPERMETHYLATED, -1*Log10 (FDR-corrected Wilcoxon Pvalue),\n ELSE Log10 (FDR-corrected Wilcoxon Pvalue)", cex=0.8,side = 1, line = 3)
#	abline(0,0);abline(sig_cutoff_line,0,col="red");abline(-sig_cutoff_line,0,col="red");
#	abline(v=0);abline(v=sig_cutoff_line,col="red");abline(v=-sig_cutoff_line,col="red");
#	rect(-sig_cutoff_line,-sig_cutoff_line,sig_cutoff_line,sig_cutoff_line,col="#0000ff32",border="transparent");
#	#abline(0,0);abline(1.3,0,col="red");abline(-1.3,0,col="red");
#	#abline(v=0);abline(v=1.3,col="red");abline(v=-1.3,col="red");
#	#rect(-1.3,-1.3,1.3,1.3,col="#0000ff32",border="transparent");
#	xpos = xlimv -4;
#	ypos = ylimv -0.2;
#	#text(x=xpos,y=-ypos, "HYPERMETHYLATION",col="red");
#	#text(x=-xpos,y=-ypos, "HYPOMETHYLATION",col="green");
#	#xpos = xlimv -7
#	#if(legend1==0){
#	#  legend(x=xpos,y=ypos, c("NN vs. Superficial", "NN vs. Invasive"),col=c("darkseagreen", "darkred"),pch=c(1, 5),bty="n",cex=0.9);
#	#}else if(legend1==1){
#	#  legend(x=xpos,y=ypos, c("NN vs. Superficial"),col=c("darkseagreen"),pch=c(1, 5),bty="n",cex=0.9);
#	#}else if (legend1==2){
#	#  legend(x=xpos,y=ypos, c("NN vs. Invasive"),col=c("darkseagreen"),pch=c(1, 5),bty="n",cex=0.9);
#	#}
#	
#	#sig
#	#sig_criteria = meth_pv<0.01 & expn_pv<0.01
#	sig_criteria = meth_pv<sig_cutoff & expn_pv<sig_cutoff
#	hypo_down_sig = hypo_down &  sig_criteria
#	hypo_up_sig = hypo_up & sig_criteria;
#	hyper_down_sig = hyper_down & sig_criteria;
#	hyper_up_sig = hyper_up & sig_criteria;
#	hdall_sig = hypo_down_sig*1+ hypo_up_sig*2 + hyper_down_sig*3 + hyper_up_sig*4;
#	hdall_sig_char = c("not_sig","hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")[hdall_sig+1];
#	#hdall_sig_char = hdall_sig[c("hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")];
#	rst = cbind( hypo_down_sig, hypo_up_sig,  hyper_down_sig, hyper_up_sig, hdall_sig_char);
#	#rlen=dim(rst)[1]/2;
#	#t=cbind(rst[1:rlen,],rst[(rlen+1):(rlen*2),])
#	return(rst);
#}
#meth_expn_plots_noFDRExp_sigColored <- function(pv,legend1,sig_cutoff,xlimv,ylimv){
#	sig_cutoff_line = -log10(sig_cutoff);
#	meth_pv = abs(pv[,1]);
#	meth_fd = pv[,2];
#	expn_pv = abs(pv[,3]);
#	expn_fd = pv[,4];
#	pcolor  = pv[,5]
#	# note: here fd is ctr/case
#	hypo_down = meth_fd>=1 & expn_fd>=1;
#	hypo_down = hypo_down & !is.na(hypo_down)
#	logpv1 = cbind(meth=log10(meth_pv[hypo_down]),
#			log10(expn=expn_pv[hypo_down]),
#			pcolor[hypo_down])
#	hypo_up = meth_fd>1 & expn_fd<1;
#	hypo_up = hypo_up & !is.na(hypo_up)
#	logpv2 = cbind(meth=log10(meth_pv[hypo_up]),
#			-log10(expn=expn_pv[hypo_up]),
#			pcolor[hypo_up])
#	hyper_down = meth_fd<1 & expn_fd>1;
#	hyper_down = hyper_down & !is.na(hyper_down)
#	logpv3 = cbind(-log10(meth=meth_pv[hyper_down]),
#			expn=log10(expn_pv[hyper_down]),
#			pcolor[hyper_down])
#	hyper_up = meth_fd<1 & expn_fd<1;
#	hyper_up = hyper_up & !is.na(hyper_up)
#	logpv4 = cbind(meth=-log10(meth_pv[hyper_up]),
#			-log10(expn=expn_pv[hyper_up]),
#			pcolor[hyper_up])
#	logpv = rbind(logpv1,logpv2,logpv3,logpv4);
#	
#	#sig
#	sig_criteria = abs(logpv[,1])>abs(log10(sig_cutoff)) & abs(logpv[,2])>abs(log10(sig_cutoff));
#	
#	#plot
#	opar2 <-par(mar=c(5,5,5,5),las=0);
#	plot(logpv[,1],logpv[,2],type="n",axes = FALSE, xlab = "", ylab = "", xlim=c(-xlimv,xlimv),ylim=c(-ylimv,ylimv));
#	colored_sig=logpv[,3]+sig_criteria;
#	#points(logpv[,1],logpv[,2],col=c("darkgreen","darkred")[logpv[,3]],pch=c(1,5)[logpv[,3]],cex=0.5);
#	points(logpv[,1],logpv[,2],col=c("darkgreen","darkred")[colored_sig],pch=c(1,5)[logpv[,3]],cex=0.5);
#	box();
#	axis(1,pos=0, label=T)
#	mtext("GENE EXPRESSION",cex=1.0,, side = 2, line = 4)
#	mtext("IF UP EXPRESSION, -1*Log10 (Wilcoxon Pvalue),\n ELSE Log10 (Wilcoxon Pvalue)", cex=0.8, side = 2, line = 2)
#	opar2 <- par(las = 3)
#	xpos = xlimv -1;
#	ypos = ylimv -1;
#	opar2 <- par(las = 1)
#	axis(2,pos=0, label=T)
#	mtext("DNA METHYLATION",cex=0.8,side = 1, line = 1)
#	mtext("IF HYPERMETHYLATED, -1*Log10 (FDR-corrected Wilcoxon Pvalue),\n ELSE Log10 (FDR-corrected Wilcoxon Pvalue)", cex=0.8,side = 1, line = 3)
#	abline(0,0);abline(sig_cutoff_line,0,col="red");abline(-sig_cutoff_line,0,col="red");
#	abline(v=0);abline(v=sig_cutoff_line,col="red");abline(v=-sig_cutoff_line,col="red");
#	rect(-sig_cutoff_line,-sig_cutoff_line,sig_cutoff_line,sig_cutoff_line,col="#0000ff32",border="transparent");
#	xpos = xlimv -4;
#	ypos = ylimv -0.2;
#	
#	#sig	
#	sig_criteria = meth_pv<sig_cutoff & expn_pv<sig_cutoff
#	hypo_down_sig = hypo_down &  sig_criteria
#	hypo_up_sig = hypo_up & sig_criteria;
#	hyper_down_sig = hyper_down & sig_criteria;
#	hyper_up_sig = hyper_up & sig_criteria;
#	hdall_sig = hypo_down_sig*1+ hypo_up_sig*2 + hyper_down_sig*3 + hyper_up_sig*4;
#	hdall_sig_char = c("not_sig","hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")[hdall_sig+1];
#	#hdall_sig_char = hdall_sig[c("hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")];
#	rst = cbind( hypo_down_sig, hypo_up_sig,  hyper_down_sig, hyper_up_sig, hdall_sig_char);
#	return(rst);
#}
##pv1,legend1,sig_cutoff,10,6
##pv = pv1
##xlimv = 10
##ylimv = 6
#meth_expn_plots_noFDRExp_sigColored_region <- function(pv,legend1,sig_cutoff,xlimv,ylimv){
#	#browser()
#	sig_cutoff_line = -log10(sig_cutoff);
#	meth_pv = abs(pv[,1]);
#	meth_fd = pv[,2];
#	expn_pv = abs(pv[,3]);
#	expn_fd = pv[,4];
#	pcolor  = pv[,5]
#	# note: here fd is ctr/case
#	inRegion = c();
#	hypo_down = meth_fd>=1 & expn_fd>=1;
#	hypo_down = hypo_down & !is.na(hypo_down)
#	logpv1 = cbind(meth=log10(meth_pv[hypo_down]),
#			log10(expn=expn_pv[hypo_down]),
#			pcolor[hypo_down])
#	t<-rep(0,dim(logpv1)[1])
#	inRegion = c(inRegion,t)
#	hypo_up = meth_fd>1 & expn_fd<1;
#	hypo_up = hypo_up & !is.na(hypo_up)
#	logpv2 = cbind(meth=log10(meth_pv[hypo_up]),
#			-log10(expn=expn_pv[hypo_up]),
#			pcolor[hypo_up])
#	t<-rep(1,dim(logpv2)[1])
#	inRegion = c(inRegion,t)
#	hyper_down = meth_fd<1 & expn_fd>1;
#	hyper_down = hyper_down & !is.na(hyper_down)
#	logpv3 = cbind(-log10(meth=meth_pv[hyper_down]),
#			expn=log10(expn_pv[hyper_down]),
#			pcolor[hyper_down])
#	t<-rep(2,dim(logpv3)[1])
#	inRegion = c(inRegion,t)
#	hyper_up = meth_fd<1 & expn_fd<1;
#	hyper_up = hyper_up & !is.na(hyper_up)
#	logpv4 = cbind(meth=-log10(meth_pv[hyper_up]),
#			-log10(expn=expn_pv[hyper_up]),
#			pcolor[hyper_up])
#	t<-rep(0,dim(logpv4)[1])
#	inRegion = c(inRegion,t)
#	logpv = rbind(logpv1,logpv2,logpv3,logpv4);
#	
#	#sig
#	sig_criteria0 = abs(logpv[,1])>abs(log10(sig_cutoff)) & 
#		abs(logpv[,2])>abs(log10(sig_cutoff))
#	sig_criteria1 = (logpv[,1])>(log10(sig_cutoff)) & 
#			(logpv[,2])>(log10(sig_cutoff)) ;
#	sig_criteria2 = (logpv[,1])>(log10(sig_cutoff)) & 
#			(logpv[,2])<(log10(sig_cutoff)); #>
#	sig_criteria2a = sig_criteria2*2
#	#plot
#	opar2 <-par(mar=c(5,5,5,5),las=0);
#	plot(logpv[,1],logpv[,2],type="n",axes = FALSE, xlab = "", ylab = "", xlim=c(-xlimv,xlimv),ylim=c(-ylimv,ylimv));
#	colored_siga=logpv[,3]+inRegion * sig_criteria0;
#	#colored_siga=logpv[,3]+sig_criteria1 + sig_criteria2a;
#	#colored_siga=logpv[,3]+sig_criteria1## + sig_criteria2a;
#	#points(logpv[,1],logpv[,2],col=c("darkgreen","darkred")[logpv[,3]],pch=c(1,5)[logpv[,3]],cex=0.5);
#	#points(logpv[,1],logpv[,2],col=c("darkgreen","darkred","blue")[colored_siga],pch=c(1,19,19)[colored_siga],cex=0.5);
#	points(logpv[,1],logpv[,2],col=c("grey","darkgreen","darkred")[colored_siga],pch=c(1,19,19)[colored_siga],cex=0.5);
#
#	box();
#	axis(1,pos=0, label=T)
#	mtext("GENE EXPRESSION",cex=1.0,, side = 2, line = 4)
#	mtext("IF UP EXPRESSION, -1*Log10 (FDR-corrected Wilcoxon Pvalue),\n ELSE Log10 (Wilcoxon Pvalue)", cex=0.8, side = 2, line = 2)
#	opar2 <- par(las = 3)
#	xpos = xlimv -1;
#	ypos = ylimv -1;
#	opar2 <- par(las = 1)
#	axis(2,pos=0, label=T)
#	mtext("DNA METHYLATION",cex=0.8,side = 1, line = 1)
#	mtext("IF HYPERMETHYLATED, -1*Log10 (FDR-corrected Wilcoxon Pvalue),\n ELSE Log10 (FDR-corrected Wilcoxon Pvalue)", cex=0.8,side = 1, line = 3)
#	abline(0,0);abline(sig_cutoff_line,0,col="red");abline(-sig_cutoff_line,0,col="red");
#	abline(v=0);abline(v=sig_cutoff_line,col="red");abline(v=-sig_cutoff_line,col="red");
#	rect(-sig_cutoff_line,-sig_cutoff_line,sig_cutoff_line,sig_cutoff_line,col="#0000ff32",border="transparent");
#	xpos = xlimv -4;
#	ypos = ylimv -0.2;
#	
#	#sig	
#	sig_criteria = meth_pv<sig_cutoff & expn_pv<sig_cutoff
#	hypo_down_sig = hypo_down &  sig_criteria
#	hypo_up_sig = hypo_up & sig_criteria;
#	hyper_down_sig = hyper_down & sig_criteria;
#	hyper_up_sig = hyper_up & sig_criteria;
#	hdall_sig = hypo_down_sig*1+ hypo_up_sig*2 + hyper_down_sig*3 + hyper_up_sig*4;
#	hdall_sig_char = c("not_sig","hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")[hdall_sig+1];
#	#hdall_sig_char = hdall_sig[c("hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")];
#	rst = cbind( hypo_down_sig, hypo_up_sig,  hyper_down_sig, hyper_up_sig, hdall_sig_char);
#	return(rst);
#}
#meth_expn_plots_noFDRExp_sigColored_region2 <- function(pv,legend1,sig_cutoff,xlimv,ylimv){
#	#browser()
#	sig_cutoff_line = -log10(sig_cutoff);
#	meth_pv = abs(pv[,1]);
#	meth_fd = pv[,2];
#	expn_pv = abs(pv[,3]);
#	expn_fd = pv[,4];
#	pcolor  = pv[,5]
#	# note: here fd is ctr/case
#	inRegion = c();
#	hypo_down = meth_fd>=1 & expn_fd>=1;
#	hypo_down = hypo_down & !is.na(hypo_down)
#	logpv1 = cbind(meth=log10(meth_pv[hypo_down]),
#			log10(expn=expn_pv[hypo_down]),
#			pcolor[hypo_down])
#	t<-rep(0,dim(logpv1)[1])
#	inRegion = c(inRegion,t)
#	hypo_up = meth_fd>1 & expn_fd<1;
#	hypo_up = hypo_up & !is.na(hypo_up)
#	logpv2 = cbind(meth=log10(meth_pv[hypo_up]),
#			-log10(expn=expn_pv[hypo_up]),
#			pcolor[hypo_up])
#	t<-rep(1,dim(logpv2)[1])
#	inRegion = c(inRegion,t)
#	hyper_down = meth_fd<1 & expn_fd>1;
#	hyper_down = hyper_down & !is.na(hyper_down)
#	logpv3 = cbind(-log10(meth=meth_pv[hyper_down]),
#			expn=log10(expn_pv[hyper_down]),
#			pcolor[hyper_down])
#	t<-rep(2,dim(logpv3)[1])
#	inRegion = c(inRegion,t)
#	hyper_up = meth_fd<1 & expn_fd<1;
#	hyper_up = hyper_up & !is.na(hyper_up)
#	logpv4 = cbind(meth=-log10(meth_pv[hyper_up]),
#			-log10(expn=expn_pv[hyper_up]),
#			pcolor[hyper_up])
#	t<-rep(0,dim(logpv4)[1])
#	inRegion = c(inRegion,t)
#	logpv = rbind(logpv1,logpv2,logpv3,logpv4);
#	
#	#sig
#	sig_criteria0 = abs(logpv[,1])>abs(log10(sig_cutoff)) & 
#			abs(logpv[,2])>abs(log10(sig_cutoff))
#	sig_criteria1 = (logpv[,1])>(log10(sig_cutoff)) & 
#			(logpv[,2])>(log10(sig_cutoff)) ;
#	sig_criteria2 = (logpv[,1])>(log10(sig_cutoff)) & 
#			(logpv[,2])<(log10(sig_cutoff)); #>
#	sig_criteria2a = sig_criteria2*2
#	#plot
#	opar2 <-par(mar=c(5,5,5,5),las=0);
#	plot(logpv[,1],logpv[,2],type="n",axes = FALSE, xlab = "", ylab = "", xlim=c(-xlimv,xlimv),ylim=c(-ylimv,ylimv));
#	colored_siga=logpv[,3]+inRegion * sig_criteria0;
#	#colored_siga=logpv[,3]+sig_criteria1 + sig_criteria2a;
#	#colored_siga=logpv[,3]+sig_criteria1## + sig_criteria2a;
#	#points(logpv[,1],logpv[,2],col=c("darkgreen","darkred")[logpv[,3]],pch=c(1,5)[logpv[,3]],cex=0.5);
#	points(logpv[,1],logpv[,2],col=c("darkgreen","darkred","blue")[colored_siga],pch=c(1,19,19)[colored_siga],cex=0.5);
#	box();
#	axis(1,pos=0, label=T)
#	mtext("GENE EXPRESSION",cex=1.0,, side = 2, line = 4)
#	mtext("IF UP EXPRESSION, -1*Log10 (Wilcoxon Pvalue),\n ELSE Log10 (Wilcoxon Pvalue)", cex=0.8, side = 2, line = 2)
#	opar2 <- par(las = 3)
#	xpos = xlimv -1;
#	ypos = ylimv -1;
#	opar2 <- par(las = 1)
#	axis(2,pos=0, label=T)
#	mtext("DNA METHYLATION",cex=0.8,side = 1, line = 1)
#	mtext("IF HYPERMETHYLATED, -1*Log10 (FDR-corrected Wilcoxon Pvalue),\n ELSE Log10 (FDR-corrected Wilcoxon Pvalue)", cex=0.8,side = 1, line = 3)
#	abline(0,0);abline(sig_cutoff_line,0,col="red");abline(-sig_cutoff_line,0,col="red");
#	abline(v=0);abline(v=sig_cutoff_line,col="red");abline(v=-sig_cutoff_line,col="red");
#	rect(-sig_cutoff_line,-sig_cutoff_line,sig_cutoff_line,sig_cutoff_line,col="#0000ff32",border="transparent");
#	xpos = xlimv -4;
#	ypos = ylimv -0.2;
#	
#	#sig	
#	sig_criteria = meth_pv<sig_cutoff & expn_pv<sig_cutoff
#	hypo_down_sig = hypo_down &  sig_criteria
#	hypo_up_sig = hypo_up & sig_criteria;
#	hyper_down_sig = hyper_down & sig_criteria;
#	hyper_up_sig = hyper_up & sig_criteria;
#	hdall_sig = hypo_down_sig*1+ hypo_up_sig*2 + hyper_down_sig*3 + hyper_up_sig*4;
#	hdall_sig_char = c("not_sig","hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")[hdall_sig+1];
#	#hdall_sig_char = hdall_sig[c("hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")];
#	rst = cbind( hypo_down_sig, hypo_up_sig,  hyper_down_sig, hyper_up_sig, hdall_sig_char);
#	return(rst);
#}
#meth_expn_plot <- function(pv,legend1,sig_cutoff,xlimv,ylimv){
#	sig_cutoff_line = -log10(sig_cutoff);
#	meth_pv = abs(pv[,1]);
#	meth_fd = pv[,2];
#	expn_pv = abs(pv[,3]);
#	expn_fd = pv[,4];
#	pcolor  = pv[,5]
#	# note: here fd is ctr/case
#	hypo_down = meth_fd>=1 & expn_fd>=1;
#	hypo_down = hypo_down & !is.na(hypo_down)
#	logpv1 = cbind(meth=log10(meth_pv[hypo_down]),log10(expn=expn_pv[hypo_down]),pcolor[hypo_down])
#	hypo_up = meth_fd>1 & expn_fd<1;
#	hypo_up = hypo_up & !is.na(hypo_up)
#	logpv2 = cbind(meth=log10(meth_pv[hypo_up]),-log10(expn=expn_pv[hypo_up]),pcolor[hypo_up])
#	hyper_down = meth_fd<1 & expn_fd>1;
#	hyper_down = hyper_down & !is.na(hyper_down)
#	logpv3 = cbind(-log10(meth=meth_pv[hyper_down]),expn=log10(expn_pv[hyper_down]),pcolor[hyper_down])
#	hyper_up = meth_fd<1 & expn_fd<1;
#	hyper_up = hyper_up & !is.na(hyper_up)
#	logpv4 = cbind(meth=-log10(meth_pv[hyper_up]),-log10(expn=expn_pv[hyper_up]),pcolor[hyper_up])
#	logpv = rbind(logpv1,logpv2,logpv3,logpv4);
#	
#	
#	
#	#plot
#	opar2 <-par(mar=c(5,5,5,5),las=0);
#	plot(logpv[,1],logpv[,2],type="n",axes = FALSE, xlab = "", ylab = "", xlim=c(-xlimv,xlimv),ylim=c(-ylimv,ylimv));
#	#points(logpv[,1],logpv[,2],col=c("darkgreen","darkred")[logpv[,3]],pch=c(1,5)[pcolor],cex=0.5); 
#	points(logpv[,1],logpv[,2],col=c("darkgreen","darkred")[logpv[,3]],pch=c(1,5)[logpv[,3]],cex=0.5);
#	box();
#	axis(1,pos=0, label=T)
#	mtext("GENE EXPRESSION",cex=1.0,, side = 2, line = 4)
#	mtext("IF UP EXPRESSION, -1*Log10 (FDR-corrected Wilcoxon Pvalue),\n ELSE Log10 (FDR-corrected Wilcoxon Pvalue)", cex=0.8, side = 2, line = 2)
#	opar2 <- par(las = 3)
#	xpos = xlimv -1;
#	ypos = ylimv -1;
#	text(x=-xpos,y=ypos, "Up Expression",col="red",srt=90);
#	text(x=-xpos,y=-ypos, "Down Expression",col="green",srt =90);
#	opar2 <- par(las = 1)
#	axis(2,pos=0, label=T)
#	mtext("DNA METHYLATION",cex=0.8,side = 1, line = 1)
#	mtext("IF HYPERMETHYLATED, -1*Log10 (FDR-corrected Wilcoxon Pvalue),\n ELSE Log10 (FDR-corrected Wilcoxon Pvalue)", cex=0.8,side = 1, line = 3)
#	abline(0,0);abline(sig_cutoff_line,0,col="red");abline(-sig_cutoff_line,0,col="red");
#	abline(v=0);abline(v=sig_cutoff_line,col="red");abline(v=-sig_cutoff_line,col="red");
#	rect(-sig_cutoff_line,-sig_cutoff_line,sig_cutoff_line,sig_cutoff_line,col="#0000ff32",border="transparent");
#	#abline(0,0);abline(1.3,0,col="red");abline(-1.3,0,col="red");
#	#abline(v=0);abline(v=1.3,col="red");abline(v=-1.3,col="red");
#	#rect(-1.3,-1.3,1.3,1.3,col="#0000ff32",border="transparent");
#	xpos = xlimv -4;
#	ypos = ylimv -0.2;
#	text(x=xpos,y=-ypos, "HYPERMETHYLATION",col="red");
#	text(x=-xpos,y=-ypos, "HYPOMETHYLATION",col="green");
#	xpos = xlimv -7
#	if(legend1==0){
#		legend(x=xpos,y=ypos, c("NN vs. Superficial", "NN vs. Invasive"),col=c("darkseagreen", "darkred"),pch=c(1, 5),bty="n",cex=0.9);
#	}else if(legend1==1){
#		legend(x=xpos,y=ypos, c("NN vs. Superficial"),col=c("darkseagreen"),pch=c(1, 5),bty="n",cex=0.9);
#	}else if (legend1==2){
#		legend(x=xpos,y=ypos, c("NN vs. Invasive"),col=c("darkseagreen"),pch=c(1, 5),bty="n",cex=0.9);
#	}
#	
#	#sig
#	#sig_criteria = meth_pv<0.01 & expn_pv<0.01
#	sig_criteria = meth_pv<sig_cutoff & expn_pv<sig_cutoff
#	hypo_down_sig = hypo_down &  sig_criteria
#	hypo_up_sig = hypo_up & sig_criteria;
#	hyper_down_sig = hyper_down & sig_criteria;
#	hyper_up_sig = hyper_up & sig_criteria;
#	hdall_sig = hypo_down_sig*1+ hypo_up_sig*2 + hyper_down_sig*3 + hyper_up_sig*4;
#	hdall_sig_char = c("not_sig","hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")[hdall_sig+1];
#	#hdall_sig_char = hdall_sig[c("hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")];
#	rst = cbind( hypo_down_sig, hypo_up_sig,  hyper_down_sig, hyper_up_sig, hdall_sig_char);
#	rlen=dim(rst)[1]/2;
#	t=cbind(rst[1:rlen,],rst[(rlen+1):(rlen*2),])
#	return(t);
#}
#
#meth_exp_volcano_plot <- function(pv){
#	meth_pv = abs(pv[,1]);
#	meth_fd = pv[,2];
#	expn_pv = abs(pv[,3]);
#	expn_fd = pv[,4];
#	pcolor  = pv[,5]
#	# note: here fd is ctr/case
#	hypo_down = meth_fd>=1 & expn_fd>=1;
#	hypo_down = hypo_down & !is.na(hypo_down)
#	logpv1 = cbind(meth=log10(meth_pv[hypo_down]),log10(expn=expn_pv[hypo_down]),pcolor[hypo_down])
#	hypo_up = meth_fd>1 & expn_fd<1;
#	hypo_up = hypo_up & !is.na(hypo_up)
#	logpv2 = cbind(meth=log10(meth_pv[hypo_up]),-log10(expn=expn_pv[hypo_up]),pcolor[hypo_up])
#	hyper_down = meth_fd<1 & expn_fd>1;
#	hyper_down = hyper_down & !is.na(hyper_down)
#	logpv3 = cbind(-log10(meth=meth_pv[hyper_down]),expn=log10(expn_pv[hyper_down]),pcolor[hyper_down])
#	hyper_up = meth_fd<1 & expn_fd<1;
#	hyper_up = hyper_up & !is.na(hyper_up)
#	logpv4 = cbind(meth=-log10(meth_pv[hyper_up]),-log10(expn=expn_pv[hyper_up]),pcolor[hyper_up])
#	logpv_hyper = rbind(logpv3,logpv4);
#	logpv_hypo = rbind(logpv1,logpv2);
#	
#	
#	
#	#plot
#	opar2 <-par(mar=c(2,5,2,5),las=0,mfrow=c(2,1));
#	plot(logpv_hyper[,2],logpv_hyper[,1],type="n",xlab = "", ylab = "",ylim=c(0,8.5),axes = FALSE); #xlim=c(-3,3)
#	#points(logpv[,1],logpv[,2],col=c("darkgreen","darkred")[logpv[,3]],pch=c(1,5)[pcolor],cex=0.5); 
#	points(logpv_hyper[,2],logpv_hyper[,1],col=c("darkgreen","darkred")[logpv_hyper[,3]],pch=c(1,5)[logpv_hyper[,3]],cex=0.5);
#	#box();
#	axis(1,pos=0, label=T)
#	axis(2,pos=0, label=T,ylim=c(0,8.5))
#	box()
#	
#	
#	plot(logpv_hypo[,2],-logpv_hypo[,1],type="n",xlab = "", ylab = "",axes = FALSE,xlim=c(-3,3))#,ylim=c(0,8.5)
#	#points(logpv[,1],logpv[,2],col=c("darkgreen","darkred")[logpv[,3]],pch=c(1,5)[pcolor],cex=0.5); 
#	points(logpv_hypo[,2],-logpv_hypo[,1],col=c("darkgreen","darkred")[logpv_hypo[,3]],pch=c(1,5)[logpv_hypo[,3]],cex=0.5);
#	#box();
#	axis(1,pos=0, label=T)
#	axis(2,pos=0, label=T,ylim=c(0,8.5))
#	box()
#	
#	mtext("GENE EXPRESSION",cex=1.0,, side = 2, line = 4)
#	mtext("IF UP EXPRESSION, -1*Log10 (FDR-corrected Wilcoxon Pvalue),\n ELSE Log10 (FDR-corrected Wilcoxon Pvalue)", cex=0.8, side = 2, line = 2)
#	opar2 <- par(las = 3)
#	text(x=-9,y=5, "Up Expression",col="red",srt=90);
#	text(x=-9,y=-5, "Down Expression",col="green",srt =90);
#	opar2 <- par(las = 1)
#	axis(2,pos=0, label=T)
#	mtext("DNA METHYLATION",cex=0.8,side = 1, line = 1)
#	mtext("IF HYPERMETHYLATED, -1*Log10 (FDR-corrected Wilcoxon Pvalue),\n ELSE Log10 (FDR-corrected Wilcoxon Pvalue)", cex=0.8,side = 1, line = 3)
#	abline(0,0);abline(2,0,col="red");abline(-2,0,col="red");
#	abline(v=0);abline(v=2,col="red");abline(v=-2,col="red");
#	rect(-2,-2,2,2,col="#0000ff32",border="transparent");
#	#abline(0,0);abline(1.3,0,col="red");abline(-1.3,0,col="red");
#	#abline(v=0);abline(v=1.3,col="red");abline(v=-1.3,col="red");
#	#rect(-1.3,-1.3,1.3,1.3,col="#0000ff32",border="transparent");
#	
#	text(x=6,y=-9, "HYPERMETHYLATION",col="red");
#	text(x=-6,y=-9, "HYPOMETHYLATION",col="green");
#	legend(x=3,y=10, c("NN vs. Superficial", "NN vs. Invasive"),col=c("darkseagreen", "darkred"),pch=c(1, 5),bty="n",cex=0.9);
#	
#	#sig
#	#sig_criteria = meth_pv<0.01 & expn_pv<0.01
#	sig_criteria = meth_pv<0.05 & expn_pv<0.05
#	hypo_down_sig = hypo_down &  sig_criteria
#	hypo_up_sig = hypo_up & sig_criteria;
#	hyper_down_sig = hyper_down & sig_criteria;
#	hyper_up_sig = hyper_up & sig_criteria;
#	hdall_sig = hypo_down_sig*1+ hypo_up_sig*2 + hyper_down_sig*3 + hyper_up_sig*4;
#	hdall_sig_char = c("not_sig","hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")[hdall_sig+1];
#	#hdall_sig_char = hdall_sig[c("hypo_down_sig","hypo_up_sig", "hyper_down_sig","hyper_up_sig")];
#	rst = cbind( hypo_down_sig, hypo_up_sig,  hyper_down_sig, hyper_up_sig, hdall_sig_char);
#	rlen=dim(rst)[1]/2;
#	t=cbind(rst[1:rlen,],rst[(rlen+1):(rlen*2),])
#	return(t);
#}

rev_comp_fct <- function(seq, rev=T, comp=T) {
	if(rev==T) {
		seq <- as.vector(unlist(strsplit(seq, split="")))
		seq <- rev(seq)
		seq <- paste(seq, collapse="")
	}	
	if(comp==T) {
		seq <- gsub("A", "1", seq, ignore.case = T)
		seq <- gsub("T", "2", seq, ignore.case = T)
		seq <- gsub("C", "3", seq, ignore.case = T)
		seq <- gsub("G", "4", seq, ignore.case = T)		
		seq <- gsub("1", "T", seq, ignore.case = T)
		seq <- gsub("2", "A", seq, ignore.case = T)
		seq <- gsub("3", "G", seq, ignore.case = T)
		seq <- gsub("4", "C", seq, ignore.case = T)
	}
	seq
}

color.batch<-function (batch) 
{
	color.numb <- table(batch)
	color.numb<-color.numb[unique.2(batch)]
	color <- c()
	for (i in 1:length(color.numb)) {
		ii <- i + 1
		color <- c(color, rep(ii, color.numb[i]))
	}
	color
}
unique.2<-function(dats){
	rst<-c()
	for(dat in dats){
		if(!is.element(dat,rst)) rst<-c(rst,dat)
	}
	return(rst)
}
#color.batch<-function(batch){
#	color.numb <- table(batch)
#	color<-c();
#	for(i in 1:length(color.numb)){
#		ii<-i+1
#		color <-c(color,rep(ii,color.numb[i]))
#	}
#	color
#}

diag.panel = function (x, ...) {
	par(new = TRUE)
	hist(x, 
			col = "light blue", 
			probability = TRUE, 
			axes = FALSE, 
			main = "")
	lines(density(x), 
			col = "red", 
			lwd = 3)
	rug(x)
}



panel.cor <- function(x, y, digits=2, prefix="", cex.cor)
{
	usr <- par("usr"); on.exit(par(usr))
	par(usr = c(0, 1, 0, 1))
	r <- abs(cor(x, y))
	txt <- format(c(r, 0.123456789), digits=digits)[1]
	txt <- paste(prefix, txt, sep="")
	if(missing(cex.cor)) cex.cor <- 0.8/strwidth(txt)
	text(0.5, 0.5, txt, cex = cex.cor * r)
}
mva.plot.1 <- function(x,y,color="#00ff0032") {
	m <- log2(y/x)
	a <- log2(x*y)/2
	plot(a,
			m,
			pch=16, cex=0.2,
			main=paste('MA plot'),
			xlab='A=log2(M*U)/2',
			#xlab ='A',
			ylab='M=log2(M/U)',
			#ylab = 'M'		
			col=color
	)
	abline(h=0,col="red",lwd=2)  #zero
	abline(h=mean(m),col="blue",lwd=2) # mean
	abline(h=median(m),col="green",lwd=2) # median
	text.legend = c("zero","mean","median")
	legend(max(a) - (max(a)-min(a))/3,max(m),legend=text.legend,col=c("red","blue","yellow"), lwd=2,cex=0.8,horiz=FALSE)
}
mva.plot <- function(x,y) {
	m <- y-x
	a <- (x+y)/2
	plot(a,
			m,
			pch=16, cex=0.2,
			main=paste('MA plot'),
			#xlab='A=log2(R*G)/2',
			xlab ='A',
			#ylab='M=log2(R/G)',
			ylab = 'M'		
	)
	abline(h=0,col="red",lwd=2)  #zero
	abline(h=mean(m),col="blue",lwd=2) # mean
	abline(h=median(m),col="green",lwd=2) # median
	text.legend = c("zero","mean","median")
	legend(max(a) - (max(a)-min(a))/3,max(m),legend=text.legend,col=c("red","blue","yellow"), lwd=2,cex=0.8,horiz=FALSE)
}

dnorm1 <-function(x,log=F){
	rst = 1/sqrt(2*pi)*exp(-x^2/2);
	if(log == T){
		rst = log(rst);
	}
	return(rst);
}


create_Density_plot.2<-function(beta.dup.pdif,beta.dup.norm.pdif,ymax=25){
	# density plot
	X11(width=5,height=4)
	pt1<-density(beta.dup.pdif)
	pt2<-density(beta.dup.norm.pdif)
	plot(pt1,main="",type="n",xlim=c(0,0.2),ylim=c(0,ymax),
			xlab="Manhattan Distance",ylab="Desnsity")
	points(pt1,col="blue",lwd=2,type="l")
	points(pt2,col="green",lwd=2,type="l")
	legend(0.07,ymax-10,c("Before Normalization","After PBR Normalization"),
			col=c("blue","green"),fill=c("blue","green"),bty="n",cex=1)
	#polygon(pt1,)
	polygon(pt2,col="#00ff0032",border="green")
	#legend(locator(),legend=c("p-value 2.2e-16"))
}
##########
# mh is a vector of mannhattan dist
##########
create_Density_plot.3<-function(mh,lname,ymax=40,xmax=0.12){
	# density plot
	X11(width=5,height=4)
	pt1<-density(mh[,ncol(mh)])
	plot(pt1,main="",type="n",xlim=c(0,xmax),ylim=c(0,ymax),
			xlab="Manhattan Distance",ylab="Density")
	color<-c()
	for(i in 1:ncol(mh)){
		pt<-density(mh[,i])
		c1<-i+1
		points(pt,col=c1,lwd=2,type="l")
		color<-c(color,c1)
	}

	legend(0.07,ymax-10,lname,
			col=c("blue","green"),fill=color,bty="n",cex=1)
	polygon(pt1,col="#00ff0032",border="green")
}

########################
# April28
########################
mod_factor<-function(dat){
	n.row<-nrow(dat)
	n.col<-ncol(dat)
	for(i in 1:n.col){
		if(is.factor(dat[,i])){
			dat[,i]<-as.character(dat[,i])
		}
	}
	return(dat)
}
mod_list<-function(dat){
	n.row<-nrow(dat)
	n.col<-ncol(dat)
	for(i in 1:n.col){
		if(is.list(dat[,i])){
			dat[,i]<-as.character(dat[,i])
		}
	}
	return(dat)
}
rep_type<-function(dat,data2){
	for(i in 1:ncol(dat)){
		if(is.numeric(data2[,i])){
			dat[,i]<-as.numeric(dat[,i])
		}
		if(is.logical(data2[,i])){
			dat[,i]<-as.logical(dat[,i])
		}
	}
	return(dat)
}
#######################
#
#########################
unique_by_min<-function(dat,id.col,dist){
	dat<-mod_factor(dat)
	dat.id<-split(dat,as.factor(dat[,id.col]))
	rr<-t(sapply(dat.id,function(x)x[which(x[,dist]==min(x[,dist])),]))
	rr<-as.data.frame(rr)
	r1<-mod_list(rr)
	r1<-rep_type(r1,dat)
	return(r1)
}

##################
#
######################
rbind1<-function(data1,data2){
	if(is.null(data1)|is.null(data2)){
		return(data1)
	}
	n.row.1<-nrow(data1)
	n.row.2<-nrow(data2)
	n.col.1<-ncol(data1)
	n.col.2<-ncol(data2)
	if(n.row.1==0 | n.row.2==0 | n.col.1==0 | n.col.2==0){
		return(data1)
	}
	data1<-mod_factor(data1)
	data2<-mod_factor(data2)
	if(n.col.1!=n.col.2){
		stop("ncol1!=col2")
	}
	n.row<-n.row.1+n.row.2
	rst<-as.data.frame(matrix(NA,n.row,n.col.1))
	for(i in 1:n.row.1){
		rst[i,]<-data1[i,]
	}
	for(j in 1:n.row.2){
		ii<-j+n.row.1
		rst[ii,]<-data2[j,]
	}
	names(rst)<-names(data1)
	return(rst)
}

######################################
#
#######################################
create_manifest<-function(db=NULL,ver=NULL,platform="OMA04"){
	if(is.null(db)){
		fn<-file.path("C:\\feipan\\database\\NCBI\\gene","OMA04Manifest_Gene_Symbol_update_April16_2010.csv")
		db<-read.delim(fn,header=T,sep=",",as.is=TRUE)
	}
	if(is.null(ver)){
		ver<-"1.5"
	}
	setwd("c:\\temp")
	library(mAnnot)
	if(platform=="OMA04"){
		OMA04Manifest<-db
		attr(OMA04Manifest,"version")=ver
		attr(OMA04Manifest,"date")=date()
		save(OMA04Manifest,file="OMA04Manifest.Rdata")
		str(OMA04Manifest)
		getData("OMA02")
		getData("OMA03")
	}else if(platform=="OMA03"){
		OMA04Manifest<-db
		attr(OMA03Manifest,"version")<-ver
		attr(OMA03Manifest,"date")=date()
		save(OMA03Manifest,file="OMA03Manifest.rdata")
		getData("OMA02")
		getData("OMA04")
	}else if(platform=="OMA02"){
		OMA02Manifest<-db
		attr(OMA02Manifest,"version")<-ver
		attr(OMA02Manifest,"date")=date()
		save(OMA02Manifest,file="OMA02Manifest.rdata")
		getData("OMA03")
		getData("OMA04")
	}else{
		cat("check...",platform,"\n")
	}
	
	
	
	system("rm -r GoldenGateManifest")
	package.skeleton(name="GoldenGateManifest",list=c("OMA02Manifest","OMA03Manifest","OMA04Manifest"))
	
	setwd("c:\\temp\\GoldenGateManifest")
	system("mv DESCRIPTION dsc_old")
	system(paste("sed 's/1.0/",ver,"/g' dsc_old >> DESCRIPTION"))
	shell(paste("sed 's/1.0/",ver,"/g' dsc_old >> DESCRIPTION"))
	system("rm dsc_old")
	
	setwd("c:\\temp")
	system("rm ./GoldenGateManifest/man/*.Rd")
	system("R CMD build GoldenGateManifest")
	system("R CMD build -binary GoldenGateManifest")
}

########################
#
##########################
blatSeq2<-function(query.data,dir.blat=NULL,dir.seq=NULL,dir.wk=NULL,byChr=TRUE){
	if(is.null(dir.blat)){
		dir.blat<-"C:\\feipan\\database\\tools\\blat\\"
	}
	if(is.null(dir.seq)){
		dir.seq<-"C:\\feipan\\database\\hg18_seq\\"
	}
	if(is.null(dir.wk)){
		dir.wk<-"C:\\feipan\\database\\work\\"
	}
	setwd(dir.wk)
	report_fa<-function(qdata){
		query<-paste(">",qdata[1],"_",qdata[2],"_",qdata[3],"\n",qdata[4],sep="")
	}
	qfa<-apply(query.data,1,report_fa)
	if(byChr==TRUE){
		#by chrom: to imp
		humanMeth27k_Chr<-query.data[,2]
		qfa.chr<-split(qfa,factor(humanMeth27k_Chr))
		for(i in 1:length(qfa.chr)){
			chr<-names(qfa.chr)[i]
			fn<-paste("query_",names(qfa.chr)[i],".fa",sep="")
			dat<-as.data.frame(qfa.chr[i])
			write.table(file=fn,dat,sep="\t",row.names=F,col.names=F,quote=F)
#			command<-paste(dir.blat,"./blat ",
#					dir.seq,"/chr",chr,".fa query_",chr,".fa query_",chr,".out.txt",sep="")
			command<-paste(dir.blat,"./blat -minScore=10 -tileSize=6 ",  
					dir.seq,"/chr",chr,".fa query_",chr,".fa query_",chr,".out.txt",sep="") #May3
			system(command)
		}
	}else{
		write.table(qfa,file="query.all.fa",sep="\t",row.names=F,col.names=F,quote=F)
		setwd(dir.wk)
		flist<-list.files(path=dir.seq,pattern=".fa")
		for(i in 1:length(flist)){
			command<-paste(dir.blat,"./blat ",dir.seq,flist[i]," query.all.fa query_",flist[i],".out.txt",sep="")
			system(command)
		}
	}
}

parse_Blat2<-function(dir.path=NULL,fn.out=NULL,max.mismatch=0,out.dir=NULL){
	if(is.null(dir.path)){
		dir.path<-"C:\\feipan\\database\\work\\"
	}
	if(is.null(out.dir)){
		out.dir<-"c:\\temp"
	}
	setwd(dir.path)
	flist<-list.files(pattern=".txt")
	bl.all<-NULL
	for(i in 1:length(flist)){
		fn<-flist[i]
		blrst<-readLines(fn,n=3)
		hd<-blrst[3]
		hd.name<-unlist(strsplit(hd,"\t"))
		bl<-read.delim(file=fn,skip=5,sep="\t",header=F)
		names(bl)<-hd.name
		
		# completely match
		#max.match<-50
		#max.mismatch<-0
		
		filter1<-function(bl1,max.mismatch){
			#browser()
			#bl.match<-bl1[1]
			bl.misMatch<-as.numeric(bl1[2])
			bl.blockCount<-as.numeric(bl1[18])
			#rst<-list()
			rst<-NULL
			#if(bl.match>=max.match & bl.misMatch<=max.mismatch & bl.blockCount==1){
			if(bl.misMatch<=max.mismatch & bl.blockCount==1){
				rst<-TRUE
			}else{
				rst<-FALSE
			}
			return(rst)
		}
		ind<-apply(bl,1,filter1,max.mismatch)
		
		bl.all.chr<-bl[ind,]
		if(is.null(bl.all)){
			bl.all<-bl.all.chr
		}else{
			bl.all<-rbind(bl.all.chr,bl.all)
		}
	}
	names(bl.all)<-c("match","mismatch","rep_match","N","Q_gap_count","Q_gap_bases","T_gap_count","T_gap_bases",
			"strand","name","size","start1","end1","Chr","size","start","end","block_count","blockSizes ","qStarts","tStarts")
	timestamp<-unclass(Sys.time())
	if(is.null(fn.out)){
		fn.out<-file.path(out.dir,paste("align_out_",timestamp,".csv",sep=""))
	}
	else {
		fn.out<-file.path(out.dir,paste(fn.out,timestamp,".csv",sep="_"))
	}
	write.table(file=fn.out,bl.all,sep=",",row.names=F)
	return(bl.all)
}
parse_Blat2.2<-function(dir.path=NULL,fn.out=NULL,max.mismatch=0,stamp=F,out.dir=NULL){
	if(is.null(dir.path)){
		dir.path<-"C:\\feipan\\database\\work\\"
	}
	if(is.null(out.dir)){
		out.dir<-"c:\\temp"
	}
	setwd(dir.path)
	flist<-list.files(pattern=".txt")
	bl.all<-c()
	for(i in 1:length(flist)){
		fn<-flist[i]
		cat("work on ");cat(fn);cat("\n")
		blrst<-readLines(fn,n=3)
		hd<-blrst[3]
		hd.name<-unlist(strsplit(hd,"\t"))
		bl<-read.delim(file=fn,skip=5,sep="\t",header=F)
		names(bl)<-hd.name
		# completely match
		#max.match<-50
		max.mismatch<-0
		filter1<-function(bl1,max.mismatch){
			bl.misMatch<-as.numeric(bl1[2])
			bl.blockCount<-as.numeric(bl1[18])
			rst<-NULL
			#if(bl.match>=max.match & bl.misMatch<=max.mismatch & bl.blockCount==1){
			#if(bl.misMatch<=max.mismatch & bl.blockCount==1){
			if(bl.misMatch<=max.mismatch & (is.na(bl.blockCount)|bl.blockCount==1)){ #on 04/05/2011
				rst<-TRUE
			}else{
				rst<-FALSE
			}
			return(rst)
		}
		ind<-apply(bl,1,filter1,max.mismatch)
		
		bl.all.chr<-bl[ind,]
		names(bl.all.chr)<-c("match","mismatch","rep_match","N","Q_gap_count","Q_gap_bases","T_gap_count","T_gap_bases",
				"strand","name","size","start1","end1","Chr","size","start","end","block_count","blockSizes ","qStarts","tStarts")
		timestamp<-unclass(Sys.time())
		fn<-gsub("txt","",fn);fn<-gsub("query","align",fn)
		fn.out<-file.path(out.dir,paste(fn,timestamp,".csv",sep=""))
		if(stamp!=T)fn.out<-file.path(out.dir,paste(fn,"csv",sep=""))
		write.table(file=fn.out,bl.all.chr,sep=",",row.names=F)
		bl.all<-c(bl.all,bl.all.chr$name)
	}
	return(bl.all)
}
merge_blat<-function(dir.path=NULL,fn.out=NULL,max.mismatch=0,stamp=F,out.dir=NULL){
	if(is.null(dir.path)){
		dir.path<-"C:\\feipan\\database\\work\\"
	}
	if(is.null(out.dir)){
		out.dir<-"c:\\temp"
	}
	setwd(dir.path)
	flist<-list.files(pattern=".txt")
	bl.all<-c()
	for(i in 1:length(flist)){
		fn<-flist[i]
		cat("work on ");cat(fn);cat("\n")
		blrst<-readLines(fn,n=3)
		hd<-blrst[3]
		hd.name<-unlist(strsplit(hd,"\t"))
		bl<-read.delim(file=fn,skip=5,sep="\t",header=F)
		names(bl)<-hd.name
		# completely match
		#max.match<-50
		max.mismatch<-0
		filter1<-function(bl1,max.mismatch){
			bl.misMatch<-as.numeric(bl1[2])
			bl.blockCount<-as.numeric(bl1[18])
			rst<-NULL
			#if(bl.match>=max.match & bl.misMatch<=max.mismatch & bl.blockCount==1){
			#if(bl.misMatch<=max.mismatch & bl.blockCount==1){
			if(bl.misMatch<=max.mismatch & (is.na(bl.blockCount)|bl.blockCount==1)){ #on 04/05/2011
				rst<-TRUE
			}else{
				rst<-FALSE
			}
			return(rst)
		}
		ind<-apply(bl,1,filter1,max.mismatch)
		
		bl.all.chr<-bl[ind,]
		names(bl.all.chr)<-c("match","mismatch","rep_match","N","Q_gap_count","Q_gap_bases","T_gap_count","T_gap_bases",
				"strand","name","size","start1","end1","Chr","size","start","end","block_count","blockSizes ","qStarts","tStarts")
		timestamp<-unclass(Sys.time())
		fn<-gsub("txt","",fn);fn<-gsub("query","align",fn)
		fn.out<-file.path(out.dir,paste(fn,timestamp,".csv",sep=""))
		if(stamp!=T)fn.out<-file.path(out.dir,paste(fn,"csv",sep=""))
		write.table(file=fn.out,bl.all.chr,sep=",",row.names=F)
		bl.all<-c(bl.all,bl.all.chr$name)
	}
	align.all<-NULL
	fns<-list.files(outDir,patte=".csv")
	for(fn in fns){
		align_rst<-read.delim(file=fn,sep=",",stringsAsFactors=F,as.is=T)
		max.mismatch<-2
		align_rst<-align_rst[align_rst$match>=(align_rst$size-max.mismatch),]
		align.nameID<-as.character(lapply(strsplit(as.character(align_rst$name),"_"),function(x)x[1]))
		length(unique(align.nameID))
		align_rst<-cbind(nameID=align.nameID,align_rst[,c("Chr","strand","start","end","match","size")])
		if(is.null(align.all)) align.all<-align_rst
		else align.all<-rbind(align.all,align_rst)
	}
	save(align.all,file=file.path(outDir,"blat_align_all.rdata"))
	return(bl.all)
}
getMapInfo.meth450<-function(chr=NULL){
	require(mAnnot)
	data(blat_align)
	return(blat.align)
}
getMapInfo.meth450.1<-function(chr=NULL){
	require(rapid.pro)
	data(HumanMethylation450.adf.ext)
	infinium.minfo<-HumanMethylation450.adf.ext[,c("ILMNID","CHROMOSOME_36","COORDINATE_36","STRAND","Start","End")]
	names(infinium.minfo)<-c("IlmnID","Chr","mapInfo","Strand","start","end")
	ind<-infinium.minfo$Chr==""|infinium.minfo$Chr=="MULTI"
	table(ind)
#	FALSE   TRUE 
#	485460    117 
	infinium.minfo<-infinium.minfo[!ind,]
	if(!is.null(chr))infinium.minfo[infinium.minfo$Chr==chr,]
	return(infinium.minfo)
}
getMapInfo.meth450.2<-function(chr=NULL,limit=T){
	require(rapid.pro)
	data(HumanMethylation450.adf.ext)
	infinium.minfo<-HumanMethylation450.adf.ext[,c("ILMNID","CHROMOSOME_36","COORDINATE_36","STRAND","Start","End")]
	names(infinium.minfo)<-c("IlmnID","Chr","mapInfo","Strand","start","end")
	if(limit==T){
		data(HumanMethylation450.adf)
		ind<-is.element(infinium.minfo$IlmnID,HumanMethylation450.adf$ILMNID)
		infinium.minfo<-infinium.minfo[HumanMethylation450.adf$ILMNID,]
		row.names(infinium.minfo)<-infinium.minfo[,"IlmnID"]
	}
	return(infinium.minfo)
}
getFlankSeq<-function(len=250,build="hg19",outdir=NULL){
	library(rapid.pro)
	data(HumanMethylation450.adf)
	mapInfo<-HumanMethylation450.adf$MAPINFO
	if(build=="hg19") {
		library(BSgenome.Hsapiens.UCSC.hg19)
	}
	else {
		library(BSgenome.Hsapiens.UCSC.hg18)
		mapInfo<-HumanMethylation450.adf$COORDINATE_36
	}
	
	align.start<-as.numeric(mapInfo)-len
	align.end<-as.numeric(mapInfo)+len
	chrs<-c(1:22,"X","Y")
	seq.all<-c();seq.name<-c()
	for(chr in chrs){
		cat("work on chr",chr,"\n")
		seq.chr<-Hsapiens[[paste("chr",chr,sep="")]]
		ind<-HumanMethylation450.adf$CHR==chr
		starts<-align.start[ind]
		ends<-align.end[ind]
		IlmnID<-HumanMethylation450.adf$ILMNID[ind]
		seq1<-c()
		for(i in 1:length(starts)){
			seq1<-c(seq1,as.character(subseq(seq.chr,starts[i],ends[i])))
		}
		names(seq1)<-IlmnID
		if(!is.null(outdir))save(seq1,file=file.path(outdir,paste("seq.flank",len*2,".chr",chr,".rdata",sep="")))
		seq.all<-c(seq.all,as.character(seq1))
		seq.name<-c(seq.name,IlmnID)
	}
	seq.all<-data.frame(IlmnID=seq.name,fseq=seq.all,stringsAsFactors=F)
	return(seq.all)
}
##########
#
##########
conSeqs_test<-function(){
	seqFns<-"c:\\temp\\seq1.fa"
	conSeqs(seqFns)
	seqPath<-"c:\\temp"
	conSeqs(seqPath=seqPath)
}
conSeqs<-function(seqFns=NULL,seqPath=NULL,outPath=NULL,ext=".fa",n=1){
	if(is.null(seqFns))seqFns<-list.files(seqPath,patt=ext,full.names=T)
	if(is.null(outPath))outPath<-filedir(seqFns[1])
	for(i in 1:length(seqFns)){
		seqs<-readLines(seqFns[i])
		if(n>0)seqs<-seqs[-(1:n)]
		seqs<-paste(seqs,collapse="")
		fn.out<-strsplit(filetail(seqFns[i]),"\\.")[[1]][1]
		write(seqs,file=file.path(outPath,fn.out))
	}
}
#######
# util
######
filetail<-function(fileName){
	fn<-gsub("\\\\","/",fileName)
	fn<-unlist(strsplit(fn,"/"))
	return(fn[length(fn)])
}
filedir<-function(fileName){
	fn<-filetail(fileName)
	return(gsub(fn,"",fileName))
}
file.ext<-function(fileName){
	fn<-strsplit(filetail(fileName),"\\.")[[1]]
	return(tolower(fn[length(fn)]))
}
