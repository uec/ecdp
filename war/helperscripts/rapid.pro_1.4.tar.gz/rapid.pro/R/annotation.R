# TODO: Add comment
# 
# Author: feipan
###############################################################################



#############
#
# Automatic Annotation
############
check_EntrezGene_test2<-function(){
	#localFn<-"/auto/uec-02/shared/production/methylation/database/NCBI/gene/gene_info.gz"
	#outdir<-"/auto/uec-02/shared/tmp/meth"
	localFn<-"/home/feipan/data/NCBI/gene/gene_info.gz"
	outdir<-"/home/feipan/data/temp"
	check_EntrezGene(localFn,outdir)
}
check_EntrezGene_test<-function(){
	localFn<-"C:\\feipan\\database\\NCBI\\gene\\gene_info.gz"
	outdir<-"c:\\temp"
	check_EntrezGene(localFn,outdir)
}
check_EntrezGene<-function(localFn,outdir=NULL){
	update<-FALSE
	data_url<-"ftp://ftp.ncbi.nih.gov/gene/DATA/gene_info.gz"
	if(is.null(outdir)) outdir<-filedir(localFn)
	fn.new<-"gene_info.new.gz"
	download.file(data_url,destfile=file.path(outdir,fn.new),method="wget")
	info1<-file.info(localFn)$mtime
	info2<-file.info(file.path(outdir,fn.new))$mtime
	if(info1!=info2){
		file.rename(localFn,paste(localFn,strsplit(as.character(info1)," ")[[1]][1],sep="_"))
		file.copy(file.path(outdir,fn.new),localFn)
		file.remove(file.path(outdir,fn.new))
		update<-TRUE
	}
	return(update)
}
update_EntrezGene.2_test<-function(){
	localFn<-"/home/feipan/data/NCBI/gene/gene_info.gz"
	outdir<-"/home/feipan/data/temp"
	rst<-update_EntrezGene.2(localFn,outdir)
	write.table(rst[["GID"]],file="gid.update.txt",sep="\t")
	write.table(rst[["GS"]],file="gs.update.txt",sep="\t")
}
update_EntrezGene.2<-function(localFn,outdir,platform="meth27"){
	require(AnnotationDbi)
	require(rapid.db)
	update<-check_EntrezGene(localFn,outdir)
	if(update==F) return()
	
	outDir<-filedir(localFn)
	ungzip(localFn,outDir)
	file.rename(gsub(".gz","",localFn),file.path(outDir,"dat.txt"))
	readGeneInfo2(outDir)
	dat<-read.delim(file=file.path(outDir,"out.txt"),header=F,sep="\t",as.is=T)
	names(dat)<-c("GeneID","Symbol")
	GeneID<-NULL
	GeneSymbol<-NULL
	gid.update<-NULL
	gs.update<-NULL
	toUpdate<-F
	if(platform=="meth27"){
		data(meth27ENTREZID)
		data(meth27GENESYMBOL)
		ilmnID<-Lkeys(meth27ENTREZID)
		GeneID<-Rkeys(meth27ENTREZID)
		GeneSymbol<-Rkeys(meth27GENESYMBOL)
		pid<-Lkeys(meth27GENESYMBOL)
		if(!all(pid==ilmnID))stop("check..")
		dat1<-data.frame(gid=GeneID,pid=ilmnID,gs=GeneSymbol,stringsAsFactors=F)
		dat1<-dat1[!is.na(dat1$gid),]
		gid<-merge(dat,dat1,by.x=1,by.y=1)
		names(gid)<-c(names(dat),"pid","gs")
		if(nrow(gid)<length(dat1$gid)){
			ind<-!is.element(dat1$gid,gid[,1])
			gid.update<-dat1[ind,]#data.frame(GeneID=dat1$gid[ind],IlmnID=ilmnID[ind])
			toUpdate<-TRUE
		}
		if(!all(gid$Symbol==gid$gs)){
			ind<-gid$Symbol!=gid$gs
			gs.update<-gid[ind,]
			toUpdate<-TRUE
		}
	}
	return(list(GID=gid.update,GS=gs.update))
}


update_EntrezGene_test<-function(){
	localFn<-"C:\\feipan\\database\\NCBI\\gene\\gene_info.gz"
	update_EtntrezGene(localFn)
}
update_EntrezGene<-function(localFn,platform="meth27"){
	update<-check_EntrezGene()
	if(update==F) return()
	dat<-read.delim(file=gzfile(localFn),skip=1,sep="\t")
	names(dat)<-c("tax_id","GeneID","Symbol","LocusTag","Synonyms","dbXrefs","chromosome","map_location","description","type_of_gene","Symbol_from_nomenclature_authority","Full_name_from_nomenclature_authority","Nomenclature_status","Other_designations","Modification_date")
	GeneID<-NULL
	GeneSymbol<-NULL
	ilmn.update<-NULL
	toUpdate<-F
	if(platform=="meth27"){
		data(meth27ENTREZID)
		data(meth27GENESYMBOL)
		ilmnID<-Lkeys(meth27ENTREZID)
		GeneID<-Rkeys(meth27ENTREZID)
		GeneSymbol<-Rkeys(meth27GENESYMBOL)
		dat1<-data.frame(gid=GeneID,pid=ilmnID,gs=GeneSymbol)
		gid<-merge(dat,dat1,by.x=2,by.y=1)
		if(nrow(gid)<length(na.omit(GeneID))){
			ind<-!is.element(GeneID,gid[,1])
			ilmn.update<-ilmnID[ind]
			toUpdate<-TRUE
		}
		if(!all(gid$Symbol==gid$gs)){
			ind<-gid$Symbol!=gid$gs
			ilmn.update<-ilmnID[ind]
			toUpdate<-TRUE
		}
	}
	
	return(ilmn.update)
}


##################################
# rsmp
#################################
download_rsmp<-function(URL=NULL,outPath){
	if(is.null(URL)) URL<-"ftp://hgdownload.cse.ucsc.edu/goldenPath/hg18/database"
	rsmpFns<-c("chr1_rmsk.txt.gz","chr2_rmsk.txt.gz","chr3_rmsk.txt.gz","chr4_rmsk.txt.gz",
			"chr5_rmsk.txt.gz","chr6_rmsk.txt.gz","chr7_rmsk.txt.gz","chr8_rmsk.txt.gz",
			"chr9_rmsk.txt.gz","chr10_rmsk.txt.gz","chr11_rmsk.txt.gz","chr12_rmsk.txt.gz",
			"chr13_rmsk.txt.gz","chr14_rmsk.txt.gz","chr15_rmsk.txt.gz","chr16_rmsk.txt.gz",
			"chr17_rmsk.txt.gz","chr18_rmsk.txt.gz","chr19_rmsk.txt.gz","chr20_rmsk.txt.gz",
			"chr21_rmsk.txt.gz","chr22_rmsk.txt.gz","chrX_rmsk.txt.gz","chrY_rmsk.txt")
	for(fn in rsmpFns){
		download.file(file.path(URL,fn),destfile=file.path(outPath,fn))
		ungzip(file.path(outPath,fn))
	}
}
prepare_rsmp<-function(datPath){
	rsmpFns<-list.files(datPath,pattern="rmsk.txt")
	rsmp.all<-NULL
	for(fn in rsmpFns){
		dat<-read.delim(file=file.path(datPath,fn),sep="\t",header=F,as.is=T)
		rsmp.chr<-dat[,c(12,6,7,8,11,13)]
		names(rsmp.chr)<-c("Class","Chr","start","end","Name","Family")
		rsmp.chr["mapInfo"]<-rsmp.chr$start+(rsmp.chr$end-rsmp.chr$start)/2
		if(is.null(rsmp.all)) rsmp.all<-rsmp.chr
		else rsmp.all<-rbind(rsmp.all,rsmp.chr)
	}
	save(rsmp.all,file=file.path(datPath,"rsmp.all.rdata"))
}
annote_rsmp_test<-function(){
	outPath<-"C:\\feipan\\manifests\\Infinium\\rsmp"
	annote_rsmp(outPath=outPath)
	outPath<-"C:\\feipan\\manifests\\OMA04\\rsmp2"
	annot_rsmp(platform="OMA04",outPath)
}
annote_rsmp<-function(platform="humanMeth27k",outPath){
	library(mAnnot)
	getData(platform)
	mani<-getMapInfo(platform)
	mani.chr<-split(mani,mani$Chr)
	load(file="C:\\feipan\\database\\ucsc\\rmsk\\rsmp.all.rdata")
	names(rsmp.all)
	rsmp.chr<-split(rsmp.all,rsmp.all$Chr)
	library(mLab)
	annot<-findNN.5(mani.chr,rsmp.chr)
	ind<-which(names(annot)=="mapInfo")
	annot$distance2<-abs(annot[,ind[1]]-annot[,ind[2]])
	write.csv(annot,file=file.path(outPath,"rsmp_annot.csv"))
	return(annot)
}
create_meth27Rmsk_test<-function(){
	datFn<-"C:\\feipan\\manifests\\Infinium\\rsmp\\rsmp_annot.csv"
	outdir<-"C:\\Documents and Settings\\feipan\\workspace\\RAPiD.db\\data"
	create_meth27RMSK(datFn,outdir)
}
create_meth27RMSK<-function(datFn,outdir){
	dat<-read.table(file=datFn,sep=",",header=T,as.is=T)
	dat.annot<-data.frame(dat$IlmnID,as.character(dat$distance2),dat$Class,dat$start.1,dat$end.1,dat$Name,dat$Family,stringsAsFactors=F)
	names(dat.annot)<-c("IlmnID","Dist","Class","Start","End","Name","Family")
	dat.annot<-dat.annot[order(dat.annot$IlmnID,decreasing=F),]
	meth27RMSK<-createBimap.2(dat.annot)
	save(meth27RMSK,file=file.path(outdir,"meth27RMSK.rdata"))
}
create_OMARMSK<-function(datFn,outdir){
	dat<-read.table(file=datFn,sep=",",header=T,as.is=T)
	dat.annot<-data.frame(dat$IlmnID,as.character(dat$distance2),dat$Class,dat$start.1,dat$end.1,dat$Name,dat$Family,stringsAsFactors=F)
	names(dat.annot)<-c("IlmnID","Dist","Class","Start","End","Name","Family")
	dat.annot<-dat.annot[order(dat.annot$IlmnID,decreasing=F),]
	return(dat.annot)
}
create_OMA04RMSK<-function(datFn,outdir){
	dat.annot<-create_OMARMSK(datFn,outdir)
	OMA04RMSK<-createBimap.2(dat.annot)
	write(OMA04RMSk,file=file.path(outdir,"OMA04RMSk.rdata"))
}
################
#
###############
readGeneInfo_test<-function(){
	setwd("c:\\feipan\\dat\\")
	datFn<-"dat.txt"
	outFn<-"out.txt"
	readGeneInfo(datFn,outFn)
	getLoadedDLLs()
	getDLLRegisteredRoutines("rapid.db")
	is.loaded("readData")
}
readGeneInfo<-function(datFn,outFn){
	library.dynam("rapid.db","rapid.db")
	.C("readData3",as.character(c(datFn,outFn)))
}
testData<-function(dat1){
	library.dynam("rapid.db","rapid.db")
	.C("testData",dat1,length(dat1),rst=integer(length(dat1)))$rst
}

readGeneInfo2<-function(wdir){
	setwd(wdir)
	library.dynam("rapid.db","rapid.db")
	.C("readData2")
}

################
# Thu Jan 20 09:07:26 2011
####################
createSQLiteDB<-function(){
	library(RSQLite)
	dbFile<-tempfile()
	db<-file.info(dbFile)
	con<-dbConnect(dbDriver("SQLite"),dbname=dbFile)
	library(mAnnot)
	getData()
	ilmn<-humanMeth27k[,c("ILmnID","Chr","MapInfo","AddressA_ID","AddressB_ID","SourceSeq","GenomeBuild")]
	sqliteWriteTable(con,"HumanMethylation27",ilmn)
	dbListTables(con)
	dbListFields(con,"HumanMethylaiton27")
	rs<-dbSendQuery(con,"Select * from HumanMethylation27")
	fetch(rs,n=10)
	dbDisconnect(con)
	dbUnloadDriver(con)
	file.copy(row.names(db),"c:\\temp\\manifestDB.sqlite")
}
createMeth27ExtTable<-function(){
	con<-dbConnect(dbDriver("SQLite"),dbname="c:\\tcga\\others\\manifestDB.sqlite")
	library(mAnnot)
	dat<-getData()
	meth27.ext<-humanMeth27k[,c("ILmnID","IlmnStrand","AlleleA_ProbeSeq","AlleleB_ProbeSeq","TopGenomicSeq","Next_Base","TSS_Coordinate",
					"Gene_Strand","Gene_ID","Symbol","Other Aliases","Accession","GID",
					"Annotation","Product","Distance_to_TSS","CPG_ISLAND","CPG_ISLAND_LOCATIONS",
					"MIR_CPG_ISLAND","MIR_NAMES","Ploidy","Species","Source","SourceStrand","SourceVersion")]
	sqliteWriteTable(con,"HumanMethylation27ext",meth27.ext,append=T)
	dbDisconnect(con)
}
createOMAtables<-function(dbname=NULL){
	if(is.null(dbname)) dbname<-"c:\\tcga\\others\\manifestDB.sqlite"
	con<-dbConnect(dbDriver("SQLite"),dbname=dbname)
	library(mAnnot)
	fn<-c("IlmnID","Chr","CpG_Coordinate","SourceSeq","GenomeBuild")
	getData("OMA02")
	oma02<-OMA02Manifest[,c("Probe_ID","Chromosome","CpG_Coordinate","Input_Sequence")]
	oma02<-data.frame(oma02,rep("36",nrow(OMA02Manifest)))
	names(oma02)<-fn
	sqliteWriteTable(con,"GoldenGateOMA02",oma02,append=T)
	dbListTables(con)
	
	getData("OMA03")
	oma03<-OMA03Manifest[,c("Probe_ID","Chromosome","CpG_Coordinate","Input_Sequence")]
	oma03<-data.frame(oma03,rep("36",nrow(OMA03Manifest)))
	names(oma03)<-fn
	sqliteWriteTable(con,"GoldenGateOMA03",oma03,append=T)
	
	getData("OMA04")
	oma04<-OMA04Manifest[,c("TargetID","Chr","CpG_Coordinate","Sequence","Genome_Build_Version")]
	names(oma04)<-fn
	sqliteWriteTable(con,"GoldenGateOMA04",oma04,append=T)
	
	dbDisconnect(con)
}
createOMAExtTables<-function(dbname=NULL){
	if(is.null(dbname)) dbname<-"c:\\tcga\\others\\manifestDB.sqlite"
	con<-dbConnect(dbDriver("SQLite"),dbname=dbname)
	getData("OMA02")
	om02<-OMA02Manifest[,c("Probe_ID","Gid","Accession","Symbol","Gene_ID","RefSeq","Dist_to_TSS",
					"CpG_island","Synonym","Annotation","Product")]
	sqliteWriteTable(con,"GoldenGateOMA02ext",oma02,append=T)
	dbListTables(con)
	
	getData("OMA03")
	oma03<-OMA03Manifest[,c("Probe_ID","Gid","Accession","Symbol","Gene_ID","RefSeq","Dist_to_TSS","CpG_island","Synonym","Annotation","Product")]
	sqliteWriteTable(con,"GoldenGateOMA03ext",oma03,append=T)
	dbListTables(con)
	
	getData("OMA04")
	oma04<-OMA04Manifest[,c("Probe_ID","Source","RefSeq","Ploidy","Species","Customer_Strand","Customer_Annotation",
					"Final_Score","Failure_Codes","Validation_Class","Validation_Bin","App_Version","Search_Key","CpG_Island",
					"ILMN_Designed_Strand","TSS_Coordinate","CpG_Offset","Gene_Strand","Gene_ID","Synonym","Accession","GID",
					"Annotation","Product")]
	sqliteWriteTable(con,"GoldenGateOMA04ext",oma04,append=T)
	dbDisconnect(con)
}
createMethyLightTables<-function(dbname=NULL){
	if(is.null(dbname)) dbname<-"c:\\tcga\\others\\manifestDB.sqlite"
	con<-dbConnect(dbDriver("SQLite"),dbname=dbname)
	getData("methyLight")
	MethyLightManifest$mapInfo<-MethyLightManifest[,"start_genome_coord_blat_aligned"]+(MethyLightManifest[,"end_genome_coord_blat_aligned"]-MethyLightManifest[,"start_genome_coord_blat_aligned"])/2
	ml<-MethyLightManifest[,c("Reaction Number","Chr_blat_aligned","mapInfo","Probe Oligo Sequence")]
	ml<-data.frame(ml,rep("36",nrow(ml)))
	names(ml)<-c("Probe_ID","Chr","MapInfo","SourceSeq","GenomeBuild")
	sqliteWriteTable(con,"MethyLightManifest",ml,append=T)
	dbDisconnect(con)
}
createSourceSeqAlignTable<-function(dbname=NULL){
	if(is.null(dbname)) dbname<-"c:\\tcga\\others\\manifestDB.sqlite"
	rn<-c("Probe_ID","Chr","Start","End","Platform")
	con<-dbConnect(dbDriver("SQLite"),dbname=dbname)
	humanMeth27k$Chr<-paste("chr",humanMeth27k$Chr,sep="")
	sourceSeqAlignment<-humanMeth27k[,c("ILmnID","Chr","start_blat_align_source_sequence","end_blat_align_source_sequence")]
	sourceSeqAlignment<-data.frame(sourceSeqAlignment,rep("meth27",nrow(humanMeth27k)))
	names(sourceSeqAlignment)<-rn
	oma02<-OMA02Manifest[,c("Probe_ID","Chromosome","start_blat_align","end_blat_align")]
	oma02<-data.frame(oma02,rep("OMA02",nrow(oma02)))
	names(oma02)<-rn
	oma02$Chr<-paste("chr",oma02$Chr,sep="")
	sourceSeqAlignment<-rbind(sourceSeqAlignment,oma02)
	dim(sourceSeqAlignment)
	oma03<-OMA03Manifest[,c("Probe_ID","Chromosome","start_blat_align","end_blat_align")]
	oma03<-data.frame(oma03,rep("OMA03",nrow(oma03)))
	names(oma03)<-rn
	oma03$Chr<-paste("chr",oma03$Chr,sep="")
	sourceSeqAlignment<-rbind(sourceSeqAlignment,oma03)
	oma04<-OMA04Manifest[,c("Probe_ID","chromosome","blat_align_start","blat_align_end")]
	oma04<-data.frame(oma04,rep("OMA04",nrow(oma04)))
	names(oma04)<-rn
	oma04$Chr<-paste("chr",oma04$Chr,sep="")
	sourceSeqAlignment<-rbind(sourceSeqAlignment,oma04)
	ml<-MethyLightManifest[,c("Reaction Number","Chr_blat_aligned","start_genome_coord_blat_aligned","end_genome_coord_blat_aligned")]
	ml<-data.frame(ml,rep("MethyLight",nrow(ml)))
	names(ml)<-rn
	sourceSeqAlignment<-rbind(sourceSeqAlignment,ml)
	names(sourceSeqAlignment)<-rn
	table(sourceSeqAlignment$Platform)
	table(sourceSeqAlignment$Chr)
	sqliteWriteTable(con,"SourceSeqAlignment",sourceSeqAlignment,append=T)
	dbDisconnect(con)
}

createFlankSeqAnnotTable<-function(dbname=NULL){
	if(is.null(dbname)) dbname<-"c:\\tcga\\others\\manifestDB.sqlite"
	con<-dbConnect(dbDriver("SQLite"),dbname=dbname)
	rn<-c("Probe_ID","Number_of_C","Number_of_G","Number_of_CpG","GC_Connect","Obs/Exp_CpG")
	flankSeqAnnot<-humanMeth27k[,c("ILmnID","Number of C [Without repeatMasked]","Number of G [Without repeatMasked]","Number of CpG [Without repeatMasked]","GC_Content [Without repeatMasked]","Obs/Exp CpG [Without repeatMasked]")]
	flankSeqAnnot<-data.frame(flankSeqAnnot,rep("meth27",nrow(humanMeth27k)))
	names(flankSeqAnnot)<-rn
	OMA02Manifest$GC_Content<-NA
	oma02<-OMA02Manifest[,c("Probe_ID","Number.of.C.in.500.bp.no.repeat.masking.","Number.of.G.in.500.bp.no.repeat.masking.","Number.of.CpGs.in.500.bp.no.repeat.masking.","GC_Content","CpG.O.E.no.repeat.masking.")]
	oma02<-data.frame(oma02,rep("OMA02",nrow(oma02)))
	names(oma02)<-rn
	flankSeqAnnot<-rbind(flankSeqAnnot,oma02)
	oma03<-OMA03Manifest[,c("Probe_ID","Number.of.C.in.500.bp.no.repeat.masking.","Number.of.G.in.500.bp.no.repeat.masking.","Number.of.CpGs.in.500.bp.no.repeat.masking.","X.G.C.no.repeat.masking.","CpG.O.E.no.repeat.masking.")]
	oma03<-data.frame(oma03,rep("OMA03",nrow(oma03)))
	names(oma03)<-rn
	flankSeqAnnot<-rbind(flankSeqAnnot,oma03)
	#oma04<-OMA04Manifest[,c("Probe_ID",)]
	#ml
	dbListTables(con)
	sqliteWriteTable(con,"500FlankSeqAnnot",flankSeqAnnot,append=T)
	dbDisconnect(con)
}

createProbeNearestAnnotTable<-function(dbname=NULL){
	if(is.null(dbname)) dbname<-"c:\\tcga\\others\\manifestDB.sqlite"
	con<-dbConnect(dbDriver("SQLite"),dbname=dbname)
	rn<-c("Probe_ID","Probe_ID2","Distance")
	nearestProbeAnnot<-humanMeth27k[,c("ILmnID","Nearest probe on OMA-002 beadarray","Distance of Infinium CpG to OMA-002 CpG [bp]")]
	names(nearestProbeAnnot)<-rn
	meth27<-humanMeth27k[,c("ILmnID","nearest probe on OMA-003 beadarray","Distance of Infinium CpG to OMA-003 CpG [bp]")]
	names(meth27)<-rn
	nearestProbeAnnot<-rbind(nearestProbeAnnot,meth27)
	meth27a<-humanMeth27k[,c("ILmnID","Nearest probe on OMA-004 beadarray","Distance of Infinium CpG to OMA-004 CpG [bp]")]
	names(meth27a)<-rn
	nearestProbeAnnot<-rbind(nearestProbeAnnot,meth27a)
	meth27b<-humanMeth27k[,c("ILmnID","MethyLight HB-Number","nearest_distance_to MethyLight")]
	names(meth27b)<-rn
	nearestProbeAnnot<-rbind(nearestProbeAnnot,meth27b)
	oma02<-OMA02Manifest[,c("Probe_ID","MethyLight_ID","Distance_to_ML(bp)")]
	names(oma02)<-rn
	nearestProbeAnnot<-rbind(nearestProbeAnnot,oma02)
	oma03<-OMA03Manifest[,c("Probe_ID","MethyLight_ID","Distance_to_ML(bp)")]
	names(oma03)<-rn
	nearestProbeAnnot<-rbind(nearestProbeAnnot,oma03)
	oma04<-OMA04Manifest[,c("Probe_ID","Nearest_OMA02_Probe","Distance_to_OMA02_Probe")]
	names(oma04)<-rn
	nearestProbeAnnot<-rbind(nearestProbeAnnot,oma04)
	oma04a<-OMA04Manifest[,c("Probe_ID","Nearest_ML_Probe","Distance_to_ML")]
	names(oma04a)<-rn
	nearestProbeAnnot<-rbind(nearestProbeAnnot,oma04a)
	oma04b<-OMA04Manifest[,c("Probe_ID","Nearest_Infinium_Probe","Distance_to_Infinium_Probe")]
	names(oma04b)<-rn
	nearestProbeAnnot<-rbind(nearestProbeAnnot,oma04b)
	sqliteWriteTable(con,"NearestProbeAnnot",nearestProbeAnnot,append=T)
	dbDisconnect(con)
}
createEntrezGeneTable<-function(dbname=NULL,wdir=NULL){
	if(is.null(dbname))dbname<-"c:\\tcga\\others\\manifestDB.sqlite"
	con<-dbConnect(dbDriver("SQLite"),dbname=dbname)
	datSrc<-"ftp://ftp.ncbi.nih.gov/gene/DATA/gene_info.gz"
	if(is.null(wdir)) wdir<-"c:\\temp"
	download.file(datSrc,destfile=file.path(wdir,"gene_info.gz"))
	ungzip(file.path(wdir,"gene_info.gz"))
	file.rename(file.path(wdir,"gene_info"),file.path(wdir,"dat.txt"))
	readGeneInfo2(wdir)
	dat<-read.table(file=file.path(wdir,"out.txt"),sep="\t",header=F,as.is=T,stringsAsFactors=F)
	names(dat)<-c("GeneID","Symbol")
	datSrc2<-"ftp://ftp.ncbi.nih.gov/gene/DATA/gene_history.gz"
	download.file(datSrc2,destfile=file.path(wdir,"gene_history.gz"))
	ungzip(file.path(wdir,"gene_history.gz"))
	dat2<-read.table(file=file.path(wdir,"gene_history"),sep="\t",header=F,skip=1,as.is=T)
	names(dat2)<-c("tax_id", "GeneID", "Discontinued_GeneID", "Discontinued_Symbol", "Discontinue_Date")
	ind<-dat2$tax_id=="9606"
	dat2<-dat2[ind,]
	sqliteWriteTable(con,"EntrezGene",dat)
	dbDisconnect(con)
}

createEntrezGeneAnnotTable<-function(dbname=NULL){
	if(is.null(dbname)) dbname<-"c:\\tcga\\others\\manifestDB.sqlite"
	con<-dbConnect(dbDriver("SQLite"),dbname=dbname)
	library(mAnnot)
	getData()
	rn<-c("Probe_ID","GeneID","Symbol","Platform")
	entrezGeneAnnot<-humanMeth27k[,c("ILmnID","GID_Update","Symbol")]
	entrezGeneAnnot<-data.frame(entrezGeneAnnot,rep("meth27",nrow(humanMeth27k)))
	names(entrezGeneAnnot)<-rn
	getData("OMA04")
	oma04<-OMA04Manifest[,c("Probe_ID","Entrez_Gene_ID_updated","Symbol_updated")]
	oma04<-data.frame(oma04,rep("OMA04",nrow(oma04)))
	names(oma04)<-rn
	entrezGeneAnnot<-rbind(entrezGeneAnnot,oma04)
	getData("OMA03")
	oma03<-OMA03Manifest[,c("Probe_ID","Gene_ID","Symbol")]
	oma03<-data.frame(oma03,rep("OMA03",nrow(oma03)))
	names(oma03)<-rn
	entrezGeneAnnot<-rbind(entrezGeneAnnot,oma03)
	getData("OMA02")
	oma02<-OMA02Manifest[,c("Probe_ID","Gene_ID","Symbol")]
	oma02<-data.frame(oma02,rep("OMA02",nrow(oma02)))
	names(oma02)<-rn
	entrezGeneAnnot<-rbind(entrezGeneAnnot,oma02)
	sqliteWriteTable(con,"EntrezGeneAnnot",entrezGeneAnnot)
	dbDisconnect(con)
}

createRefGeneTable<-function(dbname=NULL,wdir=NULL){
	refGene<-downloadRefSeq(wdir)
	if(is.null(dbname)) dbname<-"c:\\tcga\\others\\manifestDB.sqlite"
	con<-dbConnect(dbDriver("SQLite"),dbname=dbname)
	sqliteWriteTable(con,"RefGene",refGene)
	dbDisconnect(con)
}
downloadRefSeq<-function(wdir){
	datURL<-"ftp://hgdownload.cse.ucsc.edu/goldenPath/hg18/database/refGene.txt.gz"
	if(is.null(wdir)) wdir<-"c:\\temp"
	download.file(datURL,destfile=file.path(wdir,"refGene.txt.gz"))
	ungzip(file.path(wdir,"refGene.txt.gz"))
	refGene<-read.table(file=file.path(wdir,"refGene.txt"),sep="\t",header=F,as.is=T,stringsAsFactors=F)
	refGene<-data.frame(refGene,rep("hg18",nrow(refGene)))
	refGene<-refGene[,-1]
	names(refGene)<-c("Name","Chrom","Strand","TxStart","TxEnd","CdsStart","CdsEnd","ExonCount","ExonStarts","ExonEnds","Id","Name2","CdsStartStat","CdsEndStat","ExonFrames","GenomeBuild")
	return(refGene)
}
createRefGeneAnnotTable<-function(dbname=NULL){
	library(mAnnot)
	getData()
	refGeneAnnot<-humanMeth27k[,c("ILmnID","Primary/Secondary Locus [P/S]","Dist_To_-100bpTSS","in Transcription Region","in Extron Region")]
	refGeneAnnot<-data.frame(refGeneAnnot,rep("meth27",nrow(humanMeth27k)))
	rn<-c("ID","Primary_Probe","Distance_to_Upstream_100bp","Within_Transcription_Region","Within_Exon_Region","Platform")
	names(refGeneAnnot)<-rn
	getData("OMA04")
	oma04<-OMA04Manifest[,c("Probe_ID")]
	getData("OMA03")
	oma03<-OMA03Manifest[,c("Probe_ID","Primary.Secondary.Reaction.P.is.Closest.to.100.","Absolute.Distance.to.100")]
	oma03<-data.frame(oma03,rep(NA,nrow(oma03)),rep(NA,nrow(oma03)),rep("OMA03",nrow(oma03)))
	names(oma03)<-rn
	refGeneAnnot<-rbind(refGeneAnnot,oma03)
	getData("OMA02")
	oma02<-OMA02Manifest[,c("Probe_ID","Primary.Secondary.Reaction.P.is.Closest.to.100.","Absolute.Distance.to.100")]
	oma02<-data.frame(oma02,rep(NA,nrow(oma02)),rep(NA,nrow(oma02)),rep("OMA02",nrow(oma02)))
	names(oma02)<-rn
	refGeneAnnot<-rbind(refGeneAnnot,oma02)
	if(is.null(dbname)) dbname<-"c:\\tcga\\others\\manifestDB.sqlite"
	con<-dbConnect(dbDriver("SQLite"),dbname=dbname)
	sqliteWriteTable(con,"RefGeneAnnot",refGeneAnnot)
	dbDisconnect(con)
}