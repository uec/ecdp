# TODO: Add comment
# 
# Author: feipan
###############################################################################

runPBR<-function(txt){
	linearNormalization(txt)
}
runRBnorm<-function(txt){
	linearNormalization(txt,method="RBN")
}
runMAnorm<-function(txt){
	require(limma)
	fileName<-tclvalue(tkgetOpenFile(filetypes="{{{CSV File} {.csv}} {{All File} *}}"))
	if(!nchar(fileName)){
		msg<-"pls select a data matrix file first\n"
		tkmessageBox(message=msg)
		stop(msg)
	}
	dataAll<-readDataFile.2(fileName,header1=T)
	dataNorm<-normalizeBetweenArrays(as.matrix(dataAll))
	return(dataNorm)
}
runPBR_ADJ<-function(txt){
	require(PBR)
	PBR_AdjDialog("PBR ADJ Normalization")
	if(!exists("Normalization_dataAll"))return()
	if(!nchar(Normalization_dataAll)||!nchar(Normalization_batch_set_ref)){
		msg<-"Please select the data matrix and batch set reference\n"
		tkmessageBox(message=msg)
		stop(msg)
	}
	dataAll<-readDataFile.2(Normalization_dataAll,header1=T)
	dataFactor<-readDataFile.2(Normalization_batch_set_ref,header1=T)
	ord<-order(names(dataFactor))
	if(nrow(dataAll)!=nrow(dataFactor) | !any(names(dataFactor)==names(dataAll))){
		cat("data matrix should have the same length and col name of data batch set ref\n")
	}
	dataFactor<-dataFactor[,ord]
	dataAll<-dataAll[,order(names(dataAll))]
	dataBatch<-dataFactor[1,]
	dataSet<-dataFactor[2,]
	dataRef<-dataFactor[3,]
	dataNorm<-PBR.ADJ(dataAll,dataBatch,dataSet,dataRef)
	if(exists("Normalization_dataAll"))rm("Normalization_dataAll",envir=.GlobalEnv)
	if(exists("Normalization_batch_set_ref"))rm("Normalization_batch_set_ref",envir=.GlobalEnv)
	return(dataNorm)
}
linearNormalization<-function(txt=NULL,toPlot=F,toSave=T,method="PBR"){
	require(PBR)
	linearNormalizationDialog("Batch Normalization",method=method)
	if(!exists("normalization_FN_Y"))return()
	if(!nchar(normalization_FN_Y) ||!nchar(normalization_FN_Batch) ||!nchar(normalization_Scaling) ||!nchar(normalization_Median)){
		msg=">Please check the data has been loaded"
		tkinsert(txt,"end",msg)
		stop(msg)
	}
	if(!is.null(txt)){
		msg=paste(">Input data file ",normalization_FN_Y,"\n",sep="")
		tkinsert(txt,"end",msg)
		msg=paste(">Input batch file ",normalization_FN_Batch,"\n",sep="")
		tkinsert(txt,"end",msg)
	}
	
	#y<-read.table(file=normalization_FN_Y,sep=",",header=T,row.names=1)
	#x<-read.table(file=normalization_FN_Batch,sep=",",header=T,row.names=1)
	y<-readDataFile.2(normalization_FN_Y,header1=T)
	x<-readDataFile.2(normalization_FN_Batch,header1=T)
	x<-as.factor(x[1,])
	if(length(x)!=ncol(y)){
		msg<-"Please check the number of the batches is the same as the number of samples in the data\n"
		if(!is.null(txt)) tkinsert(txt,"end",msg)
		stop(msg)
	}
	ord<-order(names(x))
	x<-x[ord]
	y<-y[,order(names(y))]
	if(!any(names(x)==names(y))){
		msg<-"Please check the name of the batches match the names of the data\n"
		if(!is.null(txt)) tkinsert(txt,"end",msg)
		stop(mst)
	}
	y.new=NULL;
	x.new=NULL;
	y.norm=NULL;
	scaling <- normalization_Scaling
	median <- normalization_Median
	if(exists("normalization_FN_Y_new") && exists("normalization_FN_Batch_new")){
		if(!is.null(txt)){
			msg=paste(">Input new data file ",normalization_FN_Y_new,"\n",sep="")
			tkinsert(txt,"end",msg)
			msg=paste(">Input new batch file ",normalization_FN_Batch_new,"\n",sep="")
			tkinsert(txt,"end",msg)
		}
#		y.new<-read.table(file=normalization_FN_Y_new,header=T,sep=",",row.names=1)
#		x.new<-read.table(normalization_FN_Batch_new,header=T,sep=",",row.names=1)
		y.new<-readDataFile.2(normalization_FN_Y_new,header1=T)
		x.new<-readDataFile.2(normalization_FN_Batch_new,header1=T)
		x.new<-as.factor(x.new[1,])
		if(length(x.new)!=ncol(y.new)){
			msg<-"check data.new\n"
			if(!is.null(txt)) tkinsert(txt,"end",msg)
			stop(msg)
		}
		ord<-order(x.new)
		x.new<-x.new[ord]
		y.new<-y.new[,ord]
		if(!any(names(x.new)==names(y.new))){
			msg<-"check name of data new..\n"
			if(!is.null(txt)) tkinsert(txt,"end",msg)
			stop(msg)
		}
		y.norm<-PBR(y,x,y.new,x.new,scaling=scaling,median=median)
	}else{
		y.norm<-PBR(y,x,scaling=scaling,median=median)
	}
	if(toPlot==TRUE) normalizationPlot(y.norm)
	if(toSave==TRUE) {
		fn<-paste(normalization_FN_Y,".csv",sep="")
		write.table(as.dataframe(y.norm),file=fn,row.names=F,sep=",")
		cat(paste(">Done. Please check out the normalized data at ",fn,"\n",sep=""))
	}
	if(exists("normalization_FN_Y"))rm("normalization_FN_Y",envir = .GlobalEnv)
	if(exists("normalization_FN_Batch"))rm("normalization_FN_Batch",envir = .GlobalEnv)
	if(exists("normalization_FN_Y_new"))rm("normalization_FN_Y_new",envir = .GlobalEnv)
	if(exists("normalization_FN_Batch_new"))rm("normalization_FN_Batch_new",envir = .GlobalEnv)
	if(exists("normalization_Scaling"))rm("normalization_Scaling",envir = .GlobalEnv)
	if(exists("normalization_Median"))rm("normalization_Median",envir = .GlobalEnv)
	return(y.norm)
}
PBR_AdjDialog<-function(title=""){
	entryInit<-""
	returnValOnCancel <- "ID_CANCEL"
	entryWidth = 30
	dlg <- tktoplevel()
	tkwm.deiconify(dlg)
	tkgrab.set(dlg)
	tkfocus(dlg)
	tkwm.title(dlg,title)
	textEntryVarTcl <-tclVar(paste(entryInit))
	filetypes="{{EXCEL File} {.xls}} {{CSV File} {.csv}} {{All files} *}"
	getfile1<-function(){
		fileName<-tclvalue(tkgetOpenFile(filetypes=filetypes))
		assign("normaliztion_dataAll",fileName,envir = .GlobalEnv)
		tkconfigure(texEntryWidget1, textvariable=tclVar(fileName))
	}
	getfile2<-function(){
		fileName<-tclvalue(tkgetOpenFile(filetypes=filetypes))
		assign("normalization_batch_set_ref",fileName,envir = .GlobalEnv)
		tkconfigure(textEntryWidget2, textvariable=tclVar(fileName))
	}
	onOk<-function(){
		tkgrab.release(dlg)
		tkdestroy(dlg)
	}
	onCancel<-function(){
		tkgrab.release(dlg)
		tkdestroy(dlg)
		returnVar<<-returnValOnCancel
	}
	
	tkgrid(tklabel(dlg,text=" "))
	dlg1<-tkfrm(dlg)
	textEntryWidget1<-tkentry(dlg1,width=entryWidth,textvariable=textEntryVarTcl)
	tkbutton1<-tkbutton(dlg1,text="select",command=getfile1)
	tkgrid(tklabel(dlg1,text="DNA Methylation Data Matrix (Beta)"),textEntryWidget1,tkbutton1)
	
	textEntryWidget2<-tkentry(dlg1,width=entryWidth,textvariable=textEntryVarTcl)
	tkbutton2<-tkbutton(dlg1,text="select", command=getfile2)
	tkgrid(tklabel(dlg1,text="Normalization Batch Set Reference"),textEntryWidget2,tkbutton2)
	tkaddfrm(dlg,dlg1)
	button.ok<-tkbutton(dlg,text= "   OK   ",command=onOk)
	button.cl<-tkbutton(dlg,text=" Cancel ", command=onCancel)
	tkgrid(tklabel(dlg,text=" "),button.ok,button.cl)
	tkgrid(tklabel(dlg,text=" "))
	
	tkbind(dlg, "<Destroy>",function(){tkgrab.release(dlg)})
	tkwait.window(dlg)
}
linearNormalizationDialog<- function(title, method=NULL,entryInit="", entryWidth = 30,
		returnValOnCancel = "ID_CANCEL") {
	if(exists("normalization_FN_Y"))rm("normalization_FN_Y",envir = .GlobalEnv)
	if(exists("normalization_FN_Batch"))rm("normalization_FN_Batch",envir = .GlobalEnv)
	if(exists("normalization_FN_Y_new"))rm("normalization_FN_Y_new",envir = .GlobalEnv)
	if(exists("normalization_FN_Batch_new"))rm("normalization_FN_Batch_new",envir = .GlobalEnv)
	if(exists("normalization_Scaling"))rm("normalization_Scaling",envir = .GlobalEnv)
	if(exists("normalization_Median"))rm("normalization_Median",envir = .GlobalEnv)
	dlg <- tktoplevel()
	tkwm.deiconify(dlg)
	tkgrab.set(dlg)
	tkfocus(dlg)
	tkwm.title(dlg, title)
	textEntryVarTcl <- tclVar(paste(entryInit))
	
	getfile1<-function(){
		fileName <- tclvalue(tkgetOpenFile(filetypes = "{{CSV File} {.csv}} {{EXCEL File} {.xls}} {{All files} *}")) 
		if (!nchar(fileName)) {
			tkmessageBox(message = "Please select a file or type in the file name")
		} else {
			assign("normalization_FN_Y", fileName, envir = .GlobalEnv)
		}
		setwd(tclvalue(tclfile.dir(fileName)))
		tkconfigure(textEntryWidget1,textvariable=tclVar(fileName))
	}
	getfile2<-function(){
		fileName <- tclvalue(tkgetOpenFile(filetypes = "{{CSV File} {.csv}} {{All files} *}")) 
		if (!nchar(fileName)) {
			tkmessageBox(message = "Please select a file or type in the file name")
		} else {
			assign("normalization_FN_Batch", fileName, envir = .GlobalEnv)
		}
		tkconfigure(textEntryWidget2,textvariable=tclVar(fileName))
	}
	getfile3<-function(){
		fileName <- tclvalue(tkgetOpenFile(filetypes = "{{CSV File} {.csv}} {{All files} *}")) 
		if (!nchar(fileName)) {
			tkmessageBox(message = "No file was selected! Pls select a file or type in the file name")
		} else {
			assign("normalization_FN_Y_new", fileName, envir = .GlobalEnv)
		}
		tkconfigure(textEntryWidget3,textvariable=tclVar(fileName))
	}
	getfile4<-function(){
		fileName <- tclvalue(tkgetOpenFile(filetypes = "{{CSV File} {.csv}} {{All files} *}")) 
		if (!nchar(fileName)) {
			tkmessageBox(message = "No file was selected! Pls select a file or type in the file name")
		} else {
			assign("normalization_FN_Batch_new", fileName, envir = .GlobalEnv)
		}
		tkconfigure(textEntryWidget4,textvariable=tclVar(fileName))
	}
	rug = tklabel(dlg,text=" ")
	dlg1<-tkfrm(dlg)
	tkgrid(tklabel(dlg, text = "       "))
	textEntryWidget1 <- tkentry(dlg1, width = paste(entryWidth),textvariable = textEntryVarTcl)
	button.widget1 <- tkbutton(dlg1, text = "Select", command = getfile1)
	question = " DNA Methylation Data (Beta): "
	lab1<-tklabel(dlg1, text = question)
	tkgrid(lab1, textEntryWidget1,button.widget1,rug)
	tkgrid.configure(lab1,sticky="w")
	
	file2 = " DNA Methylation Batch Data : "
	textEntryWidget2 <- tkentry(dlg1, width = paste(entryWidth),textvariable = textEntryVarTcl)
	button.widget2 <- tkbutton(dlg1, text = "Select", command = getfile2)
	lab2<-tklabel(dlg1, text = file2)
	tkgrid(lab2, textEntryWidget2,button.widget2)
	tkgrid.configure(lab2,sticky="w")
	
	file3 = " DNA Methylation New Data (Optional): "
	textEntryWidget3 <- tkentry(dlg1, width = paste(entryWidth),textvariable = textEntryVarTcl)
	button.widget3 <- tkbutton(dlg1, text = "Select", command = getfile3)
	lab3<-tklabel(dlg1, text = file3)
	tkgrid(lab3, textEntryWidget3,button.widget3)
	tkgrid.configure(lab3,sticky="w")
	
	file4 = " DNA Methylation New Batch (Optional): "
	textEntryWidget4 <- tkentry(dlg1, width = paste(entryWidth),textvariable = textEntryVarTcl)
	button.widget4 <- tkbutton(dlg1, text = "Select", command = getfile4)
	lab4<-tklabel(dlg1, text = file4)
	tkgrid(lab4, textEntryWidget4,button.widget4)
	tkgrid.configure(lab4,sticky="w")
	
	#radiobutton1 = "Scaling: "
	rb1 <- tkradiobutton(dlg1)
	rb2 <- tkradiobutton(dlg1)
	rbValue_Scaling <- tclVar("TRUE")
	tkconfigure(rb1,variable=rbValue_Scaling,value="TRUE")
	tkconfigure(rb2,variable=rbValue_Scaling,value="FALSE")
	#tkgrid(tklabel(dlg,text="Scaling:"),tklabel(dlg,text="True "),rb1,tklabel(dlg,text="False "),rb2)
	
#	#radiobutton2 = "Median: "
#	rb3 <- tkradiobutton(dlg1)
#	rb4 <- tkradiobutton(dlg1)
#	rbValue_Median <- tclVar("FALSE")
#	tkconfigure(rb3,variable=rbValue_Median,value="TRUE")
#	tkconfigure(rb4,variable=rbValue_Median,value="FALSE")
#	lab5<-tklabel(dlg1,text="Median:")
#	tkgrid(lab5,tklabel(dlg1,text="True "),rb3,tklabel(dlg1,text="False "),rb4)
#	tkgrid.configure(lab5,sticky="w")
	#tkgrid(tklabel(dlg1, text = "       "))
	tkaddfrm(dlg,dlg1)
	
	ReturnVal <- returnValOnCancel
	onOK <- function() {
		if(!exists("normalization_FN_Y")){
			ReturnVal=tclvalue(tkget(textEntryWidget1))
			assign("normalization_FN_Y", ReturnVal, envir = .GlobalEnv)
		}
		if(!exists("normalization_FN_Batch")){
			ReturnVal=tclvalue(tkget(textEntryWidget1))
			assign("normalization_FN_Batch", ReturnVal, envir = .GlobalEnv)
		}
		if(!exists("normalization_FN_Y_new")){
			ReturnVal=tclvalue(tkget(textEntryWidget1))
			assign("normalization_FN_Y_new", ReturnVal, envir = .GlobalEnv)
		}
		if(!exists("normalization_FN_Batch_new")){
			ReturnVal=tclvalue(tkget(textEntryWidget1))
			assign("normalization_FN_Batch_new", ReturnVal, envir = .GlobalEnv)
		}
		if(method=="PBR"){
			#assign("normalization_Scaling",tclvalue(rbValue_Scaling),envir=.GlobalEnv)
			assign("normalization_Scaling","TRUE",envir=.GlobalEnv)
		}else{
			assign("normalization_Scaling","FALSE",envir=.GlobalEnv)
		}
		assign("normalization_Median",tclvalue(rbValue_Median),envir=.GlobalEnv)
		tkgrab.release(dlg)
		tkdestroy(dlg)
		#tkfocus(ttMain)
	}
	onCancel <- function() {
		ReturnVal <<- returnValOnCancel
		tkgrab.release(dlg)
		tkdestroy(dlg)
		#tkfocus(ttMain)
	}
	OK.but <- tkbutton(dlg, text = "   OK   ", command = onOK)
	Cancel.but <- tkbutton(dlg, text = " Cancel ", command = onCancel)
	tkgrid(tklabel(dlg,text=""),OK.but, Cancel.but)
	tkgrid(tklabel(dlg, text = "    "))
	
	tkfocus(dlg)
	tkbind(dlg, "<Destroy>", function() {
				tkgrab.release(dlg); 
				#tkfocus(ttMain)
			})
	tkwait.window(dlg)
	return(ReturnVal)
}

# TODO: Start to use mSet

ebaysNormalization<-function(txt){
	tkmessageBox(
			message = "This feature is under development")

}
fitModel.linear <- function(y,x){
	mod.ln<-function(y1,x){
		x<-as.factor(x)
		y1<-as.numeric(y1)
		mod <- lm(y1~x)
		mod$residuals+mean(y1)
	}
	t(apply(y,1,mod.ln,x))
}

fitModel.ln2b <- function(y,x,y.new,x.new,scaling=TRUE,median=FALSE,debug=F,capMethod="capMax"){
	if(debug){
		browser()
	}
	if(is.null(y) || is.null(x) ||is.null(y.new)||is.null(x.new)){
		stop("please check the input data is not NULL\n")
	}
	if(dim(y)[1]!=dim(y.new)[1]){
		stop("The row number of the y and y.new are expected to be the same\n")
	}
	x<-as.factor(x)
	if(nlevels(x)<nlevels(as.factor(x.new))){
		stop("please check the number of the levels of x is not less than that of x.new\n")
	}
	if(ncol(y.new)!=length(x.new)){
		stop("please check the input of batch.new and y.new,same number of col are expected.\n")
	}
	x.new<-factor(x.new,levels=levels(x))
	n.row <- nrow(y.new)
	n.col <- ncol(y.new)
	y.norm <- NULL
	y.new <- y.new[,order(x.new)]
	x.new <-x.new[order(x.new)]
	
	rep.batch<-function(y,batch,batch.new){
		batch=levels(batch)
		dat<-data.frame(Y=y,batch=batch)
		dat1<-data.frame(batch.new=batch.new)
		rst<-merge(dat1,dat,by.x=1,by.y=2,all.x=T)
		rst<-rst[order(batch.new),]
		return(rst$Y)
	}
	for(i in 1:dim(y.new)[1]){
		y1<-as.numeric(y[i,])
		if(median==T){
			md<-tapply(y1,x,median)
			y.pred<-rep.batch(md,x,x.new)
			if(scaling){
				y.pred<-y.new[i,]*median(y1)/y.pred
			}else{
				y.pred<y.new[i,]-y.pred+median(y1)
			}
		}else{#case of median==F
			md<-tapply(y1,x,mean)
			y.pred<-rep.batch(md,x,x.new)
			if(scaling==T){
				y.pred<-y.new[i,]*mean(y1)/y.pred
			}else{
				#case of scaling ==F
				y.pred<-y.new[i,]-y.pred+mean(y1)
			}
		}
		y.pred <-as.numeric(y.pred)
		y.norm <-c(y.norm,y.pred)
		if(capMethod == "capMax"){
			y.norm<-replace(y.norm,which(y.norm>1),1)
		} else if(capMethod=="fisher"){ #linear trans
			require(VGAM)
			y.norm<-fisherz(y.norm,inverse=T)
		}
	}
	matrix(y.norm,n.row,n.col)
}
fitModel.ln2 <- function(y,x,y.new,x.new,scaling=TRUE,median=FALSE,debug=F,capMax=T){
	if(debug){
		browser()
	}
	if(is.null(y) || is.null(x) ||is.null(y.new)||is.null(x.new)){
		stop("please check the input data is not NULL\n")
	}
	if(dim(y)[1]!=dim(y.new)[1]){
		stop("The row number of the y and y.new are expected to be the same\n")
	}
	x<-as.factor(x)
	if(nlevels(x)<nlevels(as.factor(x.new))){
		stop("please check the number of the levels of x is not less than that of x.new\n")
	}
	if(ncol(y.new)!=length(x.new)){
		stop("please check the input of batch.new and y.new,same number of col are expected.\n")
	}
	x.new<-factor(x.new,levels=levels(x))
	n.row <- nrow(y.new)
	n.col <- ncol(y.new)
	y.norm <- NULL
	y.new <- y.new[,order(x.new)]
	x.new <-x.new[order(x.new)]
#	rep.batch<-function(y,batch){
#		n.batch <- as.numeric(lapply(split(batch,batch),length))
#		y.tot <-NULL
#		for(i in 1:nlevels(batch)){
#			y.tot<-c(y.tot,rep(y[i],n.batch[i]))
#		}
#		return(y.tot)
#	}
	rep.batch<-function(y,batch,batch.new){
		batch=levels(batch)
		dat<-data.frame(Y=y,batch=batch)
		dat1<-data.frame(batch.new=batch.new)
		rst<-merge(dat1,dat,by.x=1,by.y=2,all.x=T)
		rst<-rst[order(batch.new),]
		return(rst$Y)
	}
	for(i in 1:dim(y.new)[1]){
		y1<-as.numeric(y[i,])
		if(median==T){
			md<-tapply(y1,x,median)
			y.pred<-rep.batch(md,x,x.new)
			if(scaling){
				y.pred<-y.new[i,]*median(y1)/y.pred
			}else{
				y.pred<y.new[i,]-y.pred+median(y1)
			}
		}else{#case of median==F
			mod <- lm(y1~x)
			coef <- mod$coefficients
			names(coef)<-names(table(x))
			y.pred <- c(coef[1],c(coef+coef[1])[-1])
			#y.pred=y.new[i,]-rep.batch(y.pred,x.new)+mean(y1)
			y.pred<-rep.batch(y.pred,x,x.new)
			if(scaling==T){
				y.pred<-y.new[i,]*mean(y1)/y.pred
			}else{
				#case of scaling ==F
				y.pred<-y.new[i,]-y.pred+mean(y1)
			}
		}
		y.pred <-as.numeric(y.pred)
		y.norm <-c(y.norm,y.pred)
		if(capMax==T) y.norm<-replace(y.norm,which(y.norm>1),1)
	}
	matrix(y.norm,n.row,n.col)
}

simBetaData<-function(){
#	batch <- as.factor(rep(c(1,2,3),3))
#	M <- matrix(rgamma(900,0.8),100,9)
#	U <- matrix(rgamma(900,0.4),100,9)
#	beta.raw <- M/(M+U)
	
	batch <- as.factor(rep(c(1,2,3),3))
	beta.raw <- matrix(rbeta(900,0.8,0.5),100,9)
	return(list(beta=beta.raw,batch=batch))
}
simNormData<-function(){
	dat <- matrix(rnorm(1000),50,20)
	batch<-as.factor(c(rep(c(1,2,3),6),1,3))
	dat.new<-matrix(rnorm(300),50,6)
	batch.new<-as.factor(c(1,2,3,1,2,2))
	return(list(beta=dat,batch=batch,beta.new=dat.new,batch.new=batch.new))
}

#################
# from PBR packages
################
PBR<-function (y, x, y.new = NULL, x.new = NULL, scaling = TRUE, median = FALSE) 
{
	if (!is.factor(x)) 
		x <- factor(x)
	y.all <- y
	if (!is.null(x.new)) {
		x.new <- factor(x.new)
		y.all <- cbind(as.data.frame(y), as.data.frame(y.new))
	}
	PBR1 <- function(y.all, x, x.new = NULL, scaling = TRUE, 
			median = TRUE) {
		y.m <- NULL
		n <- length(x)
		y <- as.numeric(y.all[1:n])
		if (is.null(x.new)) {
			x.new <- x
			y.new <- y
		}
		else {
			y.new <- y.all[(n + 1):(n + length(x.new))]
		}
		if (median) {
			y.bm <- tapply(y, x, median, na.rm = T)
			y.m <- median(y, na.rm = T)
		}
		else {
			y.bm <- tapply(y, x, mean, na.rm = T)
			y.m <- mean(y, na.rm = T)
		}
		y.norm <- y.new
		rep.batch <- function(y.bm, x.new) {
			x.table <- table(x.new)
			n <- length(x.new)
			y1 <- c()
			for (i in 1:n) {
				y1 <- c(y1, rep(as.numeric(y.bm[x.new[i]], x.table[x.new[i]])))
			}
			return(y1)
		}
		y.pred <- rep.batch(y.bm, x.new)
		resid <- y.new - y.pred
		if (scaling) {
			if (!any(y.pred == 0 || y.pred == 1 || is.na(y.pred))) 
				y.norm <- ifelse(resid > 0, (resid * (1 - y.m)/(1 - 
										y.pred) + y.m), y.m * (1 + resid/y.pred))
		}
		else {
			y.norm <- resid + y.m
		}
		y.norm
	}
	t(apply(y.all, 1, PBR1, x, x.new, scaling, median))
}

######################
# Jan 10, 2010
######################
normalizeTCGAPkg.2_test<-function(){
	tcgaPath<-"c:\\temp\\tcga"
	outPath<-"c:\\temp\\test"
	reposPath<-"c:\\temp\\tcga\\repos"
	normalizeTCGAPkg.2(tcgaPath,outPath)
}
normalizeTCGAPkg.2<-function(tcgaPath=NULL,outPath=NULL,reposPath=NULL,toPlot=T,toValidate=T){
	if(is.na(tcgaPath)) tcgaPath<-"/auto/uec-02/shared/production/methylation/meth27k/tcga"
	if(is.na(outPath)) outPath<-"/auto/uec-02/shared/production/methylation/meth27k/normalized"
	cancerType<-list.files(tcgaPath)
	cancerType<-cancerType[-grep("repos",cancerType)]
	for (cn in cancerType){
		curDir<-file.path(tcgaPath,cn)
		clearTCGARepos(curDir,reposPath)
		Pkgs<-list.files(curDir,pattern=".gz")
		Pkgs<-Pkgs[-grep("md5",Pkgs)]
		lvl3Pkgs<-Pkgs[grep("Level_3",Pkgs)]
		outDir<-file.path(outPath,cn)
		if(!file.exists(outDir)) dir.create(outDir)
		for(lvl3Pkg in lvl3Pkgs) uncompress(file.path(curDir,lvl3Pkg),outDir)
		lvl3FNs<-list.files(outDir,pattern=".txt",recursive=T)
		lvl3FNs<-lvl3FNs[-grep("MANIFEST*|DESCRIPTION*",lvl3FNs)]
		lvl3Data<-NULL;pids<-NULL
		Sids<-c();SNs<-c()
		for(fn in lvl3FNs){
			dat<-read.delim(file=file.path(outDir,fn),sep="\t",header=F,row.names=1,as.is=T)
			Sids<-c(Sids,dat[1,2])
			dat<-dat[-c(1,2),]
			if(is.null(pids)) {
				pids<-row.names(dat)
				lvl3Data<-data.frame(as.numeric(dat[,1]))
			}
			else{ 
				dat<-dat[pids,]
				lvl3Data<-data.frame(lvl3Data,as.numeric(dat[,1]))
			}
			sn<-strsplit(filetail(fn),"\\.")[[1]][[4]]
			SNs<-c(SNs,sn)
		}
		row.names(lvl3Data)<-pids
		names(lvl3Data)<-Sids
		names(SNs)<-Sids
		rst<-removeNormalSamples(lvl3Data)
		lvl3Data<-rst$tumor
		lvl3Data.n<-rst$norm
		SNs.n<-SNs[names(lvl3Data.n)]
		SNs<-SNs[names(lvl3Data)]
		if(length(SNs)<=1) next
		lvl3Data.norm<-PBR(lvl3Data,as.factor(SNs))
		if(nrow(lvl3Data.n)>0){
			lvl3Data.nnorm<-PBR(lvl3Data,as.factor(SNs),lvl3Data.n,as.factor(SNs.n))
			SNs<-c(SNs,SNs.n)
			ind<-order(SNs)
			SNs<-SNs[ind]
			lvl3Data<-cbind(lvl3Data,lvl3Data.n)[,ind]
			lvl3Data.norm<-cbind(lvl3Data.norm,lvl3Data.nnorm)[,ind]
		}
		save(lvl3Data,file=file.path(outDir,paste(cn,".rdata",sep="")))
		save(lvl3Data.norm,file=file.path(outDir,paste(cn,".norm.rdata",sep="")))
		
		if(toPlot==T){
			boxplot.2(lvl3Data,color=SNs,main="Before Normalization",fn=file.path(outDir,paste(cn,".png",sep="")))
			boxplot.2(lvl3Data.norm,color=SNs,main="After Normalization",fn=file.path(outDir,paste(cn,".norm.png",sep="")))
		}
		lvl3PkgNM<-sapply(lvl3Pkgs,function(x)gsub(".tar.gz","",x))
		dimnames(lvl3Data.norm)[[2]]<-names(lvl3Data)
		for(pn in lvl3PkgNM){
			if(!file.exists(file.path(outDir,pn))) dir.create(file.path(outDir,pn))
		}
		createNormalizedPkgs(lvl3Data.norm,outDir,lvl3PkgNM,SNs)
		if(toValidate==T){
			magePkg<-Pkgs[grep("mage",Pkgs)]
			file.copy(file.path(curDir,magePkg),file.path(outDir,magePkg),overwrite=T)
			file.copy(paste(file.path(curDir,magePkg),".md5",sep=""),paste(file.path(outDir,magePkg),".md5",sep=""),overwrite=T)
			lvl12Pkgs<-Pkgs[grep("Level_1|Level_2",Pkgs)]
			for(pkg in lvl12Pkgs){
				file.copy(file.path(curDir,pkg),file.path(outDir,pkg),overwrite=T)
				file.copy(paste(file.path(curDir,pkg),".md5",sep=""),paste(file.path(outDir,pkg),".md5",sep=""),overwrite=T)
			}
			validatePkg(outDir)
		}
	}
}
normalizeTCGAPkg_test<-function(){
	tcgaPath<-"c:\\temp\\tcga"
	outPath<-"c:\\temp\\test"
	normalizeTCGAPkg(tcgaPath,outPath)
}

normalizeTCGAPkg<-function(tcgaPath=NULL,outPath=NULL,toPlot=T){
	if(is.na(tcgaPath)) tcgaPath<-"/auto/uec-02/shared/production/methylation/meth27k/tcga"
	if(is.na(outPath)) outPath<-"/auto/uec-02/shared/production/methylation/meth27k/normalized"
	cancerType<-list.files(tcgaPath)
	cancerType<-cancerType[-grep("repos",cancerType)]
	for (cn in cancerType){
		curDir<-file.path(tcgaPath,cn)
		Pkgs<-list.files(curDir,pattern=".gz")
		Pkgs<-Pkgs[-grep("md5",Pkgs)]
		lvl3Pkgs<-Pkgs[grep("Level_3",Pkgs)]
		outDir<-file.path(outPath,cn)
		if(!file.exists(outDir)) dir.create(outDir)
		for(lvl3Pkg in lvl3Pkgs) uncompress(file.path(curDir,lvl3Pkg),outDir)
		lvl3FNs<-list.files(outDir,pattern=".txt",recursive=T)
		lvl3FNs<-lvl3FNs[-grep("MANIFEST*|DESCRIPTION*",lvl3FNs)]
		lvl3Data<-NULL;pids<-NULL
		Sids<-c();SNs<-c()
		for(fn in lvl3FNs){
			dat<-read.delim(file=file.path(outDir,fn),sep="\t",header=F,row.names=1,as.is=T)
			Sids<-c(Sids,dat[1,2])
			dat<-dat[-c(1,2),]
			if(is.null(pids)) {
				pids<-row.names(dat)
				lvl3Data<-data.frame(as.numeric(dat[,1]))
			}
			else{ 
				dat<-dat[pids,]
				lvl3Data<-data.frame(lvl3Data,as.numeric(dat[,1]))
			}
			sn<-strsplit(filetail(fn),"\\.")[[1]][[4]]
			SNs<-c(SNs,sn)
		}
		row.names(lvl3Data)<-pids
		names(lvl3Data)<-Sids
		names(SNs)<-Sids
		lvl3Data<-removeNormalSamples(lvl3Data)$tumor
		SNs<-SNs[names(lvl3Data)]
		if(length(SNs)<=1) next
		lvl3Data.norm<-PBR(lvl3Data,as.factor(SNs))
		save(lvl3Data,file=file.path(outDir,paste(cn,".rdata",sep="")))
		save(lvl3Data.norm,file=file.path(outDir,paste(cn,".norm.rdata",sep="")))
		if(toPlot==T){
			boxplot.2(lvl3Data,color=SNs,main="Before Normalization",fn=file.path(outDir,paste(cn,".png",sep="")))
			boxplot.2(lvl3Data.norm,color=SNs,main="After Normalization",fn=file.path(outDir,paste(cn,".norm.png",sep="")))
		}
		lvl3PkgNM<-sapply(lvl3Pkgs,function(x)gsub(".tar.gz","",x))
		dimnames(lvl3Data.norm)[[2]]<-names(lvl3Data)
		createNormalizedPkgs(lvl3Data.norm,outDir,lvl3PkgNM,SNs)
		magePkg<-Pkgs[grep("mage",Pkgs)]
		file.copy(file.path(curDir,magePkg),file.path(outDir,magePkg))
		file.copy(paste(file.path(curDir,magePkg),".md5",sep=""),paste(file.path(outDir,magePkg),".md5",sep=""))

	}
}

removeNormalSamples<-function(dat){
	samples<-names(dat)
	samples.type<-sapply(samples,function(x)strsplit(x,"-")[[1]][4])
	ind<-grep("20A|11A",samples.type)
	samples.norm<-samples[ind]
	samples.tumor<-samples[-ind]
	dat.norm<-dat[,samples.norm]
	dat.tumor<-dat[,samples.tumor]
	return(list(tumor=dat.tumor,normal=dat.norm))
}
createNormalizedPkgs<-function(dat.norm,outDir,Pkgs,SNs){
	dat.norm<-as.data.frame(dat.norm)
	if(!exists("HumanMethylation27.adf")) data(HumanMethylation27.adf)
	dat.norm<-dat.norm[HumanMethylation27.adf$IlmnID,]
	samples<-names(dat.norm)
	for(i in 1:length(Pkgs)){
		sn<-strsplit(Pkgs[i],"\\.")[[1]][5]
		sids<-samples[SNs==sn]
		dat.pkg<-dat.norm[,sids]
		pref<-paste(strsplit(Pkgs[i],"\\.")[[1]][c(1:3,5)],collapse=".")
		for(j in 1:length(sids)){
			sid<-sids[j]
			fn<-file.path(outDir,Pkgs[i],paste(pref,".lvl-3.",sid,".txt",sep=""))
			write(paste("Hybridization REF",sid,sid,sid,sid,sep="\t"),file=fn)
			write(paste("Composite Element REF","Beta_Value","Gene_Symbol","Chromosome","Genomic_Coordinate",sep="\t"),file=fn,append=T)
			dat<-data.frame(HumanMethylation27.adf$IlmnID,dat.pkg[,j],HumanMethylation27.adf$SYMBOL,HumanMethylation27.adf$Chr,HumanMethylation27.adf$MapInfo)
			write.table(dat,file=fn,sep="\t",quote=F,col.names=F,append=T,row.names=F)
		}
		createManifestByLevel.2(file.path(outDir,Pkgs[i]))
		compressDataPackage(file.path(outDir,Pkgs[i]))
	}
}
