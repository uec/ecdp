# TODO: Add comment
# 
# Author: feipan
###############################################################################

##############################
# plot and store all the control figures
##############################
probePlot_test<-function(){
	mData<-get(print(load(file="C:\\Documents and Settings\\feipan\\workspace\\methPipe\\data\\methData_test.rdata")))
	setwd("c:\\temp")
	gFileDir<-"c:\\temp"
	probePlot(mData=mData,data.dir=gFileDir)
	
	load(file="c:\\temp\\test2\\5543207015_idat.rda")
	probePlot(mData=idat,data.dir=gFileDir)
}
probePlot <-function(mData=NULL,txt=NULL,data.dir=NULL,fn=NULL,gtype="png"){
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Starting to generate the probe signal intensity plot ...",date(),"\n"))
	if(is.null(fn)){
		fn<-"mu_plot.png"
		if(gtype=="pdf") fn<-"mu_plot.pdf"
	}
	if(is.null(mData))mData<-get("mData",env=.GlobalEnv)
	g.M<-NULL;g.U<-NULL
	if(class(mData)=="MethyLumiSet"){
		g.M<-mData@assayData$methylated
		g.U<-mData@assayData$unmethylated
	}
	else {
		g.M=getM(mData)
		g.U=getU(mData)
	}
	if(is.null(data.dir))data.dir<-gFileDir
	MUplot(g.M,g.U,toFile=TRUE,pname=fn,data.dir,gtype=gtype)
	if(!is.null(txt)) tkinsert(txt,"end",">Finished generating the probe plots\n")
}
#probePlot <-function(txt=NULL,data.dir=NULL,mData=NULL){
#	if(!is.null(txt)) tkinsert(txt,"end",paste(">Starting to generate the probe signal intensity plot ...",date(),"\n"))
#	gdat<-mData
#	if(is.null(mData)) gdat<-loadRawData()
#	gdat.name<-"mu_plot.png"
#	if(is.null(data.dir)) data.dir<-gFileDir 
#	g.M=getM(gdat)
#	g.U=getU(gdat)
#	MUplot(g.M,g.U,toFile=TRUE,pname=gdat.name,data.dir)
#	if(!is.null(txt)) tkinsert(txt,"end",">Finished generating the probe plots\n")
#}
MUplot<-function(M,U,toFile=FALSE,pname="",data.dir="",gtype="png"){
	figName<-NULL
	if(toFile==FALSE){
		X11()
	}else{
		gdat.name=pname
		figName<-file.path(data.dir,gdat.name)
		if(gtype=="png") png(filename=figName,width=1280,height=1280)
		else pdf(file=figName,width=1280,height=1280)
	}
	#require(mLab)
	par(mfrow=c(2,2))
	plotDensity(M)
	plotDensity(U)
	boxplot(M,col="blue",main="M")
	boxplot(U,col="green",main="U")
	#mva.plot.1(as.numeric(M),as.numeric(U))
	#plot(as.numeric(M),as.numeric(U),col="yellow",ylab="M",xlab="U",main="MU")
	if(toFile==TRUE){
		dev.off()
		#shell.exec(figName)
	}
}

rfgc<-function(cData){
	rst.all<-NULL
	for(i in 1:length(cData)){
		#rst<-split(cData[[i]][,c(7,10)],as.factor(cData[[i]][,2]))
		rst<-split(cData[[i]][,c("Grn","Red")],as.factor(cData[[i]]$type))
		if(is.null(rst.all)){
			rst.all<-rst
		}else{
			for(j in 1:length(rst)){
				rst.all[[j]]<-c(rst.all[[j]],rst[[j]])
			}
		}
	}
	return(rst.all)
}
plotControlProfiles <- function(cData=NULL,figName="control_profile.png",toFile=FALSE,outDir,gtype="png")
{
	if(is.null(cData))
		cData<-readControlData()
	if(toFile==TRUE){
		if(gtype=="png")png(file=file.path(outDir,figName),width=1280,height=1280)
		else pdf(file=file.path(outDir,figName),width=1280,height=1280)
	}else{
		X11(width=1280,height=1280)
	}
	params <- par(bg="white")
	gData<-list()
	nn<-NULL
	if(class(cData)=="MethyLumiQC"){
		ctr.m<-cData@assayData$methylated
		ctr.u<-cData@assayData$unmethylated
		ctr.type<-featureData(cData)@data$Type
		for(i in 1:ncol(ctr.m)){
			dat<-data.frame(type=ctr.type,Grn=ctr.m[,i],Red=ctr.u[,i])
			gData<-c(gData,list(dat))
		}
		names(gData)<-dimnames(ctr.m)[[2]]
		gData<-rfgc(gData)
		nn<-unique(ctr.type)
	}
	else {
		gData<-rfgc(cData)
		nn<-unique(cData[[1]]$type)
	}
	n1<-ceiling(length(nn)/2)
	par(mfrow=c(n1,2))
	for(i in 1:length(nn)){
		name1<-names(gData[[i]])
		ind<-order(name1)
		dat<-NULL
		dat<-sapply(ind,function(x){c(dat,gData[[i]][[x]])})
		names(dat)<-name1[ind]
		boxplot(dat,col=(i+1),main=nn[i])
	}
	par(params)
	
	if(toFile==TRUE){
		dev.off()
		#shell.exec(file.path(outDir,figName))
	}
}
#plotControlProfiles <- function(cData=NULL,figName="control_profile.png",toFile=FALSE,outDir,gtype="png")
#{
#	if(is.null(cData))
#		cData<-readControlData()
#	if(toFile==TRUE){
#		if(gtype=="png")png(file=file.path(outDir,figName),width=1280,height=1280)
#		else pdf(file=file.path(outDir,figName),width=1280,height=1280)
#	}else{
#		X11(width=1280,height=1280)
#	}
#	params <- par(bg="white")
#	
#	gData<-rfgc(cData)
#	nn<-unique(cData[[1]]$type)
#	n1<-ceiling(length(nn)/2)
#	par(mfrow=c(n1,2))
#	for(i in 1:length(nn)){
#		name1<-names(gData[[i]])
#		ind<-order(name1)
#		dat<-NULL
#		dat<-sapply(ind,function(x){c(dat,gData[[i]][[x]])})
#		names(dat)<-name1[ind]
#		boxplot(dat,col=(i+1),main=nn[i])
#	}
#	par(params)
#	
#	if(toFile==TRUE){
#		dev.off()
#		#shell.exec(file.path(outDir,figName))
#	}
#}

##########
#########
controlPlot_test<-function(){
	cData<-get(print(load(file="C:\\Documents and Settings\\feipan\\workspace\\methPipe\\data\\cDat_test.rdata")))
	gFileDir<-"c:\\temp"
	controlPlot(cData=cData,outDir=gFileDir)
}
controlPlot<-function(mData=NULL,cData=NULL,txt=NULL,toSave=T,outDir=NULL,fn=NULL,gtype="png"){
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Start to generate the profile plots of the control probes ...",date(),"\n"))
	if(is.null(cData)){
		if(is.null(mData))cData<- get("cData",env=.GlobalEnv)#readControlData(txt);
		else cData<-mData@QC
	}
	if(is.null(outDir))outDir<-gFileDir
	if(toSave==TRUE){
		if(is.null(fn)){
			fn<-"control_plot.png" 
			if(gtype=="pdf") fn<-"control_plot.pdf"
		}
		plotControlProfiles(cData,figName=fn,toFile=toSave,outDir,gtype=gtype)
	}else{
		plotControlProfiles(cData,toFile=toSave,gtype=gtype)
	}
	if(!is.null(txt)) tkinsert(txt,"end",">Finished the control probe plots\n")
}

test_plot<-function(){
	Myhscale <- 1.5    # Horizontal scaling
	Myvscale <- 1.5    # Vertical scaling
	tt1 <- tktoplevel()
	tkwm.title(tt1,"A parabola")
	img <- tkrplot(tt1,fun=plotControlProfiles,hscale=Myhscale,vscale=Myvscale)
	tkgrid(img)
	copy.but <- tkbutton(tt1,text="Copy to Clipboard",command=function()CopyToClip())
	tkgrid(copy.but)
	x=-100:100
	y=x^2
	plot(x,y)
}
plotFailureRate_test<-function(){
	outDir<-"c:\\temp\\test2"
	load(file=file.path(outDir,"5543207015_idat.rda"))
	plotFailureRate(outDir=outDir,mData=idat)
}
plotFailureRate<-function(mData=NULL,txt=NULL,toSave=T,figName="FailureRate.png",outDir=NULL,pCut=0.05,sCut=0.1,gtype="png"){
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Start to generate the success rate plot ...",date(),"\n"))
	if(is.null(mData)){
		mData<- get("mData",envir=.GlobalEnv) #loadRawData()
	}
	perDetectRate<-calDetectionRate(mData,pCut)
	if(gtype=="pdf") figName<-"FailureRate.pdf"
	plotDetectRate(perDetectRate[[1]],toSave,figName,outDir,sCut,gtype=gtype)
	if(!is.null(txt)) tkinsert(txt,"end",">Finished the success rate plot\n")
	return(perDetectRate)
}
plotSuccessRate_test<-function(){
	mData<-get(print(load(file="C:\\Documents and Settings\\feipan\\workspace\\methPipe\\data\\methData_test.rdata")))
	plotFailureRate(outDir="c:\\temp",mData=mData)
}

controlIndexPlot<-function(txt=NULL,fromRawData=F,out.dir=NULL,toSave=F){
	if(is.null(cData)){
		if(fromRawData==TRUE){
			cData<-loadRawQCData()
		}else{
			cData<-loadQCData()
		}
	}
	
	if(is.null(out.dir)){
		out.dir<-gFileDir #tempdir();
	}
	
	controlIndex<-calControlIndex(cData)
	plotCtrIndex(controlIndex)
	if(toSave==T){
#		qcIndex<-list(dataIndex=perDetectRate,ctrIndex=controlIndex)
#		ctrIndex=list(perDetectRate=perDetectRate,controlIndex=controlIndex)
		#qcIndex<-list(ctrIndex=controlIndex)
		ctrIndex=list(controlIndex=controlIndex)
		save(ctrIndex,file=file.path(out.dir,"ctrIndex.rdata"))
		if(!is.null(txt)){
			tkconfigure(txt, state="normal")
			out<-paste("< Done\n Please check out the control Index report at ",out.dir,"/ctrIndex.rdata",sep="")
			tkinsert(txt,"end",out)
			tkconfigure(txt, state="disabled")
		}
	}
}
plotCtrIndex<-function(controlIndex,outdir=NULL,isLog=T){
	#X11()
	if(is.null(outdir)) outdir<-gFileDir
	figName<-file.path(outdir,"controlIndex.png")
	png(file=figName,width=1280,height=1280)
	len<-ceiling(length(controlIndex)/2)
	par(mfrow=c(len,2))
	#sapply(controlIndex,function(x)barplot(x,col=2:(length(x)+1)))#,main=names(x)))
	name1<-names(controlIndex)
	for(i in 1:length(controlIndex)){
		nm<-name1[i]
		dat<-controlIndex[[i]]
		if(isLog==T){
			dat<--log10(controlIndex[[i]])
		}
		ym<-NULL
		if(length(na.omit(dat)==0)){
			ym<-0.1
			next;
		}else{
			ym<-max(dat,na.rm=T)+0.1
		}
		barplot(dat,col=2:(length(dat)+1),main=nm,ylim=c(0,1))
	}
	dev.off()
	#shell.exec(figName)
}
plotDetectRate_test<-function(){
	perDetectRate<-c(0.0006164334,0.0003626079,0.0008702589,0.0003263471,0.0003263471,0.0001087824,0.0002175647)
	names(perDetectRate)<-c( "TCGA-AA-3675-01A-02D-1110-05","TCGA-AA-3966-01A-01D-1110-05", "TCGA-AA-3970-01A-01D-1110-05","TCGA-AA-3994-01A-01D-1110-05", "TCGA-AY-4070-01A-01D-1110-05","TCGA-AY-4071-01A-01D-1110-05")
	plotDetectRate(perDetectRate,T,"f.png","c:\\temp")
}
plotDetectRate<-function(perDetectRate,toSave,figName,outDir=NULL,sCut=0.1,gtype="png"){
	if(toSave==TRUE){
		if(is.null(outDir)) outDir<-gFileDir
		if(gtype=="png")png(file.path(outDir,figName),width=1200,height=1200)
		else pdf(file.path(outDir,figName),width=1200,height=1200)
	}else{
		X11()
	}
	tit<-"Proportion of Detection Pvalue Greater than 0.05"
	par(las=3,mar=c(10,4,4,2)+0.1,cex.lab=0.1)
	ylim<-ifelse(max(perDetectRate)>sCut,max(perDetectRate),sCut)+0.05
	barplot(perDetectRate,col=2:(length(perDetectRate)+1),ylab=tit,ylim=c(0,ylim),border=T)
	abline(sCut,0,col="red")
	if(toSave==TRUE){
		dev.off()
	}
}
#plotDetectRate<-function(perDetectRate,toSave,figName,outDir=NULL){
#	if(toSave==TRUE){
#		if(is.null(outDir)) outDir<-gFileDir
#		png(file.path(outDir,figName),width=1200,height=1200)
#	}else{
#		X11()
#	}
#	tit<-"Percentage of Detection Pvalue Greater than 0.05"
#	par(las=3,mar=c(10,4,4,2)+0.1,cex.lab=0.1)
#	barplot(perDetectRate,col=2:(length(perDetectRate)+1),main=tit)
##	barplot(perDetectRate[[1]],col=2:(length(perDetectRate[[1]])+1),main=tit)
##	axis(side=1,at=1:length(perDetectRate[[1]]))#labels=names(perDetectRate[[1]]))
#	if(toSave==TRUE){
#		dev.off()
#		#shell.exec(file.path(outDir,figName))
#	}
#}
calControlIndex<-function(cData){
	ctrIndex<-list()
	ctr.summary<-lapply(cData,function(x)summary(x))
	cdat<-rfgc(cData)
	ctr.pvalue<-lapply(cdat,calPvalue)
	calPvalue<-function(dat){
		len<-length(dat)
		pvalue<-c()
		len1<-seq(1,len,2)
		for(i in len1){
			dat.1<-as.numeric(dat[[i]])
			dat.2<-as.numeric(dat[[(i+1)]])
			p.value<-NA
			if(length(na.omit(dat.1))>=3 & length(na.omit(dat.2))>=3){
				wtest<-wilcox.test(dat.1,dat.2)
				p.value<-wtest$p.value
			}
			pvalue<-c(pvalue,p.value)
		}
		return(pvalue)
	}
	return(ctr.pvalue)
}
calPvalueIDAT_test<-function(){
	load(file="c:\\temp\\test2\\meth27k\\processed\\5543207015\\5543207015_idat.rda")
	pv<-calPvalueIDAT(idat)
}
calPvalueIDAT<-function(idat,bp.method="z-score",platform="humanMethylation27k"){
	data(NegCtlCode)
	ctl_code<-ctl_code[,1]
	fdat<-featureData(idat@QC)@data$Address
	cdat.m<-idat@QC@assayData$methylated
	cdat.u<-idat@QC@assayData$unmethylated
	ind<-is.element(fdat,ctl_code)
	cdat.neg.m<-rowMeans(cdat.m[ind,],na.rm=T)
	cdat.neg.u<-rowMeans(cdat.u[ind,],na.rm=T)
	dat.m<-idat@assayData$methylated
	dat.u<-idat@assayData$unmethylated
	pvalue.m<-calpvalue(dat.m,cdat.neg.m,pvalue.method=bp.method)
	pvalue.u<-calpvalue(dat.u,cdat.neg.u,pvalue.method=bp.method)
	pvalue<-ifelse(dat.m>dat.u,pvalue.m,pvalue.u)
	dimnames(pvalue)<-dimnames(dat.m)
	attr(pvalue,"p.method")<-bp.method
	return(pvalue)
}

calDetectionRate<-function(mData,threshold=0.05){
	if(is.null(mData)){
		cat("mData is null\n")
		return;
	}
	mData.beta<-NULL;mData.pvalue<-NULL;mData.M<-NULL;mData.U<-NULL;sampID<-NULL
	if(class(mData)=="MethyLumiSet"){
		mData.beta<-mData@assayData$betas
		mData.pvalue<-calPvalueIDAT(mData)
		mData.M<-mData@assayData$methyalted
		mData.U<-mData@assayData$unmethylated
		sampID<-dimnames(mData.M)[[2]]
	}else{
		mData.beta<-getBeta(mData)
		mData.pvalue<-getPvalue(mData)
		mData.M<-getM(mData)
		mData.U<-getU(mData)
		sampID<-getID(mData)
	}
	n.col<-ncol(mData.beta)
	n.row<-nrow(mData.beta)
	mData.summary<-c()
	summary.M<-summary(mData.M)
	summary.U<-summary(mData.U)
	summary.beta<-summary(mData.beta)
	summary.pvalue<-summary(mData.pvalue)
	mData.rate<-c()
	for(i in 1:n.col){
		summary.detectionRate<-sum(as.numeric(mData.pvalue[,i])>threshold,na.rm=T)/n.row
		mData.rate<-c(mData.rate,summary.detectionRate)
		
	}
	names(mData.rate)<-sampID
	mData.summary<-list(mData.rate,summary.M,
			summary.U,summary.beta,
			summary.pvalue)
	return(mData.summary)
}


normalizationPlot<-function(data){
	X11()
	boxplot(data,col="green",main="boxplot of the normalized data")
	
	diag.panel = function (x, ...) {
		par(new = TRUE)
		hist(x, 
				col = "light blue", 
				probability = TRUE, 
				axes = FALSE, 
				main = "")
		lines(density(x), 
				col = "red", 
				lwd = 3)
		rug(x)
	}
	
	
	
	panel.cor <- function(x, y, digits=2, prefix="", cex.cor)
	{
		usr <- par("usr"); on.exit(par(usr))
		par(usr = c(0, 1, 0, 1))
		r <- abs(cor(x, y))
		txt <- format(c(r, 0.123456789), digits=digits)[1]
		txt <- paste(prefix, txt, sep="")
		if(missing(cex.cor)) cex.cor <- 0.8/strwidth(txt)
		text(0.5, 0.5, txt, cex = cex.cor * r)
	}
	X11()
	pairs(data,main="scatter plot of the normalizaed data",
			lower.panel=panel.smooth,
			diag.panel =diag.panel,
			upper.panel=panel.cor)
}
plotDensity<-function(dat,color=NULL,xlab="",ylab="",main=""){
	if(is.null(color))plot(density(na.omit(dat[,1])),main=main,col=1)
	else plot(density(na.omit(dat[,1])),main=main,col=color[1])
	if(ncol(dat)>=2){
		for(i in 2:ncol(dat)){
			par(new=T,yaxt="n",xaxt="n")
			if(is.null(color))plot(density(na.omit(dat[,i])),main=main,col=i,xlab=xlab,ylab=ylab)
			else plot(density(na.omit(dat[,i])),main=main,col=color[i],xlab=xlab,ylab=ylab)
		}
	}
}

plotDensity.2<-function(dat,color=NULL,xlab="",ylab="",main="",fn=NULL){
	if(is.null(fn)){
		X11()
	}
	else{
		png(filename=fn,width=1280,height=640)
	}
	if(is.null(color))plot(density(na.omit(dat[,1])),main=main,col=1)
	else plot(density(na.omit(dat[,1])),main=main,col=color[1])
	if(ncol(dat)>=2){
		for(i in 2:ncol(dat)){
			par(new=T,yaxt="n",xaxt="n")
			if(is.null(color))plot(density(na.omit(dat[,i])),main=main,col=i,xlab=xlab,ylab=ylab)
			else plot(density(na.omit(dat[,i])),main=main,col=color[i],xlab=xlab,ylab=ylab)
		}
	}
	if(!is.null(fn)) dev.off()
}
boxplot.2<-function(dat,color=NULL,main="",fn=NULL){
	if(is.null(fn)){
		X11()
	}else{
		png(filename=fn,width=1280,height=640)
	}
	if(!is.null(color)) color<-color.batch(color)
	boxplot(dat,col=color,main=main)
	if(!is.null(fn)) dev.off()
}
###################
#
####################
plotDetectionPvalue_test<-function(){
	data(mData)
	plotDetectionPvalue(mdat=mData,outDir="c:\\temp")
}
plotDetectionPvalue<-function(txt=NULL,mdat=NULL,outDir=NULL,fn=NULL){
	if(is.null(mdat)) mdat<-get("mData",env=.GlobalEnv)
	if(is.null(outDir)) outDir<-gFileDir
	if(is.null(fn)) fn<-"DetectPvalue.png"
	pv<-getPvalue(mdat)
	bv<-getBeta(mdat)
	png(filename=file.path(outDir,fn),height=640,width=640)
	par(mfrow=c(1,2),ylog=T)
	plot(as.numeric(bv),as.numeric(pv),main="",col=1,xlim=c(0,1),xlab="Beta value",ylab="Detection P Value")
	plot(density(as.numeric(pv)),xlim=c(0,0.005),main="")
	dev.off()
}
#	if(ncol(pv)>1){
#		for(i in 2:ncol(pv)){
#			par(new=T,yaxt="n",xaxt="n")
#			plot(bv[,i],pv[,i],col=i)
#		}
#	}
#	par(new=F,ylog=T)
#	plotDensity(pv)

##########
#
###########
color.batch<-function (batch) 
{
	color.numb <- table(batch)
	color <- c()
	for (i in 1:length(color.numb)) {
		ii <- i + 1
		color <- c(color, rep(ii, color.numb[i]))
	}
	color
}