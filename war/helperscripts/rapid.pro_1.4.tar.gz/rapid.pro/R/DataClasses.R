# TODO: Add comment
# 
# Author: feipan
#meth: annot, norm, meth_expr, QC,statDif,
#methGUI
# History:
#
###############################################################################

# ==========================================================================
# 
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
library(Biobase)
setClass("CnvSet",contains="SnpSet")
setClass("gSet",contains="eSet")
if(is.null(getGeneric("getRowName")))setGeneric("getRowName",function(object,...)standardGeneric("getRowName"))
if(is.null(getGeneric("subSetByLoc")))setGeneric("subSetByLoc",function(object,start,end,chr,...)standardGeneric("subSetByLoc"))
if(is.null(getGeneric("subSetByChr")))setGeneric("subSetByChr",function(object,chr,...)standardGeneric("subSetByChr"))
if(is.null(getGeneric("getgData"))) setGeneric("getgData",function(object,...)standardGeneric("getgData"))
if(is.null(getGeneric("getChr"))) setGeneric("getChr",function(object,...)standardGeneric("getChr"))
if(is.null(getGeneric("getStart"))) setGeneric("getStart",function(object,...)standardGeneric("getStart"))
if(is.null(getGeneric("getEnd"))) setGeneric("getEnd",function(object,...)standardGeneric("getEnd"))
setMethod("getgData","gSet",function(object,...){ 
			return(object@assayData$gData)
		}
)
setMethod("getChr","gSet",function(object,...){
			return(object@featureData$Chr)
		}
)
setMethod("getStart","gSet",function(object,...){
			return(object@featureData$Start)
		}
)
setMethod("getEnd","gSet",function(object,...){
			return(object@featureData$End)
		})
setMethod("subSetByLoc","gSet",function(object,start,end=NULL,chr=NULL,...){
			ind <-object@featureData$Start>=start
			if(!is.null(end)) ind <-ind & object@featureData$End<=end
			if(!is.null(chr)) ind <-ind & (object@featureData$Chr==chr)
			gData<-object@assayData$gData[ind,]
			return(gData)
		})
setMethod("subSetByChr","gSet",function(object,chr,...){
			ind<-object@featureData$Chr==chr
			gData<-object@assayData$gData[ind,]
			return(gData)
		})
setMethod("getRowName","gSet",function(object,...){
			return(dimnames(object@assayData$gData)[[1]])
		})
#setMethod("initialize","gSet",
#		function(.Object,
#				gData=new("matrix"),...){
#			callNextMethod(.Object,gData=gData,...)
#		}
#)
#setMethod("initialize","gSet",
#		function(.Object,assayData=assayDataNew(gData=gData,gData=new("matrix")),...){
#			callNextMethod(.Object,assayData=assayData,...)
#		}
#)
setMethod("initialize","gSet",
		function(.Object,assayData=assayDataNew(gData=gData),
				featureData=new("AnnotatedDataFrame",data=data.frame(Chr=Chr,Start=Start,End=End)),
				gData=new("matrix"),Chr=new("character"),Start=new("numeric"),End=new("numeric"),
				...){
			callNextMethod(.Object,assayData=assayData,featureData=featureData,...)
		}
)
gSet_Test<-function(){
	sc<-matrix(1:100,nrow=10)
	chr<-rep("1",10)
	start<-1:10
	end<-3:12
#	dat<-new("gSet",gData=sc)
	dat2<-new("gSet",gData=sc,Chr=chr,Start=start,End=end)
	sc1<-subSetByChr(dat2,"1")
	sc2<-subSetByLoc(dat2,4,8,"1")
	sc3<-subSetByLoc(dat2,4,NULL,NULL)
	#sc4<-subSetByLoc(dat2,4)
	getValidity(getClass("gSet"))
}
#################
#
#################
setClass("methSet",contains="eSet")
if(is.null(getGeneric("getBeta")))setGeneric("getBeta",function(object,...) standardGeneric("getBeta"))
setMethod("getBeta","methSet",function(object,...){
			return(assayData(object)$BetaValue)
		})
setMethod("initialize","methSet",function(.Object,BetaValue=new("matrix"),phenoData=new("AnnotatedDataFrame"),featureData=new("AnnotatedDataFrame"),...){
			callNextMethod(.Object,BetaValue=BetaValue,...)
		})
methSet_Test<-function(){
	bv<-matrix(1:100,nrow=10)
	mset<-new("methSet",BetaValue=bv)
	dat1<-getBeta(mset)
}
#############################################
#
############################################
#if(!exists("methData")) .Load_lib()
#.Load_lib<-function(){
	setClass("methData",contains="eSet")
	if(is.null(getGeneric("getM")))setGeneric("getM",function(object,...) standardGeneric("getM"))
	if(is.null(getGeneric("getU")))setGeneric("getU",function(object,...) standardGeneric("getU"))
	if(is.null(getGeneric("getBeta")))setGeneric("getBeta",function(object,...) standardGeneric("getBeta"))
	if(is.null(getGeneric("getPvalue")))setGeneric("getPvalue",function(object,...) standardGeneric("getPvalue"))
	if(is.null(getGeneric("getColorChannel")))setGeneric("getColorChannel",function(object,...) standardGeneric("getColorChannel"))
	if(is.null(getGeneric("getBaseChannel")))setGeneric("getBaseChannel",function(object,...) standardGeneric("getBaseChannel"))
	if(is.null(getGeneric("getID")))setGeneric("getID",function(object,...)standardGeneric("getID"))
	if(is.null(getGeneric("getProbeID")))setGeneric("getProbeID",function(object,...)standardGeneric("getProbeID"))
	if(is.null(getGeneric("getPhenoData")))setGeneric("getPhenoData",function(object,...)standardGeneric("getPhenoData"))
#}
setMethod("getProbeID","methData",function(object,...){
			return(dimnames(object@assayData$M)[[1]])
		})
setMethod("initialize", "methData",
		function(.Object,
				M = new("matrix"),
				U = new("matrix"),
				BetaValue = new("matrix"),
				Pvalue = new("matrix"),
#				colorChannel=new("list"),
#				baseChannel = new("list"),
				...) {
			callNextMethod(.Object,
					M=M, U=U, BetaValue = BetaValue,Pvalue=Pvalue,
					...)
		})
# add validator to dim(bv)=dim(pv)
setMethod("getPhenoData","methData",function(object,...){
			return(pData(object@phenoData))
		})
setMethod("getID","methData",function(object,...){
			return(dimnames(object@assayData$M)[[2]])
		})
setMethod("getM","methData",function(object,...){
			return(object@assayData$M)
		})
setMethod("getU","methData",function(object,...){
			return(object@assayData$U)
		})
setMethod("getBeta","methData",function(object,...){
			return (object@assayData$BetaValue)
		})
setMethod("getPvalue","methData",function(object,...){
			return(object@assayData$Pvalue)
		})
setMethod("getColorChannel","methData",function(object,...){
			return(object@assayData$colorChannel)
		})
setMethod("getBaseChannel","methData",function(object,...){
			return(object@assayData$baseChannel)
		})

methData_test<-function(){
	data.dir<-system.file("extdata",package="Biobase")
	dat<-as.matrix(read.delim(file.path(data.dir,"exprsData.txt"),sep="\t",header=T,as.is=T,row.names=1))
	dim(dat)
	names(dat)
	mdata<-new("methData",M=dat,U=dat,BetaValue=dat,Pvalue=dat)
	pdat<-read.delim(file.path(data.dir,"pData.txt"),sep="\t",as.is=T,header=F,row.names=1)
	dim(pdat)
	pdat<-pdat[1:26,]
	vmdata<-data.frame(labelDescription=c("A","B","C"),row.names=c("E","F","G"))
	phenodata<-new("AnnotatedDataFrame",data=pdat,varMetadata=vmdata)
	head(pData(phenodata))
	phenoData(mdata)<-phenodata
	slotNames(mdata)
	mp<-mdata@phenoData
	pd<-pData(phenodata)
	dim(pd)
}
methData_test.2<-function(){
	fdat<-dat[,1:5]
	vfdata<-data.frame(labelDescription=rownames(fdat),row.names=rownames(fdat))
	fdat<-new("AnnotatedDataFrame",data=as.data.frame(t(fdat)),varMetadata=vfdata)
	featureData(mdata)<-fdat
	pData(mdata@featureData)
}
##########################
# methDataQC methods
#############
setClass("methQCData",representation(qcData="list"),prototype=list(qcData=list()))#,contains="eSet")
if(is.null(getGeneric("getQCData")))setGeneric("getQCData",function(object,...)standardGeneric("getQCData"))
#if(is.null(getGeneric("getQCType")))setGeneric("getQCType",function(object,...)standardGeneric("getQCType"))
#
setMethod("initialize","methQCData",
		function(.Object,
				qcData=new("list"),
				...){
			callNextMethod(.Object,
					qcData=qcData,
							...)
		}
)

setMethod("getQCData","methQCData",
		function(object,...){
			return(object@qcData)
		})
#setMethod("getQCType","methQCData",
#		function(object,...){
#			return(object@assayData$qcType)
#		})



test_QCData<-function(){
	dat<-list(qc1=c(1:200),qc2=c(1:10))
	dat.test<-new("methQCData",dat)
	slotNames(dat.test)
	dat.test@qcData
	rr<-getQCData(dat.test)
}
#################################
###########################
setClass("methDataSet",contains="eSet"
)
setMethod("initialize", "methDataSet",
		function(.Object,
				M = new("matrix"),
				U = new("matrix"),
				Beta = new("matrix"),
				Pvalue = new("matrix"),
				#IsRed = new("matrix"),
				...) {
			callNextMethod(.Object,
					M=M, U=U, Beta=Beta, Pvalue=Pvalue,#IsRed=IsRed,
					...)
		})
setClass("foo", representation(a = "character", b = "numeric"))
setClass("bar", representation(d = "numeric", c = "numeric"))
setClass("baz", contains = c("foo", "bar"))

if (is.null(getGeneric("pfoo")))setGeneric("pfoo", function(object,...)
				standardGeneric("pfoo"))

setMethod("pfoo", "character",
		function(object) print(object))
setMethod("pfoo", "foo",
		function(object) {
			print(object@b)
			t= object@b+20
			print(t)
		}
)
if (is.null(getGeneric("pbaz")))setGeneric("pbaz",function(o,...)
				standardGeneric("pbaz"))
setMethod("pbaz","baz",function(o){ #o has to be same as in generic 'o'
			print(o@a)
		})
.initFoo <- function(where) {
	setClass("foo", representation(a="character", b="numeric"),where=where)
	setClass("bar", representation(d="numeric", c="numeric"), where=where)
	setClass("baz", contains=c("foo", "bar"), where=where)
}
###########################
###############################
