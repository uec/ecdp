# TODO: Add comment
# 
# Author: feipan
#
# R(-based) Automated Pipeline for DNA-methylation (RAPiD) Pro 
###############################################################################

rapid.pro <-function(datPath=NULL,outPath=NULL,pkgPath=NULL,arrayPath=NULL,batchPath=NULL,tcgaPath=NULL,bp.method="filter.min",qc.plot=T,toMscan=F,toPkg=F,platform="meth27k",inc=F,arrayManifest=NULL,arrayMapping=NULL,platemapFn=NULL){
	datDir<-"/auto/uec-02/shared/production/methylation/"
	if(platform=="meth27k"){
		if(is.null(datPath)) datPath<-file.path(datDir,"meth27k/raw")
		if(is.null(outPath)) outPath<-file.path(datDir,"meth27k/processed")
		if(is.null(pkgPath)) pkgPath<-file.path(datDir,"meth27k/packaged")
		if(is.null(arrayPath)) arrayPath<-file.path(datDir,"meth27k/arraymapping")
		if(is.null(tcgaPath)) tcgaPath<-file.path(datDir,"meth27k/tcga")
		if(is.null(batchPath)) batchPath<-file.path(datDir,"meth27k/batches")
		if(is.null(platemapFn)) platemapFn<-file.path(datDir,"meth27k/arraymapping/platemap.txt") 
	}
	mData<-NULL
	assign("cData",NULL,env=.GlobalEnv)
	dataFolder<-list.files(datPath)
	processedFolder<-list.files(outPath)
	if(inc==T){
		dataFolder<-dataFolder[!is.element(dataFolder,processedFolder)]
	}
	sample.mapping<-readSampleMapping(arrayPath)
	for(df in dataFolder){
		df.dat<-file.path(datPath,df)
		df.out<-file.path(outPath,df)
		if(!file.exists(df.out)) dir.create(df.out)
		df.pkg<-file.path(pkgPath,df)
		mData<-readMethTxt(df.dat,repDir=df.out,bp.method=bp.method,sample.mapping=sample.mapping)
		if(is.null(mData)){
			cat("usage: rapid.pro(dataPath,outPath,pkgRepos,arrayPath,bp.method=\"filter.min\",qc.plot=T,toMscan=F,toPkg=T,platform=\"meth27k\")\ntype help(rapid.pro) for more details.\n")
			stop();
		}
		
		if(qc.plot==T){
			createQCplot(mData,cData,df.out)
		}
	}
	packagingArrays.2(outPath,pkgPath,inc)
	createBatchPkgs(platemapFn,batchPath,arrayPath)
	packagingMappedArrays(outPath,tcgaPath,arrayPath,inc)
	cat(paste(">Done...",date(),"\n"))
}

rapid.pro_Test<-function(){
	datPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\test_data"
	outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out" 
	#pkgPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\pkg"
	pkgPath<-"C:\\temp\\pkg"
	arrayPath<-"C:\\tcga\\arraymapping"
	rapid.pro(datPath,outPath,pkgPath,arrayPath,inc=F)
}
readSampleMapping_test<-function(){
	arrayPath<-"c:\\tcga\\arraymapping"
	smp<-readSampleMapping(arrayPath)
}
readSampleMapping<-function(arrayPath,smpFn="sample_mapping.txt"){
	smp<-NULL
	smp.name<-c("plate_id","flow_cell","sampleID")
	if(!is.null(arrayPath)){
		smpFn<-file.path(arrayPath,smpFn)
		if(file.exists(smpFn)){
			smp<-read.table(file=smpFn,sep="\t",header=F,as.is=T)
			names(smp)<-smp.name
			smp.id<-paste(smp[,1],smp[,2],sep="_")
			
			if(length(duplicated(smp.id))!=0){
				#cat(paste("The following plate barcodes are duplicated: ",smp.id[duplicated(smp.id)],"\t",smp[duplicated(smp.id),"sampleID"],"\n",sep=""))
			}
			ind<-!duplicated(smp.id)
			smp<-smp[ind,]
			rownames(smp)<-smp.id[ind]
		}
	}
	return(smp)
}
packagingMappedArrays_test<-function(){
	arrayPath<-"c:\\tcga\\arraymapping"
	outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out"
	pkgPath<-"c:\\temp\\pkg1"
	packagingMappedArrays(outPath,pkgPath,arrayPath,inc=F)
}
packagingMappedArrays<-function(outPath,pkgPath,arrayPath,inc=T){
	if(!is.null(arrayPath)){
		setwd(arrayPath)
		amFn<-gsub(".csv","",list.files(pattern=".csv"))
		
		if(inc==T){
			pkgRepos<-file.path(pkgPath,"tcga/repos")
			pkgFn<-c(list.files(pkgPath),list.files(pkgRepos))
			amFn<-amFn[!is.element(amFn,pkgFn)]
		}
		for(fn in amFn){
			am<-file.path(arrayPath,paste(fn,".csv",sep=""))
#			fn<-gsub(".csv","",fn)
			df.pkg<-file.path(pkgPath,fn)
			isTCGA<-F
			if(substr(fn,1,7)=="jhu-usc") {
				isTCGA<-T
				df.pkg<-file.path(pkgPath,"tcga/repos",fn)
			}
			if(!file.exists(df.pkg)) dir.create(df.pkg)
			createPkg.2(outPath,df.pkg,pkgname=fn,arraymapping=am,isTCGA=isTCGA)
			if(isTCGA==T)mergeTCGAPkg.2(pkgPath,df.pkg)
		}
	}
}

############################

loadAutoConfig<-function(configFn){
	config<-read.table(file=configFn,sep=",",header=F,as.is=T)
	param<-config[,2]
	names(param)<-config[,1]
	return(param)
}


###################################

###################################
createQCplot_test<-function(){
	outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\5324215005_out2\\filter.min"
	print(load(file=file.path(outPath,"mData_5324215005.rdata")))
	print(load(file=file.path(outPath,"cData_5324215005.rdata")))
	createQCplot(mData,cData,outPath)
}
createQCplot<-function(mData=NULL,cData=NULL,outPath){
	probePlot(data.dir=outPath,mData=mData)
	plotFailureRate(outDir=outPath,mData=mData)
	controlPlot(cData=cData,outDir=outPath)
}
createPkg_test<-function(){
	outPath<-"C:\\temp\\4698_out\\123"
	createPkg(outPath,outPath)
	datPath<-outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out\\5543207013"
	outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out"
	am<-"c:\\tcga\\arraymapping\\jhu-usc.edu_STAD.HumanMethylation27.1.0.0.csv"
	createPkg(datPath,outPath,arraymapping=am,pkgname="jhu-usc.edu_STAD.HumanMethylation27.1.0.0")
}
createPkg.2_test<-function(){
	am<-"c:\\tcga\\arraymapping\\jhu-usc.edu_STAD.HumanMethylation27.1.0.0.csv"
	datPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out"
	outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp"
	createPkg.2(datPath,outPath,pkgname="jhu-usc.edu_STAD.HumanMethylation27.1.0.0",arraymapping=am)
}

createPkg.2<-function(outPath,pkgPath,arraymapping,pkgname=NULL,isTCGA=T){
	if(is.null(pkgname)) pkgname<-gsub(".csv","",filetail(arraymapping))
	sampleInfo<-extractSampleInfo(arraymapping)
	chip.exist<-c()
	for(chip in sampleInfo$chipBarCode){
		outPath1<-file.path(outPath,chip)
		if(file.exists(outPath1)){
			chip.exist<-c(chip.exist,outPath1)
		}else{
			msg<-paste("Chip ",chip,"is missing\n")
			cat(msg)
			#log(msg)
		}
	}
	chip.n<-length(chip.exist)
	if(chip.n>=1){
		if(chip.n>=2){
			for(i in 1:(chip.n-1)){
				outPath1<-chip.exist[i]
				createPkg(outPath1,pkgPath,pkgname,arraymapping,packaging=F,isTCGA=isTCGA)
			}
		}
		createPkg(chip.exist[chip.n],pkgPath,pkgname,arraymapping,isTCGA=isTCGA)
	}

}

createPkg<-function(outPath,pkgPath,pkgname=NULL,arraymapping=NULL,packaging=TRUE,isTCGA=T){
	if(is.null(pkgname)) pkgname<-filetail(outPath)
	assign("tcgaPackage_A",file.path(outPath,"UnMethylation_Signal_Intensity.csv"),env=.GlobalEnv)
	assign("tcgaPackage_A_se",file.path(outPath,"UnMethylation_Signal_Intensity_STDERR.csv"),env=.GlobalEnv)
	assign("tcgaPackage_A_n",file.path(outPath,"UnMethylation_Signal_Intensity_NBeads.csv"),env=.GlobalEnv)
	assign("tcgaPackage_B",file.path(outPath,"Methylation_Signal_Intensity.csv"),env=.GlobalEnv)
	assign("tcgaPackage_B_se",file.path(outPath,"Methylation_Signal_Intensity_STDERR.csv"),env=.GlobalEnv)
	assign("tcgaPackage_B_n",file.path(outPath,"Methylation_Signal_Intensity_NBeads.csv"),env=.GlobalEnv)
	assign("tcgaPackage_R_ctr",file.path(outPath,"Control_Signal_Intensity_Red.csv"),env=.GlobalEnv)
	assign("tcgaPackage_G_ctr",file.path(outPath,"Control_Signal_Intensity_Grn.csv"),env=.GlobalEnv)
	assign("tcgaPackage_pvalue_fn",file.path(outPath,"Pvalue.csv"),env=.GlobalEnv)
	assign("tcgaPackage_beta_fn",file.path(outPath,"BetaValue.csv"),env=.GlobalEnv)
	assign("tcgaPackage_outputDir",pkgPath,env=.GlobalEnv)
	assign("tcgaPackage_name",pkgname,env=.GlobalEnv)
	createDataPackage(txt=NULL,old_scheme=FALSE,new_scheme=TRUE,packaging,auto=T,pkgname=pkgname,isTCGA,arraymapping)
}

packagingArrays_test<-function(){
	datPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out"
	outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out"
	packagingArrays.2(datPath,outPath,inc=F)
	datPath<-"C:\\temp\\pkg\\stad.HumanMethylation"
	outPath<-"C:\\temp\\pkg1"
	packagingArrays.2(datPath,outPath,inc=F,ext=".txt")
}
packagingArrays.2<-function(datPath,outPath,inc=T,ext=".csv"){
	dataFolder<-list.files(datPath)
	outFolder<-list.files(outPath)
	if(inc==T) dataFolder<-dataFolder[!is.element(dataFolder,outFolder)]
	for(df in dataFolder){
		setwd(file.path(datPath,df))
		if(!file.exists(file.path(outPath,df)))dir.create(file.path(outPath,df))
		fn<-paste(list.files(file.path(datPath,df),pattern=paste(ext,"|.png",sep="")),collapse=" ")
		#fn<-paste(list.files(file.path(datPath,df),pattern=".csv|.png"),collapse=" ")
		command<-paste("tar -cf ",df,".tar ",fn,sep="")
		dfz<-paste(df,".tar.gz",sep="")
		command2<-paste("gzip -c ",df,".tar > ",dfz,sep="")
		dfz1<-paste(dfz,".md5",sep="")
		command3<-paste("md5sum ", dfz," > ",dfz1,sep="")
		if(R.Version()$os=="mingw32"){
			shell(command)
			shell(command2)
			shell(command3)
			system(paste("mv ",dfz," \"",file.path(outPath,df,dfz),"\"",sep=""))
			system(paste("mv ",dfz1," \"",file.path(outPath,df,dfz1),"\"",sep=""))
		}else{
			system(command)
			system(command2)
			system(command3)
			system(paste("mv ",dfz," ",file.path(outPath,df,dfz),sep=""))
			system(paste("mv ",dfz1," ",file.path(outPath,df,dfz1),sep=""))
		}
		system(paste("rm ",df,".tar",sep=""))
	}
}
packagingArrays<-function(datPath,outPath,inc=T,ext=".csv"){
	dataFolder<-list.files(datPath)
	outFolder<-list.files(outPath)
	if(inc==T) dataFolder<-dataFolder[!is.element(dataFolder,outFolder)]
	for(df in dataFolder){
		setwd(file.path(datPath,df))
		if(!file.exists(file.path(outPath,df)))dir.create(file.path(outPath,df))
		fn<-paste(list.files(file.path(datPath,df),pattern=paste(ext,"|.png",sep="")),collapse=" ")
		#fn<-paste(list.files(file.path(datPath,df),pattern=".csv|.png"),collapse=" ")
		command<-paste("tar -cf ",df,".tar ",fn,sep="")
		dfz<-paste(df,".tar.gz",sep="")
		command2<-paste("gzip -c ",df,".tar > ",dfz,sep="")
		if(R.Version()$os=="mingw32"){
			shell(command)
			shell(command2)
			system(paste("mv ",dfz," \"",file.path(outPath,df,dfz),"\"",sep=""))
		}else{
			system(command)
			system(command2)
			system(paste("mv ",dfz," ",file.path(outPath,df,dfz),sep=""))
		}
		system(paste("rm ",df,".tar",sep=""))
	}
}
###################################

###################################

readMethTxt_test<-function(){
	datPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\5324215005"
	outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\5324215005_out2"
	readMethTxt(datPath,outPath,bp.method="filter.min")
	readMethTxt(datPath,outPath,bp.method=NULL)
	datPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\test_data\\5471637013"
	outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out\\5471637013"
	am<-readSampleMapping("c:\\tcga\\others\\arraymapping")
	readMethTxt(datPath,outPath,sample.mapping=am)
}
readMethTxt_test2<-function(){
	datPath<-"/home/uec-02/shared/production/methylation/meth27k/raw/5543207013"
	outPath<-"/home/uec-02/shared/production/methylation/meth27k/other/5543207013"
	am<-readSampleMapping("/home/uec-02/shared/production/methylation/meth27k/arraymapping")
	readMethTxt(datPath,outPath,sample.mapping=am)
}

readMethTxt<-function(dataDirectory,repDir=NULL,fname=NULL,txtWin=NULL,is.sepOut=T,toSave=T,bp.method="filter.min",sample.mapping=NULL){
	if(!is.null(txtWin)){
		cat("start running...",date(),"\n")
	}
	rawDatFn<-readRawTxtData(dataDirectory)
	mData<-processRawTxtData.2(rawDatFn,txtWin,bp.method)
	#cData<-readCtrTxtData(rawDatFn,txtWin)
	if(toSave==TRUE){
		#if(is.null(fname))fname<-filetail(dataDirectory)
		fname<-""
		if(is.null(repDir)) repDir <-gFileDir#"c:\\temp\\"
		save(mData,file=file.path(repDir,paste("mData",fname,".rdata",sep="")))
		save(cData,file=file.path(repDir,paste("cData",fname,".rdata",sep="")))
		if(is.sepOut==TRUE) {
			saveProcessedTxtData.2a(mData,repDir,fname,sample.mapping)
			saveCtrData2CSV.3a(cData,repDir,sample.mapping,bp.method)
		}
	}
	return(mData)
}

readRawTxtData<-function(dataDirectory){
	rawDataFileNames <- c();
	setwd(dataDirectory);
	flist = list.files(pattern=".txt",
			recursive=T);
	
	for(i in 1:length(flist)){
		flist_cur = unlist(strsplit(
						filetail(flist[i]),
						"\\."))[1];
		fidNames = flist_cur;
		if(fidNames!="Metrics"){
			rawDataFileNames<-c(rawDataFileNames,file.path(dataDirectory,flist[i]))
		}
	}
	return(rawDataFileNames)
}
readCtrTxtData<-function(fn,txtWin=NULL){
	ctrData<-list();
	data(ilmn_code)
	if(!exists("ilmn_code"))ilmn_code<-readIlmnCode()
	for(i in 1:length(fn)){
		fn.cur<-filetail(fn[i])
		if(fn.cur=="Metrices.txt") next
		prefix<-unlist(strsplit(fn.cur,"\\."))[[1]]
		fdata<-read.delim(file=fn[i],sep="\t",header=T,as.is=T)
		ctrData.tmp<-merge(ilmn_ctr_code,fdata,by.x=1,by.y=1,all.x=TRUE)
		rn<-paste(ctrData.tmp$type,ctrData.tmp$color,ctrData.tmp$name,ctrData.tmp$code,1:nrow(ctrData.tmp),sep="_")
		row.names(ctrData.tmp)<-rn #1:nrow(ctrData.tmp)#ctrData.tmp$code
		nm<-c(names(ctrData),prefix)
		#ctrData.tmp<-as.matrix(ctrData.tmp[,c(-1,-2,-3,-4)])
		ctrData<-c(ctrData,list(ctrData.tmp))
		names(ctrData)<-nm
	}
	return(ctrData)
}
bp_test<-function(){
	dat<-rnorm(20)
	bp1<-bp(dat,bp.method="filter.min")
	str(bp1)
	bp2<-bp(dat,bp.method="filter.max")
	str(bp2)
	bp3<-bp(dat,bp.method="filter.outlier")
	str(bp3)
	bp4<-bp(dat)
	str(bp4)
	dat<-rnorm(3)
	dat<-rnorm(7)
}

#bp<-function(dat,bp.method=NULL,n.cut=10,n.min=3){
bp<-function(dat,bp.method=NULL,n.cut=10,n.min=0){
	dat.avg<-NULL
	dat.err<-NULL
	dat.n<-length(dat)
	dat.n1<-dat.n
	if(dat.n<=n.min){
		dat.avg<-NA
		dat.err<-NA
	}else if(dat.n<=n.cut |is.null(bp.method)){
		dat.avg<-mean(dat,na.rm=T)
		dat.err<-sd(dat,na.rm=T)/sqrt(dat.n)
	}else if(!is.null(bp.method)){
		if(bp.method=="filter.min"){
			dat.min<-dat[-which.min(dat)]
			dat.avg<-mean(dat.min,na.rm=T)
			dat.err<-sd(dat.min,na.rm=T)/sqrt(dat.n-1)
			dat.n1<-dat.n-1
		}else if(bp.method=="filter.max"){
			dat.max<-dat[-which.max(dat)]
			dat.avg<-mean(dat.max,na.rm=T)
			dat.err<-sd(dat.max,na.rm=T)/sqrt(dat.n-1)
			dat.n1<-dat.n-1
		}else if(bp.method=="filter.outlier"){
			dat.avg<-mean(dat,na.rm=T)
			dat.std<-sd(dat,na.rm=T)
			dat.err<-dat.std/sqrt(dat.n)
			dat.n1<-dat.n
			ind<-dat>(dat.avg+3*dat.std)|dat<(dat.avg-3*dat.std)
			if(sum(ind)>0){
				dat.out<-dat[-ind]
				dat.avg<-mean(dat.out,na.rm=T)
				dat.n1<-dat.n-length(ind)
				dat.err<-sd(dat.out,na.rm=T)/sqrt(dat.n1)
			}
		}else{
			cat(paste("The method of",bp.method,"is unknown\n"))
			stop()
		}
	}
	return(c(avg=dat.avg,err=dat.err,num=dat.n,num.after=dat.n1))
}

##########################
#
# optimized: 10/22/2010
#########################
processRawTxtData.2_test<-function(){
	rawDatFn<-c("C:\\temp\\4698\\123\\4828606022_B.txt","C:\\temp\\4698\\123\\4828606022_C.txt")
	mdata<-processRawTxtData.2(rawDatFn)
}
processRawTxtData.2<-function(rawDatFn,txtWin=NULL,bp.method=NULL,pvalue.method="z-score"){
	mdata = data.frame(id=1:27578);
	mdata = mdata[-1];
	
	data(ilmn_code)
	data(ilmnCtrCode)
	if(!exists("ilmn_code"))ilmn_code<-readIlmnCode()
	if(!exists("ilmn_ctr_code")) ilmn_ctr_code<-readIlmnCtrCode()
	rownames(mdata) <- ilmn_code$IlmnID
	rownames(ilmn_code) <- ilmn_code$IlmnID
	ctl_code <- data.frame(ctl_code=c(460494,540577,430114,1660097,1940364,610692,670750,1500059,1500398,1770019,1500167,50110,1990692,610706,360079,1190458));
	
	ctrData<-list();

	for(i in 1:length(rawDatFn)){
		if(filetail(rawDatFn[i])=="Metrices.txt") next
		fdata=read.table(rawDatFn[i],header=TRUE,sep="\t",as.is=T)
	
		fdataGrn.all<-tapply(fdata$Grn,fdata$Code,bp,bp.method)
		fdataGrn<- as.data.frame(t(sapply(fdataGrn.all,as.numeric))) #data.frame(Grn_Avg=fdataGrn.all$avg,Grn_num=fdataGrn.all$num,Grn_err=fdataGrn.all$err,Grn_num2=fdataGrn.all$num.after)
		names(fdataGrn)<-c("Grn_Avg","Grn_ERR","Grn_numb","Grn_Num2")
		fdataRed.all<-tapply(fdata$Red,fdata$Code,bp,bp.method)
		fdataRed<-as.data.frame(t(sapply(fdataRed.all,as.numeric)))#data.frame(Red_Avg=fdataRed.all$avg,Red_num=fdataRed.all$num,Red_err=fdataRed.all$err,Red_num2=fdataRed.all$num.after)
		names(fdataRed)<-c("Red_Avg","Red_ERR","Red_numb","Red_Num2")
		
		meth_U_Grn = merge(fdataGrn,ilmn_code,by.x=0,by.y="AddressA_ID",all.y=T); #could generate warnings if there is missing data
		meth_U_Red = merge(fdataRed,ilmn_code,by.x=0,by.y="AddressA_ID",all.y=T);
		meth_U_Grn<-meth_U_Grn[order(meth_U_Grn$IlmnID),]
		meth_U_Red<-meth_U_Red[order(meth_U_Red$IlmnID),]
		U = ifelse(meth_U_Grn$Color_Channel=="Red",meth_U_Red$Red_Avg,meth_U_Grn$Grn_Avg);
		U.number=ifelse(meth_U_Grn$Color_Channel=="Red",meth_U_Red$Red_numb,meth_U_Grn$Grn_numb)
		names(U)<-meth_U_Grn$IlmnID
		names(U.number)<-meth_U_Grn$IlmnID
		U.number2=ifelse(meth_U_Grn$Color_Channel=="Red",meth_U_Red$Red_Num2,meth_U_Grn$Grn_Num2)
		names(U.number2)<-meth_U_Grn$IlmnID
		U.STDERR=ifelse(meth_U_Grn$Color_Channel=="Red",meth_U_Red$Red_ERR,meth_U_Grn$Grn_ERR)
		names(U.STDERR)<-meth_U_Grn$IlmnID
		U.sorted <- U
		
		meth_M_Grn = merge(fdataGrn,ilmn_code,by.x=0,by.y="AddressB_ID",all.y=T)
		meth_M_Red = merge(fdataRed,ilmn_code,by.x=0,by.y="AddressB_ID",all.y=T)
		meth_M_Grn <-meth_M_Grn[order(meth_M_Grn$IlmnID),]
		meth_M_Red <-meth_M_Red[order(meth_M_Red$IlmnID),]
		M = ifelse(meth_M_Grn$Color_Channel=="Red",meth_M_Red$Red_Avg,meth_M_Grn$Grn_Avg)
		M.number = ifelse(meth_M_Grn$Color_Channel=="Red",meth_M_Red$Red_numb,meth_M_Grn$Grn_numb)
		names(M)<-meth_M_Grn$IlmnID
		names(M.number)<-meth_M_Grn$IlmnID
		M.number2=ifelse(meth_M_Grn$Color_Channel=="Red",meth_M_Red$Red_Num2,meth_M_Grn$Grn_Num2)
		names(M.number2)<-meth_M_Grn$IlmnID
		M.STDERR=ifelse(meth_M_Grn$Color_Channel=="Red",meth_M_Red$Red_ERR,meth_M_Grn$Grn_ERR)
		names(M.STDERR)<-meth_M_Grn$IlmnID
		M.sorted <-M
		#ord.M = order(row.names(mdata))
#		d.M = data.frame(M);
#		rownames(d.M) = meth_M_Red$IlmnID;
#		M.sorted = M[ord.M] #d.M[ord.M,];
#		M.number.sorted = M.number[ord.M]
		
		betaValue = M.sorted/(M.sorted+U.sorted);
		#betaValue = round(betaValue,digits = 4);
		
		meth_ctl_Red = merge(fdataRed,ctl_code,by.x=0,by.y=1)
		ctl_red_mean= mean(meth_ctl_Red$Red_Avg);
		ctl_red_sd= sd(meth_ctl_Red$Red_Avg);
		ctl_red_ster = ctl_red_sd/4;
		
		meth_ctl_Grn = merge(fdataGrn,ctl_code,by.x=0,by.y=1);
		ctl_grn_mean= mean(meth_ctl_Grn$Grn_Avg);
		ctl_grn_sd= sd(meth_ctl_Grn$Grn_Avg);
		ctl_grn_ster = ctl_grn_sd/4;
		
		ctr_avg = ifelse(meth_M_Red$Color_Channel=="Red",ctl_red_mean,ctl_grn_mean);
		ctr_sd = ifelse(meth_M_Red$Color_Channel=="Red",ctl_red_sd,ctl_grn_sd);
		# cal p value
		t = M.sorted>U.sorted;
		AB = t*M.sorted+(!t)*U.sorted;
		pValue.red = calpvalue(matrix(AB),meth_ctl_Red$Red_Avg,pvalue.method)
		pValue.grn = calpvalue(matrix(AB),meth_ctl_Grn$Grn_Avg,pvalue.method)
		pValue = ifelse(meth_M_Red$Color_Channel=="Red",pValue.red,pValue.grn)
		
		flist_cur<-filetail(rawDatFn[i])
		prefix = unlist(strsplit(flist_cur,"\\."))[1];

		tt=data.frame(M=M.sorted,U=U.sorted,Beta=betaValue,Pvalue=pValue,
				M_STDERR=M.STDERR,U_STDERR=U.STDERR,
				M_number=M.number,U_number=U.number,
				M_number2=M.number2,U_number2=U.number2)
		names(tt)=paste(prefix,names(tt),sep="_")
		
		mdata<-data.frame(mdata,tt)
		
		#read  the ctrData
		ctrData.tmp<-merge(ilmn_ctr_code,fdata,by.x=1,by.y=1,all.x=TRUE)
		nm<-c(names(ctrData),prefix)
		ctrData<-c(ctrData,list(ctrData.tmp))
		names(ctrData)<-nm
#		#end of ctrData
		cat("Finished ",flist_cur,"\n")
		if(!is.null(txtWin))
			cat(">finished",flist_cur,"\n",sep=" ")
	}
	gg<-names(mdata)
	require(Biobase)
	mData<-new("methData",M=as.matrix(mdata[,gg[grep("M$",gg)]]),
			U=as.matrix(mdata[,gg[grep("U$",gg)]]),
			BetaValue=as.matrix(mdata[,gg[grep("Beta$",gg)]]),
			Pvalue=as.matrix(mdata[,gg[grep("Pvalue$",gg)]]),
			Mstderr=as.matrix(mdata[,gg[grep("M_STDERR$",gg)]]),
			Ustderr=as.matrix(mdata[,gg[grep("U_STDERR$",gg)]]),
			Mnumber=as.matrix(mdata[,gg[grep("M_number$",gg)]]),
			Unumber=as.matrix(mdata[,gg[grep("U_number$",gg)]]),
			Mnumber2=as.matrix(mdata[,gg[grep("M_number2$",gg)]]),
			Unumber2=as.matrix(mdata[,gg[grep("U_number2$",gg)]]));
	featureData(mData)<-new("AnnotatedDataFrame",data=ilmn_code)
	#phenoData(mData)<-createPhenoData(ctrData)
	rm(mdata)
	attr(mData,"class")<-"methData"
	attr(mData,"date")<-date()
	cData<<-ctrData
	return (mData)
}

processRawTxtData<-function(rawDatFn,txtWin=NULL){
	mdata = data.frame(id=1:27578);
	mdata = mdata[-1];
		
	data(ilmn_code)
	data(ilmnCtrCode)
	if(!exists("ilmn_code"))ilmn_code<-readIlmnCode()
	if(!exists("ilmn_ctr_code")) ilmn_ctr_code<-readIlmnCtrCode()
	rownames(mdata) <- ilmn_code$IlmnID
	rownames(ilmn_code) <- ilmn_code$IlmnID
	
	ord.M = order(row.names(mdata))
	ord.U = ord.M
	ctl_code <- data.frame(ctl_code=c(460494,540577,430114,1660097,1940364,610692,670750,1500059,1500398,1770019,1500167,50110,1990692,610706,360079,1190458));
	
	Mn <- list();
	Un <- list();
	betaValue <- list();
	Pvalue <- list();
	IsRed <- list();
	tname <- c() #list();
	ctrData<-list();
	
	for(i in 1:length(rawDatFn)){
		if(filetail(rawDatFn[i])=="Metrices.txt") next
		fdata=read.table(rawDatFn[i],header=TRUE,sep="\t",as.is=T)
		ilmnCodeFactor = as.factor(fdata$Code);
		fdata.numb = data.frame(ilmnCodeFactor,1);
		fdata.total = by(fdata.numb[[2]],fdata.numb[[1]],sum)-1;
		
		fdata.Grn = data.frame(ilmnCodeFactor,fdata$Grn);
		fdata.Grn.sum = by(fdata.Grn[[2]],fdata.Grn[[1]],sum);
		fdata.Grn.min = by(fdata.Grn[[2]],fdata.Grn[[1]],min);
		fdata.Grn.avg = (fdata.Grn.sum-fdata.Grn.min)/fdata.total;
		tn = length(fdata.Grn.avg);
		numb.Grn <- by(fdata.Grn[[1]],fdata.Grn[[1]],length) #same as the fdata.total+1
		#numb.Grn <- as.numeric(lapply(split(fdata.Grn[[1]],as.factor(fdata.Grn[[1]])),length))
		fdataGrn = data.frame(Code=names(fdata.total),Grn_Avg=fdata.Grn.avg[1:tn],Grn_numb=as.numeric(numb.Grn),stringAsFactors=F);
		
		
		fdata.Red = data.frame(ilmnCodeFactor,fdata$Red);
		fdata.Red.sum = by(fdata.Red[[2]],fdata.Red[[1]],sum);
		fdata.Red.min = by(fdata.Red[[2]],fdata.Red[[1]],min);
		fdata.Red.avg = (fdata.Red.sum-fdata.Red.min)/fdata.total;
		tn = length(fdata.Red.avg);
		numb.Red<-by(fdata.Red[[1]],fdata.Red[[1]],length)
		#numb.Red <- as.numeric(lapply(split(fdata.Red[[1]],as.factor(fdata.Red[[1]])),length))
		fdataRed = data.frame(Code=names(fdata.total),Red_Avg=fdata.Red.avg[1:tn],Red.numb=as.numeric(numb.Red),stringAsFactors=F)#fdata.total));
		
		
		meth_U_Grn = merge(fdataGrn,ilmn_code,by.x=1,by.y="AddressA_ID",all.y=T); #could generate warnings if there is missing data
		meth_U_Red = merge(fdataRed,ilmn_code,by.x=1,by.y="AddressA_ID",all.y=T);
		meth_U_Grn<-meth_U_Grn[order(meth_U_Grn$IlmnID),]
		meth_U_Red<-meth_U_Red[order(meth_U_Red$IlmnID),]
		U = ifelse(meth_U_Grn$Color_Channel=="Red",meth_U_Red$Red_Avg,meth_U_Grn$Grn_Avg);
		U.number=ifelse(meth_U_Grn$Color_Channel=="Red",meth_U_Red$Red.numb,meth_U_Grn$Grn_numb)
		names(U)<-meth_U_Grn$IlmnID
		names(U.number)<-meth_U_Grn$IlmnID
		
		#ord.U = order(row.names(mdata))
		d.U = data.frame(U);
		rownames(d.U) = meth_U_Red$IlmnID;
		U.sorted =  d.U[ord.U,] 
		U.nummber.sorted = U.number[ord.U]
		
		meth_M_Grn = merge(fdataGrn,ilmn_code,by.x=1,by.y="AddressB_ID",all.y=T)
		meth_M_Red = merge(fdataRed,ilmn_code,by.x=1,by.y="AddressB_ID",all.y=T)
		meth_M_Grn <-meth_M_Grn[order(meth_M_Grn$IlmnID),]
		meth_M_Red <-meth_M_Red[order(meth_M_Red$IlmnID),]
		M = ifelse(meth_M_Grn$Color_Channel=="Red",meth_M_Red$Red_Avg,meth_M_Grn$Grn_Avg)
		M.number = ifelse(meth_M_Grn$Color_Channel=="Red",meth_M_Red$Red.numb,meth_M_Grn$Grn_numb)
		names(M)<-meth_M_Grn$IlmnID
		names(M.number)<-meth_M_Grn$IlmnID
		
		#ord.M = order(row.names(mdata))
		d.M = data.frame(M);
		rownames(d.M) = meth_M_Red$IlmnID;
		M.sorted = d.M[ord.M,];
		M.number.sorted = M.number[ord.M]
		
		betaValue = M.sorted/(M.sorted+U.sorted);
		betaValue = round(betaValue,digits = 4);
		
		meth_ctl_Red = merge(fdataRed,ctl_code,by.x=1,by.y=1)
		ctl_red_mean= mean(meth_ctl_Red$Red_Avg);
		ctl_red_sd= sd(meth_ctl_Red$Red_Avg);
		ctl_red_ster = ctl_red_sd/4;
		
		meth_ctl_Grn = merge(fdataGrn,ctl_code,by.x=1,by.y=1);
		ctl_grn_mean= mean(meth_ctl_Grn$Grn_Avg);
		ctl_grn_sd= sd(meth_ctl_Grn$Grn_Avg);
		ctl_grn_ster = ctl_grn_sd/4;
		
		ctr_avg = ifelse(meth_M_Red$Color_Channel=="Red",ctl_red_mean,ctl_grn_mean);
		ctr_sd = ifelse(meth_M_Red$Color_Channel=="Red",ctl_red_sd,ctl_grn_sd);
		ctr_se = ifelse(meth_M_Red$Color_Channel=="Red",ctl_red_ster,ctl_grn_ster)
		# cal p value
		t = M.sorted>U.sorted;
		AB = t*M.sorted+(!t)*U.sorted;
		z_score = (AB-ctr_avg)/ctr_se;
		pValue = pnorm(as.matrix(z_score),lower.tail=FALSE);
		tpvalue=ifelse(pValue==0,"0.00000",pValue)
		
		flist_cur<-filetail(rawDatFn[i])
		prefix = unlist(strsplit(flist_cur,"\\."))[1];
		tt=data.frame(M=M.sorted,U=U.sorted,Beta=betaValue,Pvalue=tpvalue,
				M_number=M.number.sorted,U_number=U.nummber.sorted)
		names(tt)=paste(prefix,names(tt),sep="_")
		
		mdata<-data.frame(mdata,tt)
		
		#read  the ctrData
		ctrData.tmp<-merge(ilmn_ctr_code,fdata,by.x=1,by.y=1,all.x=TRUE)
		nm<-c(names(ctrData),prefix)
		ctrData<-c(ctrData,list(ctrData.tmp))
		names(ctrData)<-nm
#		#end of ctrData
		cat("working on ",i,"\n")
		if(!is.null(txtWin))
			cat(">finished",flist_cur,"\n",sep=" ")
	}
	gg<-names(mdata)
	mData<-new("methData",M=as.matrix(mdata[,gg[grep("M$",gg)]]),
			U=as.matrix(mdata[,gg[grep("U$",gg)]]),
			BetaValue=as.matrix(mdata[,gg[grep("Beta$",gg)]]),
			Pvalue=as.matrix(mdata[,gg[grep("Pvalue$",gg)]]),
			Mnumber=as.matrix(mdata[,gg[grep("M_number$",gg)]]),
			Unumber=as.matrix(mdata[,gg[grep("U_number$",gg)]]));
	featureData(mData)<-new("AnnotatedDataFrame",data=ilmn_code)
	#phenoData(mData)<-createPhenoData(ctrData)
	rm(mdata)
	attr(mData,"class")<-"methData"
	attr(mData,"date")<-date()
	cData<<-ctrData
	return (mData)
}
saveCtrData2CSV_test<-function(){
	load(file=file.path("C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out\\4207113144","cData.rdata"))
	am<-readSampleMapping("c:\\tcga\\arraymapping")
	outDir<-"c:\\temp\\4207113144"
	saveCtrData2CSV.3(cData,outDir,am)
	saveCtrData2CSV.3a(cData,outDir,verbose=F)
}
saveCtrData2CSV.3a<-function(cData=NULL,outDir,sample.mapping=NULL,bp.method="filter.min",verbose=F){
	setwd(outDir)
	data(ilmnCtrCode)
	row.names(ilmn_ctr_code)<-ilmn_ctr_code$code
	dat.grn<-NULL
	dat.red<-NULL
	for(i in 1:length(cData)){
		cdat<-split(cData[[i]][,c("code","Red","Grn")],as.factor(cData[[i]]$type))
		grn<-c();grn.name<-c();grn.code<-c()
		red<-c();red.name<-c();red.code<-c()
		for(j in 1:length(cdat)){
			grn.avg<-tapply(cdat[[j]]$Grn,cdat[[j]]$code,function(x){rs=bp(x,bp.method);rs[[1]]})
			grn<-c(grn,grn.avg)
			grn.code<-c(grn.code,names(grn.avg))
			grn.name<-c(grn.name,rep(names(cdat)[j],length(grn.avg)))
			red.avg<-tapply(cdat[[j]]$Red,cdat[[j]]$code,function(x){rs=bp(x,bp.method);rs[[1]]})
			red<-c(red,red.avg)
			red.code<-c(red.code,names(red.avg))
			red.name<-c(red.name,rep(names(cdat)[j],length(red.avg)))
		}
		names(grn)<-grn.name
		names(red)<-red.name
		if(is.null(dat.grn)) dat.grn<-data.frame(grn)
		else dat.grn<-data.frame(dat.grn,grn)
		if(is.null(dat.red)) dat.red<-data.frame(red)
		else dat.red<-data.frame(dat.red,red)
	}
	dat.nm<-names(cData)
	if(!is.null(sample.mapping)){
		sid<-sample.mapping[dat.nm,]$sampleID
		dat.nm<-ifelse(is.na(sid),dat.nm,sid)
	}
	names(dat.red)<-dat.nm
	names(dat.grn)<-dat.nm
	ctr.dat<-dat.red/(dat.red+dat.grn)
	ctr_signal_red<-data.frame(ilmn_ctr_code[red.code,],dat.red,check.names=F)
	ctr_signal_grn<-data.frame(ilmn_ctr_code[grn.code,],dat.grn,check.names=F)
	if(verbose==F){
		data(NegCtlCode)
		ctr_signal_red<-merge(ctr_signal_red,ctl_code,by.x=1,by.y=1)[,c(-3,-4)]
		ctr_signal_grn<-merge(ctr_signal_grn,ctl_code,by.x=1,by.y=1)[,c(-3,-4)]
	}
	write.csv(ctr_signal_red[,-1],file="Control_Signal_Intensity_Red.csv",row.names=F,quote=F)
	write.csv(ctr_signal_grn[,-1],file="Control_Signal_Intensity_Grn.csv",row.names=F,quote=F)
	#write.csv(data.frame(ilmn_ctr_code[grn.code,-1],ctr.dat,check.names=F),file="Control_Value.csv",row.names=F,quote=F)
}
saveCtrData2CSV.3<-function(cData=NULL,outDir,sample.mapping=NULL,bp.method="filter.min"){
	setwd(outDir)
	data(ilmnCtrCode)
	row.names(ilmn_ctr_code)<-ilmn_ctr_code$code
	dat.grn<-NULL
	dat.red<-NULL
	for(i in 1:length(cData)){
		cdat<-split(cData[[i]][,c("code","Red","Grn")],as.factor(cData[[i]]$type))
		grn<-c();grn.name<-c();grn.code<-c()
		red<-c();red.name<-c();red.code<-c()
		for(j in 1:length(cdat)){
			grn.avg<-tapply(cdat[[j]]$Grn,cdat[[j]]$code,function(x){rs=bp(x,bp.method);rs[[1]]})
			grn<-c(grn,grn.avg)
			grn.code<-c(grn.code,names(grn.avg))
			grn.name<-c(grn.name,rep(names(cdat)[j],length(grn.avg)))
			red.avg<-tapply(cdat[[j]]$Red,cdat[[j]]$code,function(x){rs=bp(x,bp.method);rs[[1]]})
			red<-c(red,red.avg)
			red.code<-c(red.code,names(red.avg))
			red.name<-c(red.name,rep(names(cdat)[j],length(red.avg)))
		}
		names(grn)<-grn.name
		names(red)<-red.name
		if(is.null(dat.grn)) dat.grn<-data.frame(grn)
		else dat.grn<-data.frame(dat.grn,grn)
		if(is.null(dat.red)) dat.red<-data.frame(red)
		else dat.red<-data.frame(dat.red,red)
	}
	dat.nm<-names(cData)
	if(!is.null(sample.mapping)){
		sid<-sample.mapping[dat.nm,]$sampleID
		dat.nm<-ifelse(is.na(sid),dat.nm,sid)
	}
	names(dat.red)<-dat.nm
	names(dat.grn)<-dat.nm
	ctr.dat<-dat.red/(dat.red+dat.grn)
	write.csv(data.frame(ilmn_ctr_code[red.code,-1],dat.red,check.names=F),file="Control_Signal_Intensity_Red.csv",row.names=F,quote=F)
	write.csv(data.frame(ilmn_ctr_code[grn.code,-1],dat.grn,check.names=F),file="Control_Signal_Intensity_Grn.csv",row.names=F,quote=F)
	#write.csv(data.frame(ilmn_ctr_code[grn.code,-1],ctr.dat,check.names=F),file="Control_Value.csv",row.names=F,quote=F)
}
saveCtrData2CSV.2a<-function(cData=NULL,outDir,sample.mapping=NULL,bp.method="filter.min"){
	setwd(outDir)
	dat.grn<-NULL
	dat.red<-NULL
	for(i in 1:length(cData)){
		cdat<-split(cData[[i]][,c("code","Red","Grn")],as.factor(cData[[i]]$type))
		grn<-c();grn.name<-c()
		red<-c();red.name<-c()
		for(j in 1:length(cdat)){
			grn.avg<-tapply(cdat[[j]]$Grn,cdat[[j]]$code,function(x){rs=bp(x,bp.method);rs[[1]]})
			grn<-c(grn,grn.avg)
			grn.name<-c(grn.name,rep(names(cdat)[j],length(grn.avg)))
			red.avg<-tapply(cdat[[j]]$Red,cdat[[j]]$code,function(x){rs=bp(x,bp.method);rs[[1]]})
			red<-c(red,red.avg)
			red.name<-c(red.name,rep(names(cdat)[j],length(red.avg)))
		}
		names(grn)<-grn.name
		names(red)<-red.name
		if(is.null(dat.grn)) dat.grn<-data.frame(grn)
		else dat.grn<-data.frame(dat.grn,grn)
		if(is.null(dat.red)) dat.red<-data.frame(red)
		else dat.red<-data.frame(dat.red,red)
	}
	dat.nm<-names(cData)
	if(!is.null(sample.mapping)){
		sid<-sample.mapping[dat.nm,]$sampleID
		dat.nm<-ifelse(is.na(sid),dat.nm,sid)
	}
	names(dat.red)<-dat.nm
	names(dat.grn)<-dat.nm
	write.csv(data.frame(name=red.name,dat.red,check.names=F),file="Control_Signal_Intensity_Red.csv",row.names=F,quote=F)
	write.csv(data.frame(name=grn.name,dat.grn,check.names=F),file="Control_Signal_Intensity_Grn.csv",row.names=F,quote=F)
}
saveCtrData2CSV.2<-function(cData=NULL,outDir,sample.mapping=NULL){
	setwd(outDir)
	dat.grn<-NULL
	dat.red<-NULL
	for(i in 1:length(cData)){
		cdat<-split(cData[[i]][,c("code","Red","Grn")],as.factor(cData[[i]]$type))
		grn<-c();grn.name<-c()
		red<-c();red.name<-c()
		for(j in 1:length(cdat)){
			grn.avg<-tapply(cdat[[j]]$Grn,cdat[[j]]$code,mean)
			grn<-c(grn,grn.avg)
			grn.name<-c(grn.name,rep(names(cdat)[j],length(grn.avg)))
			red.avg<-tapply(cdat[[j]]$Red,cdat[[j]]$code,mean)
			red<-c(red,red.avg)
			red.name<-c(red.name,rep(names(cdat)[j],length(red.avg)))
		}
		names(grn)<-grn.name
		names(red)<-red.name
		if(is.null(dat.grn)) dat.grn<-data.frame(grn)
		else dat.grn<-data.frame(dat.grn,grn)
		if(is.null(dat.red)) dat.red<-data.frame(red)
		else dat.red<-data.frame(dat.red,red)
	}
	dat.nm<-names(cData)
	if(!is.null(sample.mapping)){
		sid<-sample.mapping[dat.nm,]$sampleID
		dat.nm<-ifelse(is.na(sid),dat.nm,sid)
	}
	names(dat.red)<-dat.nm
	names(dat.grn)<-dat.nm
	write.csv(data.frame(name=red.name,dat.red,check.names=F),file="Control_Signal_Intensity_Red.csv",row.names=F,quote=F)
	write.csv(data.frame(name=grn.name,dat.grn,check.names=F),file="Control_Signal_Intensity_Grn.csv",row.names=F,quote=F)
}
saveCtrData2CSV<-function(cData=NULL,outDir,sample.mapping=NULL){
	setwd(outDir)
	dat.grn<-NULL
	dat.red<-NULL
	for(i in 1:length(cData)){
		cdat<-split(cData[[i]][,c("code","Red","Grn")],as.factor(cData[[i]]$type))
		grn<-c();grn.name<-c()
		red<-c();red.name<-c()
		for(j in 1:length(cdat)){
			grn.avg<-tapply(cdat[[j]]$Grn,cdat[[j]]$code,mean)
			grn<-c(grn,grn.avg)
			grn.name<-c(grn.name,rep(names(cdat)[j],length(grn.avg)))
			red.avg<-tapply(cdat[[j]]$Red,cdat[[j]]$code,mean)
			red<-c(red,red.avg)
			red.name<-c(red.name,rep(names(cdat)[j],length(red.avg)))
		}
		names(grn)<-grn.name
		names(red)<-red.name
		if(is.null(dat.grn)) dat.grn<-data.frame(grn)
		else dat.grn<-data.frame(dat.grn,grn)
		if(is.null(dat.red)) dat.red<-data.frame(red)
		else dat.red<-data.frame(dat.red,red)
	}
	names(dat.red)<-names(cData)
	names(dat.grn)<-names(cData)
	write.csv(data.frame(name=red.name,dat.red),file="Control_Signal_Intensity_Red.csv",row.names=F,quote=F)
	write.csv(data.frame(name=grn.name,dat.grn),file="Control_Signal_Intensity_Grn.csv",row.names=F,quote=F)
}
saveProcessedTxtData.2a_test<-function(){
	load(file=file.path("C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out\\4207113144","mData.rdata"))
	am<-readSampleMapping("c:\\tcga\\arraymapping")
	outDir<-"c:\\temp\\4207113144"
	saveProcessedTxtData.2a(mData,outDir,sample.mapping=am)
}
saveProcessedTxtData.2a<-function(mData,outDir,fname="",sample.mapping=NULL,withStamp=F){
	setwd(outDir)
	timestamp<-""
	if(withStamp==T) timestamp<-as.numeric(Sys.time())
	fn_beta<-paste(fname,"BetaValue",timestamp,".csv",sep="")
	fn_Pvalue<-paste(fname,"Pvalue",timestamp,".csv",sep="")
	fn_Intensity<-paste(fname,"Signal_Inensities",timestamp,".csv",sep="")
	fn_M<-paste(fname,"Methylation_Signal_Intensity",timestamp,".csv",sep="")
	fn_U<-paste(fname,"UnMethylation_Signal_Intensity",timestamp,".csv",sep="")
	fn_Mnum<-paste(fname,"Methylation_Signal_Intensity_NBeads",timestamp,".csv",sep="")
	fn_Unum<-paste(fname,"UnMethylation_Signal_Intensity_NBeads",timestamp,".csv",sep="")
	fn_Mstderr<-paste(fname,"Methylation_Signal_Intensity_STDERR",timestamp,".csv",sep="")
	fn_Ustderr<-paste(fname,"UnMethylation_Signal_Intensity_STDERR",timestamp,".csv",sep="")
	rename<-function(dat){
		dat<-as.data.frame(dat)
		dat.n<-sapply(names(dat),function(x)paste(strsplit(x,"_")[[1]][1:2],collapse="_"))
		if(!is.null(sample.mapping)) {
			dat.n1<-gsub("^X","",dat.n)
			sid<-sample.mapping[dat.n1,]$sampleID
			dat.n<-ifelse(is.na(sid),dat.n,sid)
		}
		names(dat)<-dat.n
		return(dat)
	}
	bv<-rename(getBeta(mData))
	write.csv(bv,file=fn_beta,row.names=T,quote=F)
	pv<-rename(getPvalue(mData))
	write.csv(pv,file=fn_Pvalue,row.names=T,quote=F)
	M<-rename(getM(mData))
	write.csv(M,file=fn_M,row.names=T,quote=F)
	U<-rename(getU(mData))
	write.csv(U,file=fn_U,row.names=T,quote=F)
	Mn<-rename(mData@assayData$Mnumber)
	write.csv(Mn,file=fn_Mnum,row.names=T,quote=F)
	Un<-rename(mData@assayData$Unumber)
	write.csv(Un,file=fn_Unum,row.names=T,quote=F)
	Mse<-rename(mData@assayData$Mstderr)
	write.csv(Mse,file=fn_Mstderr,row.names=T,quote=F)
	Use<-rename(mData@assayData$Ustderr)
	write.csv(Use,file=fn_Ustderr,row.names=T,quote=F)
}
saveProcessedTxtData.2<-function(mData,outDir,fname,withStamp=F){
	setwd(outDir)
	timestamp<-""
	if(withStamp==T) timestamp<-as.numeric(Sys.time())
	fn_beta<-paste(fname,"_BetaValue",timestamp,".csv",sep="")
	fn_Pvalue<-paste(fname,"_Pvalue",timestamp,".csv",sep="")
	fn_Intensity<-paste(fname,"_Singal_Inensities",timestamp,".csv",sep="")
	fn_M<-paste(fname,"_Methylation_Singal_Intensity",timestamp,".csv",sep="")
	fn_U<-paste(fname,"_UnMethylation_Singal_Intensity",timestamp,".csv",sep="")
	#fn_pheno<-paste(fname,"_Pheno.csv",sep="")
	write.table(getBeta(mData),file=fn_beta,sep=",",row.names=T,quote=F)
	write.table(getPvalue(mData),file=fn_Pvalue,sep=",",row.names=T,quote=F)
	write.table(getM(mData),file=fn_M,sep=",",row.names=T,quote=F)
	write.table(getU(mData),file=fn_U,sep=",",row.names=T,quote=F)
	#write.table(getPhenoData(mData),file=fn_pheno,sep=",",row.names=T,quote=F)
}
##############################
runBatchCVS_test<-function(){
	datPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\5324215005"
	outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\5324215005_out2\\CSV"
	runBatchCVS(wdir=datPath,outdir=outPath)
}
runBatchCVS<-function(txtWin=NULL,toSave=T,wdir=NULL,outdir=NULL,toStamp=F){
	if(is.null(wdir)) wdir <- choose.dir() # tclvalue(tkchooseDirectory())
	if(!is.null(txtWin)) cat("> The data file folder selected is ",wdir,"\n > Start to process the CSV raw data files...\n")
	dat<-readRawMethCSV(wdir,txtWin);
	if(toSave==T){
		if(is.null(outdir)) outdir<-gFileDir
		setwd(outdir)
		timestamp<-"";
		if(toStamp==T) timestamp<-as.numeric(Sys.time())
		beta_fn<-paste("BetaValue",timestamp,".csv",sep="")
		pvalue_fn<-paste("DetectionPvalues",timestamp,".csv",sep="")
		signal_fn_M<-paste("SingalIntensity_M",timestamp,".csv",sep="")
		signal_fn_M_se<-paste("SignalIntensity_M_se",timestamp,".csv",sep="")
		signal_fn_U<-paste("SignalIntensity_U",timestamp,".csv",sep="")
		signal_fn_U_se<-paste("SignalIntensity_U_se",timestamp,".csv",sep="")
		avg_bead_num_A<-paste("AvgBeadsNum_U",timestamp,".csv",sep="")
		avg_bead_num_B<-paste("AvgBeadsNum_M",timestamp,".csv",sep="")
		ctr_fn_red<-paste("CtrIntensity_Red",timestamp,".csv",sep="")
		ctr_fn_grn<-paste("CtrIntensity_Grn",timestamp,".csv",sep="")
		M_Dev_fn<-paste("SignalIntensity_M_Dev",timestamp,".csv",sep="")
		U_Dev_fn<-paste("SignalIntensity_U_Dev",timestamp,".csv",sep="")
		write.table(getBeta(dat),file=beta_fn,sep=",",row.names=T,col.names=T,quote=F)
		write.table(getPvalue(dat),file=pvalue_fn,sep=",",row.names=T,col.names=T,quote=F)
		write.table(getM(dat),file=signal_fn_M,sep=",",row.names=T,col.names=T,quote=F)
		write.table(getU(dat),file=signal_fn_U,sep=",",row.names=T,col.names=T,quote=F)
		write.table(dat@assayData$M_Dev,file=M_Dev_fn,sep=",",row.names=T,col.names=T,quote=F)
		write.table(dat@assayData$U_Dev,file=U_Dev_fn,sep=",",row.names=T,col.names=T,quote=F)
		if(!is.null(txtWin)) cat(">Done! Please check out the output files ",beta_fn," ",pvalue_fn," and ",signal_fn," at ",outdir,"\n")
	}
}

readRawMethCSV<-function(dataDirectory,txt=NULL){
	#cat("start reading Raw Meth CSV")
	data(ilmn_code) #readIlmnCode()
	fidNames = c();
	setwd(dataDirectory);
	flist = list.files(pattern=".csv",
			recursive=T);
	Mn <- data.frame(id=1:27578);Mn<-Mn[,-1]
	Un <- data.frame(id=1:27578);Un<-Un[,-1]
	Pvalue <- data.frame(id=1:27578); Pvalue<-Pvalue[,-1]
	Mn_Dev<-data.frame(id=1:27578);Mn_Dev<-Mn_Dev[,-1]
	Un_Dev<-data.frame(id=1:27578);Un_Dev<-Un_Dev[,-1]
	ord.U = order(ilmn_code$IlmnID);
	ord = ilmn_code$IlmnID[ord.U]
	for(i in 1:length(flist)){
		flist_cur = unlist(strsplit(filetail(flist[i]),"\\."))[1];
		fidNames = c(fidNames,flist_cur);
		
		fdata=read.table(flist[i],header=TRUE,sep=",")
		meth_U = merge(fdata,ilmn_code,by.x=1,by.y="AddressA_ID",all.y=T)
		U = ifelse(meth_U$Color_Channel=="Red",meth_U$Mean.RED,meth_U$Mean.GRN) 
		U_Dev = ifelse(meth_U$Color_Channel=="Red",meth_U$Dev.RED,meth_U$Dev.GRN)
		U.sorted = U[order(meth_U$IlmnID)]
		Un <- data.frame(Un,U.sorted)
		Un_Dev<-data.frame(Un_Dev,U_Dev[order(meth_U$IlmnID)])
		
		meth_M = merge(fdata,ilmn_code,by.x=1,by.y="AddressB_ID",all.y=T)
		M = ifelse(meth_M$Color_Channel=="Red",meth_M$Mean.RED,meth_M$Mean.GRN)
		M_Dev=ifelse(meth_M$Color_Channel=="Red",meth_M$Dev.RED,meth_M$Dev.GRN)
		M.sorted = M[order(meth_M$IlmnID)]
		Mn <- data.frame(Mn,M.sorted)
		Mn_Dev<-data.frame(Mn_Dev,M_Dev[order(meth_M$IlmnID)])
		
		ctl_code <- data.frame(ctl_code=c(460494,540577,430114,1660097,1940364,610692,670750,1500059,1500398,1770019,1500167,50110,1990692,610706,360079,1190458));
		meth_ctl = merge(fdata,ctl_code,by.x=1,by.y=1)
		ctl_red_mean= mean(meth_ctl$Mean.RED);
		ctl_red_sd= sd(meth_ctl$Mean.RED);
		ctl_grn_mean= mean(meth_ctl$Mean.GRN);
		ctl_grn_sd= sd(meth_ctl$Mean.GRN);
		ctr_avg = ifelse(meth_M$Color_Channel=="Red",ctl_red_mean,ctl_grn_mean);
		ctr_sd = ifelse(meth_M$Color_Channel=="Red",ctl_red_sd,ctl_grn_sd);
		ctr_se = ifelse(meth_M$Color_Channel=="Red",ctl_red_sd/4,ctl_grn_sd/4)
		#AB = (M.sorted+U.sorted)/2;         #use max
		AB = ifelse(M.sorted>U.sorted,M.sorted,U.sorted)#max(M.sorted,U.sorted);
		# cal p 1-pnorm(z)
		z_score = (AB-ctr_avg)/ctr_se;
		pv = pnorm(as.matrix(z_score),lower.tail=FALSE)[,1];
		Pvalue <- data.frame(Pvalue,pv)
	}
	rownames(Mn)<-ilmn_code$IlmnID
	rownames(Un)<-ilmn_code$IlmnID
	colnames(Mn)<-fidNames
	colnames(Un)<-fidNames
	rownames(Mn_Dev)<-ilmn_code$IlmnID
	rownames(Un_Dev)<-ilmn_code$IlmnID
	colnames(Mn_Dev)<-fidNames
	colnames(Un_Dev)<-fidNames
	betaValue = Mn/(Mn+Un);
	rownames(Pvalue)<-rownames(betaValue)
	colnames(Pvalue)<-fidNames
	require(Biobase)
	mData<-new("methData",M=as.matrix(Mn),U=as.matrix(Un),Beta=as.matrix(betaValue),
			M_Dev=as.matrix(Mn_Dev),U_Dev=as.matrix(Un_Dev),Pvalue=as.matrix(Pvalue))
	featureData(mData)<-new("AnnotatedDataFrame",data=ilmn_code)
	return(mData)
}

#####################################
library(Biobase)
setClass("methData",contains="eSet")
if(is.null(getGeneric("getM")))setGeneric("getM",function(object,...) standardGeneric("getM"))
if(is.null(getGeneric("getU")))setGeneric("getU",function(object,...) standardGeneric("getU"))
if(is.null(getGeneric("getBeta")))setGeneric("getBeta",function(object,...) standardGeneric("getBeta"))
if(is.null(getGeneric("getPvalue")))setGeneric("getPvalue",function(object,...) standardGeneric("getPvalue"))
if(is.null(getGeneric("getColorChannel")))setGeneric("getColorChannel",function(object,...) standardGeneric("getColorChannel"))
if(is.null(getGeneric("getBaseChannel")))setGeneric("getBaseChannel",function(object,...) standardGeneric("getBaseChannel"))
if(is.null(getGeneric("getID")))setGeneric("getID",function(object,...)standardGeneric("getID"))
if(is.null(getGeneric("getProbeID")))setGeneric("getProbeID",function(object,...)standardGeneric("getProbeID"))
if(is.null(getGeneric("getPhenoData")))setGeneric("getPhenoData",function(object,...)standardGeneric("getPhenoData"))
#}
setMethod("getProbeID","methData",function(object,...){
			return(dimnames(object@assayData$M)[[1]])
		})
setMethod("initialize", "methData",
		function(.Object,
				M = new("matrix"),
				U = new("matrix"),
				BetaValue = new("matrix"),
				Pvalue = new("matrix"),
#				colorChannel=new("list"),
#				baseChannel = new("list"),
				...) {
			callNextMethod(.Object,
					M=M, U=U, BetaValue = BetaValue,Pvalue=Pvalue,
					...)
		})
# add validator to dim(bv)=dim(pv)
setMethod("getPhenoData","methData",function(object,...){
			return(pData(object@phenoData))
		})
setMethod("getID","methData",function(object,...){
			return(dimnames(object@assayData$M)[[2]])
		})
setMethod("getM","methData",function(object,...){
			return(object@assayData$M)
		})
setMethod("getU","methData",function(object,...){
			return(object@assayData$U)
		})
setMethod("getBeta","methData",function(object,...){
			return (object@assayData$BetaValue)
		})
setMethod("getPvalue","methData",function(object,...){
			return(object@assayData$Pvalue)
		})
setMethod("getColorChannel","methData",function(object,...){
			return(object@assayData$colorChannel)
		})
setMethod("getBaseChannel","methData",function(object,...){
			return(object@assayData$baseChannel)
		})

##########
filetail<-function(fileName){
	fn<-gsub("\\\\","/",fileName)
	fn<-unlist(strsplit(fn,"/"))
	return(fn[length(fn)])
}
filedir<-function(fileName){
	fn<-filetail(fileName)
	return(gsub(fn,"",fileName))
}
#rapidGUI<-function(){
#	wm<-paste("R(-based) Automated Pipeline for DNA-methylation (RAPiD) Pro 1.1",date())
#	require(methPipe)
#	methPipeGUI(tit=wm,tcgaMenu=T,mscanMenu=T)
#}
################
pdist<-function(){
	dat<-seq(1,100,by=0.1)
	pv<-pnorm(as.matrix(dat),lower.tail=F)[,1]
	X11()
	par(mfrow=c(1,2))
	plot(pv)
	plot(density(pv),col=3)
	dat2<-seq(37.51,37.52,by=0.00001)
	pv2<-pnorm(as.matrix(dat2),lower.tail=F)[,1]
	pv2.min<-min(pv2[pv2!=0])
	pv2.min
}

#rapid<-function(datPath=NULL,fromTXT=T,fromCSV=F,figPath=NULL,outFn=NULL,outDir="c:/temp",qc.plot=T){
#	require(Biobase)
#	assign("gFileDir",outDir,env=.GlobalEnv)
#	mData<-NULL
#	if(fromTXT==T){
#		mData<-readMethTxt(datPath,repDir=outDir)
#	}
#	if(fromCSV==T){
#		mData<-runBatchCVS(wdir=datPath,outdir=outDir)
#	}
#	#	if(toMScanCalibrate==TRUE){
##		rapid.mc(datPath,figPath,outFn)
##	}
#	return(mData)
#}

rapid.mc<-function(datPath=NULL,figPath=NULL,outFn=NULL){
	require(aroma.light)
	require(R.utils)
	if(is.null(datPath)){
		datPath<-"c:\\temp\\4207113144_test"
	}
	if(is.null(figPath)){
		figPath<-"c:\\temp\\results"
	}
	if(is.null(outFn)){
		outFn<-"Dat.out.rda"
	}
	dat.all<-load_beadlevel_scan_data(datPath)
	pre_calibration_plot(dat.all$datRG,figPath)
	dat.mc<-run_multiScan_calibration(dat.all$datRG,dat.all$datControls)
	dm<-post_calibration_plot(dat.mc$datRG,figPath)
	dat<-save_calibrated_data(dm,dat.mc$datRG,dat.mc$datControls,figPath,datFn=outFn)
	saveToCSVFiles(dat,dat.mc$datControls,datPath)
}

rapid_Test<-function(datPath=NULL){
	if(is.null(datPath))datPath<-"C:\\temp\\4207113144"
	outDir<-"c:\\temp"
	rapid(datPath,fromTXT=T,fromCSV=F,outDir=outDir)
}

rapid_Test.2<-function(datPath=NULL){
	if(is.null(datPath))datPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\5324215005\\"#"C:\\temp\\4828606022"
	outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\5324215005_out\\CSV"
	md1<-runBatchCVS(wdir=datPath,outdir=outPath)
}

calpvalue<-function(dat,ctr,pvalue.method="z-score",alternative="less"){
	pvalue<-matrix(1,ncol=ncol(dat),nrow=nrow(dat))
	
	if(pvalue.method=="z-score"){
		pvalue=pnorm((dat-mean(ctr,na.rm=T))/sd(ctr,na.rm=T),lower.tail=F)
	}else if(pvalue.method=="z-test"){
		pvalue<-pnorm((dat-mean(ctr,na.rm=T))/sd(ctr,na.rm=T)/sqrt(length(ctr)),lower.tail=F)
	}else if(pvalue.method=="t-test"){
		for(i in 1:nrow(dat)){
			for(j in 1:ncol(dat)){
				
				pvalue[i,j]<-t.test(ctr,mu=dat[i,j],alternative=alternative)$p.value
			}
		}
		
	}else if(pvalue.method=="mw-test"){
		
		for(i in 1:nrow(dat)){
			for(j in 1:ncol(dat)){
				pvalue[i,j]<-wilcox.test(ctr,mu=dat[i,j],alternative=alternative)$p.value
			}
		}
	}else{
		stop("pvalue.method is unknown")
		
	}
	return(pvalue)
}

calpvalue_test<-function(){
	dat<-matrix(rnorm(20),nrow=2)
	ctr<-rnorm(16,0.1)
	pv<-calpvalue(dat,ctr,"z-test")
	pv1<-calpvalue(dat,ctr,"z-score")
	pv2<-calpvalue(dat,ctr,"t-test")
	pv3<-calpvalue(dat,ctr,"mw-test")
}

#####################
mergeTCGAPkg_test<-function(){
	pkgPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\jhu-usc.edu_STAD.HumanMethylation27.1"
	pkgRepos<-"c:\\tcga"
	mergeTCGAPkg(pkgPath,pkgRepos)
}
mergeTCGAPkg.2<-function(pkgPath,pkgRepos){
	pkgPath.tcga<-file.path(pkgPath,"tcga")
	pkgname<-filetail(pkgRepos)
	pkg.type<-strsplit(strsplit(pkgname,"_")[[1]][2],"\\.")[[1]][1]
	targetFolder<-file.path(file.path(pkgPath.tcga,pkg.type))
	if(!file.exists(targetFolder)) dir.create(targetFolder)
	pkgname2<-paste(strsplit(pkgname,"\\.")[[1]][1:4],collapse=".")
	pkgPath2<-file.path(pkgRepos,pkgname2)
	updateSN(pkgPath2,targetFolder)
	setwd(pkgPath2)
	pkgFns<-list.files(pattern=".gz")
	for(fn in pkgFns){
		system(paste("cp ",fn," ",file.path(targetFolder,fn)))
	}
}
mergeTCGAPkg<-function(pkgPath,pkgRepos){
	pkgname<-filetail(pkgPath)
	pkg.type<-strsplit(strsplit(pkgname,"_")[[1]][2],"\\.")[[1]][1]
	targetFolder<-file.path(file.path(pkgPath,pkg.type))
	if(!file.exists(targetFolder)) dir.create(targetFolder)
	updateSN(pkgPath,targetFolder)
	setwd(pkgPath)
	pkgFns<-list.files(pattern=".gz")
	for(fn in pkgFns){
		system(paste("cp ",fn," ",file.path(targetFolder,fn)))
	}
}
updateSN<-function(pkgPath,pkgRepos){
	pkgFns<-list.files(path=pkgRepos,pattern=".gz$")
	if(length(pkgFns)<1)return()
	mageFn<-gsub(".tar.gz","",pkgFns[grep("mage-tab",pkgFns)])
	setwd(file.path(pkgRepos,mageFn))
	sdrfFn<-list.files(pattern="sdrf")
	sdrf<-readLines(sdrfFn)
	incSN<-function(sn){
		paste((as.numeric(strsplit(sn,"\\.")[[1]])+c(0,1,0)),collapse=".")
	}
	pkgFns<-list.files(path=pkgPath,pattern=".gz$")
	pkgName<-filetail(pkgPath)
	pkg.cur<-strsplit(sdrf[grep(pkgName,sdrf)][1],"\t")[[1]]
	pkg.cur.lvl1<-pkg.cur[grep(".Level_1",pkg.cur)]
	pkg.cur.sn.lvl1<-strsplit(pkg.cur.lvl1,"Level_1.")[[1]][2]
	pkgName.new.lvl1<-paste(pkgName,".Level_1.",incSN(pkg.cur.sn.lvl1),sep="")
	pkg.cur.lvl2<-pkg.cur[grep(".Level_2",pkg.cur)]
	pkg.cur.sn.lvl2<-strsplit(pkg.cur.lvl2,"Level_2.")[[1]][2]
	pkgName.new.lvl2<-paste(pkgName,".Level_2.",incSN(pkg.cur.sn.lvl2),sep="")
	pkg.cur.lvl3<-pkg.cur[grep(".Level_3",pkg.cur)]
	pkg.cur.sn.lvl3<-strsplit(pkg.cur.lvl3,"Level_3.")[[1]][2]
	pkgName.new.lvl3<-paste(pkgName,".Level_3.",incSN(pkg.cur.sn.lvl3),sep="")
	
	createMD5SUM<-function(pkg){
		cmd<-paste("md5sum ",pkg," > ",pkg,".md5",sep="")
		if(R.Version()$os=="mingw32"){
			shell(cmd)
		}else{
			system(cmd)
		}
	}
	setwd(pkgPath)
	pkgFn.lvl1<-pkgFns[grep("Level_1",pkgFns)]
	file.rename(pkgFn.lvl1,paste(pkgName.new.lvl1,".tar.gz",sep=""))
	createMD5SUM(paste(pkgName.new.lvl1,".tar.gz",sep=""))
	file.rename(paste(pkgFn.lvl1,".md5",sep=""),paste(pkgName.new.lvl1,".tar.gz.md5",sep=""))
	pkgFn.lvl2<-pkgFns[grep("Level_2",pkgFns)]
	file.rename(pkgFn.lvl2,paste(pkgName.new.lvl2,".tar.gz",sep=""))
	createMD5SUM(paste(pkgName.new.lvl2,".tar.gz",sep=""))
	file.rename(paste(pkgFn.lvl2,".md5",sep=""),paste(pkgName.new.lvl2,".tar.gz.md5",sep=""))
	pkgFn.lvl3<-pkgFns[grep("Level_3",pkgFns)]
	file.rename(pkgFn.lvl3,paste(pkgName.new.lvl3,".tar.gz",sep=""))
	createMD5SUM(paste(pkgName.new.lvl3,".tar.gz",sep=""))
	file.rename(paste(pkgFn.lvl3,".md5",sep=""),paste(pkgName.new.lvl3,".tar.gz.md5",sep=""))
	merge_Packages(pkgFns,pkgRepos)
}
##########
#rapidGUI<-function(){
#	require(methPipe)
#	methPipeGUI("R-based Automated Pipeline for DNA-methylation Software Program v1.1")
#}


readDataFile.2<-function(fileName,checkName=F,rowName=1,isNum=T,header1=T,sep=NULL,skip=0,toDetail=F){
	fext<-unlist(strsplit(fileName,"\\."))
	fext<-fext[length(fext)]
	dat<-NULL
	if(fext=="csv"){
		if(is.null(sep)){
			sep = ","
		}
		dat<-read.delim(fileName,as.is=T,check.names=checkName,sep=sep,row.names=rowName,header=header1,skip=skip)
	}else if(fext=="xls" | fext=="xlsx"){
		require(gdata)
		dat<-read.xls(fileName,as.is=T,
				check.names=checkName,row.names=rowName,header=header1,skip=skip)
		
	}else if(fext=="txt"){
		if(is.null(sep)){
			sep = "\t"
		}
		dat<-read.delim(fileName,as.is=T,
				check.names=checkName,sep=sep,row.names=rowName,header=header1,skip=skip)
	}
	cName<-names(dat)
	if(nchar(dat[1,1])==0 | nchar(row.names(dat)[1])==0){
		dat<-dat[-1,]
	}
	if(isNum){ 
		options(warn=-1)
		dat<-t(apply(dat,1,as.numeric))
		options(warn=1)
	}
	dat<-as.data.frame(dat)
	names(dat)<-cName
	dim.info<-paste(nrow(dat),"x",ncol(dat),sep="")
	content.info<-sum(is.na(dat))
	#fileName1<-tclvalue(tclfile.tail(fileName))
	fileName1<-filetail(fileName)
	cat(paste("The dim of the file ",fileName1," is ",dim.info, "with NAs:  ",content.info,"\n"))
	if(toDetail==TRUE){
		content.detail<-colSums(is.na(dat))
		cat(paste("The Nas per col are: \t",names(dat),"\t",content.detail,"\n",sep=""))
	}
	return(dat)
}
