# TODO: Add comment
# 
# Author: feipan
###############################################################################

##############################
# plot and store all the control figures
##############################
probePlot_test<-function(){
	mData<-get(print(load(file="C:\\Documents and Settings\\feipan\\workspace\\methPipe\\data\\methData_test.rdata")))
	setwd("c:\\temp")
	probePlot()
}
probePlot <-function(txt=NULL,data.dir=NULL,mData=NULL){
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Starting to generate the probe signal intensity plot ...",date(),"\n"))
	gdat<-mData
	if(is.null(mData)) gdat<-loadRawData()
	gdat.name<-"mu_plot.png"
	if(is.null(data.dir)) data.dir<-gFileDir 
	g.M=getM(gdat)
	g.U=getU(gdat)
	MUplot(g.M,g.U,toFile=TRUE,pname=gdat.name,data.dir)
	if(!is.null(txt)) tkinsert(txt,"end",">Finished generating the probe plots\n")
}
MUplot<-function(M,U,toFile=FALSE,pname="",data.dir=""){
	figName<-NULL
	if(toFile==FALSE){
		X11()
	}else{
		gdat.name=pname
		figName<-file.path(data.dir,gdat.name)
		png(filename=figName,width=1280,height=1280)
		
	}
	#require(mLab)
	par(mfrow=c(2,2))
	plotDensity(M)
	plotDensity(U)
	boxplot(M,col="blue",main="M")
	boxplot(U,col="green",main="U")
	#mva.plot.1(as.numeric(M),as.numeric(U))
	#plot(as.numeric(M),as.numeric(U),col="yellow",ylab="M",xlab="U",main="MU")
	if(toFile==TRUE){
		dev.off()
		#shell.exec(figName)
	}
}

rfgc<-function(cData){
	rst.all<-NULL
	for(i in 1:length(cData)){
		#rst<-split(cData[[i]][,c(7,10)],as.factor(cData[[i]][,2]))
		rst<-split(cData[[i]][,c("Grn","Red")],as.factor(cData[[i]]$type))
		if(is.null(rst.all)){
			rst.all<-rst
		}else{
			for(j in 1:length(rst)){
				rst.all[[j]]<-c(rst.all[[j]],rst[[j]])
			}
		}
	}
	return(rst.all)
}
plotControlProfiles <- function(cData=NULL,figName="control_profile.png",toFile=FALSE,outDir)
{
	if(is.null(cData))
		cData<-readControlData()
	if(toFile==TRUE){
		png(file=file.path(outDir,figName),width=1280,height=1280)
	}else{
		X11(width=1280,height=1280)
	}
	params <- par(bg="white")
	
	gData<-rfgc(cData)
	nn<-unique(cData[[1]]$type)
	n1<-ceiling(length(nn)/2)
	par(mfrow=c(n1,2))
	for(i in 1:length(nn)){
		name1<-names(gData[[i]])
		ind<-order(name1)
		dat<-NULL
		dat<-sapply(ind,function(x){c(dat,gData[[i]][[x]])})
		names(dat)<-name1[ind]
		boxplot(dat,col=(i+1),main=nn[i])
	}
	par(params)
	
	if(toFile==TRUE){
		dev.off()
		#shell.exec(file.path(outDir,figName))
	}
}

##########
#########
controlPlot_test<-function(){
	cData<-get(print(load(file="C:\\Documents and Settings\\feipan\\workspace\\methPipe\\data\\cDat_test.rdata")))
	gFileDir<-"c:\\temp"
	controlPlot()
}
controlPlot<-function(txt=NULL,toSave=T,cData=NULL,outDir=NULL){
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Start to generate the profile plots of the control probes ...",date(),"\n"))
	if(is.null(cData))
		cData<-readControlData(txt);
	if(toSave==TRUE){
		fn<-"control_plot.png" 
		plotControlProfiles(cData,figName=fn,toFile=toSave,outDir)
	}else{
		plotControlProfiles(cData,toFile=toSave)
	}
	if(!is.null(txt)) tkinsert(txt,"end",">Finished the control probe plots\n")
}

test_plot<-function(){
	Myhscale <- 1.5    # Horizontal scaling
	Myvscale <- 1.5    # Vertical scaling
	tt1 <- tktoplevel()
	tkwm.title(tt1,"A parabola")
	img <- tkrplot(tt1,fun=plotControlProfiles,hscale=Myhscale,vscale=Myvscale)
	tkgrid(img)
	copy.but <- tkbutton(tt1,text="Copy to Clipboard",command=function()CopyToClip())
	tkgrid(copy.but)
	x=-100:100
	y=x^2
	plot(x,y)
}
plotSuccessRate_test<-function(){
	mData<-get(print(load(file="C:\\Documents and Settings\\feipan\\workspace\\methPipe\\data\\methData_test.rdata")))
	plotFailureRate(outDir="c:\\temp")
}
plotFailureRate<-function(txt=NULL,toSave=T,figName="FailureRate.png",outDir=NULL,mData=NULL){
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Start to generate the success rate plot ...",date(),"\n"))
	if(is.null(mData)){
		mData<-loadRawData()
	}
	perDetectRate<-calDetectionRate(mData)
	plotDetectRate(perDetectRate[[1]],toSave,figName,outDir)
	if(!is.null(txt)) tkinsert(txt,"end",">Finished the success rate plot\n")
	return(perDetectRate)
}
controlIndexPlot<-function(txt=NULL,fromRawData=F,out.dir=NULL,toSave=F){
	if(is.null(cData)){
		if(fromRawData==TRUE){
			cData<-loadRawQCData()
		}else{
			cData<-loadQCData()
		}
	}
	
	if(is.null(out.dir)){
		out.dir<-gFileDir #tempdir();
	}
	
	controlIndex<-calControlIndex(cData)
	plotCtrIndex(controlIndex)
	if(toSave==T){
#		qcIndex<-list(dataIndex=perDetectRate,ctrIndex=controlIndex)
#		ctrIndex=list(perDetectRate=perDetectRate,controlIndex=controlIndex)
		#qcIndex<-list(ctrIndex=controlIndex)
		ctrIndex=list(controlIndex=controlIndex)
		save(ctrIndex,file=file.path(out.dir,"ctrIndex.rdata"))
		if(!is.null(txt)){
			tkconfigure(txt, state="normal")
			out<-paste("< Done\n Please check out the control Index report at ",out.dir,"/ctrIndex.rdata",sep="")
			tkinsert(txt,"end",out)
			tkconfigure(txt, state="disabled")
		}
	}
}
plotCtrIndex<-function(controlIndex,outdir=NULL,isLog=T){
	#X11()
	if(is.null(outdir)) outdir<-gFileDir
	figName<-file.path(outdir,"controlIndex.png")
	png(file=figName,width=1280,height=1280)
	len<-ceiling(length(controlIndex)/2)
	par(mfrow=c(len,2))
	#sapply(controlIndex,function(x)barplot(x,col=2:(length(x)+1)))#,main=names(x)))
	name1<-names(controlIndex)
	for(i in 1:length(controlIndex)){
		nm<-name1[i]
		dat<-controlIndex[[i]]
		if(isLog==T){
			dat<--log10(controlIndex[[i]])
		}
		ym<-NULL
		if(length(na.omit(dat)==0)){
			ym<-0.1
			next;
		}else{
			ym<-max(dat,na.rm=T)+0.1
		}
		barplot(dat,col=2:(length(dat)+1),main=nm,ylim=c(0,1))
	}
	dev.off()
	#shell.exec(figName)
}
plotDetectRate<-function(perDetectRate,toSave,figName,outDir=NULL){
	if(toSave==TRUE){
		if(is.null(outDir)) outDir<-gFileDir
		png(file.path(outDir,figName),width=1200,height=1200)
	}else{
		X11()
	}
	tit<-"Percentage of Detection Pvalue Greater than 0.05"
	par(las=3,mar=c(10,4,4,2)+0.1,cex.lab=0.1)
	barplot(perDetectRate,col=2:(length(perDetectRate)+1),main=tit)
#	barplot(perDetectRate[[1]],col=2:(length(perDetectRate[[1]])+1),main=tit)
#	axis(side=1,at=1:length(perDetectRate[[1]]))#labels=names(perDetectRate[[1]]))
	if(toSave==TRUE){
		dev.off()
		#shell.exec(file.path(outDir,figName))
	}
}
calControlIndex<-function(cData){
	ctrIndex<-list()
	ctr.summary<-lapply(cData,function(x)summary(x))
	cdat<-rfgc(cData)
	ctr.pvalue<-lapply(cdat,calPvalue)
	calPvalue<-function(dat){
		len<-length(dat)
		pvalue<-c()
		len1<-seq(1,len,2)
		for(i in len1){
			dat.1<-as.numeric(dat[[i]])
			dat.2<-as.numeric(dat[[(i+1)]])
			p.value<-NA
			if(length(na.omit(dat.1))>=3 & length(na.omit(dat.2))>=3){
				wtest<-wilcox.test(dat.1,dat.2)
				p.value<-wtest$p.value
			}
			pvalue<-c(pvalue,p.value)
		}
		return(pvalue)
	}
	return(ctr.pvalue)
}
#	calPvalue<-function(dat){
#		len<-ncol(dat)
#		pvalue<-c()
#		for(i in 1:len/2){
#			dat.1<-as.numeric(dat[,i])
#			dat.2<-as.numeric(dat[,(i+1)])
#			p.value<-NA
#			if(length(na.omit(dat.1))>=3 & length(na.omit(dat.2))>=3){
#				wtest<-wilcox.test(dat.1,dat.2)
#				p.value<-wtest$p.value
#			}
#			pvalue<-c(pvalue,p.value)
#		}
#		return(pvalue)
#	}

calDetectionRate<-function(mData,threshold=0.05){
	if(is.null(mData)){
		cat("mData is null\n")
		return;
	}
	mData.beta<-getBeta(mData)
	mData.pvalue<-getPvalue(mData)
	mData.M<-getM(mData)
	mData.U<-getU(mData)
	n.col<-ncol(mData.beta)
	n.row<-nrow(mData.beta)
	mData.summary<-c()
	sampID<-getID(mData)
	summary.M<-summary(mData.M)
	summary.U<-summary(mData.U)
	summary.beta<-summary(mData.beta)
	summary.pvalue<-summary(mData.pvalue)
	mData.rate<-c()
	for(i in 1:n.col){
		summary.detectionRate<-sum(as.numeric(mData.pvalue[,i])>threshold,na.rm=T)/n.row
		mData.rate<-c(mData.rate,summary.detectionRate)
		
	}
	names(mData.rate)<-sampID
	mData.summary<-list(mData.rate,summary.M,
			summary.U,summary.beta,
			summary.pvalue)
	return(mData.summary)
}


normalizationPlot<-function(data){
	X11()
	boxplot(data,col="green",main="boxplot of the normalized data")
	
	diag.panel = function (x, ...) {
		par(new = TRUE)
		hist(x, 
				col = "light blue", 
				probability = TRUE, 
				axes = FALSE, 
				main = "")
		lines(density(x), 
				col = "red", 
				lwd = 3)
		rug(x)
	}
	
	
	
	panel.cor <- function(x, y, digits=2, prefix="", cex.cor)
	{
		usr <- par("usr"); on.exit(par(usr))
		par(usr = c(0, 1, 0, 1))
		r <- abs(cor(x, y))
		txt <- format(c(r, 0.123456789), digits=digits)[1]
		txt <- paste(prefix, txt, sep="")
		if(missing(cex.cor)) cex.cor <- 0.8/strwidth(txt)
		text(0.5, 0.5, txt, cex = cex.cor * r)
	}
	X11()
	pairs(data,main="scatter plot of the normalizaed data",
			lower.panel=panel.smooth,
			diag.panel =diag.panel,
			upper.panel=panel.cor)
}
plotDensity<-function(dat,color=NULL,xlab="",ylab="",main=""){
	if(is.null(color))plot(density(na.omit(dat[,1])),main=main,col=1)
	else plot(density(na.omit(dat[,1])),main=main,col=color[1])
	if(ncol(dat)>=2){
		for(i in 2:ncol(dat)){
			par(new=T,yaxt="n",xaxt="n")
			if(is.null(color))plot(density(na.omit(dat[,i])),main=main,col=i,xlab=xlab,ylab=ylab)
			else plot(density(na.omit(dat[,i])),main=main,col=color[i],xlab=xlab,ylab=ylab)
		}
	}
}
