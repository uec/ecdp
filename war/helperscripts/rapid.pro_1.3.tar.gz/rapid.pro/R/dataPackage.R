# TODO: Add comment
# 
# Author: feipan
###############################################################################



test_create_level_1_data<-function(){
	load(file.path("c:\\temp","mData.Rdata"))
	package_name<-"jhu-usc.edu_GBM.IlluminaDNAMethylation_OMA003_CPI.Level_1"
	ver<-"1.0.0"
	create_level_1_data(mData,ver,package_name)
}

create_level_1_data<-function(mData=NULL,ver=NULL,package_name=NULL,dir.work=NULL){
	hd1<-"Hybridization REF"
	header<-paste("Composite Element REF","Cy3","Cy5","Detection Pvalue",sep="\t")
	readMetaData()
	sampID<-getSampID(mData)
	IlmnID<-getProbeID(mData)
	M<-getM(mData)
	U<-getU(mData)
	pvalue<-getPvalue(mData)
	if(is.null(dir.work)){
		dir.work<-"c:\\temp"
	}
	setwd(dir.work)
	dir.create(package_name)
	fp<-file.path(dir.work,package_name)
	setwd(fp)
	for(i in 1:length(sampID)){
		fn<-file.path(fp,paste(sampID[i],ver,"txt",sep="."))
		zz<-file(fn,"wt")
		cat(paste(hd1,sampID[i],sampID[i],sampID[i],sampID[i],"\t"),file=zz,"\n")
		cat(header,file=zz,"\n")
		for(j in 1:nrow(M)){
			cat(paste(IlmnID[j],M[j],U[j],pvalue[j],sep="\t"),file=zz,"\n")
		}
		close(zz)
	}
}

test_create_level_2_data<-function(){
	load(file.path("c:\\temp","mData.Rdata"))
	threshold<-0.05
	create_level_2_data(mData,ver="1.2.0",pacakge_name="jhu-usc.edu_GBM.IlluminaDNAMethylation_OMA002_CPI")
}
create_level_2_data<-function(mData,ver=NULL,package_name=NULL,threshold=0.05,dir.work){
	if(is.null(dir.work)){
		dir.work<-"c:\\temp"
	}
	setwd(dir.work)
	head1<-paste("Composite Element REF","Beta Value",sep="\t")
	hd1<-"Hybridization REF"
	betaValue<-getBeta(mData)
	pValue<-getPvalue(mData)
	betaValue<-ifelse(pValue<threshold,betaValue,"NA")
	sampID<-getSampID(mData)
	IlmnID<-getProbeID(mData)
	if(!exists(package_name)) dir.create(package_name)
	fpath<-file.path(dir.work,package_name)
	setwd(fpath)
	for(i in 1:length(sampID)){
		fn<-file.path(fpath,paste(sampID[i],ver,"txt",sep="."))
		file.cur<-file(fn,"wt")
		cat(paste(hd1,sampID[i],sep="\t"),file=file.cur,"\n")
		cat(head1,file=file.cur,"\n")
		for(j in 1:nrow(betaValue)){
			cat(paste(IlmnID[j],betaValue[j]),file=file.cur,"\n")
		}
		close(file.cur)
	}
}



create_level_1_Infinium<-function(mData,ver=NULL,package_name=NULL,dir.work=NULL,sampID=NULL){
	hd1<-"Hybridization REF"
	header<-paste("Composite Element REF",
			"Methylated_Signal_Intensity (M)",
			"M_Number_Beads	M_STDERR",
			"Un-Methylated_Signal_Intensity (U)",
			"U_Number_Beads	U_STDERR",
			"Negative_Control_Grn_Avg_Intensity",	
			"Negative_Control_Grn_STDERR",
			"Negative_Control_Red_Avg_Intensity",
			"Negative_Control_Red_STDERR",
			"Detection_P_Value",sep="\t")
	if(is.null(sampID))sampID<-getSampID(mData)
	IlmnID<-getID(mData)
	M<-getM(mData)
	U<-getU(mData)
	pvalue<-getPvalue(mData)
	
	mstd<-getMSTD(mData)
	ustd<-getUSTD(mData)
	negCtrGrn<-getNegCtrGrn(mData)
	negStdGrn<-getNegStdGrn(mData)
	negCtrRed<-getNegCtrRed(mData)
	netStdRed<-getNegStdRed(mData)
	setwd(dir.work)
	if(!file.exists(package_name))dir.create(package_name)
	for(i in 1:ncol(M)){
		fn<-paste(pack_name,ver,sep="")
		zz<-file(fn,"wt")
		cat(paste(hd1,sampID[i],sampID[i],sampID[i],sampID[i],
						sampID[i],sampID[i],sampID[i],
						sampID[i],sampID[i],sep="\t"))
		cat(header,file=zz,"\n")
		for(j in 1:nrow(M)){
			cat(paste(IlmnID[j],M[j],mstd[j],U[j],ustd[j],negCtrGrn[j],negStdGrn[j],netCtrRed[j],negStdRed[j]),file=zz,"\n")
		}
		close(zz)
	}
}
crete_level_2_Infinium<-function(mData,ver=NULL,package_name=NULL,threshold=0.05,dir.work=NULL,sampID=NULL)
{
	hd1<-"Hybridization REF"
	header<-paste("Composite Element REF","Beta_Value")
	if(is.null(sampID)) sampID<-getSampID(mData)
	IlmnID<-getProbeID(mData)
	bv<-getBeta(mData)
	pv<-getPvalue(mData)
	betaValue<-ifelse(pv<threshold,bv,"NA")
	if(is.null(dir.work)){
		dir.work<-"c:\\temp"
	}
	setwd(dir.work)
	if(!file.exists(package_name)){
		dir.create(package_name)
	}
	for(i in 1:length(sampID)){
		fn<-paste(package_name,sampID[i],"Level_2",ver,sep=".")
		zz<-file(fn,"wt")
		cat(paste(hd1,"Beta Value",sep="\t"),file=zz,"\n")
		cat(header)
		for(j in 1:nrow(bv)){
			cat(paste(IlmnID[j],betaValue[j],sep="\t"),file=zz,"\n")
		}
		close(zz)
	}
}
create_level_3_Infinium<-function(mData,ver=NULL,package_name=NULL,threshold=0.05,dir.work=NULL,sampID=NULL){
	hd1<-"Hybridization REF"
	header<-paste("Composite Element REF","Beta_Value",
			"Gene_Symbol","Chromosome","Genomic_Coordinate",sep="\t")
	if(is.null(sampID))sampID<-getSampID(mData)
	ilmnID<-getProbeID(mData)
	betaValue<-getBeta(mData)
	pvalue<-getPvalue(mData)
	betaValue<-ifelse(pvalue<threshold,betaValue,"NA")
	library(methAnnot)
	getData()
	len<-nrow(humanMeth27k)	
	setwd(dir.work)
	if(!file.exists(package_name))dir.create(package_name)
	for(i in 1:length(sampID)){
		fn<-paste(pack_name,"Level_3",ver,sep="")
		zz<-file(fn,"wt")
		cat(paste(hd1,sampID[i],sampID[i],sampID[i],sampID[i]),file=zz,"\n")
		cat(header,file=zz,"\n")
		for(j in 1:len){
			cat(paste(ilmnID[j],betaValue[j],humanMeth27k$Symbol[j],
							humanMeth27k$Chr[j],humanMeth27k$MapInfo[j],sep="\t"),file=zz,"\n")
		}
		close(fn)
	}
}
createManifestByLevel.2_test<-function(){
	pkg_folder<-"C:\\tcga\\repos\\jhu-usc.edu_COAD.HumanMethylation27.1"
	lvl_folder<-"jhu-usc.edu_COAD.HumanMethylation27.Level_1.1.0.0"
	createManifestByLevel.2(pkg_folder,lvl_folder)
}
createManifestByLevel.2<-function(pkg_folder,lvl_folder=NULL){
	if(is.null(lvl_folder)){
		lvl_folder<-tclvalue(tclfile.tail(pkg_folder))
		pkg_folder<-tclvalue(tclfile.dir(pkg_folder))
	}
	setwd(file.path(pkg_folder,lvl_folder))
	if(file.exists("MANIFEST.txt")) file.remove("MANIFEST.txt")
	if(R.Version()$os=="mingw32"){
		md5sum<-"md5sum"
		if(file.exists(system.file("Rtools",package="rapid"))) md5sum<-file.path(system.file("Rtools",package="rapid"),"md5sum")
		shell(paste(md5sum," -t *.* > MANIFEST.txt",sep=""))
	}else if(substr(R.Version()$os,1,5)=="linux"){
		system("md5sum *.* >MANIFEST.txt")
	}else{
		system("MD5 -r *.* > MANIFEST.txt")
	}
}

#createManifestByLevel.2<-function(pkg_folder,lvl_folder=NULL){
#	if(is.null(lvl_folder)){
#		lvl_folder<-tclvalue(tclfile.tail(pkg_folder))
#		pkg_folder<-tclvalue(tclfile.dir(pkg_folder))
#	}
#	setwd(file.path(pkg_folder,lvl_folder))
#	if(file.exists("MANIFEST.txt")) file.remove("MANIFEST.txt")
#	if(R.Version()$os=="mingw32"){
#		md5sum<-"md5sum"
#		if(file.exists(system.file("Rtools",package="rapid"))) md5sum<-file.path(system.file("Rtools",package="rapid"),"md5sum")
#		shell(paste(md5sum," -t *.* > MANIFEST.txt",sep=""))
#	}else{
#		system("md5sum *.* >MANIFEST.txt")
#	}
#}


createManifest<-function(pkg_folder,lvl_folder,zz){
	#pref6<-file.path(pkg_folder,lvl_folder) #flist[i];#file.path(pkg_folder,flist[i])
	pref6<-lvl_folder
	cat("cd ", pref6,"\n",file=zz)
	command<-paste("md5sum *.* > MANIFEST.txt")
	cat(command,"\n",file=zz)
	cat("cd ..\n",file=zz)
}
modifyManifest<-function(pkg_folder,lvl_folder){
	pref6<-file.path(pkg_folder,lvl_folder)#flist[i])
	mfn<-file.path(pref6,"MANIFEST.txt")
	fc<-readLines(mfn)
	ind<-grep("MANIFEST",fc)
	fc<-fc[-ind]
	fc.new<-gsub("\\*","",fc)
	#cat(fc.new,file=mfn)
	rr<-data.frame(fc.new)
	write.table(rr,file=mfn,row.names=F,col.names=F,quote=F)
}
createManifestByLevel<-function(pkg_folder){
	setwd(pkg_folder)
	flist<-list.files()
	runBat<-file.path(pkg_folder,"run.bat")
	zz<-file(runBat,"w")
	for(i in 1:length(flist)){
		createManifest(pkg_folder,flist[i],zz)
#		pref6<-flist[i];#file.path(pkg_folder,flist[i])
#		cat("cd ", pref6,"\n",file=zz)
#		command<-paste("md5sum *.* > MANIFEST.txt")
#		cat(command,"\n",file=zz)
#		cat("cd ..\n",file=zz)
	}
	close(zz)
	shell(runBat)
	
	for(i in 1:length(flist)){
		modifyManifest(pkg_folder,flist[i])
#		pref6<-file.path(pkg_folder,flist[i])
#		mfn<-file.path(pref6,"MANIFEST.txt")
#		fc<-readLines(mfn)
#		ind<-grep("MANIFEST",fc)
#		fc<-fc[-ind]
#		fc.new<-gsub("\\*","",fc)
#		#cat(fc.new,file=mfn)
#		rr<-data.frame(fc.new)
#		write.table(rr,file=mfn,row.names=F,col.names=F,quote=F)
	}
	#unlink(runBat)
}
compressDataPackage_test<-function(){
	pkg_folder<-"c:\\temp\\4698"
	compressDataPackage(pkg_folder)
	pkg_folder<-"/auto/uec-02/shared/production/methylation/meth27k/3435323"
	compressDataPackage(pkg_folder)
	pkg_folder<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out\\5543207013\\jhu-usc.edu_STAD.HumanMethylation27.1\\jhu-usc.edu_STAD.HumanMethylation27.mage-tab.1.1.0"
	compressDataPackage(pkg_folder)
}
compressDataPackage<-function(pkg_folder,lvl_fdname=NULL){
	if(is.null(lvl_fdname)){
		lvl_fdname<-filetail(pkg_folder)
		pkg_folder<-filedir(pkg_folder)
	}
	setwd(pkg_folder)
	
	if(R.Version()$os=="mingw32"){
		tar<-"tar"
		if(file.exists(system.file("Rtools",package="rapid"))) tar<-file.path(system.file("Rtools",package="rapid"),"tar")
		command <- paste(tar," -cvf ",lvl_fdname,".tar ",lvl_fdname,sep="")
		system(command,wait=T)
		gzip<-"gzip"
		if(file.exists(system.file("Rtools",package="rapid"))) gzip<-file.path(system.file("Rtools",package="rapid"),"gzip")
		command <- paste(gzip," -f ",lvl_fdname,".tar ",sep="")
		system(command,wait=T)
		md5sum<-"md5sum"
		if(file.exists(system.file("Rtools",package="rapid"))) md5sum<-file.path(system.file("Rtools",package="rapid"),"md5sum")
		command <- paste(md5sum," ",lvl_fdname,".tar.gz>",lvl_fdname,".tar.gz.md5",sep="")
		shell(command)
	}else{
		command <- paste("tar -cvf ",lvl_fdname,".tar ",lvl_fdname,sep="")
		system(command,wait=T)
		command <- paste("gzip -f ",lvl_fdname,".tar ",sep="")
		system(command,wait=T)
		if(substr(R.Version()$os,1,5)=="linux"){
			command <- paste("md5sum ",lvl_fdname,".tar.gz>",lvl_fdname,".tar.gz.md5",sep="")
		}else{
			command <- paste("MD5 -r ",lvl_fdname,".tar.gz>",lvl_fdname,".tar.gz.md5",sep="")
		}
		system(command)
	}
}

#compressDataPackage<-function(pkg_folder,lvl_fdname=NULL){
#	if(is.null(lvl_fdname)){
#		lvl_fdname<-filetail(pkg_folder)
#		pkg_folder<-filedir(pkg_folder)
#	}
#	setwd(pkg_folder)
#	
#	if(R.Version()$os=="mingw32"){
#		tar<-"tar"
#		if(file.exists(system.file("Rtools",package="rapid"))) tar<-file.path(system.file("Rtools",package="rapid"),"tar")
#		command <- paste(tar," -cvf ",lvl_fdname,".tar ",lvl_fdname,sep="")
#		system(command,wait=T)
#		gzip<-"gzip"
#		if(file.exists(system.file("Rtools",package="rapid"))) gzip<-file.path(system.file("Rtools",package="rapid"),"gzip")
#		command <- paste(gzip," -f ",lvl_fdname,".tar ",sep="")
#		system(command,wait=T)
#		md5sum<-"md5sum"
#		if(file.exists(system.file("Rtools",package="rapid"))) md5sum<-file.path(system.file("Rtools",package="rapid"),"md5sum")
#		command <- paste(md5sum," ",lvl_fdname,".tar.gz>",lvl_fdname,".tar.gz.md5",sep="")
#		shell(command)
#	}else{
#		command <- paste("tar -cvf ",lvl_fdname,".tar ",lvl_fdname,sep="")
#		system(command,wait=T)
#		command <- paste("gzip -f ",lvl_fdname,".tar ",sep="")
#		system(command,wait=T)
#		command <- paste("md5sum ",lvl_fdname,".tar.gz>",lvl_fdname,".tar.gz.md5",sep="")
#		system(command)
#	}
#}

sendMessage<-function(txt=NULL,msg=""){
	if(!is.null(txt)){
		tkinsert(txt,"end",msg)
	}else{
		cat(msg)
	}
}
createLvl1Package_test<-function(){
	library(tcltk)
	datDir<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\TCGA Batch 26 Data Package"
	reValue<-c(file.path(datDir,"TCGA Batch 26 Methylated Signal Intensity.xls"),file.path(datDir,"TCGA Batch 26 Methylated Bead Std Error.xls"),file.path(datDir,"TCGA Batch 26 Avg Number of Methylated Beads.xls"),
			file.path(datDir,"TCGA Batch 26 Unmethylated Signal Intensity.xls"),file.path(datDir,"TCGA Batch 26 Unmethylated Bead Std Error.xls"),file.path(datDir,"TCGA Batch 26 Avg Number of Unmethylated Beads.xls"),
			file.path(datDir,"TCGA Batch 26 Negative Control Signal_Red.xls"),file.path(datDir,"TCGA Batch 26 Negative Control SIgnal_Green.xls"),"jhu-usc.edu_GBM.HumanMethylation27.Level_1.1.1.0",
			file.path(datDir,"TCGA Batch 26 README.txt"),"c:\\temp",file.path(datDir,"TCGA Batch 26 Detection p-values_bk.xls"))
	
	createLvl1Package(auto=T)
	
	reValue<-c(file.path(datDir,"TCGA Batch 26 Methylated Signal Intensity.csv"),file.path(datDir,"TCGA Batch 26 Methylated Bead Std Error.csv"),file.path(datDir,"TCGA Batch 26 Avg Number of Methylated Beads.csv"),
			file.path(datDir,"TCGA Batch 26 Unmethylated Signal Intensity.csv"),file.path(datDir,"TCGA Batch 26 Unmethylated Bead Std Error.csv"),file.path(datDir,"TCGA Batch 26 Avg Number of Unmethylated Beads.csv"),
			file.path(datDir,"TCGA Batch 26 Negative Control Signal_Red.csv"),file.path(datDir,"TCGA Batch 26 Negative Control SIgnal_Green.csv"),"jhu-usc.edu_GBM.HumanMethylation27.Level_1.1.1.0",
			file.path(datDir,"TCGA Batch 26 README.txt"),"c:\\temp",file.path(datDir,"TCGA Batch 26 Detection p-values_bk.csv"))
	assign("reValue",reValue,env=.GlobalEnv)
	createLvl1Package(auto=T)
}

createLvl1Package<-function(txt=NULL,auto=F){
	if(auto==F)createLvl1PackageDialog("Create Level 1 Data Package")
	if(is.null(reValue))return()
	if(!is.txt(txt)) tkinsert(txt,"end",message=">Start to creating the level_1 data packages:\n")
	sig_A<-reValue[1]
	sig_A_n<-reValue[2]
	sig_A_se<-reValue[3]
	sig_B<-reValue[4]
	sig_B_n<-reValue[5]
	sig_B_se<-reValue[6]
	ctr_R_fn<-reValue[7]
	ctr_G_fn<-reValue[8]
	tcgaPackage_name<-reValue[9]
	readme_fn<-reValue[10]
	outdir<-file.path(reValue[11],tcgaPackage_name)
	if(!file.exists(outdir))dir.create(outdir)
	setwd(outdir)           #
	pvalue_fn<-reValue[12]
	reValue<<-NULL
	pref<-paste(c(strsplit(tcgaPackage_name,"\\.")[[1]][c(1,2,3,5)],"lvl-1."),collapse=".")
	rst<-processLevel1Data(sig_A,sig_A_n,sig_A_se,sig_B,sig_B_n,sig_B_se,ctr_R_fn,ctr_G_fn,pvalue_fn,pref)
	
	if(readme_fn!=""){
		file.copy(readme_fn,file.path(outdir,"DESCRIPTION.TXT"))
	}
	lvl_1_fdname<-outdir
	createManifestByLevel.2(lvl_1_fdname)
	compressDataPackage(lvl_1_fdname)
	if(!is.null(txt)){
		msg<-paste(">Finished creating the level-1 data package...",date(),"\n",sep="")
		tkinsert(txt,"end",msg)
	}	
}
#createLvl1Package<-function(txt=NULL,auto=F){
#	if(auto==F)createLvl1PackageDialog("Create Level 1 Data Package")
#	if(is.null(reValue))return()
#	sig_A<-reValue[1]
#	sig_A_n<-reValue[2]
#	sig_A_se<-reValue[3]
#	sig_B<-reValue[4]
#	sig_B_n<-reValue[5]
#	sig_B_se<-reValue[6]
#	ctr_R_fn<-reValue[7]
#	ctr_G_fn<-reValue[8]
#	tcgaPackage_name<-reValue[9]
#	readme_fn<-reValue[10]
#	outdir<-file.path(reValue[11],tcgaPackage_name)
#	if(!file.exists(outdir))dir.create(outdir)
#	pvalue_fn<-reValue[12]
#	reValue<<-NULL
#	pref<-paste(c(strsplit(tcgaPackage_name,"\\.")[[1]][c(1,2,3,5)],"lvl-1."),collapse=".")
#	rst<-processLevel1Data()
#	
#	if(readme_fn!=""){
#		file.copy(readme_fn,file.path(outdir,"DESCRIPTION.TXT"))
#	}
#	lvl_1_fdname<-outdir
#	createManifestByLevel.2(lvl_1_fdname)
#	compressDataPackage(lvl_1_fdname)
#	if(!is.null(txt)){
#		msg<-paste("> Finished creating the level-1 data package...",date(),"\n",sep="")
#		tkinsert(txt,"end",msg)
#	}	
#}
updateLvl1Package<-function(txt=NULL){
	updateLvl1PackageDialog.2("Update Level 1 Data Pacakge")
	if(is.null(reValue))return()
	if(!is.null(txt)) tkinsert(txt,"end",">Start to create the level 1 data package\n")
	lvl_1_fdname<-file.path(reValue[2],reValue[4])
	create_lvl1_data_pkg(reValue[1],reValue[2],reValue[3],reValue[4])
	createManifestByLevel.2(lvl_1_fdname)
	compressDataPackage(lvl_1_fdname)
	reValue<<-NULL
	if(!is.null(txt)) tkinsert(txt,"end",">Finished the level 1 data packaging\n")
}
updateLvl1PackageDialog.2<-function(tit=""){
	dlg<-startDialog(tit)
	dlg1<-tkfrm(dlg)
	tkgrid(tklabel(dlg,text=" "))
	addTextEntryWidget(dlg1,"Select the Data Source Folder:","",isFolder=T,name="srcDataFolder")
	addTextEntryWidget(dlg1,"Select the Level 1 Package Folder:","",isFolder=T,name="pkgFolder")
	addTextEntryWidget(dlg1,"Select the Description File (Opt):","",isFolder=F,name="description")
	addTextEntryWidget(dlg1,"Type in the Data Package Name:","",isFolder=F,withSelectButton=F,name="pkgName")
	tkaddfrm(dlg,dlg1)
	endDialog(dlg,c("srcDataFolder","pkgFolder","description","pkgName"),pad=T)
}
createLvl1PackageDialog<-function(tit=""){
	dlg<-startDialog(tit)
	dlg1<-tkfrm(dlg)
	tkgrid(tklabel(dlg,text=" "))
	addTextEntryWidget(dlg1,"The Methylated Signal Intensity (M):","",isFolder=F,name="sig_A")
	addTextEntryWidget(dlg1,"The STDERR of Methylated Intensity:","",isFolder=F,name="sig_A_n")
	addTextEntryWidget(dlg1,"The Number of Methylated Beads:","",isFolder=F,name="sig_A_se")
	addTextEntryWidget(dlg1,"The Un-methylated Signal Intensity (U):","",isFolder=F,name="sig_B")
	addTextEntryWidget(dlg1,"The STDERR of Un-methylated Intensity:","",isFolder=F,name="sig_B_n")
	addTextEntryWidget(dlg1,"The Number of Un-methylated Beads:","",isFolder=F,name="sig_B_se")
	addTextEntryWidget(dlg1,"The Negative Red Control Intensity (Ctr_R):","",isFolder=F,name="ctr_R")
	addTextEntryWidget(dlg1,"The Negative Grn Control Intensity (Ctr_G):","",isFolder=F,name="ctr_G")
	addTextEntryWidget(dlg1,"The Detection P Values:","",isFolder=F,name="pvalue_fn")
	addTextEntryWidget(dlg1,"The Description File Name (opt):","",isFolder=F,name="descriptFn")
	addTextEntryWidget(dlg1,"The Data Output Folder:","c:/tcga",isFolder=T,name="outdir")
	addTextEntryWidget(dlg1,"The Level 1 Data Package Name:","jhu-usc.edu_OV.HumanMethylation27.Level_1.1.1.0",isFolder=F,withSelectButton=F,name="pkgName")
	tkaddfrm(dlg,dlg1)
	endDialog(dlg,c("sig_A","sig_A_n","sig_A_se","sig_B","sig_B_n","sig_B_se","ctr_R","ctr_G","pkgName","descriptFn","outdir","pvalue_fn"),pad=T)
}
createLvl2Package<-function(txt=NULL){
	createLvlPkgDialog("Create Level 2 Data Package","jhu-usc.edu_OV.HumanMethylation27.Level_2.1.0.0")
	if(is.null(reValue))return()
	if(!is.null(txt)) tkinsert(txt,"end",">Start to craete level 2 data package\n")
	lvlPkg<-file.path(reValue[2],reValue[4])
	create_lvl2_data_pkg.2(reValue[1],lvlPkg,reValue[3])
	createManifestByLevel.2(lvlPkg)
	compressDataPackage(lvlPkg)
	reValue<<-NULL
	if(!is.null(txt)) tkinsert(txt,"end",">Finished level 2 data packaging\n")
}
createLvlPkgDialog<-function(tit="",pkgName=""){
	dlg<-startDialog(tit)
	tkgrid(tklabel(dlg,text=" "))
	dlg1<-tkfrm(dlg)
	addTextEntryWidget(dlg1,"Select the data source Folder:","",isFolder=T,name="src_folder")
	addTextEntryWidget(dlg1,"Select the Level Package Folder:","",isFolder=T,name="lvl2_folder")
	addTextEntryWidget(dlg1,"Select the description file (opt):","",isFolder=F,name="descriptFn")
	addTextEntryWidget(dlg1,"Type in the Data Package Name:",pkgName,isFolder=F,withSelectButton=F,name="pkgName")
	tkgrid(tklabel(dlg,text=" "),dlg1)
	tkgrid.configure(dlg1,columnspan=2)
	endDialog(dlg,c("src_folder","lvl2_folder","descriptFn","pkgName"),pad=T)
}
updateLvl2Pkg<-function(txt=NULL){
	updateLvl2PackageDialog("Update Level 2 Data Package")
	if(is.null(reValue))return()
	if(!is.null(txt)) tkinsert(txt,"end",">Start to create level 2 data package\n")
	new_pkg_folder<-reValue[2]
	create_lvl2_data_pkg.2(reValue[1],reValue[2],reValue[3],reValue[4],reValue[5])
	updateDescriptFn(reValue[1],reValue[2])
	createManifestByLevel.2(new_pkg_folder)
	compressDataPackage(new_pkg_folder)
	reValue<<-NULL
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Finished ",date(),"\n"))
}
updateLvl2PackageDialog<-function(tit=""){
	dlg<-startDialog(tit)
	tkgrid(tklabel(dlg,text=" "))
	dlg1<-tkfrm(dlg)
	addTextEntryWidget(dlg1,"Select Level 1 Data Folder:","",isFolder=T,name="lvl_1_folder")
	addTextEntryWidget(dlg1,"Select Leve 2 Package Folder:","",isFolder=T,name="lvl_2_folder")
	addTextEntryWidget(dlg1,"Select Description File (Opt.):","",isFolder=F,name="descriptFn")
	addTextEntryWidget(dlg1,"Select Detection P Value File (Opt.):","",isFolder=F,name="PvalueFn")
	addTextEntryWidget(dlg1,"Set the minimum p value threshold:","0.05",name="pvalueMin",withSelectButton=F)
	tkgrid(tklabel(dlg,text=" "),dlg1)
	tkgrid.configure(dlg1,columnspan=2)
	endDialog(dlg,c("lvl_1_folder","lvl_2_folder","descriptFn","PvalueFn","pvalueMin"),pad=T)
}
createMagePkg<-function(txt=NULL){
	createMageDialog.2("Create Mage Tab Package")
	if(is.null(reValue)) return()
	if(!is.null(txt)) tkinsert(txt,"end",">Start creating mage tab package\n")
	lvl1Pkg<-gsub(".tar.gz","",reValue[1])
	lvl2Pkg<-gsub(".tar.gz","",reValue[2])
	lvl3Pkg<-gsub(".tar.gz","",reValue[3])
	cDir<-filedir(reValue[1])
	manifest_dir<-file.path(cDir,reValue[4])
	if(reValue[4]==""){
		magePkg<-filetail(gsub("Level_1","mage-tab",reValue[1]))
		manifest_dir<-file.path(cDir,paste(strsplit(magePkg,"mage-tab")[[1]][1],"mage-tab.1.0.0",sep=""))
	}
	if(!file.exists(manifest_dir)) dir.create(manifest_dir)
	fn<-filetail(lvl1Pkg)
	snum<-strsplit(fn,"\\.")[[1]]
	snum<-snum[length(snum)-2]
	pref4<-paste(strsplit(fn,".Level")[[1]][1],".",snum,sep="")
	arch_numb_lvl1<-strsplit(lvl1Pkg,"Level_1")[[1]][2]
	arch_numb_lvl2<-strsplit(lvl2Pkg,"Level_2")[[1]][2]
	arch_numb_lvl3<-strsplit(lvl3Pkg,"Level_3")[[1]][2]
	uncompress(reValue[1],filedir(reValue[1]))
	sampleIDs<-getSampleID(lvl1Pkg)
	create_Mage_TAB_SDRF.1(pref4,sampleIDs,manifest_dir,arch_numb_lvl1,arch_numb_lvl2,arch_numb_lvl3)
	type_pkg<-strsplit(strsplit(pref4,"edu_")[[1]][2],"\\.")[[1]][1]
	create_IDF_file(pref4,manifest_dir,type_pkg)
	adf_fn<-paste(pref4,".adf.txt",sep="")
	create_ADF_file(adf_fn,manifest_dir)
	createManifestByLevel.2(manifest_dir)
	compressDataPackage(manifest_dir)
	reValue<<-NULL
	if(!is.null(txt)) tkinsert(txt,"end",">Finished creating mage tab package\n")
}
#createMagePkg<-function(txt=NULL){
#	createMageDialog.2("Create Mage Tab Package")
#	if(is.null(reValue)) return()
#	if(!is.null(txt)) tkinsert(txt,"end",">Start creating mage tab package\n")
#	manifest_dir<-gsub("Level_1","mage-tab",reValue[1])
#	if(!file.exists(manifest_dir)) dir.create(manifest_dir)
#	fn<-filetail(reValue[1])
#	snum<-strsplit(fn,"\\.")[[1]]
#	snum<-snum[length(snum)-2]
#	pref4<-paste(strsplit(fn,".Level")[[1]][1],".",snum,sep="")
#	arch_numb_lvl1<-strsplit(reValue[1],"Level_1")[[1]][2]
#	arch_numb_lvl2<-strsplit(reValue[2],"Level_2")[[1]][2]
#	arch_numb_lvl3<-strsplit(reValue[3],"Level_3")[[1]][2]
#	sampleIDs<-getSampleID(reValue[1])
#	create_Mage_TAB_SDRF.1(pref4,sampleIDs,manifest_dir,arch_numb_lvl1,arch_numb_lvl2,arch_numb_lvl3)
#	type_pkg<-strsplit(strsplit(pref4,"edu_")[[1]][2],"\\.")[[1]][1]
#	create_IDF_file(pref4,manifest_dir,type_pkg)
#	adf_fn<-paste(pref4,".adf.txt",sep="")
#	create_ADF_file(adf_fn,manifest_dir)
#	createManifestByLevel.2(manifest_dir)
#	compressDataPackage(manifest_dir)
#	reValue<<-NULL
#	if(!is.null(txt)) tkinsert(txt,"end",">Finished creating mage tab package\n")
#}
createMageDialog.2<-function(tit=" "){
	dlg<-startDialog(tit)
	tkgrid(tklabel(dlg,text=" "))
	dlg1<-tkfrm(dlg)
	addTextEntryWidget(dlg1,"Select Level 1 Data Package:","",isFolder=F,name="lvl1_pkg",fileType="gz")
	addTextEntryWidget(dlg1,"Select Level 2 Data Package:","",isFolder=F,name="lvl2_pkg",fileType="gz")
	addTextEntryWidget(dlg1,"Select Level 3 Data Package:","",isFolder=F,name="lvl3_pkg",fileType="gz")
	addTextEntryWidget(dlg1,"The Mage-tab Package Name:","jhu-usc.edu_OV.HumanMethylation27.mage-tab.1.0.0",isFolder=F,name="mage_pkg",withSelectButton=F)
	tkgrid(tklabel(dlg,text=" "),dlg1)
	tkgrid.configure(dlg1,columnspan=2)
	endDialog(dlg,c("lvl1_pkg","lvl2_pkg","lvl3_pkg","mage_pkg"),pad=T)
}
createMageDialog<-function(tit=" "){
	dlg<-startDialog(tit)
	tkgrid(tklabel(dlg,text=" "))
	dlg1<-tkfrm(dlg)
	addTextEntryWidget(dlg1,"Select Level 1 Data Folder:","",isFolder=T,name="lvl1_folder")
	addTextEntryWidget(dlg1,"Select Level 2 Data Folder:","",isFolder=T,name="lvl2_folder")
	addTextEntryWidget(dlg1,"Select Level 3 Data Folder:","",isFolder=T,name="lvl3_folder")
	tkgrid(tklabel(dlg,text=" "),dlg1)
	tkgrid.configure(dlg1,columnspan=2)
	endDialog(dlg,c("lvl1_folder","lvl2_folder","lvl3_folder"),pad=T)
}
updateMagePkgDlg.2<-function(){
	dlg<-startDialog("Update mage tab package")
	tkgrid(tklabel(dlg,text=" "))
	dlg1<-tkfrm(dlg)
	addTextEntryWidget(dlg1,"Select the New Data Package (.gz):","",isFolder=F,name="lvlPkgNew")
	addTextEntryWidget(dlg1,"Select the Old Data Package (.gz):","",isFolder=F,name="lvlPkgOld")
	addTextEntryWidget(dlg1,"Select the SDRF File:","",isFolder=F,name="sdrf_file")
	addTextEntryWidget(dlg1,"Select Level-4 Sample Calls (Opt):","",isFolder=F,name="lvl4call")
	addTextEntryWidget(dlg1,"Increase the serial number of SDRF File:","YES",withSelectButton=F,name="incSN")
	tkgrid(tklabel(dlg,text=" "),dlg1)
	tkgrid.configure(dlg1,columnspan=2)
	endDialog(dlg,c("lvlPkgNew","sdrf_file","lvl4call","incSN","lvlPkgOld"),pad=T)
}
updateMagePkgDlg<-function(){
	dlg<-startDialog("Update mage tab package")
	tkgrid(tklabel(dlg,text=" "))
	dlg1<-tkfrm(dlg)
	addTextEntryWidget(dlg1,"Select the Data Level Folder:","",isFolder=T,name="lvl_folder")
	addTextEntryWidget(dlg1,"Select the SDRF File:","",isFolder=F,name="sdrf_file")
	addTextEntryWidget(dlg1,"Select Level-4 Sample Calls (Opt):","",isFolder=F,name="lvl4call")
	addTextEntryWidget(dlg1,"Increase the serial number of SDRF File:","YES",withSelectButton=F,name="incSN")
	tkgrid(tklabel(dlg,text=" "),dlg1)
	tkgrid.configure(dlg1,columnspan=2)
	endDialog(dlg,c("lvl_folder","sdrf_file","lvl4call","incSN"),pad=T)
}
GBM_samples<-function(){
	oma02Fn<-"C:\\tcga\\GBM_OMA002\\jhu-usc.edu_GBM.IlluminaDNAMethylation_OMA002_CPI.mage-tab.1.1.0\\jhu-usc.edu_GBM.IlluminaDNAMethylation_OMA002_CPI.1.sdrf.txt"
	oma03Fn<-"C:\\tcga\\GBM_OMA003\\jhu-usc.edu_GBM.IlluminaDNAMethylation_OMA003_CPI.mage-tab.1.1.0\\jhu-usc.edu_GBM.IlluminaDNAMethylation_OMA003_CPI.1.sdrf.txt"
	infiniumFn<-"C:\\tcga\\GBM\\jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.15.0\\jhu-usc.edu_GBM.HumanMethylation27.8.sdrf.txt"
	datFn<-c(oma02Fn,oma03Fn,infiniumFn)
	for(fn in datFn){
		dat<-read.table(file=fn,sep="\t",as.is=T,header=T)
		dim(dat)
		sampleID<-sapply(dat[,1],function(x)paste(strsplit(x,"-")[[1]][1:3],collapse="-"))
		length(unique(sampleID))
	}
	#265/240 oma02
	#271/246 oma03
	# 370/262 infinim
	ind<-!is.na(dat[,34]) #dat for inifinim
	table(ind)
#	FALSE  TRUE 
#	271    99 
	length(unique(sampleID))
#	[1] 91
}
updateLvl4Calls<-function(sdrfFn,lvl4CallFn,txt=NULL){
	sdrf<-read.table(file=sdrfFn,sep="\t",as.is=T)
	lvl4call<-readDataFile.2(lvl4CallFn,isNum=F,rowName=NULL)
	nh<-paste("Comment [",names(lvl4call)[2],"]",sep="")
	lvl4.new<-data.frame(calls=rep("NA",nrow(sdrf)),stringsAsFactors=F)
	names(lvl4.new)<-nh
	sdrf.new<-data.frame(sdrf,lvl4.new)
	sdrf.new[1,]<-c(sdrf[1,],nh)
	names(sdrf.new)<-sdrf.new[1,]
	for(i in 1:nrow(lvl4call)){
		ind<-sum(regexpr(lvl4call[i,1],sdrf.new[,1])>=1)
		if(ind>=1){
			ind<-grep(lvl4call[i,1],sdrf.new[,1])
			msg<-paste(">Find match of the sample of ",lvl4call[i,1]," from SDRF ",sdrf.new[ind,1],"\t",i,"\n")
			cat(msg)
			#if(!is.null(txt)) tkinsert(txt,"end",msg)
			sdrf.new[ind,nh]<-as.character(lvl4call[i,2])
		}else{
			msg<-paste("No match found for sample ",lvl4call[i,1],"\n")
			if(!is.null(txt)) tkinsert(txt,"end",msg)
			cat(msg)
		}
	}
	print(table(sdrf.new[,nh]))
	msg<-">Finished updating Level-4 Data Calls\n"
	cat(msg)
	if(!is.null(txt)) tkinsert(txt,"end",msg)
	write.table(sdrf.new,file=sdrfFn,sep="\t",row.names=F,quote=F,col.names=F)
}
updateMagePkg.2<-function(txt=NULL){
	updateMagePkgDlg.2()
	if(is.null(reValue))return()
	if(!is.null(txt)) tkinsert(txt,"end",">Start to update mage tab package\n")
	mageFolder<-filedir(reValue[2])
	mageFile<-filetail(reValue[2])
	if(reValue[3]!="") updateLvl4Calls(reValue[2],reValue[3],txt)
	if(reValue[4]=="YES") mageFolder<-updateMageSN(mageFolder)
	if(reValue[1]!=""){
		dat<-strsplit(strsplit(filetail(reValue[1]),"Methylation27.")[[1]][2],"\\.tar")[[1]][1]
		dat.old<-strsplit(strsplit(filetail(reValue[5]),"Methylation27.")[[1]][2],"\\.tar")[[1]][1]
		sdrf<-readLines(file.path(mageFolder,mageFile))
		sdrf<-gsub(dat.old,dat,sdrf)
		write(sdrf,file=file.path(mageFolder,mageFile))
	}
	createManifestByLevel.2(mageFolder)
	compressDataPackage(mageFolder)
	reValue<<-NULL
	if(!is.null(txt)) tkinsert(txt,"end",">Finished updating mage tab package\n")
}
updateMagePkg<-function (txt = NULL) 
{
	updateMagePkgDlg()
	if (is.null(reValue)) 
		return()
	if (!is.null(txt)) 
		tkinsert(txt, "end", ">Start to update mage tab package\n")
	mageFolder <- filedir(reValue[2])
	if (reValue[3] != "") 
		updateLvl4Calls(reValue[2], reValue[3], txt)
	if (reValue[4] == "YES") 
		mageFolder <- updateMageSN(mageFolder)
	if (reValue[1] != "") {
		dat <- strsplit(reValue[1], "Methylation27.")[[1]][2]
		tt <- strsplit(dat, "\\.")[[1]]
		tt[2] <- as.numeric(tt[2]) - 1
		dat.old <- paste(tt, collapse = ".")
		sdrf <- readLines(reValue[2])
		sdrf <- gsub(dat.old, dat, sdrf)
		write(sdrf, file = reValue[2])
	}
	createManifestByLevel.2(mageFolder)
	compressDataPackage(mageFolder)
	reValue <<- NULL
	if (!is.null(txt)) 
		tkinsert(txt, "end", ">Finished updating mage tab package\n")
}

createLvl3Package<-function(txt=NULL){
	createLvlPkgDialog("Create level 3 data package","jhu-usc.edu_OV.HumanMethylation27.Level_3.1.0.0")
	if(is.null(reValue))return()
	if(!is.null(txt)) tkinsert(txt,"end",">Start creating lvl 3 data package\n")
	lvl3pkg<-file.path(reValue[2],reValue[4])
	createLvl3Pkg(reValue[1],lvl3pkg,reValue[3])
	createManifestByLevel.2(lvl3pkg)
	compressDataPackage(lvl3pkg)
	reValue<<-NULL
	if(!is.null(txt)) tkinsert(txt,"end",">Finished lvl 3 data packaging\n")
}

createLvl3Pkg<-function(src_folder,lvl3_folder,descriptFn=NULL){
	flists<-list.files(src_folder,pattern=".txt")
	flists<-flists[grep("lvl-3",flists)]
	if(!file.exists(lvl3_folder)) dir.create(lvl3_folder)
	for( fn in flists){
		write(readLines(file.path(src_folder,fn)),file.path(lvl3_folder,fn))
	}
	if(!is.null(descriptFn)) {
		options(warn=-1)
		write(readLines(descriptFn),file.path(lvl3_folder,"DESCRIPTION.txt"))
		options(warn=1)
	}
}

updateLvl3Pkg<-function(txt=NULL){
	updateLvlPackageDialog("Update Level 3 Data Package")
	if(is.null(reValue))return()
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Start to create level 3 data package...",date(),"\n",sep=""))
	src_data_folder<-reValue[1]
	new_pkg_folder<-reValue[2]
	descriptFn<-reValue[5]
	if(!file.exists(new_pkg_folder)) dir.create(new_pkg_folder)
	create_lvl3_data(src_data_folder,new_pkg_folder)
	old_pkg<-filetail(new_pkg_folder)
	new_pkg<-NULL
	if(file.exists(descriptFn)) {
		options(warn=-1)
		write(readLines(descriptFn),file.path(new_pkg_folder,"DESCRIPTION.txt"))
		options(warn=1)
	}
	if(reValue[3]=="YES"){
		new_pkg_folder<-updateMageSN(new_pkg_folder)
		new_pkg<-filetail(new_pkg_folder)
	}
	if(reValue[4]!=""){
		updateMageTabFile(reValue[4],old_pkg,new_pkg)
	}
	updateDescriptFn(old_pkg,new_pkg_folder)
	createManifestByLevel.2(new_pkg_folder)
	compressDataPackage(new_pkg_folder)
	reValue<<-NULL
	if(!is.null(txt)) tkinsert(txt,"end",">Done\n")
}
updateDescriptFn<-function(old_pkg,new_pkg_folder){
	fn<-file.path(new_pkg_folder,"DESCRIPTION.txt")
	old_pkg_sn<-strsplit(old_pkg,"Level_..")[[1]][2]
	new_pkg_sn<-strsplit(filetail(new_pkg_folder),"Level_..")[[1]][2]
	if(file.exists(fn)){
		descrip<-readLines(fn)
		descrip.new<-gsub(old_pkg_sn,new_pkg_sn,descrip)
		write(descrip.new,fn)
	}
}
updateDescriptFn_test<-function(){
	updateDescriptFn("jhu-usc.edu_COAD.HumanMethylation27.Level_3.1.0.0","C:\\tcga\\repos\\jhu-usc.edu_COAD.HumanMethylation27.1\\jhu-usc.edu_COAD.HumanMethylation27.Level_3.1.1.0")
	updateDescriptFn("jhu-usc.edu_COAD.HumanMethylation27.Level_3.3.0.0","C:\\tcga\\repos\\jhu-usc.edu_COAD.HumanMethylation27.3\\jhu-usc.edu_COAD.HumanMethylation27.Level_3.3.1.0")
	updateDescriptFn("jhu-usc.edu_COAD.HumanMethylation27.Level_3.4.0.0","C:\\tcga\\repos\\jhu-usc.edu_COAD.HumanMethylation27.4\\jhu-usc.edu_COAD.HumanMethylation27.Level_3.4.1.0")
	
}
updateMageSN<-function(magePkgFolder){
	new_pkg_folder<-magePkgFolder
	new_pkg_folder1<-new_pkg_folder
	pkg_name<-tclvalue(tclfile.tail(new_pkg_folder))
	pkg_folder<-tclvalue(tclfile.dir(new_pkg_folder))
	t1<-strsplit(pkg_name,"\\.")[[1]]
	old_pkg<-paste(t1[4],t1[5],t1[6],t1[7],collapse="",sep=".")
	t1[6]<-as.numeric(t1[6])+1
	new_pkg<-paste(t1[4],t1[5],t1[6],t1[7],sep=".")
	pkg_name_new<-paste(t1,collapse=".")
	new_pkg_folder<-file.path(pkg_folder,pkg_name_new)
	file.rename(new_pkg_folder1,new_pkg_folder)
	return(new_pkg_folder)
}
updateMageTabFile<-function(mageFolder,old_pkg,new_pkg){
	sdrf_fn<-list.files(mageFolder,pattern=".sdrf")
	dat<-readLines(file.path(mageFolder,sdrf_fn))
	dat<-gsub(old_pkg,new_pkg,dat)
	write(dat,file=file.path(mageFolder,sdrf_fn))
	createManifestByLevel.2(mageFolder)
	compressDataPackage(mageFolder)
}
updateLvlPackageDialog<-function(tit=""){
	dlg<-startDialog(tit)
	tkgrid(tklabel(dlg,text="   "))
	dlg1<-tkfrm(dlg)
	addTextEntryWidget(dlg1,"Select the Leve 2 Data Folder:","",isFolder=T,name="srcDataFolder")
	addTextEntryWidget(dlg1,"Select the Level 3 Packge Folder:","",isFolder=T,name="newPkgFolder")
	addTextEntryWidget(dlg1,"Select the Mage Manifest Folder (Opt):","",isFolder=T,name="mageTabFolder")
	addTextEntryWidget(dlg1,"Select the Description File (Opt):","",isFolder=F,name="descriptFn")
	addTextEntryWidget(dlg1,"Increase the Package Series Number:","YES",withSelectButton=F,name="pkgSeriesNumber")
	tkaddfrm(dlg,dlg1)
	endDialog(dlg,c("srcDataFolder","newPkgFolder","pkgSeriesNumber","mageTabFolder","descriptFn"),pad=T)
}
###############################
#

createDataPackage.2<-function(txt=NULL,old_scheme=F,new_scheme=F,packaging=TRUE,auto=F,
		pkgname=NULL,isTCGA=F,arraymapping=NULL){
	if(auto==F) createDataPackageDialog("Create TCGA Data Package")
	if(!is.null(txt)){
		msg<-paste("> Starting ..., on ",date(),"\n",sep="")
		tkinsert(txt,"end",msg)
	}
	sig_A <- tcgaPackage_A
	sig_A_se <- tcgaPackage_A_se
	sig_B <- tcgaPackage_B
	sig_B_se<- tcgaPackage_B_se
	ctr_R_fn <- tcgaPackage_R_ctr
	ctr_G_fn <- tcgaPackage_G_ctr
	pvalue_fn <- tcgaPackage_pvalue_fn
	beta_fn <- tcgaPackage_beta_fn
	sig_A_n <-tcgaPackage_A_n
	sig_B_n <-tcgaPackage_B_n
	tcgaPackage_outdir<-tcgaPackage_outputDir
	if(!is.null(pkgname)) tcgaPackage_name<-pkgname
	readme_fn<-NULL
	if(exists("tcgaPackage_Descrip_fn")) readme_fn<-tcgaPackage_Descrip_fn
	data.dir<-filedir(sig_A)
	if(!is.null(txt)){
		msg<-paste(">Input DNA Un-Methlation Signal Intensity File is: ",filetail(tcgaPackage_A),"\n",sep="")
		cat(msg)
		msg<-paste(">Input STDER of DNA Un-Methlation Intensity File is: ",filetail(tcgaPackage_A_se),"\n",sep="")
		cat(msg)
		msg<-paste(">Input Beads Number of DNA Un-Methlation Intensity File is: ",filetail(tcgaPackage_A_n),"\n",sep="")
		cat(msg)
		msg<-paste(">Input DNA Methlation Signal Intensity File is: ",filetail(tcgaPackage_B),"\n",sep="")
		cat(msg)
		msg<-paste(">Input sTDER of DNA Methlation Intensity File is: ",filetail(tcgaPackage_B_se),"\n",sep="")
		cat(msg)
		msg<-paste(">Input Beads Number of DNA Methlation Intensity File is: ",filetail(tcgaPackage_B_n),"\n",sep="")
		cat(msg)
		msg<-paste(">Input Neg Control Red Intensity File is: ",filetail(tcgaPackage_R_ctr),"\n",sep="")
		cat(msg)
		msg<-paste(">Input Neg Control Grn Intensity File is: ",filetail(tcgaPackage_G_ctr),"\n",sep="")
		cat(msg)
		msg<-paste(">Input Detection P value File is: ",filetail(tcgaPackage_pvalue_fn),"\n",sep="")
		cat(msg)
		msg<-paste(">Input DNA Methlation Beta Value File is: ",filetail(tcgaPackage_beta_fn),"\n",sep="")
		cat(msg)
		msg<-paste(">Input the Name of the Package is: ",filetail(tcgaPackage_name),"\n",sep="")
		cat(msg)
		msg<-paste(">The output folder is: ",tcgaPackage_outputDir,"\n",sep="")
		cat(msg)
	}
	
	tdir <- tempdir()
	if(!is.null(tcgaPackage_outputDir)){
		tdir <- tcgaPackage_outputDir;
	}
	setwd(tdir)
	wdir = tcgaPackage_name
	if(!file.exists(file.path(tdir,wdir)))dir.create(wdir)
	pref6<-paste(tdir,wdir,sep="/");
	if(!is.null(txt)){
		msg<-paste(">Generating the TCGA Packaging Files in Folder ",pref6,date(),"\n",sep="")
		cat(msg)
	}
	sampleCode<-NULL
	if(!is.null(arraymapping)){
		sampleInfo<-extractSampleInfo(arraymapping)
		sampleCode<-sampleInfo$sampleCode
	}
	sampleIDa<-packInfinium.2(sig_A,sig_A_se,sig_A_n,sig_B,sig_B_se,sig_B_n,pvalue_fn,beta_fn,
			ctr_R_fn,ctr_G_fn,pref6,tcgaPackage_name,txt,readme_fn)#isTCGA=isTCGA,sampleCode)
	if(isTCGA==T ){
		if(old_scheme==TRUE){
			if(!is.null(txt)){
				msg<-paste(">Done! TCGA Packaging Files have been generate in ",tdir,wdir,"\n",sep="")
				cat(msg)	
			}
			
			if(!is.null(txt)){
				cat(paste(">Work on data compression now ...",date(),"\n",sep=""))
			}
			compressDataPackage.2(tdir,tcgaPackage_name);
			if(!is.null(txt)){
				msg<-paste(">The TCGA Package has been compressed in folder ",tdir,date(),"\n",sep="")
				cat(msg)
				msg<-paste(">Start to deposite the package...",date(),"\n")
				cat(msg)
			}
			#depositePkg(tdir)
			
		}
		if(new_scheme==TRUE & packaging==TRUE){
			#todo: retrieve the series_numbers from db/repository
			type_pkg<-strsplit(strsplit(tcgaPackage_name,"_")[[1]][2],"\\.")[[1]][1]
			t1=unlist(strsplit(tcgaPackage_name,"\\."))
			pref5 <- paste(t1[1],".",t1[2],".",t1[3],sep="")
			pref4 <- paste(pref5,".",t1[4],sep="")
			arch_numb = paste(t1[4],".",t1[5],".",t1[6],sep="")
			arch_numb_manifest<- paste("1.",t1[4],".0",sep="")
			#create level folder
			lvl_1_fdname <- paste(pref5,".Level_1.",arch_numb,sep="")
			lvl_2_fdname <- paste(pref5,".Level_2.",arch_numb,sep="")
			lvl_3_fdname <- paste(pref5,".Level_3.",arch_numb,sep="")
			pkg_folder<-file.path(tcgaPackage_outdir,pref4)
			if(file.exists(pkg_folder)){
				system(paste("rm -r ",pkg_folder,sep=""))
			}
			if(!file.exists(pkg_folder))dir.create(pkg_folder)
			setwd(pkg_folder)
			if(!file.exists(lvl_1_fdname))dir.create(lvl_1_fdname)
			if(!file.exists(lvl_2_fdname))dir.create(lvl_2_fdname)
			if(!file.exists(lvl_3_fdname))dir.create(lvl_3_fdname)
			
			#mv data files needed for new packaging
			pref6<-paste(tcgaPackage_outdir,tcgaPackage_name,sep="/")
			old_scheme_datas_dir <-pref6
			setwd(old_scheme_datas_dir)
			flist<-list.files(pattern="lvl-1")
			destination_fd <-paste(pkg_folder,"/",lvl_1_fdname,sep="")
			file.copy(flist,destination_fd,overwrite=TRUE,recursive=TRUE) 
			destination_fd <-paste(pkg_folder,"/",lvl_2_fdname,sep="")
			flist<-list.files(pattern="lvl-2")
			file.copy(flist,destination_fd,overwrite=TRUE,recursive=TRUE)
			destination_fd<-paste(pkg_folder,"/",lvl_3_fdname,sep="")
			flist<-list.files(pattern="lvl-3")
			file.copy(flist,destination_fd,overwrite=TRUE,recursive=TRUE)
			
			#create mage-tab files from sample file and update it
			manifest_fdname <- paste(pref5,".mage-tab.",arch_numb_manifest,sep="")
			manifest_dir<-file.path(pkg_folder,manifest_fdname)
			if(!file.exists(manifest_dir))dir.create(manifest_dir)
			mage_tab_fn <- paste(pref4,".sdrf.txt",sep="")
			adf_fn<-paste(pref4,".adf.txt",sep="")
			#		toAppend<-F
			#		if(toAppend){
			#			getCurrentManifest(manifest_dir,mage_tab_fn,type_pkg)
			#		}
			sampleIDa<-getSampleID(file.path(pkg_folder,lvl_1_fdname))
			create_Mage_TAB_SDRF.2(pref4,pref5,sampleIDa,manifest_dir,mage_tab_fn,arch_numb,adf_fn)
			
			create_IDF_file(pref4,manifest_dir,type_pkg)
			
			create_ADF_file(adf_fn,manifest_dir)
			data_dir<-file.path(tcgaPackage_outdir,tcgaPackage_name)
			if(!is.null(arraymapping)){
				create_Level_Description_File.2(pkg_folder,lvl_1_fdname,lvl_2_fdname,lvl_3_fdname,arraymapping)
			}else{
				create_Level_Description_File(data_dir,pkg_folder,lvl_1_fdname,lvl_2_fdname,lvl_3_fdname)
			}
			
			wdir<-pkg_folder
			#createManifestByLevel(pkg_folder)
			createManifestByLevel.2a(pkg_folder,lvl_1_fdname)
			createManifestByLevel.2a(pkg_folder,lvl_2_fdname)
			createManifestByLevel.2a(pkg_folder,lvl_3_fdname)
			createManifestByLevel.2a(pkg_folder,manifest_fdname)
			#if(packaging==TRUE){
			# compress into packages
			setwd(wdir)
			#pack lvl_1-3 and mage files
			compressDataPackage.2(pkg_folder,lvl_1_fdname)
			compressDataPackage.2(pkg_folder,lvl_2_fdname)
			compressDataPackage.2(pkg_folder,lvl_3_fdname)
			compressDataPackage.2(pkg_folder,manifest_fdname)
			#			validateInfiniumPkg(pkg_folder,tcgaPackage_name)
			#pkg_validate(pkg_folder)
			
		}
	}else if(isTCGA!=F &packaging==T){
		outPath<-tcgaPackage_outdir
		datPath<-file.path(tcgaPackage_outdir,tcgaPackage_name)
		packagingArrays.2(dataPath,outPath,inc=F,ext=".txt")
	}
#	runQCvalidation(data.dir,bvFn=beta_fn,ctrRedFn=ctr_R_fn,ctrGrnFn=ctr_G_fn)
	
	#tkconfigure(tt,cursor="arrow")
	
	if(exists("tcgaPackage_A"))rm("tcgaPackage_A",envir = .GlobalEnv)
	if(exists("tcgaPackage_B"))rm("tcgaPackage_B",envir = .GlobalEnv)
	if(exists("tcgaPackage_A_se"))rm("tcgaPackage_A_se",envir=.GlobalEnv)
	if(exists("tcgaPackage_B_se"))rm("tcgaPackage_B_se",envir=.GlobalEnv)
	if(exists("tcgaPackage_R_ctr"))rm("tcgaPackage_R_ctr",envir=.GlobalEnv)
	if(exists("tcgaPackage_G_ctr"))rm("tcgaPackage_G_ctr",envir=.GlobalEnv)
	if(exists("tcgaPackage_pvalue_fn"))rm("tcgaPackage_pvalue_fn",envir=.GlobalEnv)
	if(exists("tcgaPackage_beta_fn"))rm("tcgaPackage_beta_fn",envir=.GlobalEnv)
	if(exists("tcgaPackage_A_n"))rm("tcgaPackage_A_n",envir=.GlobalEnv)
	if(exists("tcgaPackage_B_n"))rm("tcgaPackage_B_n",envir=.GlobalEnv)
	if(exists("tcgaPackage_name"))rm("tcgaPackage_name",envir=.GlobalEnv)
	if(exists("tcgaPackage_outputDir"))rm("tcgaPackage_outputDir",envir=.GlobalEnv)
	return (pref6)
}

createDataPackage_test<-function(){
	datDir<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\TCGA Batch 49 Data Package (jhu-usc.edu_UCEC.HumanMethylation27.1.0.0)"
	tcgaPackage_A<-file.path(datDir,"TCGA Batch 49 unmethylated signal intensity.txt")
	tcgaPackage_A_se<-file.path(datDir,"TCGA Batch 49 unmethylated bead stderr.txt")
	tcgaPackage_A_n<-file.path(datDir,"TCGA Batch 49 average number of unmethylated beads.txt")
	tcgaPackage_B<-file.path(datDir,"TCGA batch 49 methylated signal intensity.txt")
	tcgaPackage_B_se<-file.path(datDir,"TCGA Batch 49 methylated bead stderr.txt")
	tcgaPackage_B_n<-file.path(datDir,"TCGA Batch 49 average number of methylated beads.txt")
	tcgaPackage_pvalue_fn<-file.path(datDir,"TCGA Batch 49 Detection P-value.txt")
	tcgaPackage_beta_fn<-file.path(datDir,"TCGA Batch 49 beta values (level 2).txt")
	tcgaPackage_R_ctr<-file.path(datDir,"TCGA Batch 49 negative control probe signal_red.txt")
	tcgaPackage_G_ctr<-file.path(datDir,"TCGA Batch 49 negative control probe signal_green.txt")
	tcgaPackage_outputDir<-"c:\\temp"
	tcgaPackage_name<-"jhu-usc.edu_UCEC.HumanMethylation27.12.0.0"
	txt=NULL
	tcgaPackage_Descrip_fn<-file.path(datDir,"readme.txt")
	createDataPackage(txt,new_scheme=T,auto=T)
}

createDataPackage<-function(txt=NULL,old_scheme=F,new_scheme=F,packaging=TRUE,tt=NULL,auto=F){
	if(auto==F) createDataPackageDialog("Create TCGA Data Package",tt)
	if(!exists("tcgaPackage_A")) return()
	if(!is.null(tt))tkfocus(tt)
	#tkconfigure(tt,cursor="watch")
	if(!is.null(txt)){
		msg<-paste("> Starting ..., on ",date(),"\n",sep="")
		tkinsert(txt,"end",msg)
	}
	sig_A <- tcgaPackage_A
	sig_A_se <- tcgaPackage_A_se
	sig_B <- tcgaPackage_B
	sig_B_se<- tcgaPackage_B_se
	ctr_R_fn <- tcgaPackage_R_ctr
	ctr_G_fn <- tcgaPackage_G_ctr
	pvalue_fn <- tcgaPackage_pvalue_fn
	beta_fn <- tcgaPackage_beta_fn
	sig_A_n <-tcgaPackage_A_n
	sig_B_n <-tcgaPackage_B_n
	tcgaPackage_outdir<-tcgaPackage_outputDir
	readme_fn<-NULL
	if(exists("tcgaPackage_Descrip_fn")) readme_fn<-tcgaPackage_Descrip_fn
	data.dir<-tclvalue(tclfile.dir(sig_A))
	if(!is.null(txt)){
		msg<-paste(">Input DNA Un-Methlation Signal Intensity File is: ",tclvalue(tclfile.tail(tcgaPackage_A)),"\n",sep="")
		tkinsert(txt,"end",msg)
		msg<-paste(">Input STDER of DNA Un-Methlation Intensity File is: ",tclvalue(tclfile.tail(tcgaPackage_A_se)),"\n",sep="")
		tkinsert(txt,"end",msg)
		msg<-paste(">Input Beads Number of DNA Un-Methlation Intensity File is: ",tclvalue(tclfile.tail(tcgaPackage_A_n)),"\n",sep="")
		tkinsert(txt,"end",msg)
		msg<-paste(">Input DNA Methlation Signal Intensity File is: ",tclvalue(tclfile.tail(tcgaPackage_B)),"\n",sep="")
		tkinsert(txt,"end",msg)
		msg<-paste(">Input sTDER of DNA Methlation Intensity File is: ",tclvalue(tclfile.tail(tcgaPackage_B_se)),"\n",sep="")
		tkinsert(txt,"end",msg)
		msg<-paste(">Input Beads Number of DNA Methlation Intensity File is: ",tclvalue(tclfile.tail(tcgaPackage_B_n)),"\n",sep="")
		tkinsert(txt,"end",msg)
		msg<-paste(">Input Neg Control Red Intensity File is: ",tclvalue(tclfile.tail(tcgaPackage_R_ctr)),"\n",sep="")
		tkinsert(txt,"end",msg)
		msg<-paste(">Input Neg Control Grn Intensity File is: ",tclvalue(tclfile.tail(tcgaPackage_G_ctr)),"\n",sep="")
		tkinsert(txt,"end",msg)
		msg<-paste(">Input Detection P value File is: ",tclvalue(tclfile.tail(tcgaPackage_pvalue_fn)),"\n",sep="")
		tkinsert(txt,"end",msg)
		msg<-paste(">Input DNA Methlation Beta Value File is: ",tclvalue(tclfile.tail(tcgaPackage_beta_fn)),"\n",sep="")
		tkinsert(txt,"end",msg)
		msg<-paste(">Input the Name of the Package is: ",tclvalue(tclfile.tail(tcgaPackage_name)),"\n",sep="")
		tkinsert(txt,"end",msg)
		msg<-paste(">The output folder is: ",tcgaPackage_outputDir,"\n",sep="")
		tkinsert(txt,"end",msg)
	}
	
	tdir <- tempdir()
	if(!is.null(tcgaPackage_outputDir)){
		tdir <- tcgaPackage_outdir;
	}
	setwd(tdir)
	wdir = tcgaPackage_name
	dir.create(wdir)
	pref6<-paste(tdir,wdir,sep="/");
	if(!is.null(txt)){
		msg<-paste(">Generating the TCGA Packaging Files in Folder ",pref6,date(),"\n",sep="")
		tkinsert(txt,"end",msg)
	}
	sampleIDa<-packInfinium.2(sig_A,sig_A_se,sig_A_n,sig_B,sig_B_se,sig_B_n,pvalue_fn,beta_fn,
			ctr_R_fn,ctr_G_fn,pref6,tcgaPackage_name,txt,readme_fn)
	if(old_scheme==TRUE){
		if(!is.null(txt)){
			msg<-paste(">Done! TCGA Packaging Files have been generate in ",tdir,wdir,"\n",sep="")
			tkinsert(txt,"end",msg)	
		}
		if(packaging==TRUE){
			if(!is.null(txt)){
				tkinsert(txt,"end",paste(">Work on data compression now ...",date(),"\n",sep=""))
			}
			compressDataPackage(tdir,tcgaPackage_name);
			if(!is.null(txt)){
				msg<-paste(">The TCGA Package has been compressed in folder ",tdir,date(),"\n",sep="")
				tkinsert(txt,"end",msg)
				msg<-paste(">Start to deposite the package...",date(),"\n")
				tkinsert(txt,"end",msg)
			}
			#depositePkg(tdir)
		}
	}
	if(new_scheme==TRUE){
		#todo: retrieve the series_numbers from db/repository
		type_pkg<-strsplit(strsplit(tcgaPackage_name,"_")[[1]][2],"\\.")[[1]][1]
		t1=unlist(strsplit(tcgaPackage_name,"\\."))
		pref5 <- paste(t1[1],".",t1[2],".",t1[3],sep="")
		pref4 <- paste(pref5,".",t1[4],sep="")
		arch_numb = paste(t1[4],".",t1[5],".",t1[6],sep="")
		arch_numb_manifest<- paste("1.",t1[4],".0",sep="")
		#create level folder
		lvl_1_fdname <- paste(pref5,".Level_1.",arch_numb,sep="")
		lvl_2_fdname <- paste(pref5,".Level_2.",arch_numb,sep="")
		lvl_3_fdname <- paste(pref5,".Level_3.",arch_numb,sep="")
		pkg_folder<-file.path(tcgaPackage_outdir,pref4)
		if(file.exists(pkg_folder)){
			system(paste("rm -r ",pkg_folder,sep=""))
		}
		dir.create(pkg_folder)
		setwd(pkg_folder)
		dir.create(lvl_1_fdname)
		dir.create(lvl_2_fdname)
		dir.create(lvl_3_fdname)
		
		#mv data files needed for new packaging
		pref6<-paste(tcgaPackage_outdir,tcgaPackage_name,sep="/")
		old_scheme_datas_dir <-pref6
		setwd(old_scheme_datas_dir)
		flist<-list.files(pattern="lvl-1")
		destination_fd <-paste(pkg_folder,"/",lvl_1_fdname,sep="")
		file.copy(flist,destination_fd,overwrite=TRUE,recursive=TRUE) 
		destination_fd <-paste(pkg_folder,"/",lvl_2_fdname,sep="")
		flist<-list.files(pattern="lvl-2")
		file.copy(flist,destination_fd,overwrite=TRUE,recursive=TRUE)
		destination_fd<-paste(pkg_folder,"/",lvl_3_fdname,sep="")
		flist<-list.files(pattern="lvl-3")
		file.copy(flist,destination_fd,overwrite=TRUE,recursive=TRUE)
		
		#create mage-tab files from sample file and update it
		manifest_fdname <- paste(pref5,".mage-tab.",arch_numb_manifest,sep="")
		manifest_dir<-file.path(pkg_folder,manifest_fdname)
		dir.create(manifest_dir)
		mage_tab_fn <- paste(pref4,".sdrf.txt",sep="")
		adf_fn<-paste(pref4,".adf.txt",sep="")
		toAppend<-F
		if(toAppend){
			getCurrentManifest(manifest_dir,mage_tab_fn,type_pkg)
		}
		create_Mage_TAB_SDRF(pref4,pref5,sampleIDa,manifest_dir,mage_tab_fn,arch_numb,adf_fn,toAppend)
	
		create_IDF_file(pref4,manifest_dir,type_pkg)
		
		create_ADF_file(adf_fn,manifest_dir)
		data_dir<-file.path(tcgaPackage_outdir,tcgaPackage_name)
		create_Level_Description_File(data_dir,pkg_folder,lvl_1_fdname,lvl_2_fdname,lvl_3_fdname)
		wdir<-pkg_folder
		#createManifestByLevel(pkg_folder)
		createManifestByLevel.2(pkg_folder,lvl_1_fdname)
		createManifestByLevel.2(pkg_folder,lvl_2_fdname)
		createManifestByLevel.2(pkg_folder,lvl_3_fdname)
		createManifestByLevel.2(pkg_folder,manifest_fdname)
		if(packaging==TRUE){
			# compress into packages
			setwd(wdir)
			#pack lvl_1-3 and mage files
			compressDataPackage(pkg_folder,lvl_1_fdname)
			compressDataPackage(pkg_folder,lvl_2_fdname)
			compressDataPackage(pkg_folder,lvl_3_fdname)
			compressDataPackage(pkg_folder,manifest_fdname)
			#depositePkg(pkg_folder)
#			validateInfiniumPkg(pkg_folder,tcgaPackage_name)
			pkg_validate(pkg_folder)
			validatePkg(wdir,txt=txt)
		}
	}
#	runQCvalidation(data.dir,bvFn=beta_fn,ctrRedFn=ctr_R_fn,ctrGrnFn=ctr_G_fn)
	
	#tkconfigure(tt,cursor="arrow")
	
	if(exists("tcgaPackage_A"))rm("tcgaPackage_A",envir = .GlobalEnv)
	if(exists("tcgaPackage_B"))rm("tcgaPackage_B",envir = .GlobalEnv)
	if(exists("tcgaPackage_A_se"))rm("tcgaPackage_A_se",envir=.GlobalEnv)
	if(exists("tcgaPackage_B_se"))rm("tcgaPackage_B_se",envir=.GlobalEnv)
	if(exists("tcgaPackage_R_ctr"))rm("tcgaPackage_R_ctr",envir=.GlobalEnv)
	if(exists("tcgaPackage_G_ctr"))rm("tcgaPackage_G_ctr",envir=.GlobalEnv)
	if(exists("tcgaPackage_pvalue_fn"))rm("tcgaPackage_pvalue_fn",envir=.GlobalEnv)
	if(exists("tcgaPackage_beta_fn"))rm("tcgaPackage_beta_fn",envir=.GlobalEnv)
	if(exists("tcgaPackage_A_n"))rm("tcgaPackage_A_n",envir=.GlobalEnv)
	if(exists("tcgaPackage_B_n"))rm("tcgaPackage_B_n",envir=.GlobalEnv)
	if(exists("tcgaPackage_name"))rm("tcgaPackage_name",envir=.GlobalEnv)
	if(exists("tcgaPackage_outputDir"))rm("tcgaPackage_outputDir",envir=.GlobalEnv)
	return (pref6)
}

getCurrentManifest<-function(manifest_dir,manifest_fn,type_pkg="GBM"){
	fn<-paste(system.file("data",package="rapid"),"/",type_pkg,"_mage_tab.txt",sep="")
	if(!file.exists(fn)){
		fn<-paste("http://epimatrix.usc.edu:8080/data/",type_pkg,"_mage_tab.txt",sep="")
	}
	dest_fn<-file.path(manifest_dir,manifest_fn)
	system(paste("rm ",dest_fn,sep=""))
	file.copy(fn,dest_fn)
}
create_IDF_file<-function(fn,manifest_dir,cancer_type=NULL){
	idf_fn <- paste(fn,".idf.txt",sep="")
	fp<-file.path(manifest_dir,idf_fn)
	part.1<-paste("Investigation Title\tTCGA Analysis of DNA Methylation for ",cancer_type,"  Using Illumina Infinium Human DNA Methylation 27 platform (HumanMethylation27)\n",sep="")				

part.1.1<-"Experimental Design\tdisease_state_design				
Experimental Design Term Source REF\tMGED Ontology				
Experimental Factor Type\tdisease	 			
Experimental Factor Type Term Source REF\tMGED Ontology				
					
Person Last Name\tLaird				
Person First Name\tPeter				
Person Mid Initials\tW				
Person Email\tplaird@usc.edu				
Person Phone\t323.442.7890				
Person Address\tUSC Epigenome Center, University of Southern California, CA 90033, USA				
Person Affiliation\tUniversity of Southern California				
Person Roles\tsubmitter				
					
Quality Control Types\treal_time_PCR_quality_control				
Quality Control Types Term Source REF\tMGED Ontology				
Replicate Type\tbioassay_replicate_reduction				
Replicate Type Term Source REF\tMGED Ontology"
	part.2<-paste("Date of Experiment",date(),sep="\t")
	part.3<-paste("Public Release Date",date(),sep="\t")
	part.4<-"Experiment Description\tTCGA Analysis of DNA Methylation Using Illumina Infinium Human DNA Methylation 27 platform"				
	if(!is.null(cancer_type)){
		part.4<-paste("Experiment Description\tTCGA Analysis of DNA Methylation for ",cancer_type," Using Illumina Infinium Human DNA Methylation 27 platform\n",sep="")
	}
	part.4.1<-"\n					
Protocol Name\tjhu-usc.edu:labeling:HumanMethylation27:01\tjhu-usc.edu:hybridization:HumanMethylation27:01\tjhu-usc.edu:image_acquisition:HumanMethylation27:01\tjhu-usc.edu:feature_extraction:HumanMethylation27:01\tjhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01
Protocol Type\tlabeling\thybridization\tscan\tfeature_extraction\tnormalization
Protocol Term Source REF\tMGED Ontology\tMGED Ontology\tMGED Ontology\tMGED Ontology\tMGED Ontology
Protocol Description\tIllumina Infinium Human DNA Methylation 27 Labeled Extract\tIllumina Infinium Human DNA Methylation 27 Hybridization Protocol\tIllumina Infinium Human DNA Methylation 27 Scan Protocol\tIllumina Infinium Human DNA Methylation 27 Feature Extraction Protocol\tIllumina Infinium Human DNA Methylation 27 Data Transformation
Protocol Parameters\t\t		
"
	sdrf_fn<-paste(fn,".sdrf.txt",sep="")
	part.5<-paste("SDRF Files",sdrf_fn,sep="\t")
	part.6<-"Term Source Name\tMGED Ontology\tcaArray\tBCR		
Term Source File\thttp://mged.sourceforge.net/ontologies/MGEDontology.php\thttp://caarraydb.nci.nih.gov/\thttp://www.tgen.org		
Term Source Version\t1.3.0.1\t2007-01\t2007-01	"
	dat<-paste(part.1,part.1.1,part.2,part.3,part.4,part.4.1,part.5,part.6,sep="\n")
	write(dat,file=fp)
}
create_ADF_file_run<-function(){
	library(tcltk)
	fn<-"jhu-usc.edu_LUAD.HumanMethylation27.1.adf.txt"
	mdir<-"C:\\tcga\\LUAD\\jhu-usc.edu_LUAD.HumanMethylation27.mage-tab.1.3.0"
	
	fn<-"jhu-usc.edu_LUSC.HumanMethylation27.2.adf.txt"
	mdir<-"C:\\tcga\\LUSC\\jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.5.0"
	create_ADF_file(fn,mdir)
	pkgFolder<-tclvalue(tclfile.dir(mdir))
	lvl_fd<-tclvalue(tclfile.tail(mdir))
	createManifestByLevel.2(pkgFolder,lvl_fd)
	compressDataPackage(pkgFolder,lvl_fd)
}

create_ADF_file<-function(fn,manifest_dir){
#	fp<-"c:\\tcga" #system.file("data",package="methPipe")
#	fp<-file.path(fp,"HumanMethylation27.adf.txt")
#	if(!file.exists(fp)){
#		fp<-"http://epinexus.usc.edu/tcga/HumanMethylation27.adf.txt"
#	}
#	dat<-read.delim(fp,sep="\t",header=T,as.is=T,check.names=F)
	data(HumanMethylation27.adf)
	dat<-HumanMethylation27.adf
	write.table(dat,file=file.path(manifest_dir,fn),sep="\t",row.names=F,quote=F)
}
create_Level_Description_File_test<-function(){
	data_dir<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\TCGA Batch 49 Data Package (jhu-usc.edu_UCEC.HumanMethylation27.1.0.0)"
	create_Level_Description_File(data_dir,"c:\\temp","","test","")
}
create_Level_Description_File<-function(data_dir,pkg_folder,fn1,fn2,fn3){
	nn<-"DESCRIPTION.txt"
	fp<-file.path(data_dir,nn)
	if(!file.exists(fp)){
		cat("Description file is not available...\n")
		return()
	}
	dat<-readLines(fp)
	dat.0<-""
	ind1<-grep("LEVEL 1",dat,ignore.case=T)
	dat.1<-""
	if(length(ind1)>0){
		ind1<-ind1[length(ind1)]
		dat.1<-dat[ind1]
		ind0<-1:(ind1-1)
		dat.0<-dat[ind0]
	}
	dat.2<-""
	ind2<-grep("LEVEL 2",dat,ignore.case=T)
	if(length(ind2)>0)dat.2<-dat[ind2]
	dat.3<-""
	ind3<-grep("LEVEL 3",dat,ignore.case=T)
	if(length(ind3)>0){
		ind3<-ind3[length(ind3)]
		#dat.3<-dat[ind3[length(ind3)]]
		dat.3<-dat[ind3]
	}
	dat.dat<-date()
	if(ind3<length(dat))dat.date<-dat[(ind3+1):length(dat)]
	lvl.1<-c(dat.0,dat.1,dat.date)#,collapse="\n")
	lvl.2<-c(dat.0,dat.2,dat.date)#,collapse="\n")
	lvl.3<-c(dat.0,dat.3,dat.date)#,collapse="\n")
	write(lvl.1,file=file.path(pkg_folder,fn1,nn))
	write(lvl.2,file=file.path(pkg_folder,fn2,nn))
	write(lvl.3,file=file.path(pkg_folder,fn3,nn))
}
#create_Level_Description_File<-function(data_dir,pkg_folder,fn1,fn2,fn3){
#	nn<-"DESCRIPTION.txt"
#	fp<-file.path(data_dir,nn)
#	if(!file.exists(fp)){
#		cat("Description file is not available...\n")
#		return()
#	}
#	dat<-readLines(fp)
#	ind1<-grep("LEVEL 1",dat,ignore.case=T)
#	dat.1<-dat[ind1]
#	dat.2<-dat[grep("LEVEL 2",dat,ignore.case=T)]
#	ind3<-grep("LEVEL 3",dat,ignore.case=T)
#	ind3<-ind3[length(ind3)]
#	#dat.3<-dat[ind3[length(ind3)]]
#	dat.3<-dat[ind3]
#	ind0<-1:(ind1-1)
#	dat.0<-dat[ind0]
#	dat.date<-dat[(ind3+1):length(dat)]
#	lvl.1<-c(dat.0,dat.1,dat.date)#,collapse="\n")
#	lvl.2<-c(dat.0,dat.2,dat.date)#,collapse="\n")
#	lvl.3<-c(dat.0,dat.3,dat.date)#,collapse="\n")
#	write(lvl.1,file=file.path(pkg_folder,fn1,nn))
#	write(lvl.2,file=file.path(pkg_folder,fn2,nn))
#	write(lvl.3,file=file.path(pkg_folder,fn3,nn))
#}

runQCvalidation<-function(data.dir,mDataFileName=NULL,
		neg_ctr_red=NULL,neg_ctr_grn=NULL,bvFn=NULL,ctrRedFn=NULL,ctrGrnFn=NULL){
	setwd(data.dir)
	dat<-NULL
	if(is.null(mDataFileName=NULL)){
		setwd(data.dir)
		flist<-list.files(pattern=".rdata")
		if(length(flist)!=0) dat<-print(load(file=flist[1]))
		dat<-get(dat)
	}else{
		dat<-print(load(file=mDataFileName))
		dat<-get(dat)
	}
	
	bv<-NULL
	if(is.null(bvFn)){
		bv<-getBeta(dat)
	}else{
		bv<-readDataFile.2(bvFn)
	}
	readNegCtrFn<-function(fn){
		dat<-readDataFile.2(fn,isNum=F,rowName=NULL)
		ind<-grep("NEG",dat[,1],ignore.case=T)
		dat<-dat[ind,-1]
		return(dat)
	}
	neg_ctr_red<-NULL
	if(is.null(ctrRedFn)){
		neg_ctr_red<-getNegCtrRed(dat)
	}else{
		neg_ctr_red<-readNegCtrFn(ctrRedFn)
	}
	neg_ctr_grn<-NULL
	if(is.null(ctrGrnFn)){
		neg_ctr_grn<-getNegCtrGrn(dat)
	}else{
		neg_ctr_grn<-readNegCtrFn(ctrGrnFn)
	}
	naRatio<-colSums(apply(bv,2,is.na))/nrow(bv)
	if(any(naRatio>0.1)){
		warning("There is a sample with more than 10% of NAs among the beta values.\n")
	}
	X11()
	barplot(naRatio,main="Percentage of NAs among samples")
	png(filenames="naRatio.png")
	barplot(naRatio,main="Percentage of NAs among samples")
	dev.off()
	
	X11()
	par(mfrow=c(2,1))
	boxplot(neg_ctr_red)
	boxplot(neg_ctr_grn)
	png(filenames="Ctr_plot.png",height=480,width=480)
	par(mfrow=c(2,1))
	boxplot(neg_ctr_red,col="red",main="")
	boxplot(neg_ctr_grn,col="green",main="")
	dev.off()
}

sampleID<-function(indir,sig_A_fileName,header1=TRUE,delim = ","){
	setwd(indir);
	header1=header1;
	
	A<-read.table(sig_A,sep=delim,header=header1,row.names=1)
	A = A[order(row.names(A)),]; #sort rows
	A = A[,order(names(A))]; #sort cols
	ProbeSize = dim(A)[1];
	print( ProbeSize);
	SampleSize = dim(A)[2];
	print( SampleSize);
	sid = names(A);
	sid = gsub("(\\.)", "-", sid)
}

create_Mage_TAB_SDRF.2_test<-function(){
	lvlDir<-"C:\\temp\\tcgaPkg\\repos\\jhu-usc.edu_STAD.HumanMethylation27.1.0.0\\jhu-usc.edu_STAD.HumanMethylation27.1\\jhu-usc.edu_STAD.HumanMethylation27.Level_1.1.0.0"
	sampleID<-getSampleID(lvlDir)
	pref4<-"jhu-usc.edu_STAD.HumanMethylation27.1"
	pref5<-"jhu-usc.edu_STAD.HumanMethylation27"
	manifest_dir<-"C:\\temp\\tcgaPkg\\repos\\jhu-usc.edu_STAD.HumanMethylation27.1.0.0\\bk"
	mage_tab_fn<-file.path(manifest_dir,"jhu-usc.edu_STAD.HumanMethylation27.1.sdrf.txt")
	arch_numb<-"1.0.0"
	adf_fn<-"jhu-usc.edu_STAD.HumanMethylation27.1.adf.txt"
	create_Mage_TAB_SDRF.2(pref4,pref5,sampleID,manifest_dir,mage_tab_fn,arch_numb,adf_fn)
}
create_Mage_TAB_SDRF.2<-function(pref4,pref5,sampleID,manifest_dir,mage_tab_fn,arch_numb,adf_fn,toAppend=F){  
	#file.append
	setwd(manifest_dir)
	if(toAppend==FALSE){
		hd1<-"Extract Name\tProtocol REF\tLabeled Extract Name\tLabel\tTerm Source REF\tProtocol REF\tHybridization Name\tArray Design File\tTerm Source REF\tProtocol REF\tScan Name\tProtocol REF\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]"
		write(hd1,mage_tab_fn,sep="",append=F)
	}
	for(i in 1:length(sampleID)){
		sidc = i;
		tcga_id = sampleID[i];	
		lvl1_fn = paste(pref4,".lvl-1.",tcga_id,".txt",sep="");
		lvl2_fn = paste(pref4,".lvl-2.",tcga_id,".txt",sep="");
		lvl3_fn = paste(pref4,".lvl-3.",tcga_id,".txt",sep="");
		lvl1_arch_fn = paste(pref5,".Level_1.",arch_numb,sep="")
		lvl2_arch_fn = paste(pref5,".Level_2.",arch_numb,sep="")
		lvl3_arch_fn = paste(pref5,".Level_3.",arch_numb,sep="")
		hd2= paste(tcga_id,"jhu-usc.edu:labeling:HumanMethylation27:01",tcga_id,"biotin",
				"MGED Ontology","jhu-usc.edu:hybridization:HumanMethylation27:01",
				tcga_id,adf_fn,"caArray",
				"jhu-usc.edu:image_acquisition:HumanMethylation27:01",tcga_id,
				"jhu-usc.edu:feature_extraction:HumanMethylation27:01",
				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",
				tcga_id,lvl1_fn,"Level 1","DNA-Methylation","yes",lvl1_arch_fn,
				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",
				tcga_id,lvl2_fn,"Level 2","DNA-Methylation","yes",lvl2_arch_fn,
				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",tcga_id,
				lvl3_fn,"Level 3","DNA-Methylation","yes",lvl3_arch_fn,sep="\t"
		);
		write(hd2,mage_tab_fn,sep="",append=TRUE);
	}
}
#create_Mage_TAB_SDRF.2<-function(pref4,pref5,sampleID,manifest_dir,mage_tab_fn,arch_numb,adf_fn,toAppend=F){  
#	#file.append
#	setwd(manifest_dir)
#	if(toAppend==FALSE){
#		hd1<-"Extract Name\tProtocol REF\tLabeled Extract Name\tLabel\tTerm Source REF\tProtocol REF\tHybridization Name\tArray Design File\tTerm Source REF\tProtocol REF\tScan Name\tProtocol REF\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]"
#		write(hd1,mage_tab_fn,sep="",append=F)
#	}
#	for(i in 1:length(sampleID)){
#		sidc = i;
#		tcga_id = sampleID[i];	
#		lvl1_fn = paste(pref4[i],".lvl-1.",tcga_id,".txt",sep="");
#		lvl2_fn = paste(pref4[i],".lvl-2.",tcga_id,".txt",sep="");
#		lvl3_fn = paste(pref4[i],".lvl-3.",tcga_id,".txt",sep="");
#		lvl1_arch_fn = paste(pref5[i],".Level_1.",arch_numb[i],sep="")
#		lvl2_arch_fn = paste(pref5[i],".Level_2.",arch_numb[i],sep="")
#		lvl3_arch_fn = paste(pref5[i],".Level_3.",arch_numb[i],sep="")
#		hd2= paste(tcga_id,"jhu-usc.edu:labeling:HumanMethylation27:01",tcga_id,"biotin",
#				"MGED Ontology","jhu-usc.edu:hybridization:HumanMethylation27:01",
#				tcga_id,adf_fn[i],"caArray",
#				"jhu-usc.edu:image_acquisition:HumanMethylation27:01",tcga_id,
#				"jhu-usc.edu:feature_extraction:HumanMethylation27:01",
#				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",
#				tcga_id,lvl1_fn,"Level 1","DNA-Methylation","yes",lvl1_arch_fn,
#				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",
#				tcga_id,lvl2_fn,"Level 2","DNA-Methylation","yes",lvl2_arch_fn,
#				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",tcga_id,
#				lvl3_fn,"Level 3","DNA-Methylation","yes",lvl3_arch_fn,sep="\t"
#		);
#		write(hd2,mage_tab_fn,sep="",append=TRUE);
#	}
#}
create_Mage_TAB_SDRF.1<-function(pref4,sampleID,manifest_dir,arch_numb_lvl1,arch_numb_lvl2,arch_numb_lvl3){  
	sdrf_tab_fn<-file.path(manifest_dir,paste(pref4,".sdrf.txt",sep=""))
	
		hd1<-"Extract Name\tProtocol REF\tLabeled Extract Name\tLabel\tTerm Source REF\tProtocol REF\tHybridization Name\tArray Design File\tTerm Source REF\tProtocol REF\tScan Name\tProtocol REF\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]"
		write(hd1,sdrf_tab_fn,sep="",append=F)
	
	adf_fn = paste(pref4,".adf.txt",sep="");
	pref5<-paste(strsplit(pref4,"HumanMethylation27")[[1]][1],"HumanMethylation27",sep="")
	for(i in 1:length(sampleID)){
		sidc = i;
		tcga_id = sampleID[i];	
		lvl1_fn = paste(pref4,".lvl-1.",tcga_id,".txt",sep="");
		lvl2_fn = paste(pref4,".lvl-2.",tcga_id,".txt",sep="");
		lvl3_fn = paste(pref4,".lvl-3.",tcga_id,".txt",sep="");
		lvl1_arch_fn = paste(pref5,".Level_1",arch_numb_lvl1,sep="")
		lvl2_arch_fn = paste(pref5,".Level_2",arch_numb_lvl2,sep="")
		lvl3_arch_fn = paste(pref5,".Level_3",arch_numb_lvl3,sep="")
		hd2= paste(tcga_id,"jhu-usc.edu:labeling:HumanMethylation27:01",tcga_id,"biotin",
				"MGED Ontology","jhu-usc.edu:hybridization:HumanMethylation27:01",
				tcga_id,adf_fn,"caArray",
				"jhu-usc.edu:image_acquisition:HumanMethylation27:01",tcga_id,
				"jhu-usc.edu:feature_extraction:HumanMethylation27:01",
				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",
				tcga_id,lvl1_fn,"Level 1","DNA-Methylation","yes",lvl1_arch_fn,
				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",
				tcga_id,lvl2_fn,"Level 2","DNA-Methylation","yes",lvl2_arch_fn,
				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",tcga_id,
				lvl3_fn,"Level 3","DNA-Methylation","yes",lvl3_arch_fn,sep="\t"
		);
		write(hd2,sdrf_tab_fn,sep="",append=TRUE);
	}
}
create_Mage_TAB_SDRF<-function(pref4,pref5,sampleID,manifest_dir,mage_tab_fn,arch_numb,adf_fn,toAppend=F){  
	#file.append
	setwd(manifest_dir)
	if(toAppend==FALSE){
		hd1<-"Extract Name\tProtocol REF\tLabeled Extract Name\tLabel\tTerm Source REF\tProtocol REF\tHybridization Name\tArray Design File\tTerm Source REF\tProtocol REF\tScan Name\tProtocol REF\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]\tProtocol REF\tNormalization Name\tDerived Array Data Matrix File\tComment [TCGA Data Level]\tComment [TCGA Data Type]\tComment [TCGA Include for Analysis]\tComment [TCGA Archive Name]"
		write(hd1,mage_tab_fn,sep="",append=F)
	}
	adf_fn<-adf_fn
	#adf_fn = paste(pref4,".adf.txt",sep="");
	for(i in 1:length(sampleID)){
		sidc = i;
		tcga_id = sampleID[i];	
		lvl1_fn = paste(pref4,".lvl-1.",tcga_id,".txt",sep="");
		lvl2_fn = paste(pref4,".lvl-2.",tcga_id,".txt",sep="");
		lvl3_fn = paste(pref4,".lvl-3.",tcga_id,".txt",sep="");
		lvl1_arch_fn = paste(pref5,".Level_1.",arch_numb,sep="")
		lvl2_arch_fn = paste(pref5,".Level_2.",arch_numb,sep="")
		lvl3_arch_fn = paste(pref5,".Level_3.",arch_numb,sep="")
		hd2= paste(tcga_id,"jhu-usc.edu:labeling:HumanMethylation27:01",tcga_id,"biotin",
				"MGED Ontology","jhu-usc.edu:hybridization:HumanMethylation27:01",
				tcga_id,adf_fn,"caArray",
				"jhu-usc.edu:image_acquisition:HumanMethylation27:01",tcga_id,
				"jhu-usc.edu:feature_extraction:HumanMethylation27:01",
				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",
				tcga_id,lvl1_fn,"Level 1","DNA-Methylation","yes",lvl1_arch_fn,
				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",
				tcga_id,lvl2_fn,"Level 2","DNA-Methylation","yes",lvl2_arch_fn,
				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",tcga_id,
				lvl3_fn,"Level 3","DNA-Methylation","yes",lvl3_arch_fn,sep="\t"
		);
		write(hd2,mage_tab_fn,sep="",append=TRUE);
	}
}
createDataPackgeNewScheme<-function(txt){
	createDataPackage(txt,old_scheme=FALSE,new_scheme=TRUE,packaging=TRUE)
	
}
###############
# note: id of ctr data start with "NEG"
###################
packInfinium.2_test<-function(){
	datDir<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\TCGA Batch 49 Data Package (jhu-usc.edu_UCEC.HumanMethylation27.1.0.0)"
	sig_A<-file.path(datDir,"TCGA Batch 49 unmethylated signal intensity.txt")
	sig_A_se<-file.path(datDir,"TCGA Batch 49 unmethylated bead stderr.txt")
	sig_A_n<-file.path(datDir,"TCGA Batch 49 average number of unmethylated beads.txt")
	sig_B<-file.path(datDir,"TCGA batch 49 methylated signal intensity.txt")
	sig_B_se<-file.path(datDir,"TCGA Batch 49 methylated bead stderr.txt")
	sig_B_n<-file.path(datDir,"TCGA Batch 49 average number of methylated beads.txt")
	pvalue_fn<-file.path(datDir,"TCGA Batch 49 Detection P-value.txt")
	beta_fn<-file.path(datDir,"TCGA Batch 49 beta values (level 2).txt")
	ctr_R_fn<-file.path(datDir,"TCGA Batch 49 negative control probe signal_red.txt")
	ctr_G_fn<-file.path(datDir,"TCGA Batch 49 negative control probe signal_green.txt")
	outdir<-"c:\\temp\\GBM"
	tcgaPackage_name<-"jhu-usc.edu_GBM.HumanMethylation27.2.0.0"
	txt=NULL
	readme_fn<-file.path(datDir,"readme.txt")
	packInfinium.2(sig_A,sig_A_se,sig_A_n,sig_B,sig_B_se,sig_B_n,pvalue_fn,beta_fn,ctr_R_fn,ctr_G_fn,outdir,tcgaPackage_name,txt,readme_fn)	
}
packInfinium.2 <-function(sig_A,sig_A_se,sig_A_n,sig_B,sig_B_se,sig_B_n,pvalue_fn,beta_fn,
		ctr_R_fn,ctr_G_fn,outdir,tcgaPackage_name,txt=NULL,readme_fn=NULL){
	# create prefs using tcgaPackage_name
	t1=unlist(strsplit(tcgaPackage_name,"\\."))
	pref5 <- paste(t1[1],".",t1[2],".",t1[3],sep="")
	pref4 <- paste(pref5,".",t1[4],sep="")
	pref <- paste(pref4,".lvl-1.",sep="")
	pref2<-paste(pref4,".lvl-2.",sep="")
	pref3<-paste(pref4,".lvl-3.",sep="")
	arch_numb = paste(t1[4],".",t1[5],".",t1[6],sep="")
	
	#outdir<-file.path(outdir,tcgaPackage_name)
	if(!file.exists(outdir))dir.create(outdir)
	setwd(outdir)
	header1=TRUE;
	rv<-processLevel1Data(sig_A,sig_A_n,sig_A_se,sig_B,sig_B_n,sig_B_se,ctr_R_fn,ctr_G_fn,pvalue_fn,pref)
	sid<-rv$sid
	pid<-rv$pid
	A<-rv$A
	B<-rv$B
	Bv<-processLevel2Data(beta_fn,A,B,sid,pid,pref2)
	processLevel3Data(Bv,sid,pid,pref3)
	create_Manifest(outdir)
	#create_SDRF(pref4,sid,outdir)
	if(!is.null(readme_fn)){
		file.copy(readme_fn,file.path(outdir,"DESCRIPTION.TXT"))
	}
	if(!is.null(txt)){
		msg<-paste("> Done with the level data processing ",date(),"\n",sep="")
		tkinsert(txt,"end",msg)
	}
	return(sid)
}

processLevel3Data<-function(Bv,sid,pid,pref3){
	data(lvl3mask)
	lvl3mask = lvl3mask[order(row.names(lvl3mask)),]; #sort rows
	pid1 = row.names(lvl3mask);
	if(sum(pid!=pid1)>0 ) stop(paste("row or col names of A do not match lvl3mask, pls check ",sig_A,"\n"));  
	
	lvl3mks<-as.data.frame(matrix(lvl3mask[,1],nrow=nrow(Bv),ncol=ncol(Bv),byrow=F))
	Bv3<-ifelse(lvl3mks==0,1,NA)*Bv
	for(i in 1:length(sid)){
		tcga_id = sid[i];
		fn = paste(pref3,tcga_id,".txt",sep="");
		hd1= paste("Hybridization REF",tcga_id,tcga_id,tcga_id,tcga_id,sep="\t");
		hd2= paste("Composite Element REF", "Beta_Value", "Gene_Symbol", "Chromosome", "Genomic_Coordinate",sep="\t");
		write(hd1,fn,sep="");
		write(hd2,fn,sep="",append=TRUE);
		dat<-data.frame(pid,Bv3[,i],lvl3mask[,2],lvl3mask[,3],lvl3mask[,4])
		write.table(dat,fn,sep="\t",row.names=F,col.names=F,quote=F,append=T)
	}
}
processLevel2Data<-function(beta_fn,A,B,sid,pid,pref2){
	header1<-TRUE
	ProbeSize<-length(pid)
	SampleSize<-length(sid)
	Bv<-readDataFile.2(beta_fn,header1=header1)
	if(  ProbeSize !=   dim(Bv)[1] || SampleSize != dim(Bv)[2])
	{
		stop (paste("dimension of Bv does not match with that of A, pls check",beta_fn,"\n"));
	}
	Bv = Bv[order(row.names(Bv)),];
	Bv = Bv[,order(names(Bv))];
	sid1 = names(Bv);
	pid1 = row.names(Bv);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Bv ",beta_fn,"\n"));  
	
	
	for(i in 1:length(sid)){
		tcga_id = sid[i];
		fn = paste(pref2,tcga_id,".txt",sep="");
		hd1= paste("Hybridization REF",tcga_id,tcga_id,tcga_id,sep="\t");
		hd2= paste("Composite Element REF", "Beta_Value", "Methylated_Signal_Intensity (M)","Un-Methylated_Signal_Intensity (U)",sep="\t");
		write(hd1,fn,sep="");
		write(hd2,fn,sep="",append=TRUE);
		dat<-data.frame(pid,Bv[,i],B[,i],A[,i])
		write.table(dat,fn,sep="\t",col.names=F,row.names=F,quote=F,append=T)
	}  
#	if(!is.null(txt)){
#		msg<-paste("> Finished processing the level-2 data Files...",date(),"\n",sep="")
#		tkinsert(txt,"end",msg)
#		tkinsert(txt,"end","> Working on the level-3 data Files.\n")
#	}
	return(Bv)
}

processLevel1Data<-function(sig_A,sig_A_n,sig_A_se,sig_B,sig_B_n,sig_B_se,ctr_R_fn,ctr_G_fn,pvalue_fn,pref){
	header1<-TRUE
	A<-readDataFile.2(sig_A,header1=header1)
	A = A[order(row.names(A)),]; #sort rows
	A = A[,order(names(A))]; #sort cols
	ProbeSize = dim(A)[1];
	print( ProbeSize);
	SampleSize = dim(A)[2];
	print( SampleSize);
	sid = names(A);
	pid = row.names(A);
	
	An<-readDataFile.2(sig_A_n,header1=header1)
	if(  ProbeSize !=   dim(An)[1] || SampleSize != dim(An)[2])
	{
		stop (paste("dimension of An does not match with that of A, pls check ",sig_A_n,"\n"));
	}
	An = An[order(row.names(An)),];
	An = An[,order(names(An))];
	sid1 = names(An);
	pid1 = row.names(An);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match An, pls check ",sig_A_n,"\n"));
	
	Ae<-readDataFile.2(sig_A_se,header1=header1)
	if(  ProbeSize !=   dim(Ae)[1] || SampleSize != dim(Ae)[2])
	{
		stop (paste("dimension of Ae does not match with that of A, pls check ",sig_A_se,"\n"));
	}
	Ae = Ae[order(row.names(Ae)),];
	Ae = Ae[,order(names(Ae))];
	sid1 = names(Ae);
	pid1 = row.names(Ae);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Ae, pls check ",sig_A_se,"\n"));  
	
	
	B<-readDataFile.2(sig_B,header1=header1)
	if(  ProbeSize !=   dim(B)[1] || SampleSize != dim(B)[2])
	{
		stop (paste("dimension of B does not match with that of A, pls check ",sig_B,"\n"));
	}
	B = B[order(row.names(B)),];
	B = B[,order(names(B))];
	sid1 = names(B);
	pid1 = row.names(B);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match ",sig_B,"\n"));
	
	Bn<-readDataFile.2(sig_B_n,header1=header1)
	if(  ProbeSize !=   dim(Bn)[1] || SampleSize != dim(Bn)[2])
	{
		stop (paste("dimension of B does not match with that of A, pls check ",sig_B_n,"\n"));
	}
	Bn = Bn[order(row.names(Bn)),];
	Bn = Bn[,order(names(Bn))];
	sid1 = names(Bn);
	pid1 = row.names(Bn);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Bn, pls check ",sig_B_n,"\n"));
	
	Be<-readDataFile.2(sig_B_se,header1=header1)
	if(  ProbeSize !=   dim(Be)[1] || SampleSize != dim(Be)[2])
	{
		stop (paste("dimension of Be does not match with that of A,pls check",sig_B_se,"\n"));
	}
	Be = Be[order(row.names(Be)),];
	Be = Be[,order(names(Be))];
	sid1 = names(Be);
	pid1 = row.names(Be);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Be, pls check",sig_B_se,"\n"));  
	
	ctr_R<-readDataFile.2(ctr_R_fn,header1=header1,rowName=NULL,isNum=F)
	ind<-grep("NEG",ctr_R[,1],ignore.case=T)
	ctr_R<-ctr_R[ind,-1]
	ctr_R = ctr_R[,order(names(ctr_R))];
	sid1 = names(ctr_R);
	#sid1 = substr(t,1,nchar(t)-nchar(".Signal_Red"));
	#names(ctr_R) = sid1;
	if(sum(sid!=sid1)>0 ) stop(paste("row or col names of A do not match ctr_R",ctr_R_fn,"\n"));
	ctr_R_avg = apply(ctr_R,2,function(x)mean(as.numeric(x),na.rm=T));
	ctr_R_stderr = apply(ctr_R,2,function(x)sd(as.numeric(x),na.rm=T))/sqrt(16);
	
	
	ctr_G<-readDataFile.2(ctr_G_fn,header1=header1,rowName=NULL,isNum=F)
	ind<-grep("NEG",ctr_G[,1],ignore.case=T)
	ctr_G<-ctr_G[ind,-1]
	ctr_G = ctr_G[,order(names(ctr_G))]; 
	sid1 = names(ctr_G);
	if(sum(sid!=sid1)>0 ) stop(paste("row or col names of A do not match ctr_G,",ctr_G_fn,"\n"));
	ctr_G_avg = apply(ctr_G,2,function(x)mean(as.numeric(x),na.rm=T));
	ctr_G_stderr = apply(ctr_G,2,function(x)sd(as.numeric(x),na.rm=T))/sqrt(16);
	
	Pv<-readDataFile.2(pvalue_fn,header1=header1)
	if(  ProbeSize !=   dim(Pv)[1] || SampleSize != dim(Pv)[2])
	{
		stop (paste("dimension of Pv does not match with that of A, pls check ",pvalue_fn,"\n"));
	}
	Pv = Pv[order(row.names(Pv)),];
	Pv = Pv[,order(names(Pv))];
	sid1 = names(Pv);
	pid1 = row.names(Pv);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Pv",pvalue_fn,"\n"));      
	
	sid = gsub("(\\.)", "-", sid)
	#setwd(outdir);
	len<-length(pid)
	cancerType<-strsplit(strsplit(pref,"edu_")[[1]][2],"\\.")[[1]][1]
	for(i in 1:length(sid)){
		tcga_id = sid[i];
		fn = paste(pref,tcga_id,".txt",sep="");
		hd1= paste("Hybridization REF",tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,sep="\t");
		hd2= paste("Composite Element REF", "Methylated_Signal_Intensity (M)", "M_Number_Beads","M_STDERR","Un-Methylated_Signal_Intensity (U)", "U_Number_Beads","U_STDERR","Negative_Control_Grn_Avg_Intensity","Negative_Control_Grn_STDERR","Negative_Control_Red_Avg_Intensity","Negative_Control_Red_STDERR","Detection_P_Value",sep="\t");
		dat<-data.frame(pid,B[,i],Bn[,i],Be[,i],A[,i],An[,i],Ae[,i],rep(ctr_G_avg[i],len),rep(ctr_G_stderr[i],len),rep(ctr_R_avg[i],len),rep(ctr_R_stderr[i],len),Pv[,i])
		if(cancerType=="GBM"){
			hd1= paste("Hybridization REF",tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,sep="\t");
			hd2= paste("Composite Element REF", "Methylated_Signal_Intensity (M)","Un-Methylated_Signal_Intensity (U)","Negative_Control_Grn_Avg_Intensity","Negative_Control_Grn_STDERR","Negative_Control_Red_Avg_Intensity","Negative_Control_Red_STDERR", "Detection_P_Value",sep="\t");
			dat<-data.frame(pid,B[,i],A[,i],rep(ctr_G_avg[i],len),rep(ctr_G_stderr[i],len),rep(ctr_R_avg[i],len),rep(ctr_R_stderr[i],len),Pv[,i])
		}
		write(hd1,fn,sep="");
		write(hd2,fn,sep="",append=TRUE);
		write.table(dat,fn,sep="\t",row.names=F,col.names=F,quote=F,append=T)
	}
	return(list(sid=sid,pid=pid,A=A,B=B))
}

#processLevel1Data<-function(sig_A,sig_A_n,sig_A_se,sig_B,sig_B_n,sig_B_se,ctr_R_fn,ctr_G_fn,pvalue_fn,pref){
#	header1<-TRUE
#	A<-readDataFile.2(sig_A,header1=header1)
#	A = A[order(row.names(A)),]; #sort rows
#	A = A[,order(names(A))]; #sort cols
#	ProbeSize = dim(A)[1];
#	print( ProbeSize);
#	SampleSize = dim(A)[2];
#	print( SampleSize);
#	sid = names(A);
#	pid = row.names(A);
#	
#	An<-readDataFile.2(sig_A_n,header1=header1)
#	if(  ProbeSize !=   dim(An)[1] || SampleSize != dim(An)[2])
#	{
#		stop (paste("dimension of An does not match with that of A, pls check ",sig_A_n,"\n"));
#	}
#	An = An[order(row.names(An)),];
#	An = An[,order(names(An))];
#	sid1 = names(An);
#	pid1 = row.names(An);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match An, pls check ",sig_A_n,"\n"));
#	
#	Ae<-readDataFile.2(sig_A_se,header1=header1)
#	if(  ProbeSize !=   dim(Ae)[1] || SampleSize != dim(Ae)[2])
#	{
#		stop (paste("dimension of Ae does not match with that of A, pls check ",sig_A_se,"\n"));
#	}
#	Ae = Ae[order(row.names(Ae)),];
#	Ae = Ae[,order(names(Ae))];
#	sid1 = names(Ae);
#	pid1 = row.names(Ae);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Ae, pls check ",sig_A_se,"\n"));  
#	
#	
#	B<-readDataFile.2(sig_B,header1=header1)
#	if(  ProbeSize !=   dim(B)[1] || SampleSize != dim(B)[2])
#	{
#		stop (paste("dimension of B does not match with that of A, pls check ",sig_B,"\n"));
#	}
#	B = B[order(row.names(B)),];
#	B = B[,order(names(B))];
#	sid1 = names(B);
#	pid1 = row.names(B);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match ",sig_B,"\n"));
#	
#	Bn<-readDataFile.2(sig_B_n,header1=header1)
#	if(  ProbeSize !=   dim(Bn)[1] || SampleSize != dim(Bn)[2])
#	{
#		stop (paste("dimension of B does not match with that of A, pls check ",sig_B_n,"\n"));
#	}
#	Bn = Bn[order(row.names(Bn)),];
#	Bn = Bn[,order(names(Bn))];
#	sid1 = names(Bn);
#	pid1 = row.names(Bn);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Bn, pls check ",sig_B_n,"\n"));
#	
#	Be<-readDataFile.2(sig_B_se,header1=header1)
#	if(  ProbeSize !=   dim(Be)[1] || SampleSize != dim(Be)[2])
#	{
#		stop (paste("dimension of Be does not match with that of A,pls check",sig_B_se,"\n"));
#	}
#	Be = Be[order(row.names(Be)),];
#	Be = Be[,order(names(Be))];
#	sid1 = names(Be);
#	pid1 = row.names(Be);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Be, pls check",sig_B_se,"\n"));  
#	
#	ctr_R<-readDataFile.2(ctr_R_fn,header1=header1,rowName=NULL,isNum=F)
#	ind<-grep("NEG",ctr_R[,1],ignore.case=T)
#	ctr_R<-ctr_R[ind,-1]
#	ctr_R = ctr_R[,order(names(ctr_R))];
#	sid1 = names(ctr_R);
#	#sid1 = substr(t,1,nchar(t)-nchar(".Signal_Red"));
#	#names(ctr_R) = sid1;
#	if(sum(sid!=sid1)>0 ) stop(paste("row or col names of A do not match ctr_R",ctr_R_fn,"\n"));
#	ctr_R_avg = apply(ctr_R,2,function(x)mean(as.numeric(x),na.rm=T));
#	ctr_R_stderr = apply(ctr_R,2,function(x)sd(as.numeric(x),na.rm=T))/sqrt(16);
#	
#	
#	ctr_G<-readDataFile.2(ctr_G_fn,header1=header1,rowName=NULL,isNum=F)
#	ind<-grep("NEG",ctr_G[,1],ignore.case=T)
#	ctr_G<-ctr_G[ind,-1]
#	ctr_G = ctr_G[,order(names(ctr_G))]; 
#	sid1 = names(ctr_G);
#	if(sum(sid!=sid1)>0 ) stop(paste("row or col names of A do not match ctr_G,",ctr_G_fn,"\n"));
#	ctr_G_avg = apply(ctr_G,2,function(x)mean(as.numeric(x),na.rm=T));
#	ctr_G_stderr = apply(ctr_G,2,function(x)sd(as.numeric(x),na.rm=T))/sqrt(16);
#	
#	Pv<-readDataFile.2(pvalue_fn,header1=header1)
#	if(  ProbeSize !=   dim(Pv)[1] || SampleSize != dim(Pv)[2])
#	{
#		stop (paste("dimension of Pv does not match with that of A, pls check ",pvalue_fn,"\n"));
#	}
#	Pv = Pv[order(row.names(Pv)),];
#	Pv = Pv[,order(names(Pv))];
#	sid1 = names(Pv);
#	pid1 = row.names(Pv);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Pv",pvalue_fn,"\n"));      
#	
#	sid = gsub("(\\.)", "-", sid)
#	#setwd(outdir);
#	len<-length(pid)
#	for(i in 1:length(sid)){
#		tcga_id = sid[i];
#		fn = paste(pref,tcga_id,".txt",sep="");
#		hd1= paste("Hybridization REF",tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,sep="\t");
#		hd2= paste("Composite Element REF", "Methylated_Signal_Intensity (M)", "M_Number_Beads","M_STDERR","Un-Methylated_Signal_Intensity (U)", "U_Number_Beads","U_STDERR","Negative_Control_Grn_Avg_Intensity","Negative_Control_Grn_STDERR","Negative_Control_Red_Avg_Intensity","Negative_Control_Red_STDERR","Detection_P_Value",sep="\t");
#		write(hd1,fn,sep="");
#		write(hd2,fn,sep="",append=TRUE);
#		dat<-data.frame(pid,B[,i],Bn[,i],Be[,i],A[,i],An[,i],Ae[,i],rep(ctr_G_avg[i],len),rep(ctr_G_stderr[i],len),rep(ctr_R_avg[i],len),rep(ctr_R_stderr[i],len),Pv[,i])
#		write.table(dat,fn,sep="\t",row.names=F,col.names=F,quote=F,append=T)
#	}
#	return(list(sid=sid,pid=pid,A=A,B=B))
#}
packInfinium_test<-function(){
	datDir<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\TCGA Batch 49 Data Package (jhu-usc.edu_UCEC.HumanMethylation27.1.0.0)"
	sig_A<-file.path(datDir,"TCGA Batch 49 unmethylated signal intensity.txt")
	sig_A_se<-file.path(datDir,"TCGA Batch 49 unmethylated bead stderr.txt")
	sig_A_n<-file.path(datDir,"TCGA Batch 49 average number of unmethylated beads.txt")
	sig_B<-file.path(datDir,"TCGA batch 49 methylated signal intensity.txt")
	sig_B_se<-file.path(datDir,"TCGA Batch 49 methylated bead stderr.txt")
	sig_B_n<-file.path(datDir,"TCGA Batch 49 average number of methylated beads.txt")
	pvalue_fn<-file.path(datDir,"TCGA Batch 49 Detection P-value.txt")
	beta_fn<-file.path(datDir,"TCGA Batch 49 beta values (level 2).txt")
	ctr_R_fn<-file.path(datDir,"TCGA Batch 49 negative control probe signal_red.txt")
	ctr_G_fn<-file.path(datDir,"TCGA Batch 49 negative control probe signal_green.txt")
	outdir<-"c:\\temp"
	tcgaPackage_name<-"jhu-usc.edu_UCEC.HumanMethylation27.1.0.0a"
	txt=NULL
	readme_fn<-file.path(datDir,"DESCRIPTION Level 1 Batch 49.txt")
	packInfinium(sig_A,sig_A_se,sig_A_n,sig_B,sig_B_se,sig_B_n,pvalue_fn,beta_fn,ctr_R_fn,ctr_G_fn,outdir,tcgaPackage_name,txt,readme_fn)	
}

packInfinium <-function(sig_A,sig_A_se,sig_A_n,sig_B,sig_B_se,sig_B_n,pvalue_fn,beta_fn,
		ctr_R_fn,ctr_G_fn,outdir,tcgaPackage_name,txt=NULL,readme_fn=NULL,isTCGA=T,sampleCode=NULL,pcut=0.05){
	delim = ",";
	header1=TRUE;
	
	pref5<-tcgaPackage_name
	pref4<-tcgaPackage_name
	if(isTCGA==T){
		t1=unlist(strsplit(tcgaPackage_name,"\\."))
		pref5 <- paste(t1[1],".",t1[2],".",t1[3],sep="")
		pref4 <- paste(pref5,".",t1[4],sep="")
		arch_numb = paste(t1[4],".",t1[5],".",t1[6],sep="")
	}
	pref <- paste(pref4,".lvl-1.",sep="")
	pref2<-paste(pref4,".lvl-2.",sep="")
	pref3<-paste(pref4,".lvl-3.",sep="")
	arch_numb<-"1.0.0"
	
	A<-readDataFile.2(sig_A,header1=header1)
	A = A[order(row.names(A)),]; #sort rows
	A = A[,order(names(A))]; #sort cols
	ProbeSize = dim(A)[1];
	print( ProbeSize);
	SampleSize = dim(A)[2];
	print( SampleSize);
	sid = names(A);
	#sid = substr(t,1,nchar(t)-9);
	#names(A) = sid;
	pid = row.names(A);
	
	An<-readDataFile.2(sig_A_n,header1=header1)
	if(  ProbeSize !=   dim(An)[1] || SampleSize != dim(An)[2])
	{
		stop ("dimension of An does not match with that of A");
	}
	An = An[order(row.names(An)),];
	An = An[,order(names(An))];
	sid1 = names(An);
	#sid1 = substr(t,1,nchar(t)-13);
	#names(An) = sid1;
	pid1 = row.names(An);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop("row or col names of A do not match An");
	
	Ae<-readDataFile.2(sig_A_se,header1=header1)
	if(  ProbeSize !=   dim(Ae)[1] || SampleSize != dim(Ae)[2])
	{
		stop ("dimension of Ae does not match with that of A");
	}
	Ae = Ae[order(row.names(Ae)),];
	Ae = Ae[,order(names(Ae))];
	sid1 = names(Ae);
	#sid1 = substr(t,1,nchar(t)-14);
	#names(Ae) = sid1;
	pid1 = row.names(Ae);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop("row or col names of A do not match Ae");  
	
	
	B<-readDataFile.2(sig_B,header1=header1)
	if(  ProbeSize !=   dim(B)[1] || SampleSize != dim(B)[2])
	{
		stop ("dimension of B does not match with that of A");
	}
	B = B[order(row.names(B)),];
	B = B[,order(names(B))];
	sid1 = names(B);
	#sid1 = substr(t,1,nchar(t)-9);
	#names(B) = sid1;
	pid1 = row.names(B);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop("row or col names of A do not match B");
	
	Bn<-readDataFile.2(sig_B_n,header1=header1)
	if(  ProbeSize !=   dim(Bn)[1] || SampleSize != dim(Bn)[2])
	{
		stop ("dimension of B does not match with that of A");
	}
	Bn = Bn[order(row.names(Bn)),];
	Bn = Bn[,order(names(Bn))];
	sid1 = names(Bn);
	#sid1 = substr(t,1,nchar(t)-13);
	#names(Bn) = sid1;
	pid1 = row.names(Bn);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop("row or col names of A do not match Bn");
	
	Be<-readDataFile.2(sig_B_se,header1=header1)
	if(  ProbeSize !=   dim(Be)[1] || SampleSize != dim(Be)[2])
	{
		stop ("dimension of Be does not match with that of A");
	}
	Be = Be[order(row.names(Be)),];
	Be = Be[,order(names(Be))];
	sid1 = names(Be);
	#sid1 = substr(t,1,nchar(t)-14);
	#names(Be) = sid1;
	pid1 = row.names(Be);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop("row or col names of A do not match Be");  
	
	Bv<-readDataFile.2(beta_fn,header1=header1)
	if(  ProbeSize !=   dim(Bv)[1] || SampleSize != dim(Bv)[2])
	{
		stop ("dimension of Bv does not match with that of A");
	}
	Bv = Bv[order(row.names(Bv)),];
	Bv = Bv[,order(names(Bv))];
	sid1 = names(Bv);
	pid1 = row.names(Bv);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop("row or col names of A do not match Bv");  
	
	Pv<-readDataFile.2(pvalue_fn,header1=header1)
	if(  ProbeSize !=   dim(Pv)[1] || SampleSize != dim(Pv)[2])
	{
		stop ("dimension of Pv does not match with that of A");
	}
	Pv = Pv[order(row.names(Pv)),];
	Pv = Pv[,order(names(Pv))];
	sid1 = names(Pv);
	pid1 = row.names(Pv);
	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop("row or col names of A do not match Pv");      
	
	ctr_R<-readDataFile.2(ctr_R_fn,header1=header1,rowName=NULL,isNum=F)
	ind<-grep("NEG",ctr_R[,1],ignore.case=T)
	ctr_R<-ctr_R[ind,-1]
	ctr_R = ctr_R[,order(names(ctr_R))]; #sort cols
	sid1 = names(ctr_R);
	#sid1 = substr(t,1,nchar(t)-nchar(".Signal_Red"));
	#names(ctr_R) = sid1;
	if(sum(sid!=sid1)>0 ) stop("row or col names of A do not match ctr_R");
	ctr_R_avg = apply(ctr_R,2,function(x)mean(as.numeric(x),na.rm=T));
	ctr_R_stderr = apply(ctr_R,2,function(x)sd(as.numeric(x),na.rm=T))/sqrt(16);
	
	
	ctr_G<-readDataFile.2(ctr_G_fn,header1=header1,rowName=NULL,isNum=F)
	ind<-grep("NEG",ctr_G[,1],ignore.case=T)
	ctr_G<-ctr_G[ind,-1]
	ctr_G = ctr_G[,order(names(ctr_G))]; #sort cols
	sid1 = names(ctr_G);
	#sid1 = substr(t,1,nchar(t)-nchar(".Signal_grn"));
	#names(ctr_G) = sid1;
	if(sum(sid!=sid1)>0 ) stop("row or col names of A do not match ctr_G");
	ctr_G_avg = apply(ctr_G,2,function(x)mean(as.numeric(x),na.rm=T));
	ctr_G_stderr = apply(ctr_G,2,function(x)sd(as.numeric(x),na.rm=T))/sqrt(16);
	
	data(lvl3mask)
	lvl3mask = lvl3mask[order(row.names(lvl3mask)),]; #sort rows
	pid1 = row.names(lvl3mask);
	if(sum(sid!=sid1)>0 ) stop("row or col names of A do not match lvl3mask");  
	
	sid = gsub("(\\.)", "-", sid)
#	if(!is.null(sampleCode)){
#		sid1 = sapply(sid,function(x)substr(x,2,nchar(sid)))
#		sid1 = sampleCode[sid];
#		sid<-ifelse(is.na(sid1,sid,sid1))
#	}
	if(!is.null(txt)){
		msg<-paste("> Finishing Reading and Processing All the Data Files ",date(),"\n",sep="")
		cat(msg)
		cat("> Working on the generating level files\n")
	}
	setwd(outdir);
	cat(paste("The number of samples is",length(na.omit(sid)),"\n"))
	#level 1  
	for(i in 1:length(sid)){
		#if(!is.null(sampleCode)) sidc = sampleCode[i,1];
		sidc = i;
		if(is.na(sid[i]))next
		tcga_id = sid[i];
		fn = paste(pref,tcga_id,".txt",sep="");
		hd1= paste("Hybridization REF",tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,sep="\t");
		hd2= paste("Composite Element REF", "Methylated_Signal_Intensity (M)", "M_Number_Beads","M_STDERR","Un-Methylated_Signal_Intensity (U)", "U_Number_Beads","U_STDERR","Negative_Control_Grn_Avg_Intensity","Negative_Control_Grn_STDERR","Negative_Control_Red_Avg_Intensity","Negative_Control_Red_STDERR","Detection_P_Value",sep="\t");
		write(hd1,fn,sep="");
		write(hd2,fn,sep="",append=TRUE);
		for( j in 1:length(pid)){
			rst = paste(pid[j],B[j,sidc],Bn[j,sidc],Be[j,sidc],A[j,sidc],An[j,sidc],Ae[j,sidc],ctr_G_avg[i],ctr_G_stderr[i],ctr_R_avg[i],ctr_R_stderr[i],Pv[j,sidc],sep="\t")
			write(rst,fn,sep="",append=TRUE);
		}
	}
	
	if(!is.null(txt)){
		msg<-paste("> Finishing processing the level-1 data files...",date(),"\n",sep="")
		cat(msg)
		cat("> Working on level-2 data files. \n")
	}
	
	#level 2
	for(i in 1:length(sid)){
		#tcga_id = sampleCode1[i,4];
		sidc = i;
		if(is.na(sid[i]))next
		tcga_id = sid[i];
		fn = paste(pref2,tcga_id,".txt",sep="");
		hd1= paste("Hybridization REF",tcga_id,tcga_id,tcga_id,sep="\t");
		hd2= paste("Composite Element REF", "Beta_Value", "Methylated_Signal_Intensity (M)","Un-Methylated_Signal_Intensity (U)",sep="\t");
		write(hd1,fn,sep="");
		write(hd2,fn,sep="",append=TRUE);
		for( j in 1:length(pid)){
			if(is.na(Pv[j,sidc])){
				rst = paste(pid[j],"NA",B[j,sidc],A[j,sidc],sep="\t")
			}else if(Pv[j,sidc]<pcut){
				rst = paste(pid[j],Bv[j,sidc],B[j,sidc],A[j,sidc],sep="\t")
			} else{
				rst = paste(pid[j],"NA",B[j,sidc],A[j,sidc],sep="\t")
			}
			write(rst,fn,sep="",append=TRUE);
		}
	}  
	if(!is.null(txt)){
		msg<-paste("> Finishing processing the level-2 data Files...",date(),"\n",sep="")
		cat(msg)
		cat("> Working on the level-3 data Files.\n")
	}
	#level 3           
	for(i in 1:length(sid)){
		sidc = i;
		if(is.na(sid[i]))next
		tcga_id = sid[i];
		fn = paste(pref3,tcga_id,".txt",sep="");
		hd1= paste("Hybridization REF",tcga_id,tcga_id,tcga_id,tcga_id,sep="\t");
		hd2= paste("Composite Element REF", "Beta_Value", "Gene_Symbol", "Chromosome", "Genomic_Coordinate",sep="\t");
		write(hd1,fn,sep="");
		write(hd2,fn,sep="",append=TRUE);
		for( j in 1:length(pid)){
			if(is.na(Pv[j,sidc])){
				rst = paste(pid[j],"NA",lvl3mask[[2]][j],lvl3mask[[3]][j],lvl3mask[[5]][j],sep="\t")
			}else if(Pv[j,sidc]<pcut & lvl3mask[[1]][j] == 0){
				rst = paste(pid[j],Bv[j,sidc],lvl3mask[[2]][j],lvl3mask[[3]][j],lvl3mask[[5]][j],sep="\t");
			} else{
				rst = paste(pid[j],"NA",lvl3mask[[2]][j],lvl3mask[[3]][j],lvl3mask[[5]][j],sep="\t");
			}
			write(rst,fn,sep="",append=TRUE);
		}
	}    
	sid<-na.omit(sid)
	create_Manifest(outdir)
	create_SDRF(pref4,sid,outdir)
	if(!is.null(readme_fn)){
		file.copy(readme_fn,file.path(outdir,"DESCRIPTION.TXT"))
	}
	if(!is.null(txt)){
		msg<-paste("> Done with the level-3 data processing ",date(),"\n",sep="")
		cat(msg)
	}
	mdata<-new("methData",M=as.matrix(A),Mn=as.matrix(An),Me=as.matrix(Ae),
			U=as.matrix(B),Un=as.matrix(Bn),Ue=as.matrix(Be),
			Beta=as.matrix(Bv),Pvalue=as.matrix(Pv))
	class(mdata)<-"methData"
	#fn<-"methData"
	fn<-file.path(outdir,paste("methData",".rdata",sep=""))
	if(file.exists(fn))fn<-file.path(outdir,paste("methData_",unclass(Sys.time()),".rdata",sep=""))
	save(mdata,file=fn)
	return(sid)
}
#
#packInfinium <-function(sig_A,sig_A_se,sig_A_n,sig_B,sig_B_se,sig_B_n,pvalue_fn,beta_fn,
#		ctr_R_fn,ctr_G_fn,outdir,tcgaPackage_name,txt=NULL,readme_fn=NULL){
#	
#	#browser();
#	delim = ",";
#	header1=TRUE;
##	lvl3mask_fn = "c:\\tcga\\level3_mask.csv"
##	if(file.exists(lvl3mask_fn)==F){
##		lvl3mask_fn = "http://epinexus.usc.edu/tcga/level3_mask.csv"
##	}
#	# create prefs using tcgaPackage_name
#	t1=unlist(strsplit(tcgaPackage_name,"\\."))
#	pref5 <- paste(t1[1],".",t1[2],".",t1[3],sep="")
#	pref4 <- paste(pref5,".",t1[4],sep="")
#	pref <- paste(pref4,".lvl-1.",sep="")
#	pref2<-paste(pref4,".lvl-2.",sep="")
#	pref3<-paste(pref4,".lvl-3.",sep="")
#	arch_numb = paste(t1[4],".",t1[5],".",t1[6],sep="")
#
#	A<-readDataFile.2(sig_A,header1=header1)
#	A = A[order(row.names(A)),]; #sort rows
#	A = A[,order(names(A))]; #sort cols
#	ProbeSize = dim(A)[1];
#	print( ProbeSize);
#	SampleSize = dim(A)[2];
#	print( SampleSize);
#	sid = names(A);
#	#sid = substr(t,1,nchar(t)-9);
#	#names(A) = sid;
#	pid = row.names(A);
#	
#	An<-readDataFile.2(sig_A_n,header1=header1)
#	if(  ProbeSize !=   dim(An)[1] || SampleSize != dim(An)[2])
#	{
#		stop (paste("dimension of An does not match with that of A, pls check ",sig_A_n,"\n"));
#	}
#	An = An[order(row.names(An)),];
#	An = An[,order(names(An))];
#	sid1 = names(An);
#	#sid1 = substr(t,1,nchar(t)-13);
#	#names(An) = sid1;
#	pid1 = row.names(An);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match An, pls check ",sig_A_n,"\n"));
#	
#	Ae<-readDataFile.2(sig_A_se,header1=header1)
#	if(  ProbeSize !=   dim(Ae)[1] || SampleSize != dim(Ae)[2])
#	{
#		stop (paste("dimension of Ae does not match with that of A, pls check ",sig_A_se,"\n"));
#	}
#	Ae = Ae[order(row.names(Ae)),];
#	Ae = Ae[,order(names(Ae))];
#	sid1 = names(Ae);
#	#sid1 = substr(t,1,nchar(t)-14);
#	#names(Ae) = sid1;
#	pid1 = row.names(Ae);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Ae, pls check ",sig_A_se,"\n"));  
#	
#	
#	B<-readDataFile.2(sig_B,header1=header1)
#	if(  ProbeSize !=   dim(B)[1] || SampleSize != dim(B)[2])
#	{
#		stop (paste("dimension of B does not match with that of A, pls check ",sig_B,"\n"));
#	}
#	B = B[order(row.names(B)),];
#	B = B[,order(names(B))];
#	sid1 = names(B);
#	#sid1 = substr(t,1,nchar(t)-9);
#	#names(B) = sid1;
#	pid1 = row.names(B);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match ",sig_B,"\n"));
#	
#	Bn<-readDataFile.2(sig_B_n,header1=header1)
#	if(  ProbeSize !=   dim(Bn)[1] || SampleSize != dim(Bn)[2])
#	{
#		stop (paste("dimension of B does not match with that of A, pls check ",sig_B_n,"\n"));
#	}
#	Bn = Bn[order(row.names(Bn)),];
#	Bn = Bn[,order(names(Bn))];
#	sid1 = names(Bn);
#	#sid1 = substr(t,1,nchar(t)-13);
#	#names(Bn) = sid1;
#	pid1 = row.names(Bn);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Bn, pls check ",sig_B_n,"\n"));
#	
#	Be<-readDataFile.2(sig_B_se,header1=header1)
#	if(  ProbeSize !=   dim(Be)[1] || SampleSize != dim(Be)[2])
#	{
#		stop (paste("dimension of Be does not match with that of A,pls check",sig_B_se,"\n"));
#	}
#	Be = Be[order(row.names(Be)),];
#	Be = Be[,order(names(Be))];
#	sid1 = names(Be);
#	#sid1 = substr(t,1,nchar(t)-14);
#	#names(Be) = sid1;
#	pid1 = row.names(Be);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Be, pls check",sig_B_se,"\n"));  
#	
#	Bv<-readDataFile.2(beta_fn,header1=header1)
#	if(  ProbeSize !=   dim(Bv)[1] || SampleSize != dim(Bv)[2])
#	{
#		stop (paste("dimension of Bv does not match with that of A, pls check",beta_fn,"\n"));
#	}
#	Bv = Bv[order(row.names(Bv)),];
#	Bv = Bv[,order(names(Bv))];
#	sid1 = names(Bv);
#	pid1 = row.names(Bv);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Bv ",beta_fn,"\n"));  
#	
#	Pv<-readDataFile.2(pvalue_fn,header1=header1)
#	if(  ProbeSize !=   dim(Pv)[1] || SampleSize != dim(Pv)[2])
#	{
#		stop (paste("dimension of Pv does not match with that of A, pls check ",pvalue_fn,"\n"));
#	}
#	Pv = Pv[order(row.names(Pv)),];
#	Pv = Pv[,order(names(Pv))];
#	sid1 = names(Pv);
#	pid1 = row.names(Pv);
#	if(sum(sid!=sid1)>0 ||sum(pid!=pid1)) stop(paste("row or col names of A do not match Pv",pvalue_fn,"\n"));      
#	
#	ctr_R<-readDataFile.2(ctr_R_fn,header1=header1,rowName=NULL,isNum=F)
#	ind<-grep("NEG",ctr_R[,1],ignore.case=T)
#	ctr_R<-ctr_R[ind,-1]
#	ctr_R = ctr_R[,order(names(ctr_R))]; #sort cols
#	sid1 = names(ctr_R);
#	#sid1 = substr(t,1,nchar(t)-nchar(".Signal_Red"));
#	#names(ctr_R) = sid1;
#	if(sum(sid!=sid1)>0 ) stop(paste("row or col names of A do not match ctr_R",ctr_R_fn,"\n"));
#	ctr_R_avg = apply(ctr_R,2,function(x)mean(as.numeric(x),na.rm=T));
#	ctr_R_stderr = apply(ctr_R,2,function(x)sd(as.numeric(x),na.rm=T))/sqrt(16);
#	
#	
#	ctr_G<-readDataFile.2(ctr_G_fn,header1=header1,rowName=NULL,isNum=F)
#	ind<-grep("NEG",ctr_G[,1],ignore.case=T)
#	ctr_G<-ctr_G[ind,-1]
#	ctr_G = ctr_G[,order(names(ctr_G))]; #sort cols
#	sid1 = names(ctr_G);
#	#sid1 = substr(t,1,nchar(t)-nchar(".Signal_grn"));
#	#names(ctr_G) = sid1;
#	if(sum(sid!=sid1)>0 ) stop(paste("row or col names of A do not match ctr_G,",ctr_G_fn,"\n"));
#	ctr_G_avg = apply(ctr_G,2,function(x)mean(as.numeric(x),na.rm=T));
#	ctr_G_stderr = apply(ctr_G,2,function(x)sd(as.numeric(x),na.rm=T))/sqrt(16);
#	
##	lvl3mask_fn_local<-system.file("data/level3_mask.csv",package="methPipe")
##	if(file.exists(lvl3mask_fn_local)){
##		lvl3mask<-lvl3mask_fn_local;
##	}
##	lvl3mask<-read.table(lvl3mask_fn,sep=delim,header=header1,row.names=1)
#	data(lvl3mask)
#	lvl3mask = lvl3mask[order(row.names(lvl3mask)),]; #sort rows
#	pid1 = row.names(lvl3mask);
#	if(sum(sid!=sid1)>0 ) stop(paste("row or col names of A do not match lvl3mask, pls check ",sig_A,"\n"));  
#	
#	sid = gsub("(\\.)", "-", sid)
#	
#	if(!is.null(txt)){
#		msg<-paste("> Finishing Reading and Processing All the Data Files ",date(),"\n",sep="")
#		tkinsert(txt,"end",msg)
#		tkinsert(txt,"end","> Working on the generating level files\n")
#	}
#	setwd(outdir);
#	#level 1  
#	for(i in 1:length(sid)){
#		#sidc = sampleCode1[i,1];
#		sidc = i;
#		tcga_id = sid[i];
#		fn = paste(pref,tcga_id,".txt",sep="");
#		hd1= paste("Hybridization REF",tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,tcga_id,sep="\t");
#		hd2= paste("Composite Element REF", "Methylated_Signal_Intensity (M)", "M_Number_Beads","M_STDERR","Un-Methylated_Signal_Intensity (U)", "U_Number_Beads","U_STDERR","Negative_Control_Grn_Avg_Intensity","Negative_Control_Grn_STDERR","Negative_Control_Red_Avg_Intensity","Negative_Control_Red_STDERR","Detection_P_Value",sep="\t");
#		write(hd1,fn,sep="");
#		write(hd2,fn,sep="",append=TRUE);
#		for( j in 1:length(pid)){
#			rst = paste(pid[j],B[j,sidc],Bn[j,sidc],Be[j,sidc],A[j,sidc],An[j,sidc],Ae[j,sidc],ctr_G_avg[i],ctr_G_stderr[i],ctr_R_avg[i],ctr_R_stderr[i],Pv[j,sidc],sep="\t")
#			write(rst,fn,sep="",append=TRUE);
#		}
#	}
#	
#	if(!is.null(txt)){
#		msg<-paste("> Finishing processing the level-1 data files...",date(),"\n",sep="")
#		tkinsert(txt,"end",msg)
#		tkinsert(txt,"end","> Working on level-2 data files. \n")
#	}
#	
#	#level 2
#	for(i in 1:length(sid)){
#		#sidc = sampleCode1[i,1];
#		#tcga_id = sampleCode1[i,4];
#		sidc = i;
#		tcga_id = sid[i];
#		fn = paste(pref2,tcga_id,".txt",sep="");
#		hd1= paste("Hybridization REF",tcga_id,tcga_id,tcga_id,sep="\t");
#		hd2= paste("Composite Element REF", "Beta_Value", "Methylated_Signal_Intensity (M)","Un-Methylated_Signal_Intensity (U)",sep="\t");
#		write(hd1,fn,sep="");
#		write(hd2,fn,sep="",append=TRUE);
#		for( j in 1:length(pid)){
#			if(Pv[j,sidc]<0.05){
#				rst = paste(pid[j],Bv[j,sidc],B[j,sidc],A[j,sidc],sep="\t")
#			} else{
#				rst = paste(pid[j],"NA",B[j,sidc],A[j,sidc],sep="\t")
#			}
#			write(rst,fn,sep="",append=TRUE);
#		}
#	}  
#	if(!is.null(txt)){
#		msg<-paste("> Finishing processing the level-2 data Files...",date(),"\n",sep="")
#		tkinsert(txt,"end",msg)
#		tkinsert(txt,"end","> Working on the level-3 data Files.\n")
#	}
#	#level 3           
#	for(i in 1:length(sid)){
#		#sidc = sampleCode1[i,1];
#		#tcga_id = sampleCode1[i,4];
#		sidc = i;
#		tcga_id = sid[i];
#		fn = paste(pref3,tcga_id,".txt",sep="");
#		hd1= paste("Hybridization REF",tcga_id,tcga_id,tcga_id,tcga_id,sep="\t");
#		hd2= paste("Composite Element REF", "Beta_Value", "Gene_Symbol", "Chromosome", "Genomic_Coordinate",sep="\t");
#		write(hd1,fn,sep="");
#		write(hd2,fn,sep="",append=TRUE);
#		for( j in 1:length(pid)){
#			if(Pv[j,sidc]<0.05 & lvl3mask[[1]][j] == 0){
#				rst = paste(pid[j],Bv[j,sidc],lvl3mask[[2]][j],lvl3mask[[3]][j],lvl3mask[[5]][j],sep="\t");
#			} else{
#				rst = paste(pid[j],"NA",lvl3mask[[2]][j],lvl3mask[[3]][j],lvl3mask[[5]][j],sep="\t");
#			}
#			write(rst,fn,sep="",append=TRUE);
#		}
#	}    
#	#browser();
#	create_Manifest(outdir)
#	create_SDRF(pref4,sid,outdir)
#	if(!is.null(readme_fn)){
#		#data.dir<-tclvalue(tclfile.dir(sig_A))
#		file.copy(readme_fn,file.path(outdir,"DESCRIPTION.TXT"))
#	}
#	if(!is.null(txt)){
#		msg<-paste("> Done with the level-3 data processing ",date(),"\n",sep="")
#		tkinsert(txt,"end",msg)
#	}
#	mdata<-new("methData",M=as.matrix(A),Mn=as.matrix(An),Me=as.matrix(Ae),
#			U=as.matrix(B),Un=as.matrix(Bn),Ue=as.matrix(Be),
#			Beta=as.matrix(Bv),Pvalue=as.matrix(Pv))
#	class(mdata)<-"methData"
#	#fn<-tclvalue(tclfile.tail(sig_A))
#	#fn<-unlist(strsplit(fn,"\\."))[1]
#	fn<-"methData"
#	#outdir.1<-tclvalue(tclfile.dir(outdir))
#	save(mdata,file=file.path(outdir,paste(fn,".rdata",sep="")))
#	return(sid)
#}

create_Manifest<-function(wkdir){
	fn = "MANIFEST.txt";
	setwd(wkdir);
	flist = list.files();
	write(flist[1],fn,sep="");
	for(i in 2:length(flist)){
		write(flist[i],fn,append=TRUE);
	}
}
create_SDRF_complete_run<-function(){
	data.dir<-"c:\\tcga\\OV"
	SDRF_pkg_name<-"jhu-usc.edu_OV.HumanMethylation27.2.sdrf.txt"
	create_SDRF_complete(SDRF_pkg_name,data.dir)
	
	data.dir<-"c:\\tcga\\LUSC"
	pkg_name<-"jhu-usc.edu_LUSC.HumanMethylation27.2.sdrf.txt"
	create_SDRF_complete(pkg_name,data.dir)
}
create_SDRF_complete<-function(pkg_name,data.dir=NULL){
	if(is.null(data.dir)) data.dir<-"c:\\tcga\\OV"
	setwd(data.dir)
	dlist<-list.files(pattern="Level_1")
	ind<-grep("tar",dlist)
	dlist<-dlist[ind]
	dlist<-dlist[-grep("gz",dlist)]
	#ind1<-grep(".md5",dlist)
	#dlist<-dlist[-ind1]
	sid.all<-c()
	pref4.all<-c()
	pref5.all<-c()
	arch_numb.all<-c()
	for(i in 1:length(dlist)){
		setwd(data.dir)
		#system(paste("gzip -d ",dlist[i],sep=""))
		#fn<-substr(dlist[i],1,(nchar(dlist[i])-3))
		fn<-dlist[i]
		system(paste("tar -xvf ",fn,sep=""))
		fn1<-substr(fn,1,(nchar(fn)-3))
		setwd(file.path(data.dir,fn1))
		flist<-list.files(pattern="lvl-1")
		sid<-sapply(flist,function(x)strsplit(x,"lvl-1")[[1]][2])
		sid<-sapply(sid,function(x)strsplit(x,"\\.")[[1]][2])
		sid.all<-c(sid.all,sid)
		np<-unlist(strsplit(dlist[i],"\\.Level_1\\."))
		arch_numb<-substr(np[2],1,(nchar(np[2])-4))
		pref5<-np[1]
		pref4<-paste(np[1],strsplit(arch_numb,"\\.")[[1]][1],sep=".")
		arch_numb.all<-c(arch_numb.all,rep(arch_numb,length(flist)))
		pref5.all<-c(pref5.all,rep(pref5,length(flist)))
		pref4.all<-c(pref4.all,rep(pref4,length(flist)))
	}
	#create_SDRF(pkg_name,sid.all,data.dir)
	adf_fn<-paste(pref4.all,".adf.txt",sep="")
	create_Mage_TAB_SDRF.2(pref4.all,pref5.all,sid.all,data.dir,pkg_name,arch_numb.all,adf_fn)
}

##################
# SDRF of Old Scheme
#################
create_SDRF<-function(pref4,sampleID,outdir){
	setwd(outdir)
	hd1= paste("Extract Name","Protocol REF","Labeled Extract Name",
			"Label","Term Source REF","Protocol REF","Hybridization Name",
			"Array Design File","Term Source REF","Protocol REF","Scan Name",
			"Protocol REF","Protocol REF","Normalization Name",
			"Derived Array Data Matrix File","Comment [TCGA Data Level]",
			"Protocol REF","Normalization Name","Derived Array Data Matrix File",
			"Comment [TCGA Data Level]","Protocol REF","Normalization Name",
			"Derived Array Data Matrix File","Comment [TCGA Data Level]",sep="\t");
	sdrf_fn = paste(pref4,".sdrf.txt",sep="");
	write(hd1,sdrf_fn,sep="");
	adf_fn = paste(pref4,".adf.txt",sep="");
	
	for(i in 1:length(sampleID)){
		sidc = i;
		tcga_id = sampleID[i];	
		lvl1_fn = paste(pref4,".lvl-1.",tcga_id,".txt",sep="");
		lvl2_fn = paste(pref4,".lvl-2.",tcga_id,".txt",sep="");
		lvl3_fn = paste(pref4,".lvl-3.",tcga_id,".txt",sep="");
		hd2= paste(tcga_id,"jhu-usc.edu:labeling:HumanMethylation27:01",tcga_id,"biotin",
				"MGED Ontology","jhu-usc.edu:hybridization:HumanMethylation27:01",
				tcga_id,adf_fn,"caArray",
				"jhu-usc.edu:image_acquisition:HumanMethylation27:01",tcga_id,
				"jhu-usc.edu:feature_extraction:HumanMethylation27:01",
				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",
				tcga_id,lvl1_fn,"Level 1","jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",
				tcga_id,lvl2_fn,"Level 2",
				"jhu-usc.edu:within_bioassay_data_set_function:HumanMethylation27:01",tcga_id,
				lvl3_fn,"Level 3",sep="\t"
		);
		write(hd2,sdrf_fn,sep="",append=TRUE);
	}
}
#####################
# 05/03/2010 - Release 3.1
# https://wiki.nci.nih.gov/display/TCGA/DCC+Archive+Validator+version+3
# https://wiki.nci.nih.gov/download/attachments/21695888/validator3.zip?version=12
######################
validatePkg_test<-function(){
	pkgPath<-"C:\\temp\\jhu-usc.edu_UCEC.HumanMethylation27.1"
	validatePkg(pkgPath)
}
validatePkg_test.2<-function(){
	pkgPath<-"/home/feipan/temp/jhu-usc.edu_OV.HumanMethylation27.15"
	validatePkg(pkgPath)
}
validatePkg<-function(pkgPath,validatorPath=NULL,javaPath=NULL,txt=NULL){
	msg<-paste(">Start to run QC validator...",date(),"\n")
	cat(msg)
	if(!is.null(txt)){
		tkinsert(txt,"end",msg)
	}
	#if(is.null(validatorPath))validatorPath<-file.path(system.file(package="methPipe"),"validator3")#"c:\\tcga\\validator3"
	if(is.null(validatorPath)){
		validatorPath<-system.file("validator3",package="rapid")
	}
	setwd(validatorPath)
	fn<-file.path(pkgPath,"qc_validator.txt")
	if(R.Version()$os=="mingw32"){
		runbat<-"java -showversion -Xms1024M -Xmx1024M -classpath .;gov;conf;lib/opencsv.jar;lib/ant.jar;lib/log4j.jar;lib/serializer.jar;lib/xml-apis.jar;lib/xercesImpl.jar;lib/xalan.jar;lib/acegi-security-1.0.4.jar;lib/antlr-2.7.6.jar;lib/asm.jar;lib/axis.jar;lib/caGrid-CQL-cql.1.0-1.2.jar;lib/castor-1.0.2.jar;lib/cglib-2.1.3.jar;lib/cog-jglobus.jar;lib/commons-codec-1.3.jar;lib/commons-collections-3.2.jar;lib/commons-discovery-0.2.jar;lib/commons-logging-1.1.jar;lib/hibernate3.jar;lib/jaxrpc.jar;lib/log4j-1.2.14.jar;lib/sdk-client-framework.jar;lib/sdk-grid-remoting.jar;lib/sdk-security.jar;lib/spring.jar;lib/tcgadccws-beans.jar;lib/xercesImpl.jar;lib/postgresql.jar gov/nih/nci/ncicb/tcga/dcc/qclive/soundcheck/Soundcheck %*"
		if(!is.null(javaPath))runbat<-file.path(javaPath,runbat)
		cmd<-paste(runbat," \"",pkgPath,"\" > \"",fn,"\"",sep="")
		shell(cmd)
	}else{
		runbat<-paste(javaPath,"java -showversion -Xms1024M -Xmx1024M -classpath ",validatorPath,":.:gov:conf:lib/opencsv.jar:lib/ant.jar:lib/log4j.jar:lib/serializer.jar:lib/xml-apis.jar:lib/xercesImpl.jar:lib/xalan.jar:lib/acegi-security-1.0.4.jar:lib/antlr-2.7.6.jar:lib/asm.jar:lib/axis.jar:lib/caGrid-CQL-cql.1.0-1.2.jar:lib/castor-1.0.2.jar:lib/cglib-2.1.3.jar:lib/cog-jglobus.jar:lib/commons-codec-1.3.jar:lib/commons-collections-3.2.jar:lib/commons-discovery-0.2.jar:lib/commons-logging-1.1.jar:lib/hibernate3.jar:lib/jaxrpc.jar:lib/log4j-1.2.14.jar:lib/sdk-client-framework.jar:lib/sdk-grid-remoting.jar:lib/sdk-security.jar:lib/spring.jar:lib/tcgadccws-beans.jar:lib/xercesImpl.jar:lib/postgresql.jar gov/nih/nci/ncicb/tcga/dcc/qclive/soundcheck/Soundcheck ",sep="")
		if(!is.null(javaPath))runbat<-file.path(javaPath,runbat)
		cmd<-paste(runbat," ",pkgPath," > ",fn,sep="")
		system(cmd)
	}
	qc.rst<-readLines(fn)
	check<-"Validation passed with no errors or warnings."
	if(qc.rst[length(qc.rst)]!=check){
		msg<-paste(">There are some errors in QC Validation, more details are in ",fn,"\n")
		cat(msg)
		if(!is.null(txt)) tkinsert(txt,"end",msg)
	}else{
		msg<-">Done with running QC validator without errors\n"
		cat(msg)
		if(!is.null(txt))tkinsert(txt,"end",msg)
	}
}
validateInfiniumPkg<-function(pkg.dir,pkg_name=NULL){
	#validator.dir<-paste(system.file("data",package="methPipe"),"/validator3",sep="")
	validator.dir<-"c:\\tcga\\validator3"
	setwd(validator.dir)
	#pfile<-file.path(validator.dir,"validate.bat")
	runbat<-readLines("validate.bat")
	zz<-file(file.path(validator.dir,"run1.bat"),"w")
	#cat("cd ",validator.dir,"\n",file=zz)
	timestamp<-unclass(Sys.time())
	if(!is.null(pkg_name)) {
		fn<-paste("script.out.",pkg_name,timestamp,".txt",sep="")
	}
	else {
		fn<-paste("script.out",timestamp,".txt",sep="")
	}
	command<-paste(runbat," ",pkg.dir,">",fn,sep="")
	cat(command,"\n",file=zz)
	close(zz)
	shell(file.path(validator.dir,"run1.bat"))
	shell(file.path(validator.dir,fn))
	
}






###############
# May 13, 2010
###############
depositePkg<-function(pkgFolder){
	repos<-"feipan@epimatrix.usc.edu:/tcga/data"
	setwd(pkgFolder)
	flist.md5<-list.files(pattern=".md5")
	flist.gz<-list.files(pattern=".gz")
	flist<-c(flist.md5,flist.gz)
	flist.name<-paste(flist,collapse="/n")
	wdir<-"c:\\temp" #tempdir()
	#fn.manifest<-updateManifest()
	#flist<-c(flist,fn.manifest)
	scopy(flist,repos)
}
updateManifest<-function(toDB=T){
	fn<-"MANIFEST.TXT"
	download.file(paste(repos,fn,sep="/"),destfile=wdir)
	fn.manifest<-file.path(wdir,fn)
	zz<-file(fn.manifest)
	cat(flist.name,file=zz,append=T)
	close(zz)
	if(toDB==T){
		cat("to do...\n")
	}
	return(fn.manifest)
}
scopy<-function(flist,repos){
	#repos<-"feipan@epimatrix.usc.edu:/home/feipan/apache-tomcat-6.0.20/webapps/ROOT/tcga/data"
	wdir<-"c:\\temp"#tempdir()
	fn<-file.path(wdir,"run.bat")
	zz<-file(fn,"w")
	flists<-paste(flist,collapse=" ")
	cat(paste("c:/cygwin/bin/scp ",flists," ",repos,"\n"),file=zz)
	close(zz)
	shell(fn)
}
downloadRepos<-function(pgk){
	repos<-"http://epimatrix.usc.edu:8080/tcga/data"
	if(is.null(wdir)){
		wdir<-"c:\\temp" #tempdir()
	}
	fn.dest<-file.path(wdir,pkg_name)
	fn.repos<-paste(repos,pkg_name,sep="/")
	download.file(fn.repos,destfile=fn.dest)
	return(fn.dest)
}
loadPkgFromRepos<-function(pkg_name,txt=NULL,wdir=NULL){
	fn.dest<-downloadRepos(pkg_name)
	msg<-paste("Data package ",pkg_name," are downloaded into ",fn.dest,"\n",sep="")
	cat(msg)
	if(!is.null(txt)){
		tkinsert(txt,"end",msg)
	}
}
viewDataRepos<-function(pkg_type){
	fn<-downloadRepos(pkg_type)
	dat<-read.table(fn,sep="\t")
	ind<-dat[1,]==pkg_type
	dat<-dat[ind,]
	data.entry(dat)
}

################################
run_merge_SDRF_files<-function(){
	#COAD
	pkg_folders<-c("C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.1\\jhu-usc.edu_COAD.HumanMethylation27.mage-tab.1.0.0\\jhu-usc.edu_COAD.HumanMethylation27.1.sdrf.txt",
					"C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.2\\jhu-usc.edu_COAD.HumanMethylation27.mage-tab.1.1.0\\jhu-usc.edu_COAD.HumanMethylation27.2.sdrf.txt",
					"C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.3\\jhu-usc.edu_COAD.HumanMethylation27.mage-tab.1.3.0\\jhu-usc.edu_COAD.HumanMethylation27.3.sdrf.txt",
					"C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.4\\jhu-usc.edu_COAD.HumanMethylation27.mage-tab.1.4.0\\jhu-usc.edu_COAD.HumanMethylation27.4.sdrf.txt",
					"C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.5\\jhu-usc.edu_COAD.HumanMethylation27.mage-tab.1.5.0\\jhu-usc.edu_COAD.HumanMethylation27.5.sdrf.txt")	
	fn<-"c:\\tcga\\COAD\\jhu-usc.edu_COAD.HumanMethylation27.5.sdrf.txt"
	merge_SDRF_files(pkg_folders,fn)
	#READ
	pkg_folders<-c("C:\\tcga\\jhu-usc.edu_READ.HumanMethylation27.1\\jhu-usc.edu_READ.HumanMethylation27.mage-tab.1.0.0\\jhu-usc.edu_READ.HumanMethylation27.1.sdrf.txt",
			"C:\\tcga\\jhu-usc.edu_READ.HumanMethylation27.2\\jhu-usc.edu_READ.HumanMethylation27.mage-tab.1.1.0\\jhu-usc.edu_READ.HumanMethylation27.2.sdrf.txt",
			"C:\\tcga\\jhu-usc.edu_READ.HumanMethylation27.3\\jhu-usc.edu_READ.HumanMethylation27.mage-tab.1.3.0\\jhu-usc.edu_READ.HumanMethylation27.3.sdrf.txt",
			"C:\\tcga\\jhu-usc.edu_READ.HumanMethylation27.4\\jhu-usc.edu_READ.HumanMethylation27.mage-tab.1.4.0\\jhu-usc.edu_READ.HumanMethylation27.4.sdrf.txt",
			"C:\\tcga\\jhu-usc.edu_READ.HumanMethylation27.5\\jhu-usc.edu_READ.HumanMethylation27.mage-tab.1.5.0\\jhu-usc.edu_READ.HumanMethylation27.5.sdrf.txt")
	fn<-"c:\\tcga\\jhu-usc.edu_READ.HumanMethylation27.5.sdrf.txt"
	merge_SDRF_files(pkg_folders,fn)
	# GBM
	pkg_folders<-c("C:\\tcga\\GBM\\jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.0.0\\jhu-usc.edu_GBM.HumanMethylation27.1.sdrf.txt",
			"C:\\tcga\\GBM\\jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.7.0\\jhu-usc.edu_GBM.HumanMethylation27.7.sdrf.txt",
			"C:\\tcga\\GBM\\jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.6.0\\jhu-usc.edu_GBM.HumanMethylation27.6.sdrf.txt",
			"C:\\tcga\\jhu-usc.edu_GBM.HumanMethylation27.8\\jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.8.0\\jhu-usc.edu_GBM.HumanMethylation27.8.sdrf.txt")
	fn<-"c:\\tcga\\GBM\\jhu-usc.edu_GBM.HumanMethylation27.8.sdrf.txt"
	merge_SDRF_files(pkg_folders,fn)
	#LUSC
	# update to level_3.2.3
	createManifestByLevel.2("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.2.3.0")
	compressDataPackage("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.2.3.0")
	# update sdrf
	fn<-"C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2\\jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.2.0\\jhu-usc.edu_LUSC.HumanMethylation27.2.sdrf.txt"
	sdrf<-readLines(fn)
	sdrf1<-gsub("Level_3.2.2.0","Level_3.2.3.0",sdrf)
	write(sdrf1,file=fn)
	createManifestByLevel.2("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.2.0")
	compressDataPackage("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.2.0")
	# remove old 2.1
	fn<-"C:\\tcga\\LUSC\\jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.7.0\\jhu-usc.edu_LUSC.HumanMethylation27.2.sdrf.txt"
	sdrf<-readLines(fn)
	ind<-grep("Level_1.2.1.0",sdrf)
	sdrf1<-sdrf[-ind]
	write(sdrf1,file=fn)
	
	pkg_folders<-c("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2\\jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.2.0\\jhu-usc.edu_LUSC.HumanMethylation27.2.sdrf.txt",
			"C:\\tcga\\LUSC\\jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.7.0\\jhu-usc.edu_LUSC.HumanMethylation27.2.sdrf.txt",
			"C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.3\\jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.3.0\\jhu-usc.edu_LUSC.HumanMethylation27.3.sdrf.txt")
	fn<-"c:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2.sdrf.txt"
	merge_SDRF_files(pkg_folders,fn,outdir="C:\\tcga\\LUSC\\jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.7.0")
	
	createManifestByLevel.2("C:\\tcga\\LUSC","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.7.0")
	compressDataPackage("c:\\tcga\\LUSC","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.7.0")
}
merge_Packages_run<-function(){
	cur_pkgs<-"c:\\tcga\\LUSC"
	new_pkg<-"c:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.3"
	merge_Packages(cur_pkgs,new_pkg,inc=F)
	new_pkg<-"c:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2"
	
	
	cur_pkgs<-"c:\\tcga\\COAD"
	new_pkg<-"C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.5"
	new_pkg<-"C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.6"
	
	
	cur_pkgs<-"c:\\tcga\\KIRC"
	new_pkg<-"C:\\tcga\\jhu-usc.edu_KIRC.HumanMethylation27.1"
	cur_pkgs<-"c:\\tcga\\LUAD"
	new_pkg<-"C:\\tcga\\jhu-usc.edu_LUAD.HumanMethylation27.1"

	pkg_validate(new_pkg)
	merge_Packages(cur_pkgs,new_pkg)
	
	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.1.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.1.0")

	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.2.3.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.2.3.0")
	new_pkg<-"C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.2"
	
	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.1","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.1.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.1","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.1.0")
	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.1","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.1.4.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.1","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.1.4.0")
	new_pkg<-"C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.1"
	
	createManifestByLevel.2("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.2.4.0")
	compressDataPackage("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.2.4.0")
	createManifestByLevel.2("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.2.0")
	compressDataPackage("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.2.0")
	
	createManifestByLevel.2("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.3","jhu-usc.edu_LUSC.HumanMethylation27.Level_1.3.1.0")
	compressDataPackage("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.3","jhu-usc.edu_LUSC.HumanMethylation27.Level_1.3.1.0")
	createManifestByLevel.2("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.3","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.3.0")
	compressDataPackage("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.3","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.3.0")
}
createMD5SUM<-function(fn,fdir=NULL){
	if(is.null(fdir))fdir<-filedir(fn)
	cdir<-getwd()
	setwd(fdir)
	if(R.Version()$os=="mingW32"){
		md5sum<-file.path(system.file("Rtools",package="rapid","md5sum"))
		shell(paste(md5sum," *.* > ",fn),sep="")
	}else{
		system(paste("md5sum *.* > ",fn))
	}
	setwd(cdir)
}
uncompress<-function(fn,fDir=NULL){
	rst<-NULL
	cdir<-getwd()
	if(!is.null(fDir))setwd(fDir)
	if(R.Version()$os=="mingw32"){
		tar<-file.path(system.file("Rtools",package="rapid"),"tar")
		rst<-system(paste(tar," -xzf ",fn,sep=""))
	}else{
		rst<-system(paste("tar -xzf",fn))
	}
	setwd(cdir)
	return(rst)
}
merge_Packages.2_test<-function(){
	cur_pkgs<-"C:\\temp\\STAD"
	new_pkg<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\jhu-usc.edu_STAD.HumanMethylation27.1"
	merge_Packages.2(cur_pkgs,new_pkg)
}
merge_Packages.2<-function(cur_pkgs,new_pkg,inc=T){
	setwd(cur_pkgs)
	mage_dir<-list.files(cur_pkgs,pattern="mage-tab")
	new_pkg_fn<-list.files(new_pkg,pattern="tar")
	if(length(mage_dir)>=1){
		mage_fn<-mage_dir[grep("tar.gz$",mage_dir)]
		if(length(mage_fn)!=1)stop("Mage file is missing or non-unique,please validate the data repository\n")
		uncompress(mage_fn)
		mage_dir<-gsub(".tar.gz","",mage_fn)
		mage_dir.new<-list.files(new_pkg,pattern="mage-tab")
		mage_dir.new<-mage_dir.new[grep("tar.gz$",mage_dir.new)]
		if(length(mage_dir.new)!=1) stop("Mage file is missing or non-unique, please validate the new data package\n")
		uncompress(mage_dir.new,new_pkg)
		mage_dir.new<-gsub(".tar.gz","",mage_dir.new)
		sdrf_fn<-list.files(file.path(cur_pkgs,mage_dir),pattern="sdrf")
		sdrf_fn.cur<-file.path(cur_pkgs,mage_dir,sdrf_fn)
		sdrf_fn.new<-file.path(new_pkg,mage_dir.new,list.files(file.path(new_pkg,mage_dir.new),pattern="sdrf"))
		update_SDRF_files.2(sdrf_fn.cur,sdrf_fn.new)
		# create new magtab
		t1<-strsplit(mage_dir,"\\.")[[1]]
		t2<-as.numeric(t1[6])
		if(inc==T) t2<-t2+1
		t1[6]<-t2
		magetab_fn<-paste(t1,collapse=".")
		file.rename(mage_dir,magetab_fn)
		mage_fn_new<-file.path(cur_pkgs,magetab_fn)
		createManifestByLevel.2(cur_pkgs,magetab_fn)
		compressDataPackage(cur_pkgs,magetab_fn)
		
		#bk old pkgs and magtab
		setwd(cur_pkgs)
		if(!file.exists("bk")) dir.create("bk")
		file.copy(paste(mage_dir,".tar.gz",sep=""),paste("bk/",mage_dir,".tar.gz",sep=""))
		file.copy(paste(mage_dir,".tar.gz.md5",sep=""),paste("bk/",mage_dir,".tar.gz.md5",sep=""))
		t2<-strsplit(new_pkg_fn[1],"\\.")[[1]][5]
		for(i in 1:3){
			fn<-list.files(cur_pkgs,paste("Level_",i,".",t2,sep=""))
			fn<-fn[grep("tar",fn)]
			for(f1 in fn){
				file.copy(f1,file.path("bk",f1))
				file.remove(f1)
			}
		}
		# rm old magtab
		if(inc==T){
			file.remove(file.path(cur_pkgs,paste(mage_dir,".tar.gz",sep="")))
			file.remove(file.path(cur_pkgs,paste(mage_dir,".tar.gz.md5",sep="")))
		}
		new_pkg_fn<-new_pkg_fn[-grep("mage",new_pkg_fn)] #note: for old repos,don't trans mage file
	}
	#trans new pkgs
	for(fn in new_pkg_fn) file.copy(file.path(new_pkg,fn),file.path(cur_pkgs,fn))
}
	
	merge_Packages<-function(cur_pkgs,new_pkg,inc=T){
		setwd(cur_pkgs)
		mage_dir<-list.files(cur_pkgs,pattern="mage-tab")
		new_pkg_fn<-list.files(new_pkg,pattern="tar")
		if(length(mage_dir)>=1){
			mage_dir<-mage_dir[-grep("tar",mage_dir)]
			mage_dir.new<-list.files(new_pkg,pattern="mage-tab")
			mage_dir.new<-mage_dir.new[-grep("tar",mage_dir.new)]
			sdrf_fn<-list.files(file.path(cur_pkgs,mage_dir),pattern="sdrf")
			sdrf_fn.cur<-file.path(cur_pkgs,mage_dir,sdrf_fn)
			sdrf_fn.new<-file.path(new_pkg,mage_dir.new,list.files(file.path(new_pkg,mage_dir.new),pattern="sdrf"))
			#file.copy(sdrf_fn.cur,paste(file.path(cur_pkgs,sdrf_fn),"_bk",sep=""))
			update_SDRF_files.2(sdrf_fn.cur,sdrf_fn.new)
			# create new magtab
			t1<-strsplit(mage_dir,"\\.")[[1]]
			t2<-as.numeric(t1[6])
			if(inc==T) t2<-t2+1
			t1[6]<-t2
			magetab_fn<-paste(t1,collapse=".")
			file.rename(mage_dir,magetab_fn)
			mage_fn_new<-file.path(cur_pkgs,magetab_fn)
			createManifestByLevel.2(cur_pkgs,magetab_fn)
			compressDataPackage(cur_pkgs,magetab_fn)
			
			#new_pkg_fn<-list.files(new_pkg,pattern="tar")
			#bk old pkgs and magtab
			setwd(cur_pkgs)
			if(!file.exists("bk")) dir.create("bk")
			file.copy(paste(mage_dir,".tar.gz",sep=""),paste("bk/",mage_dir,".tar.gz",sep=""))
			file.copy(paste(mage_dir,".tar.gz.md5",sep=""),paste("bk/",mage_dir,".tar.gz.md5",sep=""))
			t2<-strsplit(new_pkg_fn[1],"\\.")[[1]][5]
			for(i in 1:3){
				fn<-list.files(cur_pkgs,paste("Level_",i,".",t2,sep=""))
				fn<-fn[grep("tar",fn)]
				for(f1 in fn){
					file.copy(f1,file.path("bk",f1))
					file.remove(f1)
				}
			}
			new_pkg_fn<-new_pkg_fn[-grep("mage",new_pkg_fn)]
			# rm old magtab
			if(inc==T){
				file.remove(file.path(cur_pkgs,paste(mage_dir,".tar.gz",sep="")))
				file.remove(file.path(cur_pkgs,paste(mage_dir,".tar.gz.md5",sep="")))
			}
		}
		#trans new pkgs
		for(fn in new_pkg_fn) file.copy(file.path(new_pkg,fn),file.path(cur_pkgs,fn))
	}
	
update_SDRF_files.2_test<-function(){
	src_sdrf<-"C:\\tcga\\GBM\\jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.16.0\\jhu-usc.edu_GBM.HumanMethylation27.8.sdrf.txt"
	new_sdrf<-"C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.7\\jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.7.0\\jhu-usc.edu_GBM.HumanMethylation27.7.sdrf.txt"
	fn<-"c:\\temp\\gbm.sdrf.txt"
	update_SDRF_files.2(src_sdrf,new_sdrf,fn)
}
update_SDRF_files.2<-function(src_sdrf,new_sdrf,fn=NULL){
	dat.src<-read.delim(file=src_sdrf,sep="\t",header=F,stringsAsFactors=F)
	dat.new<-read.delim(file=new_sdrf,sep="\t",header=F,stringsAsFactors=F)
	if(ncol(dat.src)>ncol(dat.new)){
		len<-ncol(dat.src)-ncol(dat.new)
		dat.new2<-matrix(NA,nrow=nrow(dat.new),ncol=len)
		dat.new<-data.frame(dat.new,dat.new2)
	}
	dat.src<-apply(dat.src,1,function(x)paste(x,collapse="\t"))
	dat.new<-apply(dat.new,1,function(x)paste(x,collapse="\t"))
	dat.new<-dat.new[-1]
	dat.new1<-strsplit(dat.new[1],"\t")[[1]]
	sid.new<-dat.new1[length(dat.new1)]
	sid<-paste("Level_1.",strsplit(sid.new,"\\.")[[1]][5],sep="")
	ind<-grep(sid,dat.src)
	if(length(ind)>0) dat.src<-dat.src[-ind]
	
	dat.src<-c(dat.src,dat.new)
	if(is.null(fn)) fn<-src_sdrf
	write(dat.src,file=fn,sep="\n")
}
update_SDRF_files<-function(src_sdrf,new_sdrf,fn=NULL){
	dat.src<-readLines(src_sdrf)
	dat.new<-readLines(new_sdrf)
	dat.new<-dat.new[-1]
	dat.new1<-strsplit(dat.new[1],"\t")[[1]]
	sid.new<-dat.new1[length(dat.new1)]
	sid<-paste("Level_1.",strsplit(sid.new,"\\.")[[1]][5],sep="")
	ind<-grep(sid,dat.src)
	if(length(ind)>0) dat.src<-dat.src[-ind]
	
	dat.src<-c(dat.src,dat.new)
	if(is.null(fn)) fn<-src_sdrf
	write(dat.src,file=fn,sep="\n")
}
merge_SDRF_files<-function(pkg_folders,fn,outdir=NULL){
	if(is.null(outdir))outdir<-"c:\\tcga"
	setwd(outdir)
	dat.all<-NULL
	for(i in 1:length(pkg_folders)){
		dat<-read.table(file=pkg_folders[i],header=F,sep="\t");
		if(is.null(dat.all)){
			dat.all<-dat
		}else{
			dat<-dat[-1,]
			dat.all<-rbind(dat.all,dat)
		}
	}
	write.table(dat.all,file=fn,sep="\t",quote=F,row.names=F,col.names=F)
}
mergePkgUEC<-function(txt=NULL){
	uploadUECRepos(txt)
}
##################
# new data package folder, eg, C:\tcga\repos\jhu-usc.edu_GBM.HumanMethylation27.2
# current data package folder, eg, c:\tcga\GBM
##################
mergeDataPackages.2<-function(txt=NULL,auto=F){
	if(auto==F){
		dlg<-startDialog("Merge Data Packages")
		dlg1<-tkfrm(dlg)
		addTextEntryWidget(dlg1,"Select the new data package folder: ",isFolder=T,name="textEntry1")
		addTextEntryWidget(dlg1,"Select the local data repository folder:",isFolder=T,name="textEntry2")
		addTextEntryWidget(dlg1,"Increase the serial number of mage-tab archive:","YES",withSelectButton=F,name="textEntry3")
		tkgrid(tklabel(dlg,text="  "))
		tkaddfrm(dlg,dlg1)
		endDialog(dlg,c("textEntry1","textEntry2","textEntry3"),pad=T)
	}
	if(is.null(reValue))return()
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Start to merge data packages from ",reValue[1]," to ",reValue[2],"\t",date(),"\n"))
	new_pkg<-reValue[1]
	if(!file.exists(new_pkg)) stop("selected file does not exist\n")
	src_pkgs<-reValue[2]
	inc<-F
	if(reValue[3]=="YES") inc<-T
	merge_Packages.2(src_pkgs,new_pkg,inc)
	#tcgaPackage_folder<<-src_pkgs
	reValue<<-NULL
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Finished. ",date(),"\n"))
}
mergeDataPackages<-function(txt=NULL){
	dlg<-startDialog("Merge Data Packages")
	dlg1<-tkfrm(dlg)
	addTextEntryWidget(dlg1,"Select the new data package folder: ",isFolder=T,name="textEntry1")
	addTextEntryWidget(dlg1,"Select the local data repository folder:",isFolder=T,name="textEntry2")
	addTextEntryWidget(dlg1,"Increase the serial number of mage-tab archive:","YES",withSelectButton=F,name="textEntry3")
	tkgrid(tklabel(dlg,text="  "))
	tkaddfrm(dlg,dlg1)
	endDialog(dlg,c("textEntry1","textEntry2","textEntry3"),pad=T)
	if(is.null(reValue))return()
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Start to merge data packages from ",reValue[1]," to ",reValue[2],"\t",date(),"\n"))
	new_pkg<-reValue[1]
	if(!file.exists(new_pkg)) stop("selected file does not exist\n")
	src_pkgs<-reValue[2]
	inc<-F
	if(reValue[3]=="YES") inc<-T
	merge_Packages(src_pkgs,new_pkg,inc)
	tcgaPackage_folder<<-src_pkgs
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Finished. ",date(),"\n"))
}
GBM.6_lvl3_0227<-function(){
	setwd("C:\\tcga\\jhu-usc.edu_GBM.HumanMethylation27.6.0.0")
	lvl2<-read.delim("jhu-usc.edu_GBM.HumanMethylation27.6.lvl-2.TCGA-07-0227-20A-01D-0595-05.txt",sep="\t",header=T,skip=1)
	lvl3<-read.delim("jhu-usc.edu_GBM.HumanMethylation27.6.lvl-3.TCGA-14-1458-01A-01D-0595-05.txt",sep="\t",header=T,skip=1)
	lvl3.mask<-ifelse(is.na(lvl3[,2]),NA,1)
	lvl3.dat<-lvl2[,2]*lvl3.mask
	lvl3[,2]<-lvl3.dat
	write.table(lvl3,file="jhu-usc.edu_GBM.HumanMethylation27.6.lvl-3.TCGA-07-0227-20A-01D-0595-05.txt",sep="\t",row.names=F,quote=F)

}
GBM.7_sdrf<-function(){
	setwd("C:\\tcga\\jhu-usc.edu_GBM.HumanMethylation27.7\\jhu-usc.edu_GBM.HumanMethylation27.Level_1.7.0.0")
	flist<-list.files(pattern=".txt")
	flist<-flist[-49]
	sid<-sapply(flist,function(x)strsplit(x,"lvl-1")[[1]][2])
	sids<-sapply(sid,function(x)strsplit(x,"\\.")[[1]][2])
	create_Mage_TAB_SDRF(pkg_folder,manifest_fd)
}
GBM.8_lvl_1<-function(){
	setwd("C:\\tcga\\jhu-usc.edu_GBM.HumanMethylation27.8\\jhu-usc.edu_GBM.HumanMethylation27.Level_1.8.0.0")
	flist<-list.files(pattern=".txt")
	#flist<-flist[-c("DESCRIPTION.txt","MANIFEST.txt")]
	flist<-flist[c(-1,-32)]
	for(i in 1:length(flist)){
		dat<-read.delim(flist[i],header=T,sep="\t",check.names=F)
		dat<-dat[,c(-3,-4,-6,-7)]
		write.table(dat,file=flist[i],sep="\t",quote=F,row.names=F)
	}
}

update_lvl3_mask<-function(){
	data.dir<-"c:\\tcga"
	setwd(data.dir)
	lvl3msk.fn<-"level3_mask_May25.csv"
	lvl3msk<-read.delim(file=lvl3msk.fn,header=T,row.names=1,sep=",",as.is=T)
	library(mAnnot)
	db<-getData()
	gs<-as.character(humanMeth27k$Symbol)
	names(gs)<-humanMeth27k[,1]
	lvl3msk.new<-merge(lvl3msk,gs,by.x=0,by.y=0)
	lvl3msk.new$SYMBOL <-lvl3msk.new$y
	write.table(lvl3msk.new,file="level3_mask1.csv",quote=F,row.names=F,sep=",")
}
create_lvl1_data_pkg<-function(srcFolder,pkgFolder,descriptFn=NULL,pkgName){
	pkgFolder<-file.path(pkgFolder,pkgName)
	if(!file.exists(pkgFolder)) dir.create(pkgFolder)
	flists<-list.files(srcFolder,pattern=".txt")
	flists<-flists[grep("lvl-1",flists)]
	if(!is.null(descriptFn) & file.exists(descriptFn)){
		options(warn=-1)
		write(readLines(descriptFn),file.path(pkgFolder,"DESCRIPTION.txt"))
		options(warn=1)
	}
	for(fn in flists){
		dat<-readLines(file.path(srcFolder,fn))
		write(dat,file.path(pkgFolder,fn))
	}
}
create_lvl2_data_pkg_test<-function(){
	pvalue_fn<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\TCGA Batch 38 Data Package\\TCGA Batch 38 P-values.xls"
	lvl1Folder<-"C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.8\\jhu-usc.edu_GBM.HumanMethylation27.Level_1.8.0.0"
	lvl2Folder<-"c:\\temp\\test"
	create_lvl2_data_pkg(lvl1Folder,pvalue_fn,lvl2Folder)
}
create_lvl2_data_pkg.2<-function(lvl1Folder,lvl2Folder,descriptFn,pvalue_fn=NULL,threshold=0.05){
	if(!file.exists(lvl2Folder)) dir.create(lvl2Folder)
	if(!is.null(pvalue_fn) ){
		create_lvl2_data_pkg(lvl1Folder,lvl2Folder,pvalue_fn,threshold)
	}else{
		flists<-list.files(lvl1Folder,pattern=".txt")
		flists<-flists[grep("usc.edu",flists)]
		flists<-flists[grep("lvl-2",flists)]
		for(fn in flists){
			dat<-readLines(file.path(lvl1Folder,fn))
			write(dat,file.path(lvl2Folder,fn))
		}
	}
	if(file.exists(descriptFn)){
		options(warn=-1)
		write(readLines(descriptFn),file.path(lvl2Folder,"DESCRIPTION.txt"))
		options(warn=1)
	}
}
create_lvl2_data_pkg<-function(lvl1Folder,lvl2Folder,pvalue_fn,threshold=0.05){
	pvalue<-readDataFile.2(pvalue_fn)
	index<-row.names(pvalue)
	nn<-names(pvalue)
	flists<-list.files(lvl1Folder,pattern=".txt")
	flists<-flists[grep("usc.edu",flists)]
	if(!file.exists(lvl2Folder)) dir.create(lvl2Folder)
	for( fn in flists){
		cat(fn,"\n")
		sid<-strsplit(fn,"lvl-1")[[1]][2]
		sid<-strsplit(sid,"\\.")[[1]][2]
		hd1<-paste("Hybridization REF",sid,sid,sid,sep="\t")
		hd2<-c("Composite Element REF\tBeta_Value\tMethylated_Signal_Intensity (M)\tUn-Methylated_Signal_Intensity (U)")
		if(sum(nn==sid)==0){
			stop(paste("Pvalue Files does not contain the sample ",sid,"\n"))
		}
		pv<-pvalue[,sid]
		lvl_2_mask<-ifelse(pv<threshold,1,NA) #checked 
		dat.lvl1<-readDataFile.2(file.path(lvl1Folder,fn),header1=F,isNum=F)
		hd<-(dat.lvl1[2,])
		dat.lvl1<-dat.lvl1[c(-1,-2),]
#		pid<-dat.lvl1[1,]
#		row.names(dat.lvl1)<-pid
		dat.lvl1<-dat.lvl1[index,]
		
		M<-as.numeric(dat.lvl1[,1])
		#U<-as.numeric(dat.lvl1[,grep("(U)",hd)])
		U<-as.numeric(dat.lvl1[,4])
		beta1<-M/(M+U)*lvl_2_mask
		dat.lvl2<-data.frame(rownames(dat.lvl1),beta1,M,U)
		fn_lvl2<-gsub("lvl-1","lvl-2",fn)
		write(hd1,file=file.path(lvl2Folder,fn_lvl2))
		write(hd2,file=file.path(lvl2Folder,fn_lvl2),append=T)
		write.table(dat.lvl2,file=file.path(lvl2Folder,fn_lvl2),quote=F,row.names=F,col.names=F,append=T)
	}
}
create_lvl3_data<-function(lvl2Folder,lvl3Folder){
	require(methPipe)
	print(data(lvl3mask))
	ind<-order(row.names(lvl3mask))
	flist<-list.files(lvl2Folder)
	flist<-flist[grep("usc.edu",flist)]
	flist<-flist[grep("lvl-2",flist)]
	hd2<-"Composite Element REF\tBeta_Value\tGene_Symbol\tChromosome\tGenomic_Coordinate"
	for(fn in flist){
		cat(fn,"\n")
		dat<-read.table(file=file.path(lvl2Folder,fn),header=F,sep="\t",as.is=T)
		hd1<-dat[1,]
		sid<-as.character(hd1[1,2])
		hd1<-paste("Hybridization REF",sid,sid,sid,sid,sep="\t")
		dat<-dat[c(-1,-2),]
		dat<-dat[ind,]
		dat.lvl3<-as.numeric(ifelse(lvl3mask$mask_lvl3==0,dat[,2],NA))
		dat.lvl3<-data.frame(pid=dat[,1],Beta_Value=dat.lvl3,gs=lvl3mask$SYMBOL,chr=lvl3mask$Chr,coord=lvl3mask$MapInfo)
		#names(dat.lvl3)<-hd2
		fn_lvl3<-gsub("lvl-2","lvl-3",fn)
		write(hd1,file=file.path(lvl3Folder,fn_lvl3))
		write(hd2,file=file.path(lvl3Folder,fn_lvl3),append=T)
		write.table(dat.lvl3,file=file.path(lvl3Folder,fn_lvl3),row.names=F,col.names=F,quote=F,append=T,sep="\t")
	}
}
update_lvl3_data_run<-function(){
	#READ
	dataFolder.READ<-c("")
	update_lvl3_data(dataFolder.READ)
	#GBM
	dataFolder.GBM<-c("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.6\\jhu-usc.edu_GBM.HumanMethylation27.Level_3.6.0.0")
	dataFolder.GBM<-c("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.8\\jhu-usc.edu_GBM.HumanMethylation27.Level_3.8.0.0")
	
	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.1","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.9.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.1","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.9.0")
	dataFolder.GBM<-c("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.1\\jhu-usc.edu_GBM.HumanMethylation27.Level_3.1.2.0")
	create_lvl3_data("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.1\\jhu-usc.edu_GBM.HumanMethylation27.Level_2.1.2.0","C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.1\\jhu-usc.edu_GBM.HumanMethylation27.Level_3.1.3.0")
	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.1","jhu-usc.edu_GBM.HumanMethylation27.Level_3.1.3.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.1","jhu-usc.edu_GBM.HumanMethylation27.Level_3.1.3.0")
	pkg_validate("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.1")
	merge_Packages("c:\\tcga\\GBM","C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.1")
	
	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.2","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.10.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.2","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.10.0")
	
	
	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.3","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.10.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.3","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.10.0")
	
	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.4","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.10.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.4","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.10.0")
	
	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.5","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.10.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.5","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.10.0")
	
	update_lvl3_data(dataFolder.GBM)
	#LUSC
	dataFolder.LUSC<-c("C:\\tcga\\jhu-usc.edu_LUSC.HumanMethylation27.2\\jhu-usc.edu_LUSC.HumanMethylation27.Level_3.2.0.0")
	update_lvl3_data(dataFolder.LUSC)
	dataFolder.OV<-c("C:\\tcga\\jhu-usc.edu_OV.HumanMethylation27.10\\jhu-usc.edu_OV.HumanMethylation27.Level_3.10.0.0",
			"C:\\tcga\\jhu-usc.edu_OV.HumanMethylation27.10\\jhu-usc.edu_OV.HumanMethylation27.Level_3.10.0.0")
	#OV
	dataFolder.OV<-c("C:\\tcga\\jhu-usc.edu_OV.HumanMethylation27.11\\jhu-usc.edu_OV.HumanMethylation27.Level_3.11.0.0")
	dataFolder.OV<-c("C:\\tcga\\repos\\jhu-usc.edu_OV.HumanMethylation27.12\\jhu-usc.edu_OV.HumanMethylation27.Level_3.12.1.0")
	update_lvl3_data(dataFolder.OV)
	#LUSC
	dataFolder.LUSC<-c("C:\\tcga\\LUSC\\bk\\jhu-usc.edu_LUSC.HumanMethylation27.1\\jhu-usc.edu_LUSC.HumanMethylation27.Level_3.1.2.0")
	update_lvl3_data(dataFolder.LUSC)
	#COAD
	dataFolder<-c("C:\\tcga\\repos\\jhu-usc.edu_COAD.HumanMethylation27.2\\jhu-usc.edu_COAD.HumanMethylation27.Level_3.2.1.0",
			"C:\\tcga\\repos\\jhu-usc.edu_COAD.HumanMethylation27.5\\jhu-usc.edu_COAD.HumanMethylation27.Level_3.5.1.0")
	update_lvl3_data(dataFolder)
}
update_lvl3_data<-function(dataFolder=NULL){
	require(mAnnot)
	db<-getData()
	gs<-as.character(humanMeth27k$Symbol)
	names(gs)<-humanMeth27k[,1]
	if(is.null(dataFolder)){
	dataFolder<-c("C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.1\\jhu-usc.edu_COAD.HumanMethylation27.Level_3.1.0.0",
			"C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.2\\jhu-usc.edu_COAD.HumanMethylation27.Level_3.2.0.0",
			"C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.3\\jhu-usc.edu_COAD.HumanMethylation27.Level_3.3.0.0",
			"C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.4\\jhu-usc.edu_COAD.HumanMethylation27.Level_3.4.0.0",
			"C:\\tcga\\jhu-usc.edu_COAD.HumanMethylation27.5\\jhu-usc.edu_COAD.HumanMethylation27.Level_3.5.0.0"
			)
		}
	for(i in 1:length(dataFolder)){
		setwd(dataFolder[i])
		flist<-list.files(pattern="lvl-3");
		for(j in 1:length(flist)){
			dat<-read.delim(file=flist[j],header=F,sep="\t",row.names=1,as.is=T)
			header1<-dat[1,]
			header2<-dat[2,]
			dat<-dat[c(-1,-2),]
			ind<-names(gs)
			dat<-dat[ind,]
			dat$V3<-gs
			#dat[ind,3]<-gs
			write.table(header1,file=flist[j],row.names=T,sep="\t",col.names=F,quote=F)
			write.table(header2,file=flist[j],row.names=T,sep="\t",append=T,col.names=F,quote=F)
			write.table(dat,file=flist[j],row.names=T,sep="\t",append=T,col.names=F,quote=F)
		}
	}
	require(tcltk)
	for(i in 1:length(dataFolder)){
		fd<-tclvalue(tclfile.tail(dataFolder[i]))
		pkg_folder<-tclvalue(tclfile.dir(dataFolder[i]))
		createManifestByLevel.2(pkg_folder,fd)
		compressDataPackage(pkg_folder,fd)
	}
}

create_IDF_file_run<-function(){
	fn<-"jhu-usc.edu_KIRC.HumanMethylation27.1.0.0"
	md<-"c:\\temp"
	ct<-"Kidney Renal Cell Carcinoma"
	create_IDF_file(fn,md,ct)
	fn<-"jhu-usc.edu_LUAD.HumanMethylation27.1.0.0"
	ct<-"Lung Adenocarcinoma"
	create_IDF_file(fn,md,ct)
}
getSampleID<-function(dataFolder){
	setwd(dataFolder)
	flist<-list.files(pattern="lvl-1")
	sid<-sapply(flist,function(x)strsplit(x,"lvl-1")[[1]][2])
	sid<-sapply(sid,function(x)strsplit(x,"\\.")[[1]][2])
}
##############
# June 9
#############
pkg_lvl_1_filter_run<-function(){
	sourceDir<-"C:\\tcga\\jhu-usc.edu_OV.HumanMethylation27.9.0.0"
	destDir<-"C:\\tcga\\jhu-usc.edu_OV.HumanMethylation27.9\\jhu-usc.edu_OV.HumanMethylation27.Level_1.9.0.0"
	pkg_lvl_1_filter(sourceDir,destDir)
	
	sourceDir<-"C:\\tcga\\GBM\\va\\jhu-usc.edu_GBM.HumanMethylaiton27.8.0.0"
	destDir<-"C:\\tcga\\GBM\\va\\jhu-usc.edu_GBM.HumanMethylation27.Level_1.8.0.0"
	destDir<-"C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.7\\jhu-usc.edu_GBM.HumanMethylation27.Level_1.7.0.0"
	pkg_lvl_1_filter(destDir)
	update_pkg_compression(destDir)
}
update_pkg_compression<-function(dir1){
	require(tcltk)
	pkgFolder<-tclvalue(tclfile.dir(dir1))
	lvl<-tclvalue(tclfile.tail(dir1))
	createManifestByLevel.2(pkgFolder,lvl)
	compressDataPackage(pkgFolder,lvl)
}
pkg_lvl_1_filter<-function(sourceDir, destDir=NULL){
	if(is.null(destDir)) destDir=sourceDir
	setwd(sourceDir)
	flist<-list.files(pattern="lvl-1")
	for(i in 1:length(flist)){
		dat<-read.delim(file=flist[i],sep="\t",header=F,as.is=T,row.names=1)
		names(dat)<-dat[2,]
#		col.new<-c("U_Number_Beads", "Negative_Control_Grn_STDERR", 
#				"Negative_Control_Red_STDERR", "U_STDERR", "M_Number_Beads", 
#				"Un-Methylated_Signal_Intensity (U)", "M_STDERR", 
#				"Negative_Control_Grn_Avg_Intensity", "Methylated_Signal_Intensity (M)", 
#				"Negative_Control_Red_Avg_Intensity", "Detection_P_Value")
		col.new<-c("Methylated_Signal_Intensity (M)","Un-Methylated_Signal_Intensity (U)","Detection_P_Value","Negative_Control_Red_Avg_Intensity","Negative_Control_Grn_Avg_Intensity","Negative_Control_Grn_STDERR","Negative_Control_Red_STDERR")
		dat.new<-dat[,col.new]
		write.table(dat.new,file=file.path(destDir,flist[i]),row.names=T,col.names=F,quote=F,sep="\t")
	}
}

#################
# June 10
################
pkg_validate_run<-function(){
	pkgFolder<-"C:\\tcga\\jhu-usc.edu_KIRC.HumanMethylation27.1"
	pkgFolder<-"C:\\tcga\\repos\\jhu-usc.edu_OV.HumanMethylation27.9"
	pkgFolder<-"C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.8"
	pkgFolder<-"C:\\tcga\\repos\\jhu-usc.edu_GBM.HumanMethylation27.6"
	pkgFolder<-"C:\\tcga\\repos\\jhu-usc.edu_KIRC.HumanMethylation27.1"
	pkg_validate(pkgFolder)
}
pkg_validate<-function(pkgFolder){
	setwd(pkgFolder)
	#idf
	dlist<-list.files(pattern="mage-tab")
	dlist<-dlist[-grep("tar",dlist)]
	sid<-NULL
	for(i in 1:length(dlist)){
		setwd(file.path(pkgFolder,dlist[i]))
		pkgType<-strsplit(strsplit(dlist[i],"_")[[1]][2],"\\.")[[1]][1]
		flist<-list.files(pattern="idf")
		idf<-readLines(flist)
		sdrf.fn<-list.files(pattern="sdrf")
		idf.sdrf<-idf[grep("SDRF Files",idf)]
		isdrf<-strsplit(idf.sdrf,"\t")[[1]][2]
		cat(paste("SDRF Files in IDF files is ",isdrf," \n",sep=""))
		if(isdrf!=sdrf.fn){
			cat("sdrf")
			stop("")
		}
		idf.ov<-grep("ovarian",idf)
		if(length(idf.ov)!=0){
			cat("It's a ovarian data package\n")
			if(pkgType!="OV"){
				stop("it's not a OV pkg\n");
			}
		}
		
		idf.type<-grep(pkgType,idf)
		if(length(idf.type)==0){
			cat(paste(pkgType,"is missing in idf file\n"),sep="")
			stop("")
		}
		#adf
		flist<-list.files(pattern="adf")
		adf<-read.delim(flist,sep="\t",header=T,row.names=1)
		if(adf["cg00763679",1]!="SEPT2"){
			stop("cg00763679\n")
		}
		if(adf["cg00720072",1]!="MARCH5"){
			stop("cg00720072\n")
		}
		if(nrow(adf)!=27578){
			stop("number of adf \n")
		}
		#sdrf
		sdrf<-read.delim(sdrf.fn,sep="\t",skip=1,header=F)
		sid<-sdrf[,1]
		cat(paste("number of total sid in sdrf is: ",length(sid),"\n",sep=""))
	}
	checkDP<-function(lvl,dir1,sid.1){
		#DESCRIPTION
		dp<-readLines("DESCRIPTION.txt")
#		dp1<-dp[grep["HumanMethylation27",dp]]
#		if(!is.null(dp1)){
#			pkn<-strsplit(dp1,"archive")[[1]][2]
#			cat(paste("pkg name in description is: ",pkn,"\n",sep=""))
#			arch.num<-strsplit(dir1,lvl)[[1]][2]
#			arch.num.1<-strsplit(dp[1],"HumanMethylation27")[[1]][2]
#			if(arch.num!=arch.num.1){
#				stop("archive number of pkg does not match the archive number described in description file\n")
#			}
#		}
		s0227<-0
		sidl<-NULL
		#ind<-grep("TCGA-07-0227-20A",dp)
		ind<-grep("normal",dp)
		if(length(ind)!=0){
			sidl<-dp[ind]
			s0227<-1
			sidl<-strsplit(sidl,"normal")[[1]][1] #"TCGA-07-0227-20A")[[1]][1]
		}else{
			sidl<-dp[grep("archive contains",dp)]
			sidl<-strsplit(sidl,"Batch")[[1]][1]
		}
		
		sidl<-unlist(strsplit(sidl," "))
		sid.num<-c()
		for(i in 1:length(sidl)){
			options(warn=-1)
			sid.n<-as.numeric(sidl[i])
			options(warn=1)
			if(!is.na(sid.n) & sidl[i]==as.character(sid.n)){
				sid.num<-c(sid.num,sid.n)
			}
		}
		sid.total<-sum(sid.num)+s0227
		if(sid.total!=length(sid.1)){
			stop(paste("sid numbers in description of ",lvl,"is ",length(sid.1),", does not match the total number sids ",sid.total,".\n",sep=""))
		}	
	}
	checkLevel<-function(lvl){
		lvl.fn<-paste("lvl-",strsplit(lvl,"_")[[1]][2],sep="")
		setwd(pkgFolder)
		dlist<-list.files(pattern=lvl)
		dlist<-dlist[-grep("tar",dlist)]
		for(i in 1:length(dlist)){
			setwd(file.path(pkgFolder,dlist[i]))
			flist<-list.files(pattern="lvl")
			sid.1<-sapply(flist,function(x)strsplit(strsplit(x,lvl.fn)[[1]][2],"\\.")[[1]][2])
			if(length(sid[sid.1])!=length(sid.1)){
				stop(paste("sid in ",lvl," is not all included in sdrf sids\n",sep=""))
			}
			dat<-readLines(flist[1])
			if(length(dat)!=27580){
				stop(paste("rnow in ",lvl," is not 27580\n",sep=""))
			}
			if(lvl=="Level_3"){
				dat<-read.delim(flist[1],header=T,row.name=1,sep="\t")
				if(dat["cg00720072",2]!="MARCH5"){
					stop("cg00720072 in lvl3 is not MARCH5\n")
				}
			}
			if(file.exists("DESCRIPTION.txt"))checkDP(lvl,dlist[i],sid.1)
		}
	}
	#lvl_1
	checkLevel("Level_1")
	#lvl_2
	checkLevel("Level_2")
	#lvl_3
	checkLevel("Level_3")
	cat("> post-validation checking is done.\n")
}
rename_pkg_files<-function(){
	pkgFolder<-"C:\\tcga\\repos\\jhu-usc.edu_KIRC.HumanMethylation27.1.0.0"
	setwd(pkgFolder)
	flist<-list.files(pattern="lvl")
	for(i in 1:length(flist)){
		dat<-readLines(flist[i])
		dat<-sapply(dat,function(x)paste(x,"\n",sep=""))
		fn<-gsub("KIRC","KIRP",flist[i])
		zz<-file(fn)
		cat(dat,file=zz)
		close(zz)
	}
}

#################
# Sep 17, 2010
#################
pkg_Level3_data_run<-function(){
	outdir<-"c:\\tcga\\repos\\lvlJune18"
	data.dir<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\UPDATED LEVEL 3 AND README FOR TCGA GBM-OV DATA PACKAGES"
	setwd(data.dir)
	dlist<-list.files()
	for(i in 1:length(dlist)){
		setwd(file.path(data.dir,dlist[i]))
		fn<-list.files(pattern=".csv")
		pkgName<-substr(fn,1,(nchar(fn)-4))
		pkg_Level3_data(fn,outdir,pkgName,ftype="csv")
		setwd(file.path(data.dir,dlist[i]))
		fn2<-list.files(pattern=".txt")
		descript<-readLines(fn2)
		ind<-c(grep("LEVEL 1",descript),grep("LEVEL 2",descript))
		descript<-descript[-ind]
		fn.descript<-file.path(outdir,pkgName,"DESCRIPTION.txt")
		write.table(data.frame(descript),fn.descript,row.names=F,quote=F,col.names=F)
	}
	for(i in 1:length(dlist)){
		setwd(file.path(data.dir,dlist[i]))
		fn<-list.files(pattern=".csv")
		pkgName<-substr(fn,1,(nchar(fn)-4))
		createManifestByLevel.2(outdir,pkgName)
		compressDataPackage(outdir,pkgName)
	}
}

pkg_Level3_data<-function(fn,outdir,pkgName,ttype=NULL,version=NULL,ftype=""){
	require(gdata)
	dat<-NULL
	if(ftype=="csv"){
		dat<-read.delim(fn,header=T,as.is=T,row.names=1,sep=",")
	}else{
		dat<-read.xls(fn,header=T,as.is=T,check.names=T,skip=0,row.names=1)
	}
	dat<-dat[-1,]
	names(dat)<-gsub("\\.","-",names(dat))
	cat(paste("The size of the file is: ",nrow(dat),"x",ncol(dat),"\n"))
	gs<-dat[,1]
	chr<-dat[,2]
	coord<-dat[,3]
	dat<-dat[,c(-1,-2,-3)]
	setwd(outdir)
	dir.create(pkgName)
	setwd(pkgName)
	sid<-names(dat)
	ttype<-strsplit(strsplit(pkgName,"_")[[1]][2],"\\.")[[1]][1]
	sn<-strsplit(strsplit(pkgName,"_")[[1]][3],"\\.")[[1]][2]
	fileNames<-paste("jhu-usc.edu_",ttype,".HumanMethylation27.",sn,".lvl-3.",sid,".txt",sep="")
	hd2<-c("Composite Element REF","Beta_Value","Gene_Symbol","Chromosome","Genomic_Coordinate")
	for(i in 1:ncol(dat)){
		dat.lvl3<-data.frame(row.names(dat), dat[,i],gs,chr,coord)
		header<-c("Hybridization REF",sid[i],sid[i],sid[i],sid[i])
		write.table(t(data.frame(header)),file=fileNames[i],sep="\t",col.names=F,row.names=F,quote=F)
		write.table(t(data.frame(hd2)),file=fileNames[i],sep="\t",col.names=F,row.names=F,quote=F,append=T)
		write.table(dat.lvl3,file=fileNames[i],sep="\t",col.names=F,row.names=F,quote=F,append=T)
	}
}

update_Mage_tab_file_run<-function(){
	update_Mage_tab_file("C:\\tcga\\GBM\\jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.9.0\\jhu-usc.edu_GBM.HumanMethylation27.8.sdrf.txt","jhu-usc.edu_GBM.HumanMethylation27.Level_3.6.0.0","jhu-usc.edu_GBM.HumanMethylation27.Level_3.6.1.0")
	createManifestByLevel.2("c:\\tcga\\GBM","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.9.0")
	compressDataPackage("c:\\tcga\\GBM","jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.9.0")
	
	update_Mage_tab_file("C:\\tcga\\LUSC\\jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.6.0\\jhu-usc.edu_LUSC.HumanMethylation27.2.sdrf.txt","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.1.2.0","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.1.3.0")
	createManifestByLevel.2("c:\\tcga\\LUSC","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.6.0")
	compressDataPackage("c:\\tcga\\LUSC","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.6.0")
	for(i in 7:8){
		update_Mage_tab_file("c:\\tcga\\OV\\jhu-usc.edu_OV.HumanMethylation27.mage-tab.1.3.0\\jhu-usc.edu_OV.HumanMethylation27.2.sdrf.txt",paste("jhu-usc.edu_OV.HumanMethylation27.Level_3.",i,".1.0",sep=""),paste("jhu-usc.edu_OV.HumanMethylation27.Level_3.",i,".2.0",sep=""))
	}
	for(i in 9:11){
		update_Mage_tab_file("c:\\tcga\\OV\\jhu-usc.edu_OV.HumanMethylation27.mage-tab.1.3.0\\jhu-usc.edu_OV.HumanMethylation27.2.sdrf.txt",paste("jhu-usc.edu_OV.HumanMethylation27.Level_3.",i,".0.0",sep=""),paste("jhu-usc.edu_OV.HumanMethylation27.Level_3.",i,".1.0",sep=""))
	}
	createManifestByLevel.2("c:\\tcga\\OV","jhu-usc.edu_OV.HumanMethylation27.mage-tab.1.3.0")
	compressDataPackage("c:\\tcga\\OV","jhu-usc.edu_OV.HumanMethylation27.mage-tab.1.3.0")
}
update_Mage_tab_file<-function(mfn,pkg_old,pkg_new){
	dat<-read.delim(mfn,header=F,sep="\t")
	dat<-apply(dat,1,function(x)gsub(pkg_old,pkg_new,x))
	write.table(t(dat),file=mfn,row.names=F,col.names=F,sep="\t",quote=F)
}
gsub_files_run<-function(){
	gsub_files("Beta Value","Beta_Value","C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.1\\jhu-usc.edu_LUSC.HumanMethylation27.Level_3.1.3.0")
	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.1","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.1.3.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.1","jhu-usc.edu_LUSC.HumanMethylation27.Level_3.1.3.0")
	createManifestByLevel.2("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.1","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.1.0")
	compressDataPackage("C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.1","jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.1.0")
	
	gsub_files("Beta_Value","Beta Value","C:\\tcga\\LUSC\\jhu-usc.edu_LUSC.HumanMethylation27.Level_3.1.3.0")
	gsub_files("Beta_Value","Beta Value","C:\\tcga\\LUSC\\jhu-usc.edu_LUSC.HumanMethylation27.Level_3.2.1.0")
	pkg<-"jhu-usc.edu_LUSC.HumanMethylation27.Level_3.2.2.0"
	pkg<-"jhu-usc.edu_LUSC.HumanMethylation27.Level_3.1.3.0"
	pkgFolder<-"c:\\tcga\\LUSC"

	pkg<-"jhu-usc.edu_LUSC.HumanMethylation27.mage-tab.1.6.0"
	
	
	#LUSC
	pkgFolder<-"C:\\tcga\\repos\\jhu-usc.edu_LUSC.HumanMethylation27.1"
	pkg<-"jhu-usc.edu_LUSC.HumanMethylation27.Level_2.1.3.0"
	pkg<-"jhu-usc.edu_LUSC.HumanMethylation27.Level_1.1.3.0"
	
	#GBM
	pkgFolder<-"C:\\tcga\\GBM\\"
	
	gsub_files("Beta Value","Beta_Value",paste(pkgFolder,pkg,sep=""))
	createManifestByLevel.2(pkgFolder,pkg)
	compressDataPackage(pkgFolder,pkg)
	
	pkg<-"jhu-usc.edu_GBM.HumanMethylation27.Level_3.6.0.0"
	pkg<-"jhu-usc.edu_GBM.HumanMethylation27.Level_2.6.0.0"
	pkg<-"jhu-usc.edu_GBM.HumanMethylation27.Level_1.6.0.0"
	pkg<-"jhu-usc.edu_GBM.HumanMethylation27.Level_3.8.0.0"
	pkg<-"jhu-usc.edu_GBM.HumanMethylation27.Level_2.8.0.0"
	pkg<-"jhu-usc.edu_GBM.HumanMethylation27.Level_1.8.0.0"
	pkg<-"jhu-usc.edu_GBM.HumanMethylation27.Level_1.7.1.0"
	pkg<-"jhu-usc.edu_GBM.HumanMethylation27.mage-tab.1.9.0"

	#OV
	pkgFolder<-"C:\\tcga\\OV\\test\\"
	pkg<-"jhu-usc.edu_OV.HumanMethylation27.mage-tab.1.3.0"
	pkg<-"jhu-usc.edu_OV.HumanMethylation27.Level_3.7.2.0"
	gsub_files("-563-","-0563-","C:\\tcga\\OV\\test\\jhu-usc.edu_OV.HumanMethylation27.Level_3.7.2.0")
	pkg<-"jhu-usc.edu_OV.HumanMethylation27.Level_3.11.1.0"
	pkg<-"jhu-usc.edu_OV.HumanMethylation27.Level_3.10.0.0"
	pkg<-"jhu-usc.edu_OV.HumanMethylation27.Level_3.9.0.0"
	pkg<-"jhu-usc.edu_OV.HumanMethylation27.Level_3.8.2.0"
	pkg<-"jhu-usc.edu_OV.HumanMethylation27.Level_3.7.2.0"
	
}
gsub_files<-function(src,target,folder){
	setwd(folder)
	flist<-list.files()
	for(i in 1:length(flist)){
		dat<-readLines(flist[i])
		dat.new<-gsub(src,target,dat)
		dat.new<-paste(dat.new,"\n",sep="")
		zz<-file(flist[i])
		cat(dat.new,file=zz,sep="")
		close(zz)
	}
}
####################
# June 25
######################
rename_files_run<-function(){
	folder<-"C:\\tcga\\OV\\test\\jhu-usc.edu_OV.HumanMethylation27.Level_3.7.2.0"
	rename_files(folder,"563","0563")
}
rename_files<-function(folder,src,target){
	setwd(folder)
	flist<-list.files()
	for(i in 1:length(flist)){
		name.new<-gsub(src,target,flist[i])
		file.rename(flist[i],name.new)
	}
}

###########################
#########################
ViewPkgManifest<-function(txt=NULL){
	dlg<-startDialog("Package Manifest")
	dlg1<-tkfrm(dlg)
	addTextEntryWidget(dlg1,"Select the Package Manifest:","c:/tcga/package.txt",isFolder=F,name=pkgManifest)
	tkaddfrm(dlg,dlg1)
	endDialog(dlg,c("pkgManifest"))
	if(is.null(reValue))return()
	dat<-read.table(file=reValue[1],sep="\t",header=F)
	openTableView(dat)
}
openTableView_test<-function(){
	dat<-matrix(1:9,nrow=3)
	openTableView(dat)
}
openTableView<-function(dat=NULL){
	tclRequire("Tktable")
	datCol<-ncol(dat)
	datRow<-nrow(dat)
	datVar<-NULL
	for(i in 0:(datCol-1)){
		for(j in 0:(datRow-1)){
			.Tcl(paste("set datVar(",i,",",j,") ",dat[i+1,j+1],sep=""))
		}
	}
	t1<-startDialog("Package Manifest")
	tkgrid(tklabel(t1,text="Package Manifest"))
	tlable<-tkwidget(t1,"table",variable="datVar",cols=datCol,rows=datRow,titlerows="1",colwidth="25",selectmode="extended",background="white")
	tkgrid(tlable)
	endDialog(t1,pad=F,pack=T)
}
openTableView.2<-function(dat=NULL,maxRow=25){
	tclRequire("Tktable")
	datCol<-ncol(dat)
	datRow<-nrow(dat)
	if(datRow>(maxRow-1)) { datRow<-maxRow }
	else { maxRow<-datRow }
	datVar<-NULL
	setDatVar<-function(curRowPos=0){
		dat1<-dat[(curRowPos+1):(curRowPos+maxRow),]
		dat1[1,]<-dat[1,]
		for(i in 0:(datCol-1)){
			for(j in curRowPos:(curRowPos+maxRow)){
				.Tcl(paste("set datVar(",i,",",j,") ",dat1[i+1,j+1],sep=""))
			}
		}
	}
	setDatVar()
	t1<-startDialog("Package Manifest")
	tkgrid(tklabel(t1,text=" "),tklabel(t1,text="Package Manifest"))
	tlable<-tkwidget(t1,"table",variable="datVar",cols=datCol,rows=datRow,titlerows="1",colwidth="25",selectmode="extended",background="white")
	tkgrid(tklabel(t1,text=" "),tlable,tklabel(t1,text=" "))
	tkgrid(tklabel(t1,text=" "))
	nextPage<-function(){
		curRowPos<-curRowPos + maxRow
		if(curRowPos>nrow(dat)) curRowPos<-nrow(dat)
		setDatVar(curRowPos)
	}
	prePage<-function(){
		curRowPos<-curRowPos - maxRow
		if(curRowRow<0) curRowPos<-0
		setDatVar(curRowPos)
	}
	dlg1<-tkfrm(t1)
	nextButton<-tkbutton(dlg1,text="  Next  ",command=nextPage)
	preButton<-tkbutton(dlg1,text="Previous",command=prePage)
	tkgrid(nextButton,preButton)
	tkaddfrm(t1,dlg1)
	tkgrid(tklabel(t1,text=" "))
}
UpdatePkgManifest<-function(txt=NULL){
	if(!is.null(txt)) tkinsert(txt,"end",">Start to update the package manifest\n")
	dlg<-startDialog("Update Package Manifest")
	tkgrid(tklabel(dlg,text=" "))
	dlg1<-tkfrm(dlg)
	addTextEntryWidget(dlg1,"Select the Package Folder:","",name="pkgFolder")
	addTextEntryWidget(dlg1,"Select the Package Manifest:","c:/tcga/package.txt",isFolder=F,name="pkgManifest")
	tkaddfrm(dlg,dlg1)
	endDialog(dlg,c("pkgFolder","pkgManifest"))
	pkgFolder<-reValue[1]
	fn<-reValue[2]
	create_pkg_manifest(pkgFolder,txt,fn)
	if(!is.null(txt)) tkinsert(txt,"end",">Finished updating manifest")
}
###############################
# Nov 18
##############################
update_plat_manifest_test<-function(){
	arraysFn<-"c:\\tcga\\others\\raw_manifest.txt"
	pkgManifestFn<-"c:\\tcga\\others\\package.txt"
	batchManifestFn<-"c:\\tcga\\others\\batchManifest.txt"
	arrayMapFn<-"c:\\tcga\\others\\arraymapping\\sample_mapping.txt"
	reposPath<-"c:\\tcga"
	pkgFolder<-c("BRCA","COAD","GBM","KIRC","KIRP","LAML","LUAD","LUSC","OV","READ","STAD","UCEC")
	plateMapFn<-"c:\\tcga\\others\\platemap.txt"
	pm<-update_plate_manifest(reposPath,pkgFolder,pkgManifestFn,batchManifestFn,arrayMapFn,plateMapFn)
	dim(pm$bm)
#	[1] 2463    7
	names(pm$bm)
#	[1] "pkg"                     "sampleIDs"              
#	[3] "Batch_Number"            "Cancer_Type"            
#	[5] "Total_Sample_Number"     "Total_Ctr_Sample_Number"
#	[7] "Ctr_Sample_Name"        
	batchNumber<-unique(pm$bm[,"Batch_Number"])
	batchNumber[order(batchNumber)]
#	[1] "1"        "10"       "12"       "13"       "14"       "15"      
#	[7] "16"       "17"       "18"       "19"       "2"        "20"      
#	[13] "21"       "22"       "23"       "24"       "25"       "26"      
#	[19] "27"       "28"       "29"       "3"        "30"       "31"      
#	[25] "32"       "33"       "34"       "36"       "37"       "38"      
#	[31] "39"       "41"       "45"       "46"       "47"       "48"      
#	[37] "49"       "50"       "51"       "52"       "53"       "56"      
#	[43] "57"       "58"       "59"       "60"       "64"       "65"      
#	[49] "66"       "69"       "9 and 11"
	length(unique(pm$bm[,"sampleIDs"]))
#	[1] 2458
	ind<-duplicated(pm$bm[,"sampleIDs"])
	sample.dup<-pm$bm[ind,"sampleIDs"]
	ind2<-is.element(pm$bm[,"sampleIDs"],sample.dup)
	sampl.dups<-pm$bm[ind2,1:7]
	sampl.dups[order(sampl.dups[,"sampleIDs"]),]
#	pkg
#	189  jhu-usc.edu_COAD.HumanMethylation27.Level_1.1.0.0
#	2172 jhu-usc.edu_READ.HumanMethylation27.Level_1.1.0.0
#	228  jhu-usc.edu_COAD.HumanMethylation27.Level_1.2.1.0
#	2199 jhu-usc.edu_READ.HumanMethylation27.Level_1.2.0.0
#	244  jhu-usc.edu_COAD.HumanMethylation27.Level_1.3.0.0
#	2209 jhu-usc.edu_READ.HumanMethylation27.Level_1.3.0.0
#	262  jhu-usc.edu_COAD.HumanMethylation27.Level_1.4.0.0
#	2219 jhu-usc.edu_READ.HumanMethylation27.Level_1.4.0.0
#	263  jhu-usc.edu_COAD.HumanMethylation27.Level_1.5.2.0
#	2220 jhu-usc.edu_READ.HumanMethylation27.Level_1.5.0.0
#	sampleIDs Batch_Number Cancer_Type Total_Sample_Number
#	189  TCGA-07-0227-20A-01D-0820-05           28        COAD                  32
#	2172 TCGA-07-0227-20A-01D-0820-05           28        READ                  17
#	228  TCGA-AV-A03D-20A-01D-0825-05           29        COAD                   8
#	2199 TCGA-AV-A03D-20A-01D-0825-05           29        READ                  11
#	244  TCGA-AV-A03E-20A-01D-A004-05           30        COAD                  16
#	2209 TCGA-AV-A03E-20A-01D-A004-05           30        READ                  10
#	262  TCGA-AV-A03D-20A-01D-A00B-05           33        COAD                  18
#	2219 TCGA-AV-A03D-20A-01D-A00B-05           33        READ                  10
#	263  TCGA-07-0227-20A-01D-0904-05           36        COAD                  32
#	2220 TCGA-07-0227-20A-01D-0904-05           36        READ                   9
}
update_plate_manifest<-function(reposPath,pkgFolder,pkgManifestFn,arraysFn,batchManifestFn,arrayMapFn,plateMapFn,toValidate=T){
if(toValidate==T){
		for(pkg in pkgFolder) validatePkg(file.path(reposPath,pkg))
	}
	create_pkg_manifest.2a(reposPath,pkgFolder,pkgManifestFn)
	bm<-create_batch_manifest.2(pkgManifestFn,reposPath,batchManifestFn,pkgFolder)
	plateMap<-create_plate_manifest(batchManifestFn,arrayMapFn,plateMapFn)
	return(list(plateMap=plateMap,bm=bm))
}
create_plate_manifest_test<-function(){
	batchManifestFn<-"c:\\tcga\\batchManifest_meth27.txt"
	bm<-read.delim(file=batchManifestFn,sep="\t")
	dim(bm)
#	[1] 1740    6
	bm.dup<-bm[duplicated(bm[,1]),]
	dim(bm.dup)
#	[1] 5 6
	
	arrayMapFn<-"c:\\tcga\\others\\arraymapping\\sample_mapping.txt"
	ar<-read.delim(file=arrayMapFn,sep="\t",header=F)
	ind<-substr(ar[,3],1,4)=="TCGA"
	ar.tcga<-ar[ind,]
	dim(ar.tcga)
#	[1] 1385    3
	dim(ar.tcga)
	table(duplicated(ar.tcga[,3]))
#	FALSE  TRUE 
#	1267   118
	ar.tcga.unique<-ar.tcga[!duplicated(ar.tcga[,3]),]
	dim(ar.tcga.unique)
#	[1] 1267    3
	fn<-"c:\\tcga\\platemap.txt"
	pl<-create_plate_manifest(batchManifestFn,arrayMapFn,fn)
	dim(pl)
#	[1] 881   8
	length(unique(pl[,1]))
#	[1] 776
	
	ind<-is.element(ar.tcga.unique[,3],unique(pl[,1]))
	head(ar.tcga.unique[ind,])
#	288 5493991030  A TCGA-B6-A0IM-01A-11D-A032-05
#	289 5493991030  B TCGA-B6-A0I2-01A-11D-A032-05
#	290 5493991030  C TCGA-AO-A0J3-01A-11D-A032-05
#	291 5493991030  D TCGA-A8-A07G-01A-11D-A032-05
	ar.tcga.unique.ex<-ar.tcga.unique[!ind,]
	dim(ar.tcga.unique.ex)
#	[1] 491   3
	head(ar.tcga.unique.ex)
#	1 5543338058  A TCGA-BR-4371-11A-01D-1156-05
#	2 5543338058  B TCGA-BR-4369-01A-01D-1156-05
#	3 5543338058  C TCGA-CG-4472-01A-01D-1156-05
#	4 5543338058  D TCGA-BR-4366-11A-01D-1156-05
	unique(ar.tcga.unique.ex[,1])
#	[1] 5543338058 5543338036 5543338035 5543338034 5543338026 5543207082
#	[7] 5543207080 5543207078 5543207074 5543207073 5543207072 5543207071
#	[13] 5543207070 5543207066 5543207065 5543207063 5543207062 5543207061
#	[19] 5543207051 5543207049 5543207030 5543207029 5543207015 5543207013
#	[25] 5491110026 5491110017 5491110003 5491110002 5491110001 5471637028
#	[31] 5471514030 5471514029 5471514021 5471514020 5471514019 5471514012
#	[37] 5471514008 5471514003 5471514002 5471514001 5380348029 5333963048
#	[43] 5333963045 5333963040 5333963037 5333963031 5333963026 5333963025
#	[49] 5333963021 5333963004 5333963001 5330092045 5330092011 5316776011
#	[55] 4841860026
	ar.tcga.unique.ex[ar.tcga.unique.ex[,1]=="4841860026",]
#	3077 4841860026  G TCGA-30-1869-01A-01D-0652-05
}
create_plate_manifest<-function(batchManifestFn,arrayMapFn,fn=NULL){
	bm<-read.delim(file=batchManifestFn,sep="\t")
	ar<-read.delim(file=arrayMapFn,sep="\t",header=F)
	names(ar)<-c("chip_id","array","sample")
	pl<-merge(ar,bm,by.x=3,by.y=2)
	if(!is.null(fn)) write.table(pl,file=fn,sep="\t",row.names=F,quote=F)
	return(pl)
}
create_batch_manifest_test<-function(){
	tcgaRepos<-"c:\\tcga"
	bmFn<-"c:\\tcga\\batchManifest.txt"

	manifestFn<-"c:\\tcga\\package_all.txt"
	fdir<-c("BRCA","COAD","GBM","KIRC","LAML","LUAD","LUSC","OV","READ","GBM_OMA002","GBM_OMA003")
	batchManifest<-create_batch_manifest(manifestFn,tcgaRepos,bmFn,fdir)
	dim(batchManifest)
	#	[1] 2276    6	
	bmFn<-"c:\\tcga\\batchManifest_meth27.txt"
	manifestFn<-"c:\\tcga\\package_meth27.txt"
	fdir<-c("BRCA","COAD","GBM","KIRC","LAML","LUAD","LUSC","OV","READ")
	batchManifest<-create_batch_manifest(manifestFn,tcgaRepos,bmFn,fdir)
	dim(batchManifest)
#	[1] 1740    6 //meth27
	table(duplicated(batchManifest[,1]))
	batchManifest[duplicated(batchManifest[,1]),]
#	sample_id Batch_Number Cancer_Type Total_Sample_Number
#	1664  TCGA-07-0227-20A-01D-0820-05           28        READ                  17
#	16911 TCGA-AV-A03D-20A-01D-0825-05           29        READ                  11
#	17011 TCGA-AV-A03E-20A-01D-A004-05           30        READ                  10
#	17111 TCGA-AV-A03D-20A-01D-A00B-05           33        READ                  10
#	1712  TCGA-07-0227-20A-01D-0904-05           36        READ                   9
}

create_batch_manifest.2<-function(manifestFn,tcgaRepos,bmFn=NULL,fdir=NULL){
	if(is.null(fdir)){
		fdir<-list.files(tcgaRepos)
		fdir<-fdir[-which(fdir=="repos")]
	}
	manifest<-read.delim(file=manifestFn,sep="\t",as.is=T)
	manifest<-manifest[grep("Level_1",manifest[,1]),]
	batchManifest<-NULL
	for(fd in fdir){
		cat(fd,"\n")
		manifest2<-manifest[grep(fd,manifest[,1]),]
		if(nrow(manifest2)<1){
			cat(paste(fd," is missing....\n"))
			next;
		}
		for(i in 1:nrow(manifest2)){
			sampleDir<-file.path(tcgaRepos,fd,manifest2[i,1])
			sampleIDs<-getSampleID(sampleDir)
			#batchManifest1<-data.frame(sampleIDs,as.data.frame(matrix(manifest2[i,],nrow=length(sampleIDs),ncol=ncol(manifest2))))
			temp<-data.frame(sampleIDs=as.character(sampleIDs),pkg=manifest2[i,1])
			batchManifest1<-merge(temp,manifest2[i,],by.x=2,by.y=1)
			if(is.null(batchManifest)){
				batchManifest<-batchManifest1
			}else{
				batchManifest<-rbind(batchManifest,batchManifest1)
			}
		}
	}
	if(!is.null(bmFn)) write.table(batchManifest,file=bmFn,sep="\t",row.names=F,quote=F)
	return(batchManifest)
}

create_batch_manifest<-function(manifestFn,tcgaRepos,bmFn=NULL,fdir=NULL){
	manifest<-read.delim(file=manifestFn,sep="\t",as.is=T)
	if(is.null(fdir)){
		fdir<-list.files(tcgaRepos)
		fdir<-fdir[-which(fdir=="repos")]
	}
	batchManifest<-NULL
	for(fd in fdir){
		cat(fd,"\n")
		mage<-list.files(file.path(tcgaRepos,fd),"mage")
		mageDir<-mage[-grep("tar",mage)]
		sdrfFn<-list.files(file.path(tcgaRepos,fd,mageDir),"sdrf",full.name=T)
		sdrf<-read.delim(file=sdrfFn,sep="\t",as.is=T)
		sdrf<-sdrf[,c(1,19)]
		if(is.null(batchManifest)) {
			batchManifest<-merge(sdrf,manifest,by.x=2,by.y=1)
			batchManifest<-batchManifest[!duplicated(batchManifest[,2]),]
		}else{
			batchManifest1<-merge(sdrf,manifest,by.x=2,by.y=1)
			batchManifest1<-batchManifest1[!duplicated(batchManifest1[,2]),]
			batchManifest<-rbind(batchManifest,batchManifest1)
		}
	}
	batchManifest<-batchManifest[,-1]
	nm<-names(batchManifest)
	nm[1]<-"sample_id"
	names(batchManifest)<-nm
	if(!is.null(bmFn)) write.table(batchManifest,file=bmFn,sep="\t",row.names=F,quote=F)
	return(batchManifest)
}
create_pkg_manifest.2_test<-function(){
	pkgFolders<-"c:\\tcga"
	create_pkg_manifest.2(pkgFolders)
}

create_pkg_manifest.2a<-function(reposPath,pkgFolder=NULL,pkgManifestFn=NULL,txt=NULL){
	if(is.null(pkgFolder)){
		pkgFolder<-list.files(reposPath)
		pkgFolder<-pkgFolder[-which(pkgFolder=="repos")]
	}
	create_pkg_manifest(file.path(reposPath,pkgFolder[1]),txt,fn=pkgManifestFn,toUpdate=F,toAppend=F)
	for(pkg in pkgFolder[-1]){
		create_pkg_manifest(file.path(reposPath,pkg),txt,fn=pkgManifestFn,toUpdate=F,toAppend=T)
	}
}
create_pkg_manifest.2<-function(pkgFolders,txt=NULL,fn=NULL){
	pkgFolder<-list.files(pkgFolders)
	pkgFolder<-pkgFolder[-which(pkgFolder=="repos")]
	create_pkg_manifest(file.path(pkgFolders,pkgFolder[1]),txt,fn=NULL,toUpdate=F,toAppend=F)
	for(pkg in pkgFolder[-1]){
		create_pkg_manifest(file.path(pkgFolders,pkg),txt,fn=NULL,toUpdate=F,toAppend=T)
	}
}
create_pkg_manifest_test<-function(){
	create_pkg_manifest("c:\\tcga\\GBM",toAppend=F)
	create_pkg_manifest("c:\\tcga\\READ",toAppend=T)
	create_pkg_manifest("c:\\tcga\\COAD",toAppend=F)
	create_pkg_manifest("c:\\tcga\\BRCA",toAppend=F)
	create_pkg_manifest("c:\\tcga\\KIRC")
	create_pkg_manifest("c:\\tcga\\LAML")
	create_pkg_manifest("c:\\tcga\\LUAD",toAppend=F)
	create_pkg_manifest("c:\\tcga\\LUSC")
#	create_pkg_manifest("c:\\tcga\\GBM_OMA002")
#	create_pkg_manifest("c:\\tcga\\GBM_OMA003")
#	create_pkg_manifest("c:\\tcga\\OV")
}
############
# pre: pkgs are uncompressed
#############
create_pkg_manifest<-function(pkgFolder,txt=NULL,fn=NULL,toUpdate=F,toAppend=T){
	if(is.null(fn)) fn<-"c:\\tcga\\package.txt"
	#mani<-read.delim(file=fn,sep="\t",header=T)
	pkgNames<-list.files(pkgFolder,pattern="Level_")
	ind<-grep("tar",pkgNames)
	pkgNames<-pkgNames[-ind]
	pkg_info<-paste("PkgName","Batch_Number","Cancer_Type","Total_Sample_Number","Total_Ctr_Sample_Number","Ctr_Sample_Name",sep="\t")
	if(toAppend==T) pkg_info<-readLines(fn)
	pkg_info.all<-c()
	for(pkg in pkgNames){
		pkgDir<-file.path(pkgFolder,pkg)
		pkgNumb<-sum(regexpr(pkg,pkg_info)>=1)
		if(pkgNumb>0){
			cat(paste("Package ", pkg," is already in the manifest\n"))
			if(toUpdate==F) stop()
		}
		fn0<-list.files(pkgDir)
		sample_number<-length(fn0)-2
		ctr_sample_number<-sum(regexpr("-20A-",fn0)>=1) #0227
		ctr_sample<-fn0[grep("-20A-",fn0)] #0227
		if(ctr_sample_number>1){
			ctr_sample<-paste(ctr_sample,collapse=";")
		}else if(ctr_sample_number==0){
			ctr_sample<-"None"
		}
		fn1<-file.path(pkgDir,"DESCRIPTION.txt")
		if(file.exists(fn1)){
			descript<-readLines(fn1)
			dat<-descript[grep("[B,b]atch",descript)]
			batch.sn<-NA
			if(!is.null(dat)){
				batch.sn<-strsplit(strsplit(tolower(dat),"batch ")[[1]][2],"\\.")[[1]][1]
				if(is.na(batch.sn)) batch.sn<-strsplit(strsplit(tolower(dat),"batches ")[[1]][2],"\\.")[[1]][1]
				batch.sn<-gsub(")","",batch.sn)
				#batch.sn<-sapply(strsplit(tolower(dat),"batch ")[[1]][-1],function(x)strsplit(x,"\\.| ")[[1]][1])
				if(length(batch.sn)>1) batch.sn<-paste(batch.sn,collapse=" or ")
			}
			cancer_type<-strsplit(strsplit(pkgDir,"edu_")[[1]][2],"\\.")[[1]][1]
		}
		pkg_info1<-paste(pkg,batch.sn,cancer_type,sample_number,ctr_sample_number,ctr_sample,sep="\t")
		pkg_info.all<-paste(pkg_info.all,pkg_info1,sep="\n")
	}
	if(toAppend==F) pkg_info.all<-paste(pkg_info,pkg_info.all,sep="")
	else pkg_info.all<-substr(pkg_info.all,2,nchar(pkg_info.all))
	write(pkg_info.all,file=fn,append=toAppend)
}


###
# Nov 29, 2010
###
createBatchPkgs_test<-function(){
	platmapFn<-"c:\\tcga\\platemap.txt"
	batchPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\test_data"
	arrayPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out"
	createBatchPkgs(platmapFn,batchPath,arrayPath)
}
createBatchPkgs_test2<-function(){
	batchPath<-"/home/uec-02/shared/production/methylation/meth27k/other/batches"
	createBatchPkgs(batchPath=batchPath)
}

createBatchPkgs<-function(platmapFn=NULL,batchPath=NULL,arrayPath=NULL){
	if(is.null(platmapFn)) platmapFn<-"/home/uec-02/shared/production/methylation/meth27k/arraymapping/platemap.txt"
	if(is.null(batchPath)) batchPath<-"/auto/uec-02/shared/production/methylation/meth27k/batches"
	if(is.null(arrayPath)) arrayPath<-"/auto/uec-02/shared/production/methylation/meth27k/processed"
	platmap<-read.table(file=platmapFn,sep="\t",header=T,as.is=T)
	batches<-split(platmap,platmap$Batch_Number)
	datFns<-processedCSVFileNames()
	Methylation_Signal_Intensity<-NULL;
	Methylation_Signal_Intensity_NBeads<-NULL;
	BetaValue<-NULL
	Methylation_Signal_Intensity_STDERR<-NULL;
	UnMethylation_Signal_Intensity<-NULL;
	UnMethylation_Signal_Intensity_NBeads<-NULL;
	UnMethylation_Signal_Intensity_STDERR<-NULL;
	Pvalue<-NULL;
	Control_Signal_Intensity_Grn<-NULL;
	Control_Signal_Intensity_Red<-NULL;
	for(batch in batches){
		chips<-unique(batch$chip_id)
		chip.exist<-c()
		for(chip in chips){
			if(file.exists(file.path(arrayPath,chip))) chip.exist<-c(chip.exist,chip)
			else cat(paste("The array ",chip," from batch",batch$Batch_Number[1],"is missing\n"))
		}
		if(length(chip.exist)>0) {
			chips<-chip.exist;
		}else{
			next
		}
		chip<-chips[1]
		dataPath<-file.path(arrayPath,chip)
		#datFNs<-list.files(datPath,pattern=".csv")
		Methylation_Signal_Intensity<-read.csv(file=file.path(dataPath,datFns["M"]),check.names=F)
		Methylation_Signal_Intensity_NBeads<-read.csv(file=file.path(dataPath,datFns["Mn"]),check.names=F)
		Methylation_Signal_Intensity_STDERR<-read.csv(file=file.path(dataPath,datFns["Mse"]),check.names=F)
		UnMethylation_Signal_Intensity<-read.csv(file=file.path(dataPath,datFns["U"]),check.names=F)
		UnMethylation_Signal_Intensity_NBeads<-read.csv(file=file.path(dataPath,datFns["Un"]),check.names=F)
		UnMethylation_Signal_Intensity_STDERR<-read.csv(file=file.path(dataPath,datFns["Use"]),check.names=F)
		BetaValue<-read.csv(file=file.path(dataPath,datFns["Bv"]),check.names=F)
		Pvalue<-read.csv(file=file.path(dataPath,datFns["Pv"]),check.names=F)
		Control_Signal_Intensity_Grn<-read.csv(file=file.path(dataPath,datFns["Gctr"]),check.names=F)
		Control_Signal_Intensity_Red<-read.csv(file=file.path(dataPath,datFns["Rctr"]),check.names=F)
		if(length(chips)>1){
			for(i in 2:length(chips)){
				chip<-chips[i]
				dataPath<-file.path(arrayPath,chip)
				Methylation_Signal_Intensity2<-read.csv(file=file.path(dataPath,datFns["M"]),check.names=F)
				Methylation_Signal_Intensity<-cbind(Methylation_Signal_Intensity,Methylation_Signal_Intensity2)
				Methylation_Signal_Intensity_NBeads2<-read.csv(file=file.path(dataPath,datFns["Mn"]),check.names=F)
				methylation_Signal_Intensity_NBeads<-cbind(Methylation_Signal_Intensity_NBeads,Methylation_Signal_Intensity_NBeads2)
				Methylation_Signal_Intensity_STDERR2<-read.csv(file=file.path(dataPath,datFns["Mse"]),check.names=F)
				Methylation_Signal_Intensity_STDERR<-cbind(Methylation_Signal_Intensity_STDERR,Methylation_Signal_Intensity_STDERR2)
				UnMethylation_Signal_Intensity2<-read.csv(file=file.path(dataPath,datFns["U"]),check.names=F)
				UnMethylation_Signal_Intensity<-cbind(UnMethylation_Signal_Intensity,UnMethylation_Signal_Intensity2)
				UnMethylation_Signal_Intensity_NBeads2<-read.csv(file=file.path(dataPath,datFns["Un"]),check.names=F)
				UnMethylation_Signal_Intensity_NBeads<-cbind(UnMethylation_Signal_Intensity_NBeads,UnMethylation_Signal_Intensity_NBeads2)
				UnMethylation_Signal_Intensity_STDERR2<-read.csv(file=file.path(dataPath,datFns["Use"]),check.names=F)
				UnMethylation_Signal_Intensity_STDERR<-cbind(UnMethylation_Signal_Intensity_STDERR,UnMethylation_Signal_Intensity_STDERR2)
				BetaValue2<-read.csv(file=file.path(dataPath,datFns["Bv"]),check.names=F)
				BetaValue<-cbind(BetaValue,BetaValue2)
				Pvalue2<-read.csv(file=file.path(dataPath,datFns["Pv"]),check.names=F)
				Pvalue<-cbind(Pvalue,Pvalue2)
				Control_Signal_Intensity_Grn2<-read.csv(file=file.path(dataPath,datFns["Gctr"]),check.names=F)
				Control_Signal_Intensity_Grn<-cbind(Control_Signal_Intensity_Grn,Control_Signal_Intensity_Grn2)
				Control_Signal_Intensity_Red2<-read.csv(file=file.path(dataPath,datFns["Rctr"]),check.names=F)
				Control_Signal_Intensity_Red<-cbind(Control_Signal_Intensity_Red,Control_Signal_Intensity_Red2)
			}
		}
		batch<-batch$Batch_Number[1]
		if(!file.exists(file.path(batchPath,batch)))dir.create(file.path(batchPath,batch))
		write.csv(Methylation_Signal_Intensity,file=file.path(batchPath,batch,datFns["M"]),row.names=F,quote=F)
		write.csv(Methylation_Signal_Intensity_NBeads,file=file.path(batchPath,batch,datFns["Mn"]),row.names=F,quote=F)
		write.csv(Methylation_Signal_Intensity_STDERR,file=file.path(batchPath,batch,datFns["Mse"]),row.names=F,quote=F)
		write.csv(UnMethylation_Signal_Intensity,file=file.path(batchPath,batch,datFns["U"]),row.names=F,quote=F)
		write.csv(UnMethylation_Signal_Intensity_NBeads,file=file.path(batchPath,batch,datFns["Un"]),row.names=F,quote=F)
		write.csv(UnMethylation_Signal_Intensity_STDERR,file=file.path(batchPath,batch,datFns["Use"]),row.names=F,quote=F)
		write.csv(BetaValue,file=file.path(batchPath,batch,datFns["Bv"]),row.names=F,quote=F)
		write.csv(Pvalue,file=file.path(batchPath,batch,datFns["Pv"]),row.names=F,quote=F)
		write.csv(Control_Signal_Intensity_Grn,file=file.path(batchPath,batch,datFns["Gctr"]),row.names=F,quote=F)
		write.csv(Control_Signal_Intensity_Red,file=file.path(batchPath,batch,datFns["Rctr"]),row.names=F,quote=F)
	}
}

processedCSVFileNames<-function(){
	csvFN<-c("Methylation_Signal_Intensity.csv","Methylation_Signal_Intensity_NBeads.csv","Methylation_Signal_Intensity_STDERR.csv","UnMethylation_Signal_Intensity.csv","UnMethylation_Signal_Intensity_NBeads.csv","UnMethylation_Signal_Intensity_STDERR.csv","BetaValue.csv","Pvalue.csv","Control_Signal_Intensity_Grn.csv","Control_Signal_Intensity_Red.csv")
	tcgaFn<-c("tcgaPackage_B","tcgaPackage_B_n","tcgaPackage_B_se","tcgaPackage_A","tcgaPackage_A_n","tcgaPackage_B_se","tcgaPackage_beta_fn","tcgaPackage_pvalue_fn","tcgaPackage_G_ctr","tcgaPackage_R_ctr")
	name1<-c("M","Mn","Mse","U","Un","Use","Bv","Pv","Gctr","Rctr")
	#rst<-t(data.frame(csvFN,tcgaFn,name1))
	names(csvFN)<-name1
	return(csvFN)
}

#############################
#
#############################
RepositoryAdd_test<-function(){
	tcga<-"c:\\tcga"
	repos<-"c:\\temp\\repos"
	fdir<-c("OV","GBM")
	RepositoryAdd(tcga,repos)
}
RepositoryAdd<-function(tcga,repos,fdir=NULL){
	if(is.null(fdir))fdir<-list.files(tcga)
	setwd(repos)
	for(fd in fdir){
		if(fd!="repos")
		{
			fd<-file.path(tcga,fd)
			pkgs<-list.files(fd,pattern="gz",recursive=T,full.names=T)
			for(fn in pkgs){
				fn1<-filetail(fn)
				if(!file.exists(fn1))file.copy(fn,file.path(repos,fn1))
			}
		}
	}
}
RepositoryManifest<-function(tcga){
	fdir<-list.files(tcga)
	#fdir<-fdir[-which(fdir=="repos")]
	for(fd in fdir){
		setwd(file.path(tcga,fd))
		if(R.Version()$os=="mingw32"){
			md5<-file.path(system.file("Rtools",package="rapid"),"md5sum")
			shell(paste(md5," -t *.gz* > MD5"))
		}else{
			system("md5sum *.gz* > MD5")
		}
	}
}
uploadFiles_test<-function(){
	host<-"epinexus.usc.edu"
	repos<-"/home/feipan/test"
	localFns<-c("c:\\temp\\auc_test.txt","c:\\temp\\t1.txt")
	user<-"feipan"
	uploadFiles(localFns,host,repos,user)
}
uploadFiles<-function(localFns,host,repos,user,isFolder=F){
	rst<-NULL
	cdir<-getwd()
	host<-paste(user,"@",host,":",repos,sep="")
	scp<-"scp"
	if(R.Version()$os=="mingw32"){
		scp<-file.path(system.file("Rtools",package="rapid"),"bin/scp")
	}
	for(fn in localFns){
		setwd(filedir(fn))
		fn<-filetail(fn)
		rst<-system(paste(scp,fn,host,sep=" "),invisible=F)
	}
	setwd(cdir)
	return(rst)
}
###########
# Upload files in the same folder
# note: -3joj.txt 
##########
uploadFiles.2_test<-function(){
	localFns<-choose.files()
	uploadFiles.2(localFns,host="epinexus.usc.edu",repos="/home/feipan/test",user="feipan")
}
uploadFiles.2<-function(localFns,host,repos,user,isFolder=F){
	host<-paste(user,"@",host,":",repos,sep="")
	scp<-"scp"
	if(R.Version()$os=="mingw32"){
		scp<-file.path(system.file("Rtools",package="rapid"),"bin/scp")
	}
	datDir<-filedir(localFns[1])
	setwd(datDir)
	localFns<-sapply(localFns,function(x)filetail(x))
	fn<-paste(localFns,collapse=" ")
	system(paste(scp,fn,host,sep=" "),invisible=F)
}
downloadFiles_test<-function(){
	host<-"epinexus.usc.edu"
	repos<-"/home/feipan/test"
	localDir<-"c:\\temp"
	user<-"feipan"
	downloadFiles(localDir,host,repos,user,isFolder=T)
}
downloadFiles<-function(localDir,host="hpc-epc.usc.edu",repos="/home/uec-02/shared/production/methylation/meth27k/tcga",
		user="feipan",isFolder=F,Fn=NULL){
	rst<-NULL
	cdir<-getwd()
	if(!is.null(Fn)) repos<-file.path(repos,Fn)
	host<-paste(user,"@",host,":",repos,sep="")
	scp<-"scp"
	if(R.Version()$os=="mingw32"){
		scp<-file.path(system.file("Rtools",package="rapid"),"bin/scp")
	}
	setwd(localDir)
	if(isFolder==F) rst<-system(paste(scp,host,".",sep=" "),invisible=F)
	else rst<-system(paste(scp,"-r",host,"."),invisible=F)
	setwd(cdir)
	return(rst)
}
createLocalRepos_test<-function(){
	reValue<-c("c:/temp/.","GBM")
	createLocalRepos()
}
createLocalRepos.2<-function(txt=NULL,host="hpc-uec.usc.edu",repos="/home/uec-02/shared/production/methylation/meth27k/tcga",inter=T){
	if(inter==T)createLocalReposDlg()
	if(is.null(reValue)) return()
	if(!is.null(txt))tkinsert(txt,"end",paste(">Start to create local data repository...",date(),"\n"))
	reposDir<-reValue[1]
	cancerType<-reValue[2]
	reValue<<-NULL
	downloadFiles(reposDir,host,repos,isFolder=T,Fn=cancerType)
	if(!is.null(txt)) tkinsert(txt,"end",paste("> Finished creating local repository at ",reposDir,"\n"))
}
createLocalRepos<-function(txt=NULL,host="hpc-uec.usc.edu",repos="/home/uec-02/shared/production/methylation/meth27k/tcga",inter=T){
	if(inter==T)createLocalReposDlg()
	if(is.null(reValue)) return()
	if(!is.null(txt))tkinsert(txt,"end",">Start to create local data repository\n")
	tcgaRepos<-paste(host,repos,sep=":")
	reposDir<-reValue[1]
	cancerType<-reValue[2]
	scp<-"scp"
	if(R.Version()$os=="mingw32"){
		rt<-system.file("Rtools",package="rapid")
		if(file.exists(rt)){
			scp<-file.path(rt,"bin/scp")
		}
	}
	tcgaRepos<-file.path(tcgaRepos,toupper(cancerType))
	rst<-system(paste(scp," -r ",tcgaRepos," ",reposDir),invisible=F)
	reValue<<-NULL
	if(!is.null(txt)) tkinsert(txt,"end",paste("> Finished creating local repository at ",reposDir,"\n"))
}
createLocalReposDlg<-function(){
	dlg<-startDialog("Create Local Data Repository")
	tkgrid(tklabel(dlg,text=""))
	dlg1<-tkfrm(dlg)
	addTextEntryWidget(dlg1,"Select the data repository folder:","",isFolder=T,name="reposDir")
	addTextEntryWidget(dlg1,"Type in the type of cancer:","GBM",isFolder=F,name="cancerType")
	tkaddfrm(dlg,dlg1)
	endDialog(dlg,c("reposDir","cancerType"))
}

#todo: check md5sum
updateLocalRepos_test<-function(){
	reValue<-c("C:\\temp\\COAD_test","COAD")
	updateLocalRepos(txt=NULL)
}
updateLocalRepos<-function(txt=NULL,host="hpc-uec.usc.edu",repos="/home/uec-02/shared/production/methylation/meth27k/tcga",auto=F){
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Start to update the local data repository...",date(),"\n"))
	if(auto==F)createLocalReposDlg()
	if(is.null(reValue))return()
	localDir<-reValue[1]
	remoteDir<-reValue[2]
	localPkgs<-list.files(localDir,"gz")
	if(file.exists(file.path(localDir,"MD5"))) {
		md5.local<-read.delim(file=file.path(localDir,"MD5"),sep=" ",header=F)
		localPkgs<-md5.local[,3]
	}
	localDir1<-file.path(localDir,"bk")
	if(!file.exists(localDir1)) dir.create(localDir1)
	downloadFiles(localDir1,host=host,repos=repos,Fn=file.path(remoteDir,"MD5"),isFolder=F)
	md5<-read.delim(file=file.path(localDir1,"MD5"),sep=" ",header=F)
	remPkgs<-md5[,3]
	newPkgs<-remPkgs[!is.element(remPkgs,localPkgs)]
	if(length(newPkgs)>0){
		msg<-paste(">The following new data package(s) will be downloaded:\n",paste(newPkgs,collapse="\n"),"Please validate local data repository\n",sep="")
		cat(msg)
		if(!is.null(txt))tkinsert(txt,"end",msg)
	}
	newPkgs<-c(newPkgs,"MD5")
	for(pkg in newPkgs){
		downloadFiles(localDir,host=host,repos=repos,Fn=file.path(remoteDir,pkg),isFolder=F)
	}
	reValue<<-NULL
	if(!is.null(txt))tkinsert(txt,"end",">Finished updating the local data repository\n")
}

ViewUecRepository<-function(txtWin){
	link<-"http://epinexus.usc.edu/MPL"
	if(R.Version()$os=="mingw32"){
		shell.exec(link)
	}else{
		system(link)
	}
}
uploadUECRepos_test<-function(){
	reValue<-c("C:\\temp\\COAD_test\\jhu-usc.edu_COAD.HumanMethylation27.Level_2.4.10.0.tar.gz","COAD","feipan")
	uploadUECRepos(txt=NULL)
}
uploadUECRepos<-function(txt=NULL,host="hpc-uec.usc.edu",repos="/home/uec-02/shared/production/methylation/meth27k",auto=F){
	if(auto==F)uploadReposDlg.2()
	if(is.null(reValue)) return()
	pkgs<-reValue[1]
	pkgs<-strsplit(gsub("[{|}]","",pkgs)," ")[[1]]
	rmDir<-reValue[2]
	user<-reValue[3]
	if(!is.null(txt)) tkinsert(txt,"end",paste(">Start to upload the following data packages to HPC-UEC repository: \n",paste(pkgs,collapse="\n"),"\n",sep=""))
	
	localDir<-filedir(pkgs[1])
	localDir1<-file.path(localDir,"bk")
	if(!file.exists(localDir1)) dir.create(localDir1)
	downloadFiles(localDir1,host,Fn=file.path(rmDir,"MD5"),user=user)
	md5<-read.table(file.path(localDir1,"MD5"),sep=" ",head=F)
	pkgFns<-sapply(pkgs,function(x)filetail(x))
	pkg.exists<-pkgs[is.element(pkgFns,md5[,3])]
	if(length(pkg.exists)>0){
		msg<-paste(">The following data packages already exists, please update local data repository first:\n",paste(pkg.exists,collapse="\n"),"\n",sep="")
		cat(msg)
		if(!is.null(txt))tkinsert(txt,"end",msg)
		return()
	}
	dat<-data.frame(c1=rep("",length(pkgs)),c2=rep("",length(pkgs)),pkgFns)
	write.table(dat,file=file.path(localDir,"MD5"),append=T,row.names=F,col.names=F,sep=" ",quote=F)
	pkgs<-c(file.path(localDir,"MD5"),pkgs)
	rmDir<-file.path(repos,"tcga",rmDir)
	rst<-uploadFiles.2(pkgs,host,repos=rmDir,user=user,isFolder=F)
	reValue<<-NULL
	if(!is.null(txt)) tkinsert(txt,"end",">Finished uploading data packages")
}
uploadReposDlg.2<-function(){
	dlg<-startDialog("Upload Data Packages")
	tkgrid(tklabel(dlg,text=""))
	frm<-tkfrm(dlg)
	addTextEntryWidget(frm,"Select the local data packages:","",isFolder=F,fileType="any",name="localDir")
	addTextEntryWidget(frm,"Type in the remote data folder:","GBM",isFolder=F,withSelectButton=F,name="rmDir")
	addTextEntryWidget(frm,"Type in the account name:","feipan",withSelectButton=F,name="user")
	tkaddfrm(dlg,frm)
	endDialog(dlg,c("localDir","rmDir","user"))
}
uploadReposDlg<-function(){
	dlg<-startDialog("Upload Data Packages")
	tkgrid(tklabel(dlg,text=""))
	frm<-tkfrm(dlg)
	addTextEntryWidget(frm,"Select the local data repository folder:","c:/tcga",isFolder=T,name="localDir")
	addTextEntryWidget(frm,"Type in the remote data folder:","GBM",isFolder=F,withSelectButton=F,name="rmDir")
	addTextEntryWidget(frm,"Type in the account name:","feipan",withSelectButton=F,name="user")
	tkaddfrm(dlg,frm)
	endDialog(dlg,c("localDir","rmDir","user"))
}
viewTcgaDCC<-function(txt){
	link<-"http://tcga-data.nci.nih.gov/tcga/"
	if(R.Version()$os=="mingw32"){
		shell.exec(link)
	}else{
		system(link)
	}
}
submitTcgaDcc<-function(txt=NULL){
	pkgs<-choose.files()
	if(pkgs==""|length(pkgs)==0)return()
	rv<-tkmessageBox(message="Are you sure to continue?",type="yesno")
	if(tclvalue(rv)=="no") return()
	else{
		if(!is.null(txt)) tkinsert(txt,"end",paste(">Start to submit the following data package(s) to DCC:",paste(pkgs,collapse="\n"),"\n",sep=""))
		uploadFiles(pkgs,host="cbioftp2.nci.nih.gov",repos="",user="jmhi")
		if(!is.null(txt)) tkinsert(txt,"end",">Finished submitting data packages\n")
	}
}
openSampleDB<-function(txt){
	shell.exec("http://epinexus.usc.edu/mdb/index.jsp")
}
RepositoryValidate_run<-function(){
	javaPath<-"/auto/uec-00/shared/production/software/java/1.6.0_21/bin/"
	tcga<-""
	validatorPath<-""
	RepositoryValidate(tcga,validatorPath,javaPath)
}
RepositoryValidate<-function(tcga,validatorPath,javaPath){
	fdir<-list.files(tcga)
	fdir<-fdir[-which(fdir=="repos")]
	for(fd in fdir){
		fd<-file.path(tcga,fd)
		validatePkg(fd,validatorPath,javaPath)
		setwd(fd)
		fdr<-list.files(fd,pattern="jhu-usc")
		fdr<-fdr[-grep("gz",fdr)]
		for(f1 in fdr){
			system(paste("rm -r ",f1))
		}
	}
}

RepositoryCL_test<-function(){
	tcga<-"/auto/uec-02/shared/production/methylation/OMA002/tcga"
	RepositoryCL(tcga)
	tcga<-"/auto/uec-02/shared/production/methylation/OMA003/tcga"
	RepositoryCL(tcga)
	tcga<-"/auto/uec-02/shared/production/methylation/meth27k/tcga"
	RepositoryCL(tcga)
}
RepositoryCL<-function(tcga){
	pkgFD<-list.files(tcga)
	pkgFD<-pkgFD[-which(pkgFD=="repos")]
	repos<-list.files(file.path(tcga,"repos"),pattern="gz")
	cat(length(repos),"\n")
	pkgs.all<-c()
	for(fd in pkgFD){
		fd<-file.path(tcga,fd)
		pkgs<-list.files(fd,pattern="gz")
		pkgs.all<-c(pkgs.all,pkgs)
	}
	setwd(file.path(tcga,"repos"))
	for(fn in pkgs.all){
		if(file.exists(fn)) file.remove(fn)
	}
	repos<-list.files(file.path(tcga,"repos"),pattern="gz")
	cat(length(repos),"\n")
}

####################
# NOv22,2010
######################
update_HumanMeth27k.ADF<-function(){
	library(mAnnot)
	getData()
	geneInfo<-data.frame(ilmnid=humanMeth27k$ILmnID,gid=humanMeth27k$GID_Update,gs=as.character(humanMeth27k$Symbol),stringsAsFactors=F)
	row.names(geneInfo)<-geneInfo$ilmnid
	str(geneInfo)
	library(methPipe)
	data(HumanMethylation27.adf)
	names(HumanMethylation27.adf)
	ind<-HumanMethylation27.adf$IlmnID
	geneInfo<-geneInfo[ind,]
	table(geneInfo$gs=="")
	HumanMethylation27.adf$Gene_ID<-geneInfo$gid
	HumanMethylation27.adf$SYMBOL<-geneInfo$gs
	table(is.na(HumanMethylation27.adf$Gene_ID))
	data(lvl3mask)
	names(lvl3mask)
	lvl3mask<-lvl3mask[ind,]
	table(lvl3mask$SYMBOL==HumanMethylation27.adf$SYMBOL)
#	TRUE 
#	27578 
	save(HumanMethylation27.adf,file=file.path("c:\\tcga\\others","HumanMethylation27.adf.rdata"))
	write.table(HumanMethylation27.adf,file=file.path("c:\\tcga\\others","HumanMethylation27.adf.txt"),sep="\t",row.names=F,quote=F)
}
summarry_updating_ADF<-function(){
	load(file=file.path("c:\\tcga\\others\\","HumanMethylation27.adf.rdata"))
	adf2<-HumanMethylation27.adf
	names(adf2)
	load(file=file.path("c:\\tcga\\others","HumanMethylation27.adf.v1.rdata"))
	adf1<-HumanMethylation27.adf
	row.names(adf1)<-adf1$IlmnID
	adf1<-adf1[adf2$IlmnID,]
	all(adf1$IlmnID==adf2$IlmnID)
#	[1] TRUE
	adf1$Gene_ID<-gsub("GeneID:","",adf1$Gene_ID)
	table(adf1$Gene_ID==adf2$Gene_ID)
#	FALSE  TRUE 
#	111 27458
	table(adf1$SYMBOL==adf2$SYMBOL)
#	FALSE  TRUE 
#	234 27344 
	adf<-data.frame(adf1[,c("IlmnID","Gene_ID","SYMBOL")],adf2[,c("Gene_ID","SYMBOL")])
	names(adf)<-c("IlmnID","Gene_ID","SYMBOL","Gene_ID.new","SYMBOL.new")
	adf$Is_GID_Same<-adf$Gene_ID==adf$Gene_ID.new
	table(adf$Is_GID_Same)
	adf$Is_SYMBL_Same<-adf$SYMBOL==adf$SYMBOL.new
	table(adf$Is_SYMBL_Same)
	adf<-adf[order(adf$Is_SYMBL_Same,decreasing=T),]
	write.csv(adf,file="c:\\tcga\\others\\adf_comp.csv")
	
	data(lvl3mask)
	names(lvl3mask)
	lvl3mask<-lvl3mask[adf2$IlmnID,]
	table(lvl3mask$SYMBOL==adf2$SYMBOL)
#	TRUE 
#	27578 
}



##################
#merged
#################
#######################
readArrayMaps_test<-function(){
	amDir<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\arraymapping"
	dat<-readArrayMaps(amDir)
#	[1] "Plate"                      "BeadChip#"                 
#	[3] "Barcode Terminus"           "Well Position"             
#	[5] "Well Position"              "Infinium Barcode"          
#	[7] "Biospecimen Barcode Side"   "Biospecimen Barcode Bottom"
#	[9] "Tissue Type"                "Histology"                 
#	[11] "TCGA BATCH"                 "Sample ID"                 
#	[13] "Detected Genes (0.01)"      "Detected Genes (0.05)"     
#	[15] "Signal Average GRN"         "Signal Average RED"        
#	[17] "Signal P05 GRN"             "Signal P05 RED"            
#	[19] "Signal P25 GRN"             "Signal P25 RED"            
#	[21] "Signal P50 GRN"             "Signal P50 RED"            
#	[23] "Signal P75 GRN"             "Signal P75 RED"            
#	[25] "Signal P95 GRN"             "Signal P95 RED"            
#	[27] "# OF DROPOUTS"              "% DROPOUTS"  
}
readArrayMaps<-function(amDir){
	amFn<-list.files(amDir,pattern=".csv",recursive=T)
	arrayMappingInfo<-NULL
	for(i in 1:length(amFn)){
		am1<-read.delim(file=file.path(amDir,amFn[i]),sep=",",head=T,as.is=T,check.names=F)
		if(is.null(arrayMappingInfo)){
			arrayMappingInfo<-am1
		}else{
			arrayMappingInfo<-rbind(arrayMappingInfo,am1)
		}
	}
	return(arrayMappingInfo)
}
#jhu-usc.stad_create<-function(){
#	amDir<-"C:\\tcga\\arraymapping"
#	datPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\test_data"
#	outPath<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\tmp"
#	rapid.pro(datPath,outPath,outPath,arrayPath=amDir)
#	
#}
extractSampleInfo_test<-function(){
	amFn<-"c:\\tcga\\arraymapping\\jhu-usc.edu_STAD.HumanMethylation27.1.0.0.csv"
	samInfo<-extractSampleInfo(amFn)
}
extractSampleInfo<-function(amFn,sep=","){
	am<-read.delim(file=amFn,sep=sep,head=T,as.is=T,check.names=F)
	plate<-unique(am$Plate)
	chipBarcode<-unique(sapply(am$"Infinium Barcode",function(x)strsplit(x,"_")[[1]][1]))
	tcgaBatch<-unique(am$"TCGA BATCH")
	cancerType<-unique(am$Histology)
	cancerType.n<-table(am$Histology)
	tcgaSampleID<-am$"Biospecimen Barcode Side"
	sampleID<-am$"Sample ID"
	sampleCode<-tcgaSampleID
	names(sampleCode)<-sampleID
	sampleInfo<-list(chipBarCode=chipBarcode,sampleCode=sampleCode,sampleID=sampleID,tcgaSampleID=tcgaSampleID,cancerType=cancerType,cancerType.n=cancerType.n,tcgaBatch=tcgaBatch,plate=plate,sampleInfo=am)
	return(sampleInfo)
}
createDescription<-function(amFn){
	sampInfo<-extractSampleInfo(amFn)
	d1<-sampInfo$cancerType.n[order(sampInfo$cancerType.n,decreasing=T)]
	d2<-paste(d1,names(d1),collapse=", ")
	batch<-paste(sampInfo$tcgaBatch,collapse=",")
	date1<-paste(strsplit(date()," ")[[1]][c(2,3,5)],collapse=" ")
	header<-paste("The data archive contains The Cancer Genome Atlas (TCGA) analysis of DNA methylation profilings using the IIllumina Infinium Human DNA Methylation27 platform. The Infinium platform analyzes up to 27,578 CpG dinucleotides spanning the entire set of 14,495 Consensus Coding DNA Sequence (CCDS) genes. DNA samples were received, bisulfite converted and the methylation profiling was evaluated using IIllumina Infinium Human DNA Methylation27 technology.\n",
			"This archive contains Infinium-based DNA methylation data for ",d2," from Batch ",batch,".\n",sep="")
	description_lvl_1<-paste(header, "LEVEL 1 data contain the non-background corrected signal intensities of the methylated (M) and unmethylated (U) probes and the mean negative control cy5 (red) and cy3 (green) signal intensities. We also provide a detection p-value for each data point. The Detection p-values provide an indication of DNA methylation measurement quality for each locus and are calculated based on the difference in signal intensity of each probe compared to the set of negative control probes. Specifically, the p-value is calculated using a Z-test by comparing the methylated and unmethylated signal intensities to the mean(red) or mean(green) of the 16 negative control probes on the array. The choice of red or green is determined by the nucleotide immediately upstream of the targeted CpG site. The color channel for each probe is listed in the manifest as well as Level 3 data files. Measurements for which the minimum detection p-value is less than 0.05 for M and U are considered to have a signal intensity significantly above background. We also include the number of replicate beads for methylated and unmethylated bead types as well as the standard error of methylated and unmethylated signal intensities. Similar values are also provided for the negative control probes.\n",date1,"\n",sep="")
	description_lvl_2<-paste(header,"LEVEL 2 data files contain the beta value calculations for each probe and sample, calculated as: Beta = M/(M+U), using non-background corrected data. In this formula, M and U represent the mean signal intensities for replicate methylated (M) and unmethylated (U) probes on the array. Data points with a detection p-value > 0.05 are masked as \"NA\", and represent beta values with non-significant detection of DNA methylation compared to background. Please note that we use a slightly different formula for calculating the beta value than Illumina BeadStudio or GenomeStudio software.\n",date1,"\n",sep="")
	description_lvl_3<-paste(header,"LEVEL 3 data contain beta value calculations, gene IDs and genomic coordinates for each probe on the array. In addition, we have masked data for probes that contain known single nucleotide polymorphisms (SNPs) after comparison to the dbSNP database (Build 130). In addition, we have masked data for probes that contain repetitive element DNA sequences that cover the targeted CpG dinucleotide in each 50 bp probe sequence.We have also masked probes that are not uniquely aligned to the human genome (build 36) at 20 nucleotides at the 3' terminus of the probe sequence, as well as those that span known regions of insertions and deletions (indells) in the human genome. Data points from probes containing SNPs, repetitive elements, other non-unique sequences and/or indells are masked with an \"NA\" descriptor.\n",date1,"\n",sep="")
	description<-c(lvl_1=description_lvl_1,lvl_2=description_lvl_2,lvl_3=description_lvl_3)
	return(description)
}

create_Level_Description_File.2_test<-function(){
	am<-"c:\\tcga\\arraymapping\\jhu-usc.edu_STAD.HumanMethylation27.1.0.0.csv"
	pkg_folder<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out\\jhu-usc.edu_STAD.HumanMethylation27.1"
	f1<-"jhu-usc.edu_STAD.HumanMethylation27.Level_1.1.0.0"
	f2<-"jhu-usc.edu_STAD.HumanMethylation27.Level_2.1.0.0"
	f3<-"jhu-usc.edu_STAD.HumanMethylation27.Level_3.1.0.0"
	create_Level_Description_File.2(pkg_folder,f1,f2,f3,am)
}
create_Level_Description_File.2<-function(pkg_folder,lvl_1_fd,lvl_2_fd,lvl_3_fd,arraymapping){
	des<-createDescription(arraymapping)
	fn<-"DESCRIPTION.txt"
	write(des["lvl_1"],file=file.path(pkg_folder,lvl_1_fd,fn))
	write(des["lvl_2"],file=file.path(pkg_folder,lvl_2_fd,fn))
	write(des["lvl_3"],file=file.path(pkg_folder,lvl_3_fd,fn))
}
createManifestByLevel.2a_test<-function(){
	pkg_folder<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out\\5543207013\\jhu-usc.edu_STAD.HumanMethylation27.1\\jhu-usc.edu_STAD.HumanMethylation27.mage-tab.1.1.0"
	createManifestByLevel.2a(pkg_folder)
}
createManifestByLevel.2a<-function(pkg_folder,lvl_folder=NULL){
	if(R.Version()$os=="mingw32"){
		createManifestByLevel.2(pkg_folder,lvl_folder)
	}else{
		setwd(pkg_folder)
		cmd<-"md5sum *.* > MANIFEST.txt"
		system(command)
	}
}
compressDataPackage.2_test<-function(){
	pkg_folder<-"c:\\temp\\4698"
	compressDataPackage.2(pkg_folder)
	pkg_folder<-"/auto/uec-02/shared/production/methylation/meth27k/3435323"
	compressDataPackage.2(pkg_folder)
	pkg_folder<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\temp\\testing_out\\5543207013\\jhu-usc.edu_STAD.HumanMethylation27.1\\jhu-usc.edu_STAD.HumanMethylation27.mage-tab.1.1.0"
	compressDataPackage.2(pkg_folder)
}
compressDataPackage.2<-function(pkg_folder,lvl_fdname=NULL){
	if(is.null(lvl_fdname)){
		lvl_fdname<-filetail(pkg_folder)
		pkg_folder<-filedir(pkg_folder)
	}
	setwd(pkg_folder)
	command <- paste("tar -cvf ",lvl_fdname,".tar ",lvl_fdname,sep="")
	system(command,wait=T)
	command <- paste("gzip ",lvl_fdname,".tar ",sep="")
	system(command,wait=T)
	command <- paste("md5sum ",lvl_fdname,".tar.gz>",lvl_fdname,".tar.gz.md5",sep="")
	if(R.Version()$os=="mingw32"){
		shell(command)
	}else{
		system(command)
	}
}
