# TODO: Add comment
# 
# Author: feipan
###############################################################################


#################
# IlluminaHumanMethylation450k
#################
IlluminaHumanMethylation450k_test<-function(){
	library("IlluminaHumanMethylation450k.db")
	ls("package:IlluminaHumanMethylation450k.db")
	#[1] "IlluminaHumanMethylation450k"                 
	#[2] "IlluminaHumanMethylation450k_dbconn"          
	#[3] "IlluminaHumanMethylation450k_dbfile"          
	#[4] "IlluminaHumanMethylation450k_dbInfo"          
	#[5] "IlluminaHumanMethylation450k_dbschema"        
	#[6] "IlluminaHumanMethylation450k_getControls"     
	#[7] "IlluminaHumanMethylation450k_getProbeOrdering"
	#[8] "IlluminaHumanMethylation450k_getProbes"       
	#[9] "IlluminaHumanMethylation450kACCNUM"           
	#[10] "IlluminaHumanMethylation450kALIAS2PROBE"      
	#[11] "IlluminaHumanMethylation450kBLAME"            
	#[12] "IlluminaHumanMethylation450kBUILD"            
	#[13] "IlluminaHumanMethylation450kCHR"              
	#[14] "IlluminaHumanMethylation450kCHR36"            
	#[15] "IlluminaHumanMethylation450kCHR37"            
	#[16] "IlluminaHumanMethylation450kCHRLENGTHS"       
	#[17] "IlluminaHumanMethylation450kCHRLOC"           
	#[18] "IlluminaHumanMethylation450kCHRLOCEND"        
	#[19] "IlluminaHumanMethylation450kCOLORCHANNEL"     
	#[20] "IlluminaHumanMethylation450kCPG36"            
	#[21] "IlluminaHumanMethylation450kCPG37"            
	#[22] "IlluminaHumanMethylation450kCPGCOORDINATE"    
	#[23] "IlluminaHumanMethylation450kCPGS"             
	#[24] "IlluminaHumanMethylation450kDESIGN"           
	#[25] "IlluminaHumanMethylation450kDMR"              
	#[26] "IlluminaHumanMethylation450kENSEMBL"          
	#[27] "IlluminaHumanMethylation450kENSEMBL2PROBE"    
	#[28] "IlluminaHumanMethylation450kENTREZID"         
	#[29] "IlluminaHumanMethylation450kENZYME"           
	#[30] "IlluminaHumanMethylation450kENZYME2PROBE"     
	#[31] "IlluminaHumanMethylation450kFANTOM"           
	#[32] "IlluminaHumanMethylation450kGENENAME"         
	#[33] "IlluminaHumanMethylation450kGO"               
	#[34] "IlluminaHumanMethylation450kGO2ALLPROBES"     
	#[35] "IlluminaHumanMethylation450kGO2PROBE"         
	#[36] "IlluminaHumanMethylation450kISCPGISLAND"      
	#[37] "IlluminaHumanMethylation450kMAP"              
	#[38] "IlluminaHumanMethylation450kMAPCOUNTS"        
	#[39] "IlluminaHumanMethylation450kMETHYL27"         
	#[40] "IlluminaHumanMethylation450kNUID"             
	#[41] "IlluminaHumanMethylation450kOMIM"             
	#[42] "IlluminaHumanMethylation450kORGANISM"         
	#[43] "IlluminaHumanMethylation450kORGPKG"           
	#[44] "IlluminaHumanMethylation450kPATH"             
	#[45] "IlluminaHumanMethylation450kPATH2PROBE"       
	#[46] "IlluminaHumanMethylation450kPFAM"             
	#[47] "IlluminaHumanMethylation450kPMID"             
	#[48] "IlluminaHumanMethylation450kPMID2PROBE"       
	#[49] "IlluminaHumanMethylation450kPROSITE"          
	#[50] "IlluminaHumanMethylation450kRANDOM"           
	#[51] "IlluminaHumanMethylation450kREFSEQ"           
	#[52] "IlluminaHumanMethylation450kSVNID"            
	#[53] "IlluminaHumanMethylation450kSVNREV"           
	#[54] "IlluminaHumanMethylation450kSVNURL"           
	#[55] "IlluminaHumanMethylation450kSYMBOL"           
	#[56] "IlluminaHumanMethylation450kUNIGENE"          
	#[57] "IlluminaHumanMethylation450kUNIPROT"    
	probes<-IlluminaHumanMethylation450k_getProbes()
	str(probes)
	probe_Design_Color<-c(rep("I_R",nrow(probes[["I"]]$R)),rep("I_G",nrow(probes[["I"]]$G)),rep("II",nrow(probes[["II"]])))
	probe_Design<-c(rep("I",nrow(probes[["I"]]$R)),rep("I",nrow(probes[["I"]]$G)),rep("II",nrow(probes[["II"]])))
	ilmn450<-data.frame(rbind(probes[["I"]]$R,probes[["I"]]$G,probes[["II"]]),
			Probe_Design=probe_Design,Probe_Design_Color_Channel=probe_Design_Color)
	dim(ilmn450)
	#	[1] 621078      5
	names(ilmn450)
	#[1] "Probe_ID" "M"        "U" 		"Probe_Design"	"Probe_Design_Color_Channel"
	names(ilmn450)<-c("Probe_ID","M_Address","U_Address","Probe_Design","Probe_Design_Color_Channel")
	length(unique(ilmn450$Probe_ID))
#	[1] 485577
	
	ord<-IlluminaHumanMethylation450k_getProbeOrdering()
	ilmn450_code<-merge(ilmn450,ord,by.x=1,by.y=1)
	dim(ilmn450_code)
#	[1] 621078      7
	names(ilmn450_code)
#	[1] "Probe_ID"      "M_Address"     "U_Address"     "Probe_Design" "Probe_Design_Color_Channel"
#	[5] "DESIGN"        "COLOR_CHANNEL"
	ind<-is.element(ilmn450_code$Probe_ID,ilmn450_code$Probe_ID[duplicated(ilmn450_code$Probe_ID)])
	ilmn450_code2<-ilmn450_code[!ind,]
	dim(ilmn450_code2)
	ilmn450_code<-ilmn450_code[ind,]
	ilmn450_code1<-ilmn450_code[ilmn450_code$DESIGN==as.character(ilmn450_code$Probe_Design),]
	dim(ilmn450_code1)
	nrow(ilmn450_code1)+nrow(ilmn450_code2)
	ilmn450_code<-rbind(ilmn450_code1,ilmn450_code2)
	dim(ilmn450_code)
	save(ilmn450_code,file="c:\\feipan\\manifests\\humanMeth450k\\ilmn450_code.rdata")
	
	head(ord)
	#Probe_ID DESIGN COLOR_CHANNEL
	#1 cg00035864     II          Both
	#2 cg00050873      I           Red
	#3 cg00061679     II          Both
	#4 cg00063477     II          Both
	#5 cg00121626     II          Both
	#6 cg00212031      I           Red
	table(ord$DESIGN)
	#I     II 
	#135501 350076 
	dim(ord)
	#[1] 485577      3
	table(ord$COLOR_CHANNEL)
	#Both    Grn    Red 
	#350076  46298  89203 
	
	ctr<-IlluminaHumanMethylation450k_getControls()
	dim(ctr)
	#[1] 850   4
	names(ctr)
	#[1] "Address"       "Type"          "Color_Channel" "Name"         
	head(ctr)
	#Address     Type Color_Channel          Name
	#1 21630339 STAINING           -99      DNP(20K)
	#2 27630314 STAINING           Red    DNP (High)
	#3 43603326 STAINING        Purple     DNP (Bkg)
	#4 41666334 STAINING         Green Biotin (High)
	#5 24669308 STAINING           -99    Biotin(5K)
	#6 34648333 STAINING          Blue  Biotin (Bkg)
	table(ctr$Type)
	#BISULFITE CONVERSION I BISULFITE CONVERSION II               EXTENSION           HYBRIDIZATION 
	#12                       4                       4                       3 
	#NEGATIVE         NON-POLYMORPHIC                  NORM_A                  NORM_C 
	#614                       4                      32                      61 
	#NORM_G                  NORM_T           SPECIFICITY I          SPECIFICITY II 
	#32                      61                      12                       3 
	#STAINING          TARGET REMOVAL 
	#6                       2 
	ctr.neg<-ctr[ctr$Type=="NEGATIVE",]
	unique(ctr.neg$Address)
	write.csv(ctr.neg,file="c:\\temp\\NegCtlCode450.csv")
	ctl_code<-ctr.neg
	save(ctl_code,file="c:\\temp\\NegCtlCode450.rdata")
	
	gs<-toTable(IlluminaHumanMethylation450kSYMBOL)
	dim(gs)
	#[1] 331594      2
	head(gs)
	#probe_id  symbol
	#1 cg00000029    RBL2
	#2 cg00000108 C3orf35
	#3 cg00000109  FNDC3B
	#4 cg00000236   VDAC3
	#5 cg00000289   ACTN1
	#6 cg00000292  ATP2A1
	gid<-toTable(IlluminaHumanMethylation450kENTREZID)
	dim(gid)
	#[1] 331594      2
	head(gid)
	#probe_id gene_id
	#1 cg00000029    5934
	#2 cg00000108  339883
	#3 cg00000109   64778
	#4 cg00000236    7419
	#5 cg00000289      87
	#6 cg00000292     487
	length(unique(gid$probe_id))
#[1] 331594
	acc<-toTable(IlluminaHumanMethylation450kACCNUM)
	dim(acc)
#	[1] 647767      2
	head(acc)
#	probe_id    accession
#	1 cg00000029    NM_005611
#	2 cg00000108    NM_178339
#	3 cg00000108    NM_178342
#	4 cg00000109 NM_001135095
#	5 cg00000109    NM_022763
#	6 cg00000236 NM_001135694
	length(unique(acc$probe_id))
#	[1] 365088
	alias<-toTable(IlluminaHumanMethylation450kALIAS2PROBE)
	dim(alias)
#	[1] 1445524       2
	head(alias)
#	probe_id alias_symbol
#	1 cg00000029     FLJ26459
#	2 cg00000029         P130
#	3 cg00000029         RBL2
#	4 cg00000029          Rb2
#	5 cg00000108        APRG1
#	6 cg00000108      C3orf35
	length(unique(alias$probe_id))
#	[1] 331594
	refseq<-toTable(IlluminaHumanMethylation450kREFSEQ)
	dim(refseq)
#	[1] 1205102       2
	head(refseq)
#	probe_id accession
#	1 cg00000029 NM_005611
#	2 cg00000029 NP_005602
#	3 cg00000108 NM_178339
#	4 cg00000108 NM_178342
#	5 cg00000108 NP_848029
#	6 cg00000108 NP_848032
	length(unique(refseq$probe_id))
	#[1] 331594
	
	m27<-toTable(IlluminaHumanMethylation450kMETHYL27)
	dim(m27)
	#[1] 485577      2
	head(m27)
	#Probe_ID Methyl27_Loci
	#1 cg00035864             0
	#2 cg00050873             0
	#3 cg00061679             0
	#4 cg00063477             0
	#5 cg00121626             0
	#6 cg00212031             0
	table(m27$Methyl27_Loci)
	#0      1 
	#459599  25978 
	
	nuid<-toTable(IlluminaHumanMethylation450kNUID)
	dim(nuid)
#	[1] 485577      2
	head(nuid)
}
manifest_ilmn_test<-function(){
	datFn<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\dan\\infinium_450_manifest.csv.zip"
	datFn<-"C:\\feipan\\manifests\\humanMeth450k\\infinium 450 manifest.csv"
	dat<-read.delim(file=datFn,as.is=T,stringsAsFactors=F,sep=",")
	names(dat);dim(dat)
	save(dat,file="c:\\feipan\\manifests\\humanMeth450k\\infinium_450_manifest.rdata")
#	[1] "TargetID"                    "ProbeID_A"                  
#	[3] "ProbeID_B"                   "ILMNID"                     
#	[5] "NAME"                        "ADDRESSA_ID"                
#	[7] "ALLELEA_PROBESEQ"            "ADDRESSB_ID"                
#	[9] "ALLELEB_PROBESEQ"            "INFINIUM_DESIGN_TYPE"       
#	[11] "NEXT_BASE"                   "COLOR_CHANNEL"              
#	[13] "FORWARD_SEQUENCE"            "GENOME_BUILD"               
#	[15] "CHR"                         "MAPINFO"                    
#	[17] "SOURCESEQ"                   "CHROMOSOME_36"              
#	[19] "COORDINATE_36"               "STRAND"                     
#	[21] "PROBE_SNPS"                  "PROBE_SNPS_10"              
#	[23] "RANDOM_LOCI"                 "METHYL27_LOCI"              
#	[25] "UCSC_REFGENE_NAME"           "UCSC_REFGENE_ACCESSION"     
#	[27] "UCSC_REFGENE_GROUP"          "UCSC_CPG_ISLANDS_NAME"      
#	[29] "RELATION_TO_UCSC_CPG_ISLAND" "PHANTOM"                    
#	[31] "DMR"                         "ENHANCER"                   
#	[33] "HMM_ISLAND"                  "REGULATORY_FEATURE_NAME"    
#	[35] "REGULATORY_FEATURE_GROUP"    "DHS"            
	table(dat$INFINIUM_DESIGN_TYPE)
#	I     II 
#	135501 350076 
	head(dat$UCSC_REFGENE_NAME)
#	"VDAC3;VDAC3"       "ACTN1;ACTN1;ACTN1"
	dat<-dat[order(dat$TargetID),]
	library(mAnnot)
	data(meth450)
	meth450<-meth450[order(meth450$IlmnID),]
	all(meth450$IlmnID==dat$TargetID)
	meth450$UCSC_REFGENE_NAME<-dat$UCSC_REFGENE_NAME
	save(meth450,file="c:\\temp\\meth450.rdata")
	
	table(dat$UCSC_REFGENE_NAME=="")
#	FALSE   TRUE 
#	365860 119717
	head(dat$UCSC_REFGENE_GROUP)
#	"TSS1500"           "Body;3'UTR"        "Body;Body"
	head(dat$UCSC_REFGENE_ACCESSION)
#	"NM_001135095;NM_022763"              ""
	table(dat$UCSC_REFGENE_ACCESSION!="")
#	FALSE   TRUE 
#	119717 365860
}
assay_450k_test<-function(){
	library(rapid.db)
	con<-dbCon()
	dat<-dbQuery(con,"assay_450k")
	dim(dat);names(dat)
#	[1] 485836     31
#	[1] "Name"                    "AddressA_ID"            
#	[3] "AlleleA_ProbeSeq"        "AddressB_ID"            
#	[5] "AlleleB_ProbeSeq"        "InfiniumDesignType"     
#	[7] "Next_Base"               "Color_Channel"          
#	[9] "FORWARD_SEQUENCE"        "GenomeBuild"            
#	[11] "Chr"                     "MAPINFO"                
#	[13] "SOURCESEQ"               "CHROMOSOME_36"          
#	[15] "COORDINATE_36"           "PROBE_SNPS"             
#	[17] "PROBE_SNPS_10"           "ucscRefGene_NAME"       
#	[19] "ucscRefGene_ACCESSION"   "ucscRefGene_GROUP"      
#	[21] "ucscCpgIslands_NAME"     "ucscCpgIslands_GROUP"   
#	[23] "Fantom"                  "DMR"                    
#	[25] "Enhancer"                "HMM_Island"             
#	[27] "RegulatoryFeature_NAME"  "RegulatoryFeature_GROUP"
#	[29] "DHS"                     "Manifest_Revision"      
#	[31] "CPG_ISLAND"             
#	
	table(dat$Chr)
#	1    10    11    12    13    14    15    16    17    18    19     2 
#	72 46867 24409 28805 24555 12301 15087 15261 21982 27888  5925 25526 34830 
#	20    21    22     3     4     5     6     7     8     9     X     Y 
#	10383  4246  8558 25173 20487 24344 36629 30023 20966  9869 11234   416 
	length(unique(dat$ucscRefGene_NAME)) #42457
	length(unique(dat$ucscRefGene_ACCESSION)) #52671
	dbDisconnect(con)
}
#####################
#
#####################
#Loaded 114142980 letters in 1 sequences
#Searched 615050 bases in 12301 sequences
#Loaded 242951149 letters in 1 sequences
#Searched 1741500 bases in 34830 sequences
#Loaded 199501827 letters in 1 sequences
#Searched 1258650 bases in 25173 sequences
#Loaded 191273063 letters in 1 sequences
#Searched 1024350 bases in 20487 sequences
#Loaded 180857866 letters in 1 sequences
#Searched 1217200 bases in 24344 sequences
#Loaded 170899992 letters in 1 sequences
#Searched 1831450 bases in 36629 sequences
#Loaded 158821424 letters in 1 sequences
#Searched 1501150 bases in 30023 sequences
#Loaded 146274826 letters in 1 sequences
#Searched 1048300 bases in 20966 sequences
#Loaded 135374737 letters in 1 sequences
#Searched 1220450 bases in 24409 sequences
#Loaded 134452384 letters in 1 sequences
#Searched 1440250 bases in 28805 sequences
#Loaded 132349534 letters in 1 sequences
#Searched 1227750 bases in 24555 sequences
#Loaded 140273252 letters in 1 sequences
#Searched 493450 bases in 9869 sequences
#Loaded 106368585 letters in 1 sequences
#Searched 754350 bases in 15087 sequences
#Loaded 100338915 letters in 1 sequences
#Searched 763050 bases in 15261 sequences
#Loaded 88827254 letters in 1 sequences
#Searched 1099100 bases in 21982 sequences
#Loaded 78774742 letters in 1 sequences
#Searched 1394400 bases in 27888 sequences
#Loaded 76117153 letters in 1 sequences
#Searched 296250 bases in 5925 sequences
#Loaded 63811651 letters in 1 sequences
#Searched 1276300 bases in 25526 sequences
#Loaded 62435964 letters in 1 sequences
#Searched 519150 bases in 10383 sequences
#Loaded 46944323 letters in 1 sequences
#Searched 212300 bases in 4246 sequences
#Loaded 49691432 letters in 1 sequences
#Searched 427900 bases in 8558 sequences
#Loaded 154913754 letters in 1 sequences
#Searched 561700 bases in 11234 sequences
#Loaded 57772954 letters in 1 sequences
#Searched 20800 bases in 416 sequences

blat_alignment<-function(){
	library(rapid.db)
	library(mAnnot)
	outDir<-"c:\\feipan\\manifests\\humanMeth450k\\alignment"
	con<-dbCon()
	dat<-dbQuery(con,"assay_450k")
	dat<-dat[,c("Name","Chr","ucscRefGene_NAME","SOURCESEQ","COORDINATE_36")]
	dat<-dat[dat$Chr!="",]  #TRUE 72
	dat<-dat[dat$Chr=="1",] #dat<-dat[is.element(dat$Chr,c("1","2","3"),]
	dim(dat)
	blatSeq2(dat,dir.wk=outDir)
	rst<-parse_Blat2.2(outDir,fn=NULL,out.dir=outDir)
	
	align.all<-NULL
	fns<-list.files(outDir,patte=".csv")
	for(fn in fns){
		align_rst<-read.delim(file=fn,sep=",",stringsAsFactors=F,as.is=T)
		max.mismatch<-2
		align_rst<-align_rst[align_rst$match>=(align_rst$size-max.mismatch),]
		align.nameID<-as.character(lapply(strsplit(as.character(align_rst$name),"_"),function(x)x[1]))
		cat(length(unique(align.nameID)),"\n")
		align_rst<-cbind(nameID=align.nameID,align_rst[,c("Chr","strand","start","end","match","size")])
		if(is.null(align.all)) align.all<-align_rst
		else align.all<-rbind(align.all,align_rst)
	}
	save(align.all,file=file.path(outDir,"blat_align_all.rdata"))
	
	#select the nearest and mark the duplicate
	library(rapid.pro)
	data(HumanMethylation450.adf)
	dat<-HumanMethylation450.adf[,c("ILMNID","CHR","MAPINFO","SOURCESEQ")] #485577
	
	
	#build36
	outDir<-"c:\\feipan\\manifests\\humanMeth450k\\alignment"
	load(file=file.path(outDir,"blat_align_all.rdata"))
	dim(align.all)    #486431      7
	length(unique(align.all$nameID)) #485764
	dat<-HumanMethylation450.adf[,c("ILMNID","CHR","SOURCESEQ","COORDINATE_36")] #485577
	dim(dat) #485577      4
	align.all<-merge(align.all,dat,by.x=1,by.y=1)
	dim(align.all) #486179     10
	mid<-align.all$start+(align.all$end-align.all$start)/2
	dis<-abs(as.numeric(align.all$COORDINATE_36)-mid)
	table(dis<=25)
#	FALSE   TRUE 
#	633 485428 
	align.all$dis<-dis
	write.csv(align.all,file=file.path(outDir,"blat_align_all.csv"))
	
	align.cm<-align.all[align.all$match==align.all$size,] 
	dim(align.cm) #485539
	table(align.cm$dis<=25)
#	FALSE   TRUE 
#	34 485387 

	dup<-is.element(align.all$nameID,align.all$nameID[duplicated(align.all$nameID)])
	align.unique.cm<-align.all[(!dup)&align.all$match==align.all$size,] 
	dim(align.unique.cm) #485051
	table(align.unique.cm$dis<=25)
	table(align.unique.cm$CHR)
	write.csv(align.unique.cm,file=file.path(outDir,"blat_align_unique.cm.csv"))
	
	#build37
	outDir<-"c:\\feipan\\manifests\\humanMeth450k\\alignment_build37"
	load(file=file.path(outDir,"blat_align_all.rdata"))
	dim(align.all) #486347  7
	length(unique(align.all$nameID)) #485764
	dim(dat) #485577      4
	align.all<-merge(align.all,dat,by.x=1,by.y=1) 
	length(unique(align.all$nameID)) #485512
	mid<-align.all$start+(align.all$end-align.all$start)/2
	dis<-abs(align.all$MAPINFO-mid)
	table(dis<=25)
#	FALSE   TRUE 
#	613 485482
	table(dis>500)
#	FALSE   TRUE 
#	485574    521 
	align.all$dis<-abs(align.all$MAPINFO-mid)
	
	align.cm<-align.all[align.all$match==align.all$size,] 
	dim(align.cm) #485456  11
	length(unique(align.cm$nameID)) #485440
	save(align.cm,file=file.path(outDir,"blat_align_cpmatch.rdata"))
	
	#ord<-is.element(align.all$nameID,align.all$nameID[duplicated(align.all$nameID)])
	#cm<-align.all$match==align.all$size
	ord<-is.element(align.cm$nameID,align.cm$nameID[duplicated(align.cm$nameID)])
	align.all.nodup.cm<-align.cm[(!ord),]
	dim(align.all.nodup.cm)  #485438
	ind<-align.all.nodup.cm$dis<=25
	table(ind)
	align.all2<-align.all.nodup.cm[ind,]
	dim(align.all2) #485437
	save(align.all2,file=file.path(outDir,"blat_align2.rdata"))
	blat.align<-align.all2[,c("nameID","CHR","start","end","MAPINFO","strand","SOURCESEQ")];
	names(blat.align)<-c("IlmnID","Chr","start","end","mapInfo","strand","srcseq")
	save(blat.align,file=file.path(outDir,"blat_align.rdata"))

	align.all.dup<-align.all[ord,]
	align.all.2<-split(align.all.dup,align.all.dup$nameID)
	align.2.unique<-sapply(align.all.2,function(x)x[which.min(x$dis),])
	align.unique<-rbind(align.all[!ord,],align.2.unique)
	dim(align.unique)
	save(align.unique,file=file.path(outDir,"align.unique.rdata"))
	
	table(align.unique$dis<=24)
	align.all2<-align.all[dis<24,]
	
	###
	align.all<-align.all[order(align.all$nameID),]
	ord<-order(dis,decreasing=F)
	align.all.ord<-align.all[ord,]
	ind2<-!duplicated(align.all.ord$nameID)
	align.unique<-align.all.ord[ind2,]
	dim(align.unique)
	
	ind3<-!ind2
	align.all<-cbind(align.all.ord,is_duplicated=ind3)
	dat<-unclass(Sys.time())
	fn.out<-file.path(out.dir,paste("align.all_",dat,".csv",sep=""))
	write.table(align.all.o,file=fn.out,sep=",",row.names=F)
	write.table(align.unique,file=file.path(out.dir,paste("align.unique_",dat,".csv",sep="")),
			sep=",",row.names=F)
	save(align.unique,file=paste("align.unique_",dat,".csv",sep=""))
	
	pid.dup<-align.all$nameID[align.all$is_duplicated==TRUE]
	align.unique<-align.all[align.all$is_duplicated==FALSE,]
	dim(align.unique)
	ind.unique<-is.element(align.unique$nameID,pid.dup)
	table(ind.unique)
	align.rst<-data.frame(align.unique,un_uniqueness=ind.unique)
	write.table(align.rst,file=file.path(out.dir,"align.unique.csv"),sep=",",row.names=F)
	#align_rst.all<-report_align(rst,dat,out.dir=outDir)
	dbDisconnect(con)
	
}
blat_align_batch_test<-function(){
	outdir<-"c:\\temp\\test1"
	blat_align_batch(outdir=outdir)
}
blat_align_batch<-function(build="37",platform="meth450k",outdir=NULL,start=F){
	chrs<-c(1:22,"X","Y")
	if(is.null(outdir))outdir<-paste("/auto/uec-02/shared/production/methylation/database/",platform,"/alignment_",build,sep="")
	if(!file.exists(outdir))dir.create(outdir)
	if(build=="37"){
		for(chr in chrs){
			code<-paste("/auto/uec-02/shared/production/methylation/database/tools/blat/blat -minScore=10 -tileSize=6 /auto/uec-02/shared/production/methylation/database/NCBI/build.37.1/hs_ref_GRCh37_chr",
					chr,".fa /auto/uec-02/shared/production/methylation/database/",platform,"/srcseq/query_",
					chr,".fa /auto/uec-02/shared/production/methylation/database/",platform,"/alignment_37/blat_out.chr",
					chr,".txt",sep="")
			fn<-paste("blat.chr",chr,".sh",sep="")
			write(code,file=file.path(outdir,fn))
		}
	}else if(build=="36"){
		for(chr in chrs){
			code<-paste("/auto/uec-02/shared/production/methylation/database/tools/blat/blat -minScore=10 -tileSize=6 /auto/uec-02/shared/production/methylation/database/hg18_seq/chr",
					chr,".fa /auto/uec-02/shared/production/methylation/database/",platform,"/srcseq/query_",
					chr,".fa /auto/uec-02/shared/production/methylation/database/",platform,"/alignment_36/blat_out.chr",
					chr,".txt",sep="")
			fn<-paste("blat.chr",chr,".sh",sep="")
			write(code,file=file.path(outdir,fn))
		}
	}
	write(paste("cd ",outdir),file=file.path(outdir,"run.sh"))
	for(chr in chrs){
		code<-paste("qsub -N Align -q laird -l walltime=10:00:00 -l nodes=1:ppn=8 blat.chr",chr,".sh",sep="")
		write(code,file=file.path(outdir,"run.sh"),append=T)
	}
	if(start==T){system(paste("chmod +x",file.path(outdir,"run.sh")),wait=F);system(file.path(outdir,"run.sh"),wait=F)}
}
blat_align_batch.1<-function(){
	chrs<-c(1:22,"X","Y")
	outdir<-"/auto/uec-02/shared/production/methylation/database/meth450k/alignment_37"
	for(chr in chrs){
		code<-paste("/auto/uec-02/shared/production/methylation/database/tools/blat/blat -minScore=10 -tileSize=6 /auto/uec-02/shared/production/methylation/database/NCBI/build.37.1/hs_ref_GRCh37_chr",
				chr,".fa /auto/uec-02/shared/production/methylation/database/meth450k/srcseq/query_",
				chr,".fa /auto/uec-02/shared/production/methylation/database/meth450k/alignment_37/blat_out.chr",
				chr,".txt",sep="")
		fn<-paste("blat.chr",chr,".sh",sep="")
		write(code,file=file.path(outdir,fn))
	}
	
	for(chr in chrs){
		code<-paste("qsub -N Align -q laird -l walltime=100:00:00 -l nodes=1:ppn=8 blat.chr",chr,".sh",sep="")
		write(code,file=file.path(outdir,"run.sh"),append=T)
	}
	outdir<-"/auto/uec-02/shared/production/methylation/database/meth450k/alignment_36"
	for(chr in chrs){
		code<-paste("/auto/uec-02/shared/production/methylation/database/tools/blat/blat -minScore=10 -tileSize=6 /auto/uec-02/shared/production/methylation/database/hg_seq18",
				chr,".fa /auto/uec-02/shared/production/methylation/database/meth450k/srcseq/query_",
				chr,".fa /auto/uec-02/shared/production/methylation/database/meth450k/alignment_36/blat_out.chr",
				chr,".txt",sep="")
		fn<-paste("blat.chr",chr,".sh",sep="")
		write(code,file=file.path(outdir,fn))
	}
}
getFlankSeq_test<-function(){
	outDir<-"c:\\feipan\\manifests\\HumanMeth450k"
	seq.all<-getFlankSeq()
	save(seq.all,file=file.path(outDir,"flank500.hg19.rdata"))
	seq.all<-getFlankSeq(len=50,outdir=outDir)
	save(seq.all.file=file.path(outDir,"flank100.hg19.rdata"))
	seq.all<-getFlankSeq(build="hg18")
	save(seq.all,file=file.path(outDir,"flank500.hg18.rdata"))
	seq.all<-getFlankSeq(len=50,build="hg18")
	save(seq.all,file=file.path(outDir,"flank100.hg18.rdata"))
}


calSrcSeqStat<-function(){
	library(rapid.db)
	con<-dbCon()
	meth450<-dbQuery(con,"assay_450k")
	names(meth450) #485836
	srcSeq<-meth450$SOURCESEQ;names(srcSeq)<-meth450$Name
	srcSeq.len<-sapply(srcSeq,function(x)nchar(x))
	table(srcSeq.len)
#	srcSeq.len
#	0     50 
#	72 485764 
	srcSeq.1<-gsub("CG","H",toupper(meth450$SOURCESEQ))
	srcSeq.2<-sapply(srcSeq.1,function(x)strsplit(x,"")[[1]])
	srcSeq.ind<-sapply(srcSeq.2,function(x)length(grep("H",x)))
	table(srcSeq.ind)
	srcSeq[srcSeq.ind==11]
	dbDisconnect(con)
}
localAlign_test<-function(){
	seq1<-"ATCGACGAGGAGTAGAA"
	seq2<-"TAATTATCGACGAGGAGTAGAATA"
	localAlign(seq1,seq2)
	matchPattern(DNAString(seq1),DNAString(seq2))
	seq2<-"AAATTATCGACGAGGAGTAGAAATCGACGAGGAGTAGAA"
	localAlign(seq1,seq2)
	seq2<-"ATCGACGAGGAGTAGAAAATTTTTCTACTCCTCGTCGATAA"
	localAlign(seq1,seq2)
}
localAlign<-function(seq1,seq2){
	if(nchar(seq1)>nchar(seq2))return()
	seq1<-toupper(seq1);len1<-nchar(seq1)
	seq2<-toupper(seq2);len2<-nchar(seq2)
	rst<-c();strand<-c()
	for(i in 1:(len2-len1+1)){
		seq2a<-substr(seq2,i,(i+len1-1))
		if(seq1==seq2a){
			rst<-c(rst,i)
			strand<-c(strand,"+")
		}else if(seq1==as.character(reverseComplement(DNAString(seq2a)))){
			rst<-c(rst,i)
			strand<-c(strand,"-")
		}
	}
	return(list(rst,strand))
}
localAlignMeth450<-function(){
	library(rapid.pro)
	data(HumanMethylation450.adf)
	meth<-HumanMethylation450.adf
	chrs<-c(1:22,"X","Y")
	rst<-list();nm<-c()
	for(chr in chrs){
		ord<-meth$Chr==chr
		meth.seq<-meth[ord,"SOURCESEQ"]
		seq100<-load(file=file.path(datDir,paste("seq.flank100.chr",chr,".rdata")))
		meth.seq<-meth.seq[names(seq100)]
		nm<-c(nm,names(seq100))
		for(i in 1:length(meth.seq)){
			rst<-list(rst,localAlign(meth.seq[i],seq100[i]))
		}
	}
	names(rst)<-nm
	return(rst)
}
####################
# ftp://ftp.ncbi.nih.gov/gene/DATA/gene_info.gz
# ftp://ftp.ncbi.nih.gov/gene/DATA/gene2accession.gz
# by ucsc_ref_acc
####################
annot_EntrezGeneID_test<-function(){
	datFn<-"c:\\feipan\\database\\NCBI\\gene\\gene2accession"
	outFn<-"c:\\feipan\\manifests\\humanMeth450k\\entrezGene.rdata"
	annot_EntrezGeneID(datFn,outFn)
	print(load(file=outFn))
}
annot_EntrezGeneID<-function(datFn=NULL,outFn=NULL){
	library(rapid.pro)
	data(HumanMethylation450.adf)
	meth450<-HumanMethylation450.adf
	geneAcc<-read.delim(datFn,sep="\t",header=F,stringsAsFactors=F)
	names(geneAcc)<-c("tax_id","GeneID","status","RNA_nucleotide_accession.version","RNA_nucleotide_gi","protein_accession.version","protein_gi","genomic_nucleotide_accession.version","genomic_nucleotide_gi","start_position_on_the_genomic_accession","end_position_on_the_genomic_accession","orientation","assembly")
	geneAcc<-geneAcc[geneAcc$tax_id=="9606",]
	meth450.accession<-meth450$REFGENE_ACCESSION;names(meth450.accession)<-meth450$ILMNID
	meth450.accession<-sapply(meth450.accession,function(x)strsplit(x,";")[[1]])
	meth450.ilmn<-c();meth450.accession.all<-c();nn<-names(meth450.accession)
	for(i in 1:length(meth450.accession)){
		meth450.accession.all<-c(meth450.accession.all,meth450.accession[[i]])
		meth450.ilmn<-c(meth450.ilmn,rep(nn[i],length(meth450.accession[[i]])))
	}
	entrez.accession<-geneAcc$RNA_nucleotide_accession.version
	entrez.accession<-sapply(entrez.accession,function(x)strsplit(x,"\\.")[[1]][1])
	table(is.element(meth450.accession.all,entrez.accession))
	meth450.accession.all<-data.frame(ucscRefGene_ACCESSION=meth450.accession.all,IlmnID=meth450.ilmn,stringsAsFactors=F)
	entrez.accession<-data.frame(Entrez_Accession=entrez.accession,GeneID=geneAcc$GeneID,stringsAsFactors=F)
	meth450.gid<-merge(meth450.accession.all,entrez.accession,by.x=1,by.y=1)
	length(unique(meth450.gid$IlmnID))
	length(unique(meth450.gid$GeneID))
	if(is.null(outFn))outFn<-"EntrezGeneAnnot_Meth450k.rdata"
	save(meth450.gid,file=outFn)
}

annot_Accession2GID_test<-function(){
	datFn<-"C:\\feipan\\manifests\\humanMeth450k\\accession\\entrezAccessionAnnot.rdata"
	outFn<-"c:\\feipan\\manifests\\humanMeth450k\\accession\\meth450Acc2GID.rdata"
	print(load(file=datFn))
	names(meth450.gid)
	annot<-annot_Accession2GID(datFn,outFn)
	table(annot$EntrezGeneID==annot$GeneID)
}
annot_Accession2GID<-function(datFn,outFn){
	annot<-get(print(load(file=datFn)))
	gid.n<-tapply(annot$GeneID,annot$IlmnID,function(x)length(unique(x)))
#	table(gid.n>1)
#	FALSE   TRUE 
#	332141  33245
	ind<-gid.n==1
	gid<-tapply(annot$GeneID,annot$IlmnID,function(x)x[1])
	#filtering
	gid<-gid[ind]
	gid<-data.frame(ilmnID=names(gid),GeneID=gid)
	data(meth450)
	annotGid<-merge(meth450,gid,by.x=1,by.y=1,all.x=T)
	save(annotGid,file=outFn)
	return(annotGid)
}
create_Infinium450kACC_Table<-function(){
	con<-dbCon("C:\\Documents and Settings\\feipan\\Desktop\\people\\tejas\\testTab.db")
	dat<-get(load(file="C:\\feipan\\manifests\\humanMeth450k\\accession.all.rdata"))
	dat2<-data.frame(IlmnID=names(dat),ACCESSION=dat)
	dbWrite(con,dat2,"Infinium450kACC")
	dbDisconnect(con)
}
annot_EntrezGeneID2_test<-function(){
	tssAnnotFn<-"C:\\feipan\\manifests\\humanMeth450k\\annotTSS\\annot.all.rdata"
	datPath<-"c:\\feipan\\manifests\\humanMeth450k\\annotTSS"
	annot_EntrezGeneID2(tssAnnotFn,datPath)
}
annot_EntrezGeneID2<-function(tssAnnotFn=NULL,max.dis=2000,datPath=NULL){
	library(mAnnot)
	data(meth450)
	annotTSS<-NULL
	if(!is.null(tssAnnotFn))annotTSS<-get(print(load(tssAnnotFn)))
	else annotTSS<-annot_TSS()
	dat<-merge(meth450,annotTSS,by.x="IlmnID",by.y="IlmnID",all.x=T)
	dat<-dat[order(dat$IlmnID),]
	meth450<-meth450[order(meth450$IlmnID),]
	dat$GeneIDbyDis2000<-ifelse(dat$dis<=max.dis,dat$geneID,NA) #249517
	dat$GeneIDbyDis1500<-ifelse(dat$dis<=1500,dat$geneID,NA)  #234276
	dat$GeneIDbyDis5000<-ifelse(dat$dis<=5000,dat$geneID,NA) #315453
	#meth450$GeneID<-ifelse(!is.na(meth450$GeneID),gene450$GeneID,annotTSS$geneID)
	meth450$GeneIDbyDis<-dat$GeneIDbyDis2000
	if(is.null(datPath))datPath<-"c:\\feipan\\manifests\\humanMeth450k"
	save(meth450,file=file.path(datPath,"meth450Gene.rdata"))
	save(dat,file=file.path(datPath,"meth450.all.rdata"))
}
annot_EntrezGeneID3_test<-function(){
	datFn<-"c:\\feipan\\manifests\\humanMeth450k\\infinium_450_manifest.rdata"
	gidAnnot<-annot_EntrezGeneID3(datFn)
	save(gidAnnot,file="c:\\manifests\\humanMeth450k\\gidAnnot3.rdata")
}
annot_EntrezGeneID3<-function(gs2gid=NULL){
	library(mAnnot);data(meth450)
	if(is.null(gs2gid)){
		con<-dbCon()
		entrez<-dbQuery(con,"EntrezGeneSynonym")
		dbDisconnect(con)
		gs2gid<-entrez$GeneID;names(gs2gid)<-entrez$Synonym
	}
	refgene<-meth450$UCSC_REFGENE_NAME
	gid<-sapply(refgene,function(x){
				symbol<-strsplit(x,";")[[1]]
				gids<-gs2gid[symbol]
				gids<-unique(gids[!is.na(gids)])
				if(length(gids)>1)gids<-paste(gids,collapse=";")
				return(gids)
			})
	gid.len<-sapply(gids,function(x)length(strsplit(x,";")[[1]][1]))
	show(table(gid.len))
	names(gid)<-meth450$IlmnID
	gid<-gid[gid.len==1]
	return(gid)
}
create_entrezGeneSyn<-function(datFn,outFn){
	entrezGene<-read.delim(file=gzfile(datFn),sep="\t",stringsAsFactors=F,skip=1,head=F)
	names(entrezGene)<-c("tax_id","GeneID","Symbol","LocusTag","Synonyms","dbXrefs","chromosome","map_location","description","type_of_gene","Symbol_from_nomenclature_authority","Full_name_from_nomenclature_authority","Nomenclature_status","Other_designations","Modification_date")
	entrezGene<-entrezGene[entrezGene$tax_id=="9606",]
	EntrezIDSynonyms<-entrezGene[,c("GeneID","Symbol")]
	names(EntrezIDSynonyms)<-c("GeneID","Synonym")
	for(i in 1:nrow(entrezGene)){
		gid<-entrezGene[i,"GeneID"]
		synonyms<-sapply(entrezGene$Synonyms[i],function(x)strsplit(as.character(x),"\\|")[[1]])
		for(syn in synonyms){
			syn2<-data.frame(GeneID=as.character(gid),Synonym=as.character(syn),stringsAsFactors=F)
			EntrezIDSynonyms<-rbind(EntrezIDSynonyms,syn2)
		}
	}
	save(EntrezIDSynonyms,file=outFn)
}
########################
# 04/13/2011
##########################
annot_rmsp<-function(){
	#preprocess prepare data
	data.wk<-"C:\\feipan\\database\\ucsc\\rmsk"
	setwd(data.wk)
	flist<-list.files(pattern=".txt")
	rsmp.all<-NULL
	for(i in 1:length(flist)){
		chr<-strsplit(flist[i],"_")[[1]][1]
		dat<-read.delim(file=flist[i],sep="\t",header=F)
		rsmp.chr<-dat[,c(12,6,7,8,11,13)]
		names(rsmp.chr)<-c("Class","Chr","start","end","Name","Family")
		rsmp.chr["mapInfo"]<-rsmp.chr$start+(rsmp.chr$end-rsmp.chr$start)/2
		if(is.null(rsmp.all)){
			rsmp.all<-rsmp.chr
		}else{
			rsmp.all<-rbind(rsmp.all,rsmp.chr)
		}
	}
	save(rsmp.all,file="rsmp.all.rdata")
	
	#alignment and calculation
	infinium.info<-getMapInfo.meth450()
	infinium.minfo.chr<-split(infinium.info,infinium.info$Chr)
	
	load(file=file.path("C:\\feipan\\database\\ucsc\\rmsk","rsmp.all.rdata"))
	rtype.1<-unique(rsmp.all$Class)
	rtype<-as.character(rtype.1) #c("Simple_repeat","LINE","SINE","LTR","Low_complexity")
	type.len<-length(rtype) #15
	rsmp.type<-split(rsmp.all,rsmp.all$Class)
	rst.all <- NULL
	
	out.dir<-"C:\\feipan\\manifests\\HumanMeth450k\\rmsk"
	setwd(out.dir)
	for(i in 1:type.len){
		rtype1<-rtype[i]
		ind<-rsmp.all$Class==rtype1
		rsmp.all.type <- rsmp.all[ind,]
		rstp.all.type.chr<-split(rsmp.all.type,rsmp.all.type$Chr)
		
		rst<-findNN.5(infinium.minfo.chr,rstp.all.type.chr)
		fn1<-file.path(out.dir,paste("rst.all_",i,"_",rtype1,".csv",sep=""))
		write.table(rst,file=fn1,sep=",",row.names=F)
	}
	
	#post-process
	out.dir<-"C:\\feipan\\database\\ucsc\\hg19\\repeatMask\\rst" ##	out.dir<-"C:\\feipan\\manifests\\HumanMeth450k\\rmsk"
	setwd(out.dir)
	flist<-list.files(pattern=".csv")
	for(i in 1:length(flist)){
		rst<-read.csv(file=flist[i])
		rst.new<-rst[,c("IlmnID","Chr","start.1","end.1","Family","dist")] #rst[,c(1,9,10,12,14)]
		rtype1<-paste(strsplit(strsplit(flist[i],"\\.")[[1]][2],"_")[[1]][c(-1,-2)],collapse="_") #rst[1,c("Family")]
		names(rst.new)<-c("IlmnID","Chr","Start_Of_Repeat","End_of_Repeat","Type_of_Repeat",paste("Distance_to_the_mid_of_the_closest_",rtype1,sep=""))
		rst.new$Overlap_with_Repeat<-rst$mapInfo<=rst.new$End_of_Repeat & rst$mapInfo>=rst.new$Start_Of_Repeat
		table(rst.new$Overlap_with_Repeat)
		cat("working on ",i,"\n")
		fn<-paste("rst.new_",i,"_",rtype1,".rdata",sep="")
		save(rst.new,file=file.path(out.dir,fn))
	}
	
	rst.all<-NULL
	flist<-list.files(pattern=".rdata")
	for(i in 1:length(flist)){
		fn<-flist[i]
		rr<-strsplit(fn,"\\.")[[1]][2]
		rtype<-substr(rr,7,nchar(rr))
		#cat("rtype: ",rtype,"\n")
		print(load(file=file.path(out.dir,fn)))
		#cat(table(rst.new[,6]),"\n")
		rst.1<-rst.new[rst.new$Overlap_with_Repeat==TRUE,]
		names(rst.1)<-c("IlmnID","Chr","Start_Of_Repeat","End_of_Repeat","Type_of_Repeat",
				"Distance_to_the_mid_of_the_closest","Overlap_with_Repeat")
		if(is.null(rst.all)){
			rst.all<-rst.1
		}else{
			if(!is.null(rst.1)){
				if(ncol(rst.1)>0)rst.all<-rbind(rst.all,rst.1)
			}
		}
	}
	#setwd("c:\\feipan\\manifests\\humanMeth450k\\repeatAnnot\\36")
	save(rst.all,file="rst.all.rdata")
	write.table(rst.all,file="rst.all.csv",sep=",",row.names=F)
	
	#filter
	setwd("C:/feipan/database/ucsc/hg19/repeatMask")
	load(file="rst.all.rdata")
	dim(rst.all) #77748 7
	names(rst.all)
	length(unique(rst.all$IlmnID)) #77610
	library(rapid.pro)
	infinium.minfo<-get(data(HumanMethylation450.adf)) 
	manifest.new<-merge(rst.all,infinium.minfo,by.x=1,by.y=1,all.y=T)	
	length(unique(rst.all[,1])) #not unique
	manifest.new$Overlap_with_at_least_one_type_repeat<-ifelse(is.na(manifest.new[,7])|manifest.new[,7]==F,F,TRUE)
	table(manifest.new$Overlap_with_at_least_one_type_repeat)
	dim(manifest.new) #485715
	write.table(manifest.new,file="manifest.rmsp.csv",sep=",",row.names=F)
	save(manifest.new,file="manifest.rmsp.rdata")
	
	
	library(mAnnot);data(blat_align)
	dim(blat.align);names(blat.align)
	blat.align<-blat.align[,c("IlmnID","start","end","mapInfo")]
	names(blat.align)<-c("IlmnID","blat_start","blat_end","mapInfo")
	manifest.new2<-merge(manifest.new,blat.align,by.x=1,by.y=1)
	start<-ifelse(manifest.new2$blat_start>manifest.new2$Start_Of_Repeat,manifest.new2$blat_start,manifest.new2$Start_Of_Repeat)
	end<-ifelse(manifest.new2$blat_end>manifest.new2$End_of_Repeat,manifest.new2$End_of_Repeat,manifest.new2$blat_end)
	manifest.new2$overlap_len<-sapply(manifest.new2$SOURCESEQ,nchar)
	manifest.new2<-manifest.new2[manifest.new2$overlap_len>25,]
	dis.start<-abs(manifest.new2$Start_Of_Repeat-manifest.new2$mapInfo)
	dis.end<-abs(manifest.new2$End_of_Repeat-manifest.new2$mapInfo)
	manifest.new2$Distance_to_edge_of_the_closest_repeat<-ifelse(dis.start<dis.end,dis.start,dis.end)
	manifest.new2$repeats_within_5bp<-manifest.new2$Distance_to_edge_of_the_closest_repeat<=5
	table(manifest.new2$repeats_within_5bp)
#	FALSE  TRUE 
#	71098  6650 
	manifest.new2$repeats_within_10bp<-manifest.new2$Distance_to_edge_of_the_closest_repeat<=10
	table(manifest.new2$repeats_within_10bp)
#	FALSE  TRUE 
#	64743 13005 
	manifest.new2$repeats_within_20bp<-manifest.new2$Distance_to_edge_of_the_closest_repeat<=20
	table(manifest.new2$repeats_within_20bp)
#	FALSE  TRUE 
#	56572 21176 
	manifest.new2$covered_with_repeats<-manifest.new2$mapInfo<=manifest.new2$End_of_Repeat&manifest.new2$mapInfo>=manifest.new2$Start_Of_Repeat
	
	dim(manifest.new2) #485575
	#manifest.new2<-manifest.new[order(manifest.new[,6],decreasing=F),] #"Distance_to_the_mid_of_the_closest"
	manifest.new2<-manifest.new2[order(manifest.new2$Distance_to_edge_of_the_closest,decreasing=F),]
	manifest.new2<-manifest.new2[!duplicated(manifest.new2$IlmnID),]
	dim(manifest.new2)#485437
	repeatAnnot<-manifest.new2
	save(repeatAnnot,file="manifest.rmsp2_05072011.rdata")
	write.csv(manifest.new2,file="manifest.rmsp2_05072011.csv",row.names=F)
	
	rst.all$IlmnID=as.vector(rst.all$IlmnID)
	rst.all$Type_of_Repeat=as.vector(rst.all$Type_of_Repeat)
	rst.all.id<-split(rst.all,as.factor(as.character(rst.all[,1])))
	rst.all.unique<-t(sapply(rst.all.id,function(x)x[which(x[,6]==min(x[,6])),]))
	write.table(rst.all.unique,file="rst.all.unique.csv",sep=",",row.names=F)
	
	#check
	rst.all[(duplicated(rst.all[,1])),]
	rst.all[(rst.all[,1]=="cg25095951"),]
	rst.all.unique[rst.all.unique[,1]=="cg25095951"]
	
	rst.all.unique<-read.table(file=file.path(out.dir,"rst.all.unique.csv"),head=T,sep=",")
	table(overlap_with_at_least_one_Repeat)
	manifest.new$overlap_with_at_least_one_type_Repeat<-overlap_with_at_least_one_Repeat
	manifest.new$distance_to_the_closest_one_type_Repeat<-distance_to_the_closest_one_type_Repeat
	
	
}
annot_rmsp_batch<-function(){
	outdir<-"/auto/uec-02/shared/production/methylation/database/meth450k/manifest/rmsk/hg19/batch2"
	for(i in 1:15){ #16
		code<-readLines("annot_rmsk.R")
		code[2]<-paste("i<-",i,sep="")
		fn<-paste("annot_rmsk",i,".R",sep="")
		write(code,file=file.path(outdir,fn))
	}
	
	outdir<-file.path(getwd(),"batch2")
	for(i in 1:15){
		code<-readLines("annot_rmsk.sh")
		code[5]<-"cd /auto/uec-02/shared/production/methylation/database/meth450k/manifest/rmsk/hg19/batch2"
		code[6]<-paste("/auto/uec-00/shared/production/software/R/bin/Rscript"," annot_rmsk",i,".R",sep="")
		fn<-paste("annot_rmsk",i,".sh",sep="")
		write(code,file=file.path(outdir,fn))
	}
	
	code<-c()
	for(i in 1:15){
		code<-paste(code,"\nqsub annot_rmsk",i,".sh",sep="")
		write(code,file=file.path(outdir,"run.sh"))
	}
	system(file.path(outdir,"run.sh"))
}
##################
# data source: ftp://hgdownload.cse.ucsc.edu/goldenPath/hg18/database/snp130.txt.gz
# data date: 09/20/2009 12:00AM 
#
# 08/04/2010, exclude indel
#####################
annot_snp_Infinium<-function(build="snp131"){
	if(build=="snp130")data.dir<-"C:\\feipan\\database\\ucsc\\snp\\build130\\chr.rdata"
	else data.dir<-"C:\\feipan\\database\\ucsc\\hg19\\snp131"
	setwd(data.dir)
	#load(file="snp130.all.rdata")
	#length(snp.chr)
	
	infi<-getMapInfo.meth450()
	infi.chr<-split(infi,infi$Chr)
	#data.dir<-"C:\\feipan\\database\\ucsc\\snp\\build130\\chr.rdata"
	flist<-list.files(path=data.dir,pattern=".rdata")
	for(i in 1:length(flist)){
		cat(">>chr: ",i,"\n");cat(flist[i],"\n")
		print(load(file.path(data.dir,file=flist[i])))
		rr<-abs(snp.chr[[1]]$end-snp.chr[[1]]$start)
		snp.chr[[1]]<-snp.chr[[1]][rr<2,]
		map.rst<-findNN.5(infi.chr,snp.chr)
		#setwd("C:\\feipan\\manifests\\Infinium")
		setwd("C:\\feipan\\manifests\\HumanMeth450k\\snp130")
		save(map.rst,file=paste("map.",build,".rst.chr",i,".rdata",sep=""))
	}
	
	#post-process
	datDir<-paste("C:\\feipan\\manifests\\HumanMeth450k\\",build,sep="")
	setwd(datDir)
	flist<-list.files(pattern=".rdata")
	map.rst.all<-NULL
	for(i in 1:length(flist)){
		cat(">>chr: ",i,"\n")
		load(file=flist[i])
		if(is.null(map.rst.all)){
			map.rst.all<-map.rst
		}else{
			map.rst.all<-rbind(map.rst.all,map.rst)
		}
	}
	#snp130
	write.table(map.rst.all,file="map.snp130.csv",sep=",",row.names=F)
	save(map.rst.all,file="map.snp130.rdata")
	dim(map.rst.all)
	map.rst.new<-map.rst.all[,c(1,8:14,16)]
	names(map.rst.new)<-c("IlmnID","Chr","start_UCSC_snp","end_UCSC_snp130",
			"name_UCSC_snp130","strand_UCSC_snp130","refNCBI_UCSC_snp130",
			"refUCSC_UCSC_snp130","observed_UCSC_snp130",
			"distance_to_nearest_UCSC_snp130")
	map.rst.new<-map.rst.new[map.rst.all$isWithin==TRUE,]
	save(map.rst.new,file="map.rst.isWithin.rdata")
	
	#snp131
	setwd("C:\\feipan\\manifests\\humanMeth450k\\snp131")
	load(file="map.snp131.rda")
	dim(map.rst.all) #485437
	map.rst.new<-map.rst.all[,c(1,8:15,17)]
	names(map.rst.new)<-c("IlmnID","Chr","start_UCSC_snp131","end_UCSC_snp131",
			"name_UCSC_snp131","strand_UCSC_snp131","refNCBI_UCSC_snp131",
			"refUCSC_UCSC_snp131","observed_UCSC_snp131",
			"distance_to_nearest_UCSC_snp131")
	map.rst.new<-map.rst.new[map.rst.all$isWithin==TRUE,]
	dim(map.rst.new) #145578
	length(unique(map.rst.new$IlmnID))
	table(map.rst.new$distance_to_nearest_UCSC_snp131<=10)
#	FALSE  TRUE 
#	99764 45814 
	map.rst.new$snp_within_10bp<-map.rst.new$distance_to_nearest_UCSC_snp131<=10
	table(map.rst.new$distance_to_nearest_UCSC_snp131<=20)
#	FALSE  TRUE 
#	71891 73687 
	map.rst.new$snp_within_20bp<-map.rst.new$distance_to_nearest_UCSC_snp131<=20
	map.rst.new$snp_within_5bp<-map.rst.new$distance_to_nearest_UCSC_snp131<=5
	table(map.rst.new$distance_to_nearest_UCSC_snp131<=5)
	save(map.rst.new,file="map.rst.isWithin.rdata")
}
#########
#INDEL
#########
annot_snp_infinium.2<-function(build="snp130"){ 
	library(mAnnot)
	infinium<-getMapInfo.meth450()
	infinium$start<-infinium$mapInfo 
	infinium$end<-infinium$mapInfo
	infinium.chr<-split(infinium,as.factor(infinium$Chr)) 
	if(build=="snp130")data.dir<-"C:\\feipan\\database\\ucsc\\snp\\build130\\chr.rdata" 
	else data.dir<-"C:\\feipan\\database\\ucsc\\hg19\\snp131"
	setwd(data.dir) 
	flist<-list.files(pattern=".rdata") 
	for(i in 1:length(flist)){ 
		print(load(flist[i]))
		rr<-abs(snp.chr[[1]]$end-snp.chr[[1]]$start)
		if(sum(rr>=2)<1)next
		snp.chr[[1]]<-snp.chr[[1]][rr>=2,] 
		map.rst.2<-findNN.5(infinium.chr,snp.chr)
		save(map.rst.2,file=paste("map.rst.2.",i,".rdata",sep="")) 
		write.table(map.rst.2,file=paste("map.rst.2.",i,".csv",sep=""),sep=",",row.names=F) 
	}
	#post-process
	outDir<-"C:\\feipan\\manifests\\humanMeth450k\\snp131"
	setwd(outDir)
	print(load(file="map.rst.2.snp131.rda"))
	dim(map.rst.all)
	map.rst<-map.rst.all[map.rst.all$isWithin==T,c(1,8:15,16)]
	dim(map.rst) #3415
	names(map.rst)<-c("IlmnID","Chr","start_UCSC_snp131","end_UCSC_snp131",
			"name_UCSC_snp131","strand_UCSC_snp131","refNCBI_UCSC_snp131",
			"refUCSC_UCSC_snp131","observed_UCSC_snp131",
			"distance_to_nearest_UCSC_snp131")
	save(map.rst,file=file.path(outDir,"map.rst.2.snp131.isWithin.rdata"))
}
validate_snp_annot<-function(){
	outDir<-"C:\\feipan\\manifests\\humanMeth450k\\snp131"
	print(load(file=file.path(outDir,"map.rst.isWithin.rdata")))
	library(mAnnot)
	meth450<-get(data(HumanMethylation450.adf.ext))
	map2<-merge(map.rst.new,meth450,by.x=1,by.y=1)
	map2.snp<-map2[,c(1:12,32:33)]
	table(map2.snp$snp_within_10bp==T)
	table(map2.snp$snp_within_20bp==T)
	table(map2.snp$PROBE_SNPS!="")
	table(map2.snp$PROBE_SNPS_10!="")
	ind1<-map2.snp$PROBE_SNPS_10!="";ind2<-map2.snp$snp_within_10bp==T
	map2i<-map2.snp[ind1|ind2,]
	table((map2i$snp_within_10bp==T)==(map2i$PROBE_SNPS_10!=""))
	map2.snp.10<-map2.snp[map2.snp$snp_within_10bp==T,c(1,5,11,12,13,14)]
	map2.snp.20<-map2.snp[map2.snp$snp_within_20bp==T,c(1,5,11,12,13,14)]
	
	meth450a<-meth450[,c(1,15,16)]
	mani<-merge(meth450a,map.rst.new,by.x=1,by.y=1,all.x=T)
	mani$snp_within_10bp[is.na(mani$snp_within_10bp)]<-F
	mani$snp_within_20bp[is.na(mani$snp_within_20bp)]<-F
	table(mani$snp_within_10bp)
	table(mani$snp_within_20bp)
	
	print(load(file=file.path(outDir,"map.rst.2.snp131.isWithin.rdata")))
	map.rst$within_indel<-T
	mani<-merge(mani,map.rst,by.x=1,by.y=1,all.x=T)
	mani$within_indel[is.na(mani$within_indel)]<-F
	table(mani$within_indel)
	names(mani)
	save(mani,file=file.path(outDir,"manifest_snp131.all.rdata"))
	write.csv(mani,file=file.path(outDir,"manifest_snp131.all.csv"),quote=F,row.names=F)
	mani2<-mani[,c("TargetID","CHR","MAPINFO","snp_within_10bp","snp_within_20bp","name_UCSC_snp131.x","distance_to_nearest_UCSC_snp131.x","within_indel")]
	snpAnnot$name_UCSC_snp131.x[is.na(mani2$name_UCSC_snp131.x)]<-""
	nm<-names(mani2);nm[6]<-"name";names(mani2)<-nm
	names(mani2)<-c("TargetID","CHR","MAPINFO","snp_within_10bp","snp_within_20bp","name","distance_to_nearest_snp131","within_indel")
	snpAnnot<-mani2
	save(snpAnnot,file=file.path(outDir,"manifest_snp131_05072011.rdata"))
	write.csv(mani2,file=file.path(outDir,"manifest_snp131.csv"),quote=F,row.names=F)
}
#table(mani2$snp_within_10bp==T|mani2$within_indel==T)
#	FALSE   TRUE 
#	437100  48477
#annot_snp_infinium.2<-function(){ 
#	infinium<-getMapInfo.meth450()
#	infinium.chr<-split(infinium,as.factor(infinium$Chr)) 
#	data.dir<-"C:\\feipan\\database\\ucsc\\snp\\build130\\chr.rdata" 
#	setwd(data.dir) 
#	flist<-list.files(pattern=".rdata") 
#	for(i in 1:length(flist)){ 
#		load(flist[i]) 
#		snp.chr[[1]]$start<-snp.chr[[1]]$mapInfo-500 
#		snp.chr[[1]]$end<-snp.chr[[1]]$mapInfo+500 
#		map.rst.2<-findNN.5(infinium.chr,snp.chr)
#		save(map.rst.2,file=paste("map.rst.2.",i,".rdata",sep="")) 
#		write.table(map.rst.2,file=paste("map.rst.2.",i,".csv",sep=""),sep=",",row.names=F) 
#	}
#}
#annot_snp_Infinium<-function(){
#	data.dir<-"C:\\feipan\\database\\ucsc\\snp\\build130\\chr.rdata"
#	setwd(data.dir)
#	#load(file="snp130.all.rdata")
#	#length(snp.chr)
#	
#	infi<-getMapInfo.meth450()
#	infi.chr<-split(infi,infi$Chr)
#	data.dir<-"C:\\feipan\\database\\ucsc\\snp\\build130\\chr.rdata"
#	flist<-list.files(path=data.dir,pattern=".rdata")
#	for(i in 1:length(flist)){
#		cat(">>chr: ",i,"\n");cat(flist[i],"\n")
#		print(load(file.path(data.dir,file=flist[i])))
#		rr<-snp.chr[[1]]$end-snp.chr[[1]]$start
#		snp.chr[[1]]<-snp.chr[[1]][rr<2,]
#		map.rst<-findNN.5(infi.chr,snp.chr)
#		#setwd("C:\\feipan\\manifests\\Infinium")
#		setwd("C:\\feipan\\manifests\\HumanMeth450k\\snp130")
#		save(map.rst,file=paste("map.snp130.rst.chr",i,".rdata",sep=""))
#	}
#	
#	setwd("C:\\feipan\\manifests\\HumanMeth450k\\snp130")
#	flist<-list.files(pattern=".rdata")
#	map.rst.all<-NULL
#	for(i in 1:length(flist)){
#		cat(">>chr: ",i,"\n")
#		load(file=flist[i])
#		if(is.null(map.rst.all)){
#			map.rst.all<-map.rst
#		}else{
#			map.rst.all<-rbind(map.rst.all,map.rst)
#		}
#	}
#	dim(map.rst.all)
#	write.table(map.rst.all,file="map.snp130.csv",sep=",",row.names=F)
#	save(map.rst.all,file="map.snp130.rdata")
#	
#	map.rst.new<-map.rst.all[,c(1,8:14,16)]
#	names(map.rst.new)<-c("IlmnID","start_UCSC_snp130","end_UCSC_snp130",
#			"name_UCSC_snp130","strand_UCSC_snp130","refNCBI_UCSC_snp130",
#			"refUCSC_UCSC_snp130","observed_UCSC_snp130",
#			"distance_to_nearest_UCSC_snp130")
#	map.rst.new<-map.rst.new[map.rst.all$isWithin==TRUE,]
#	save(map.rst.new,file="map.rst.isWithin.rdata")
#}


annot_snp_batch<-function(){
	chrs<-c(1:22,"X","Y")
	outdir<-file.path("/auto/uec-02/shared/production/methylation/database/meth450k/manifest/snp131",
			"batch3")
	outdir<-file.path("/auto/uec-02/shared/production/methylation/database/meth450k/manifest/snp131",
			"batch")
	
	for(chr in chrs){
		code<-readLines("annot_snp.2.R")
		code[2]<-paste("chr<-\"",chr,"\"",sep="")
		fn<-paste("annot_snp.2.chr",chr,".R",sep="")
		write(code,file=file.path(outdir,fn))
	}
	for(chr in chrs){
		code1<-"#PBS -N mAnnot\n#PBS -q laird\n#PBS -l walltime=10:00:00\n#PBS -l nodes=1:ppn=8\n"
		code2<-paste("cd ",outdir,"\n/auto/uec-00/shared/production/software/R/bin/Rscript ",sep="")
		code3<-paste("annot_snp.2.chr",chr,".R",sep="")
		write(paste(code1,code2,code3),file=file.path(outdir,paste("annot_snp.2.chr",chr,".sh",sep="")))
	}
	code<-c()
	for(chr in chrs){
		code1<-paste("qsub annot_snp.2.chr",chr,".sh",sep="")
		code<-paste(code,code1,sep="\n")
	}
	write(code,file=file.path(outdir,"run.sh"))
	
}
#########################
# May 12,2011
# update polycomb annotation
##########################
annot_polycomb_test<-function(){
	outDir<-"c:\\feipan\\manifests\\humanMeth450k"
	outFn<-"PolycombAnnot.rdata"
	poly<-annot_polycomb(outDir,outFn)
}
annot_polycomb<-function(outDir,outFn){
	library(rapid.pro)
	require(rapid.db)
	data(HumanMethylation450.adf)
	adf<-HumanMethylation450.adf[,c("ENTREZGENEID","ILMNID")]
	con<-dbCon()
	poly<-dbQuery(con,"PolycombOccupancy")
	table(poly$PolyComb)
#	Eed H3K27me3    Suz12 
#	16710    16710    16710 
	suz12<-poly[poly$PolyComb=="Suz12",c(1,2,3)]
	names(suz12)<-c("ENTREZGENEID","GENENAME","Suz12Occupancy")
	dat<-merge(suz12,adf,by.x=1,by.y=1,all.y=T)
	eed<-poly[poly$PolyComb=="Eed",c(1,3)]
	names(eed)<-c("ENTREZGENEID","EedOccupancy")
	dat2<-merge(eed,adf,by.x=1,by.y=1,all.y=T)
	h3k27me3<-poly[poly$PolyComb=="H3K27me3",c(1,3)]
	names(h3k27me3)<-c("ENTREZGENEID","H3K27me3Occupancy")
	dat3<-merge(h3k27me3,adf,by.x=1,by.y=1,all.y=T)
	dat<-merge(dat,dat2,by.x="ILMNID",by.y="ILMNID")
	dat<-merge(dat,dat3,by.x="ILMNID",by.y="ILMNID")
	dat<-dat[,c("ILMNID","ENTREZGENEID","GENENAME","Suz12Occupancy","EedOccupancy","H3K27me3Occupancy")]
	dat$Suz12Occupancy<-ifelse(dat$Suz12Occupancy=="0","NO","YES")
	eed<-ifelse(dat$EedOccupancy=="NO"|is.na(dat$EedOccupancy),F,T)
	h3k27<-ifelse(dat$H3K27me3Occupancy=="NO"|is.na(dat$H3K27me3Occupancy),F,T)
	suz12<-ifelse(dat$Suz12Occupancy=="NO"|is.na(dat$Suz12Occupancy),F,T)
	dat$Total_Polycomb<-eed+h3k27+suz12
	dat$Any_Polycomb<-eed|h3k27|suz12
	save(dat,file=file.path(outDir,outFn))
	return(dat)
}

#########################
# May 12 2011
########################
annot_nearestProbe_test<-function(){
	outDir<-"c:\\feipan\\manifests\\humanMeth450k"
	outFn<-"AnnotNearestProbe.rdata"
	dat<-annot_nearestProbe(outDir,outFn)
}
annot_nearestProbe<-function(outDir,outFn,logFn){
	library(mAnnot)
	adf<-get(print(data(meth450)))
	adf.chr<-split(adf,adf$Chr)
	data(meth27)
	meth27.chr<-split(meth27,meth27$Chr)
	map27<-Rpg(adf.chr,meth27.chr,logFn)
	save(map27,file=file.path(outDir,"AnnotNearestProbe.meth27k.rdata"))
	data(oma04)
	oma04.chr<-split(oma04,oma04$Chr)
	map04<-Rpg(adf.chr,oma04.chr,logFn)
	save(map04,file=file.path(outDir,"AnnotNearestProbe.oma04.rdata"))
	data(oma03)
	oma03.chr<-split(oma03,oma03$Chr)
	map03<-Rpg(adf.chr,oma03.chr,logFn)
	save(map03,file=file.path(outDir,"AnnotNearestProbe.oma03.rdata"))
	data(oma02)
	oma02.chr<-split(oma02,oma02$Chr)
	map02<-Rpg(adf.chr,oma02.chr,logFn)
	save(map02,file=file.path(outDir,"AnnotNearestProbe.oma02.rdata"))
	data(ml)
	ml.chr<-split(ml,ml$Chr)
	map.ml<-Rpg(adf.chr,ml.chr,logFn)
	save(map.ml,file=file.path(outDir,"AnnotNearestProbe.ml.rdata"))
	map27<-Rpg2(map27,logFn)
	map04<-Rpg2(map04,logFn)
	map03<-Rpg2(map03,logFn)
	map02<-Rpg2(map02,logFn)
	map.ml<-Rpg2(map.ml,logFn)
	dat<-merge(adf,map27,by.x="IlmnID",by.y="IlmnID",all.x=T)
	dat<-merge(dat,map04,by.x="IlmnID",by.y="IlmnID",all.x=T)
	dat<-merge(dat,map03,by.x="IlmnID",by.y="IlmnID",all.x=T)
	dat<-merge(dat,map02,by.x="IlmnID",by.y="IlmnID",all.x=T)
	annot<-merge(dat,map.ml,by.x="IlmnID",by.y="IlmnID",all.x=T)
	save(annot,file=file.path(outDir,outFn))
	return(annot)
}
annot_nearestProbe.1<-function(outDir,outFn){
	library(mAnnot)
	library(rapid.pro)
	data(HumanMethylation450.adf)
	adf<-HumanMethylation450.adf[,c("ILMNID","CHR","MAPINFO")]
	names(adf)<-c("IlmnID","Chr","mapInfo");adf$start<-adf$mapInfo
	adf.chr<-split(adf,adf$Chr)
	meth27<-getMapInfo()
	meth27.chr<-split(meth27,meth27$Chr)
	map27<-findNN.3(adf.chr,meth27.chr)
	save(map27,file=file.path(outDir,"AnnotNearestProbe.meth27k.rdata"))
	oma04<-getMapInfo("OMA04")
	oma04.chr<-split(oma04,oma04$Chr)
	map04<-findNN.3(adf.chr,oma04.chr)
	save(map04,file=file.path(outDir,"AnnotNearestProbe.oma04.rdata"))
	oma03<-getMapInfo("OMA03")
	oma03.chr<-split(oma03,oma03$Chr)
	map03<-findNN.3(adf.chr,oma03.chr)
	save(map03,file=file.path(outDir,"AnnotNearestProbe.oma03.rdata"))
	oma02<-getMapInfo("OMA02")
	oma02.chr<-split(oma02,oma02$Chr)
	map02<-findNN.3(adf.chr,oma02.chr)
	save(map02,file=file.path(outDir,"AnnotNearestProbe.oma02.rdata"))
	ml<-getMapInfo("MethyLight")
	ml.chr<-split(ml,ml$Chr)
	map.ml<-findNN.3(adf.chr,ml.chr)
	save(map.ml,file=file.path(outDir,"AnnotNearestProbe.ml.rdata"))
	dat<-merge(adf,map27,by.x="IlmnID",by.y="IlmnID",all.x=T)
	dat<-merge(dat,map04,by.x="IlmnID",by.y="IlmnID",all.x=T)
	dat<-merge(dat,map03,by.x="IlmnID",by.y="IlmnID",all.x=T)
	dat<-merge(dat,map02,by.x="IlmnID",by.y="IlmnID",all.x=T)
	annot<-merge(dat,map.ml,by.x="IlmnID",by.y="IlmnID",all.x=T)
	save(annot,file=file.path(outDir,outFn))
	return(annot)
}
###################
#
###################
annot_sourceSeq_test<-function(){
	outDir="c:\\feipan\\manifests\\humanMeth450k"
	outFn="srcSeqAnnot.rdata"
	annot_sourceSeq(outDir,outFn)
}
annot_sourceSeq<-function(outDir,outFn){
	library(mAnnot)
	library(rapid.pro)
	data(HumanMethylation450.adf)
	srcSeq<-HumanMethylation450.adf$SOURCESEQ
	names(srcSeq)<-HumanMethylation450.adf$ILMNID
	annot<-sapply(srcSeq,function(x)annotSeq(x))
	annot<-t(annot);
	dimnames(annot)[[2]]<-c("num.C","num.G","num.A","num.T","num.CG","GC_content","Obs_Exp_ratio")
	save(annot,file=file.path(outDir,outFn))
}
########################
# ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/database/refGene.txt.gz
#######################
annot_exonMap_test<-function(){
	logFn<-"c:\\temp\\test1\\log.txt"
	datFn<-"C:\\feipan\\database\\ucsc\\hg19\\refGene.txt"
	annot<-annot_exonMap(datFn,logFn)
	print(load(file="c:\\feipan\\manifests\\humanMeth450k\\exonMap\\annot.all.rdata"))
	outFn<-"c:\\feipan\\manifests\\humanMeth450k\\exonMap\\exonAnnot.rdata"
	annot<-annot_exonMap2(annot=dat,outFn=outFn)
	table(annot$Within_Transcripts)
#	NO    YES 
#	297271 188166 
	table(annot$Within_Exon)
}
annot_exonMap<-function(datFn=NULL,logFn=NULL,max.node=8){
	library(mAnnot)
	if(is.null(datFn))datFn<-"C:\\feipan\\database\\ucsc\\hg19\\refGene.txt"
	refgene<-read.table(datFn,sep="\t",header=F,stringsAsFactors=F)
	names(refgene)<-c("bin","name","chrom","strand","txStart","txEnd","cdsStart","cdsEnd","exonCount","exonStarts","exonEnds","score","name2","cdsStartStat","cdsEndStat","exonFrames")
	refgene<-refgene[,c(2,3,4,5,6,9,10,11)]
	names(refgene)<-c("Name","Chr","strand","start","end","exonCount","exonStarts","exonEnds")
	chr<-paste("chr",c(1:22,"X","Y"),sep="")
	refgene<-refgene[is.element(refgene$Chr,chr),]
	refgene$mapInfo<-ifelse(refgene$strand=="+",refgene$start,refgene$end)
	ref.chr<-split(refgene,refgene$Chr)
	data(meth450)
	meth.chr<-split(meth450,meth450$Chr)
	if(is.null(logFn))logFn<-"/home/uec-01/shared/tmp/feipan/log"
	proc<-Rpg(meth.chr,ref.chr,logFn,max.node=max.node,func="findNN.3a")
	annot<-Rpg2(proc,logFn)
	return(annot)
}
annot_exonMap2<-function(annot,outFn){
	annot<-data.frame(annot)
	annot$Within_Transcripts<-ifelse(annot$mapInfo>=annot$start.1&annot$mapInfo<=annot$end.1,"YES","NO")
	exon.starts<-sapply(annot$exonStarts,function(x)as.numeric(strsplit(x,",")[[1]]))
	exon.ends<-sapply(annot$exonEnds,function(x)as.numeric(strsplit(x,",")[[1]]))
	annot$Within_Exon<-"NO"
	for(i in 1:nrow(annot)){
		for(j in 1:annot$exonCount[i]){
			if(annot$exonCount[i]!=length(exon.starts[[i]])|annot$exonCount[i]!=length(exon.ends[[i]])){cat("data errors\n");next}
			if(annot$mapInfo[i]>=exon.starts[[i]][j]&annot$mapInfo[i]<=exon.ends[[i]][j]) annot$Within_Exon[i]<-"YES"
		}
	}
	annot<-annot[,c("IlmnID","Chr","Name","strand","start.1","end.1","exonCount","exonStarts","exonEnds","Within_Transcripts","Within_Exon","dist")]
	names(annot)<-c("IlmnID","Chr","Name","strand","start","end","exonCount","exonStarts","exonEnds","Within_Transcripts","Within_Exon","Distance_To_TSS")
	save(annot,file=outFn)
	return(annot)
}
######################
# ftp://ftp.ncbi.nih.gov/genomes/H_sapiens/mapview/seq_gene.md.gz
# ftp://ftp.ncbi.nih.gov/genomes/H_sapiens/ARCHIVE/BUILD.37.1/mapview/seq_gene.md.gz
#####################
annot_TSS_test<-function(){
	datFn<-"C:\\feipan\\database\\NCBI\\genomes\\seq_gene.md"
	logFn<-"c:\\temp"
	an<-annot_TSS(datFn,logFn)
}
annot_TSS<-function(datFn=NULL,logFn=NULL,max.node=8){
	library(mAnnot)
	if(is.null(datFn))datFn<-"/auto/uec-02/shared/production/methylation/database/NCBI/genomes/build37.1/seq_gene.md"
	if(is.null(logFn))logFn<-"/auto/uec-02/shared/production/methylation/database/meth450k/annotTSS/log"
	gene<-read.table(datFn,sep="\t",stringsAsFactors=F,header=F)
	names(gene)<-c("tax_id","chromosome","chr_start","chr_stop","chr_orient","contig","ctg_start","ctg_stop","ctg_orient","feature_name","feature_id","feature_type","group_label","transcript","evidence_code")
	ind<-gene$group_label!="HuRef-Primary Assembly"&gene$group_label!="Hs_Celera-Primary Assembly"&gene$group_label!="CRA_TCAGchr7v2-Primary Assembly"
	ind2<-gene$feature_type=="GENE"
	gene<-gene[ind&ind2,]
	gene<-gene[,c(2,3,4,5,10,11,14)]
	names(gene)<-c("Chr","start","end","orient","symbol","geneID","acc")
	gene$mapInfo<-ifelse(gene$orient=="+",gene$start,gene$end)
	gene$TSS<-gene$mapInfo
	gene.chr<-split(gene,gene$Chr)
	data(meth450)
	meth.chr<-split(meth450,meth450$Chr)
	proc<-Rpg(meth.chr,gene.chr,logFn,max.node=max.node,func="findNN.3a")
	annot<-Rpg2(proc,logFn)
	save(annot,file=file.path(filedir(logFn),"AnnotTSS.rdata"))
	return(annot)
}
##################
# ftp://ftp.ncbi.nih.gov/gene/DATA/gene2go.tar.gz
# http://archive.geneontology.org/latest-lite/termdb: graph_path.txt
# term_id          term_name          term_type   term_acc term_is_obsolete
# 2782    2782 molecular_function molecular_function GO:0003674                0
# 6587    6587 biological_process biological_process GO:0008150                0
# 4511    4511 cellular_component cellular_component GO:0005575                0
##################
annot_GeneOntology_test<-function(){
	outFn<-"c:\\feipan\\humanMeth450k\\goAnnot\\annot.rata"
	annot_GeneOntology(outFn=outFn)
}
annot_GeneOntology<-function(datFn=NULL,graphFn=NULL,termFn=NULL,outFn=NULL){
	if(is.null(datFn))datFn<-"C:\\feipan\\database\\NCBI\\gene\\gene2go"
	dat<-read.delim(datFn,sep="\t",header=F,stringsAsFactors=F)
	names(dat)<-c("tax_id","GeneID","GO_ID Evidence","Qualifier","GO_term","PubMed","Category")
	data(humanMethylation450.adf)
	annot<-merge(humanMethylation450.adf,dat,by.x="ENTREZGENE",by.y="Gene_ID",all.x=T)
	if(is.null(graphFn))graphFn<-"C:\\feipan\\database\\NCBI\\geneOntology\\graph_path.txt"
	graph<-read.delim(graphFn,sep="\t",header=F,stringsAsFactors=F)
	names(graph)<-c("graph_id","term1_id","term2_id","relationship_type_id","distance","relation_distance")
	if(is.null(termFn))termFn<-"C:\\feipan\\database\\NCBI\\geneOntology\\term.txt"
	term<-read.delim(termFn,sep="\t",header=F,stringsAsFactors=F)
	names(term)<-c("term_id","term_name","term_type","term_acc","term_is_obsolete","term_is_root","term_is_relation")
	graph2<-graph[graph$term2_id=="34180",] #root
	graph.term1<-merge(graph2,term,by.x="term1_id",by.y="term_id")
	annot<-merge(annot,graph.term1,by.x="GO_term",by.y="term_name")
	if(is.null(outFn))outFn<-"c:\\feipan\\manfiests\\humanMeth450k\\goAnnot\\goAnnot.all.rdata";
	save(annot,file=outFn)
}
################
# ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/database/phastConsElements46way.txt.gz
################
annot_conElem_test<-function(){
	datFn<-"/auto/uec-02/shared/production/methylation/database/ucsc/hg19/phastConsElements46way.txt.gz"
	logFn<-"/auto/uec-02/shared/production/methylation/database/meth450k/conElem/log"
	outFn<-"/auto/uec-02/shared/production/methylation/database/meth450k/conElem/annotConElem.rdata"
	annot_conElem(datFn,logFn,outFn)
}
annot_conElem<-function(datFn,logFn,outFn){
	library(mAnnot)
	dat<-read.delim(gzfile(datFn),sep="\t",header=F,stringsAsFactors=F)
	names(dat)<-c("bin","Chr","start","end","name","score")
	dat$mapInfo<-dat$start
	dat.chr<-split(dat,dat$Chr)
	data(meth450)
	meth.chr<-split(meth450,meth450$Chr)
	proc<-Rpg(meth.chr,dat.chr,logFn=logFn,max.time=50)
	annot<-Rpg2(proc)
	save(annot,file=outFn)
	return(annot)
}
####################
# ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/database/recombRate.txt.gz
####################
annot_recombRate_test<-function(){
	datFn<-"/auto/uec-02/shared/production/methylation/database/ucsc/hg19/recombRate.txt.gz"
	logFn<-"/auto/uec-02/shared/production/methylation/database/meth450k/recombRate/log"
	outFn<-"/auto/uec-02/shared/production/methylation/database/meth450k/recombRate/annot_RecombRate.rdata"
	annot_recombRate(datFn,logFn,outFn)
}
annot_recombRate<-function(datFn,logFn,outFn){
	library(mAnnot)
	dat<-read.delim(gzfile(datFn),sep="\t",header=F,stringsAsFactors=F)
	names(dat)<-c("Chr","start","end","name","decodeAvg","decodeFemale","decodeMale","marshfieldAvg","marshfieldFemale","marshfieldMale","genethonAvg","genethonFemale","genethonMale")
	dat$mapInfo<-dat$start
	dat.chr<-split(dat,dat$Chr)
	data(meth450)
	meth.chr<-split(meth450,meth450$Chr)
	proc<-Rpg(dat.chr,meth.chr,logFn)
	annot<-Rpg2(proc,outFn)
	save(annot,file=outFn)
}
#####################
# ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/database/cpgIslandExt.txt.gz
# ftp://ftp.ncbi.nih.gov/genomes/H_sapiens/ARCHIVE/BUILD.37.1/mapview/seq_cpg_islands.md.gz
#####################
annot_cpgIslands_test<-function(){
	datFn<-"C:\\feipan\\database\\NCBI\\genomes\\build37.1\\seq_cpg_islands.md.gz"
	logFn<-"c:\\temp\\log"
	outFn<-"c:\\temp\\annotCGI_relaxed"
	annot_cpgIslands(datFn,logFn,outFn)
	outFn<-"c:\\temp\\annotCGI_strict"
	annot_cpgIslands(datFn,logFn,outFn,type="strict")
	
	datFn<-"C:\\feipan\\database\\ucsc\\hg19\\cpgIslandExt.txt.gz"
	annot_cpgIslands(datFn,type="UCSC")
	
	#check
	dat2<-dat[dat$groupLabel=="Primary_Assembly",];head(dat2)
	datFn2<-"C:\\feipan\\database\\NCBI\\genomes\\build37.1\\seq_contig.md.gz"
	ctg<-read.delim(gzfile(datFn2),sep="\t",header=F,stringsAsFactors=F,skip=1)
	names(ctg)<-c("tax_id","Chr","start","end","orent","feature_name","tgi","feature_type","group_label","weight")
	table(ctg$group_label)
	ctg[ctg$feature_name=="NT_077402.2",]
	
	datFn<-"C:\\feipan\\database\\NCBI\\genomes\\build37.2\\seq_cpg_islands.md.gz"
	dat<-read.delim(gzfile(datFn),sep="\t",header=F,stringsAsFactors=F)
	names(dat)<-c("tax_id","Chr","start","end","contig","ctg_start","ctg_end","groupLabel","weight")
	dat<-dat[dat$groupLabel=="GRCh37.p2-Primary Assembly"|dat$groupLabel=="GRCh37.p2-PATCHES",]
}
annot_cpgIslands<-function(datFn,logFn=NULL,outFn=NULL,type="relaxed"){
	dat<-read.delim(gzfile(datFn),sep="\t",header=F,stringsAsFactors=F)
	if(type!="UCSC"){
		names(dat)<-c("tax_id","Chr","start","end","contig","ctg_start","ctg_end","groupLabel","weight")
		dat<-dat[dat$weight==type,];dat<-dat[dat$groupLabel=="Primary_Assembly",]
	}else{
		names(dat)<-c("bind","Chr","start","end","name","length","cpgNum","gcNum","perCpg","perGc","obsExp")
	}
	dat$mapInfo<-dat$start
	dat.chr<-split(dat,dat$Chr)
	library(mAnnot)
	data(meth450)
	meth450.chr<-split(meth450,meth450$Chr)
	proc<-Rpg(dat.chr,meth450.chr,logFn) 
	annot.start<-Rpg2(proc,outFn)
	save(annot.start,file=paste(outFn,".start.rdata",sep=""))
	dat$mapInfo<-dat$end
	dat.chr<-split(dat,dat$Chr)
	proc<-Rpg(dat.chr,meth450.chr,logFn)
	annot.end<-Rpg2(proc,outFn)
	save(annot.end,file=paste(outFn,".end.rdata",sep=""))
}
###################
#
###################
annot_primaryProbe<-function(){
	
}

#################
#
#################
annot_mutations<-function(){
	
}


###################
# meth450k ADF
###################
createMeth450ADF_test<-function(){
	outDir<-"c:\\temp"
	HumanMethylation450.adf<-createMeth450ADF("Infinium450kADF",outDir)
	names(HumanMethylation450.adf)
	HumanMethylation450a.adf<-createMeth450ADF("Infinium450kADF_3",toSave=F)
	adf<-HumanMethylation450a.adf[!is.na(HumanMethylation450a.adf$EntrezGeneID),]
	adf<-adf[!duplicated(adf$ILMNID),c("ILMNID","EntrezGeneID","GeneSymbol")]
	HumanMethylation450.adf<-merge(HumanMethylation450.adf,adf,by.x="ILMNID",by.y=1,all.x=T)
	save(HumanMethylation450.adf,file=file.path(outDir,"HumanMethylation450.adf.rdata"))
	
	HumanMethylation450b.adf<-createMeth450ADF("Infinium450kADF_2",toSave=F)
	data(HumanMethylation450.adf); adf<-HumanMethylation450.adf[,c(-2,-3)]
	HumanMethylation450.adf<-merge(HumanMethylation450b.adf,adf,by.x="ILMNID",by.y=1,all.y=T)
	save(HumanMethylation450.adf,file=file.path(outDir,"HumanMethylation450.adf.rdata"))
}
createMeth450ADF<-function(viewName="Infinium450kADF",outFn="HumanMethylation450.adf",outDir=NULL,limit=T,dbName=NULL,toSave=T){
	require(rapid.db)
	if(is.null(outDir)) outDir<-"c:\\temp"
	if(is.null(dbName))dbName<-"C:\\Documents and Settings\\feipan\\Desktop\\people\\tejas\\testTab.db"
	con<-dbCon(dbname=dbName)
	dbListTables(con)
	HumanMethylation450.adf<-dbQuery(con,viewName)
	if(limit==T){
		HumanMethylation450.adf<-HumanMethylation450.adf[,c("ILMNID","mrnaAcc","geneSymbol","geneGeneID","GENOME_BUILD","CHR","MAPINFO","COORDINATE_36","SOURCESEQ","ALLELEB_PROBESEQ","ALLELEA_PROBESEQ","NEXT_BASE","COLOR_CHANNEL")]
		names(HumanMethylation450.adf)<-c("ILMNID","REFGENE_ACCESSION","GENESYMBOL","ENTREZGENEID","GENOME_BUILD","CHR","MAPINFO","COORDINATE_36","SOURCESEQ" ,"ALLELEB_PROBESEQ","ALLELEA_PROBESEQ","NEXT_BASE","COLOR_CHANNEL")
	}
	if(toSave==T){
		setwd(outDir)
		write.table(HumanMethylation450.adf,file=paste(outFn,".txt",sep=""),sep="\t",quote=F,row.names=F)
		save(HumanMethylation450.adf,file=paste(outFn,".rdata",sep=""))
	}
	dbDisconnect(con)
	return(HumanMethylation450.adf)
}

createMeth450ADF.1.1<-function(viewName="Infinium450kADF",outFn=NULL,outDir=NULL,toSave=T){
	require(rapid.db)
	if(is.null(outFn))outFn<-"HumanMethylation450.adf.txt"
	if(!is.null(outDir)) outFn<-file.path(outDir,outFn)
	con<-dbCon(dbname="C:\\Documents and Settings\\feipan\\Desktop\\people\\tejas\\testTab.db")
	dbListTables(con)
	adf<-dbQuery(con,viewName)
	if(toSave==T)write.table(adf,file=outFn,sep="\t",quote=F,row.names=F)
	HumanMethylation450.adf<-adf
	dbDisconnect(con)
	return(adf)
}
createMeth450ADF.1<-function(){
	con<-dbCon(dbname="C:\\Documents and Settings\\feipan\\Desktop\\people\\tejas\\testTab.db")
	dbListTables(con)
	#adf<-dbQuery(con,"Infinium450kADF")
	adf<-dbQuery(con,"Infinium450kADF_3")
	dim(adf)
	names(adf)
	write.table(adf,file="c:\\feipan\\manifests\\meth450.adf.txt",sep="\t",quote=F,row.names=F)
	HumanMethylation450.adf<-adf
	save(HumanMethylation450.adf,file="c:\\feipan\\manifests\\HumanMethylation450.adf.rdata")
	dbDisconnect(con)
}
createMeth450ADF.2<-function(){
	library(rapid.pro)
	data(HumanMethylation450.adf)
	data(HumanMethylation27.adf)
	names(HumanMethylation27.adf)
	HumanMethylation450.adf<-createMeth450ADF("Infinium450kADF")
	HumanMethylation450.adf<-HumanMethylation450.adf[,c("ILMNID","UCSC_REFGENE_ACCESSION","geneSymbol","geneGeneID",
					"GENOME_BUILD","CHR","MAPINFO","COORDINATE_36","SOURCESEQ","ALLELEB_PROBESEQ","ALLELEA_PROBESEQ",
					"NEXT_BASE","COLOR_CHANNEL")]
	names(HumanMethylation450.adf)<-c("ILMNID","REFGENE_ACCESSION","GENESYMBOL","ENTREZGENEID",
			"GENOME_BUILD","CHR","MAPINFO","COORDINATE_36","SOURCESEQ","ALLELEB_PROBESEQ","ALLELEA_PROBESEQ",
			"NEXT_BASE","COLOR_CHANNEL")
	meth450<-read.delim(file="C:\\feipan\\manifests\\humanMeth450k\\infinium 450 manifest.csv",sep=",",stringsAsFactors=F)
	meth450.chr<-meth450$CHR;names(meth450.chr)<-meth450$ILMNID
	meth450.chr<-meth450.chr[HumanMethylation450.adf$ILMNID];all(names(meth450.chr)==HumanMethylation450.adf$ILMNID)
	HumanMethylation450.adf$CHR<-meth450.chr
	save(HumanMethylation450.adf,file="c:\\feipan\\manifests\\humanMeth450k\\HumanMethylation450.adf.rdata")
	write.csv(HumanMethylation450.adf,file="c:\\feipan\\manifests\\humanMeth450k\\HumanMethylation450.adf.csv",row.names=F,quote=F)
	write.table(HumanMethylation450.adf,file="c:\\feipan\\manifests\\humanMeth450k\\HumanMethylation450.adf.txt",sep="\t",row.names=F,quote=F)
}
createMeth450.adf.ext_test<-function(){
	adf<-createMeth450.adf.ext(outDir="c:\\temp")
	names(adf)
}
createMeth450.adf.ext<-function(viewName="Infinium450kADF",outFn=NULL,outDir=NULL,dbName=NULL,toSave=T){
	library(mAnnot)
	library(rapid.db)
	print(data(blat_align))
	if(is.null(outDir))outDir<-"C:\\feipan\\manifests\\humanMeth450k"
	align<-blat.align[,c(1,3,4,6)]
	dim(align);names(align)<-c("IlmnID","blat_start","blat_end","blat_strand")
	length(unique(align$IlmnID))
	HumanMethylation450.adf<-createMeth450ADF(viewName,dbName=dbName,limit=F,toSave=F)
	dim(HumanMethylation450.adf)
	HumanMethylation450.adf.ext<-merge(HumanMethylation450.adf,align,by.x=1,by.y=1,all.x=T)
	print(data(meth450lvl3mask))
	lvl3mask<-meth450lvl3mask[,c(2,1)];names(lvl3mask)<-c("IlmnID","MASK_LEVEL3")
	HumanMethylation450.adf.ext<-merge(HumanMethylation450.adf.ext,lvl3mask,by.x=1,by.y=1,all.x=T)
	con<-dbCon()
	dbListTables(con)
	nearestProbe<-dbQuery(con,"NearestProbeAnnot")
	nearestProbe<-nearestProbe[,c()]
	HumanMethylation450.adf.ext<-merge(HumanMethylation450.adf.ext,nearestProbe,by.x="IlmnID",by.y=1,all.x=T)
	polycomb<-dbQuery(con,"PolycombOccupancy")
	suz12<-polycomb[polycomb$PolyComb=="Suz12",c("EntrezGene_ID","Occupancy")]
	eed<-polycomb[polycomb$PolyComb=="Eed",c("EntrezGene_ID","Occupancy")]
	h3k27me3<-polycomb[polycomb$PolyComb=="H3K27me3",c("EntrezGene_ID","Occupancy")]
	polycomb<-merge(suz12,eed,by.x=1,by.y=1);polycomb<-merge(polycomb,h3k27me3,by.x=1,by.y=1)
	HumanMethylation450.adf.ext<-merge(HumanMethylation450.adf.ext,polycomb,by.x="IlmnID",by.y=1,all.x=T)
	seqAnnot<-dbQuery(con,"SourceSeqAnnot")
	seqAnnot<-seqAnnot[seqAnnot$platform=="meth450",c("IlmnID","Number_of_C","Number_of_G","Number_of_A","Number_of_T","Number_of_CpG","GC_Content","Obs_Exp_Ratio")]
	HumanMethylation450.adf.ext<-merge(HumanMethylation450.adf.ext,seqAnnot,by.x="IlmnID",by.y=1,all.x=T)
	cgiAnnot<-dbQuery(con,"CpGIslandAnnot")
	cgiAnnot<-cgiAnnot[,c()]
	HumanMethylation450.adf.ext<-merge(HumanMethylation450.adf.ext,seqAnnot,by.x="IlmnID",by.y=1,all.x=T)
	dbDisconnect(con)
	if(toSave==T){
		if(is.null(outFn))outFn<-"HumanMethylation450.adf.ext"
		save(HumanMethylation450.adf.ext,file=file.path(outDir,paste(outFn,".rdata",sep="")))
		write.csv(HumanMethylation450.adf.ext,file=file.path(outDir,paste(outFn,".csv",sep="")),row.names=F,quote=F)
	}
	return(HumanMethylation450.adf.ext)
}
createMeth450.adf.ext.1.2<-function(viewName="Infinium450kADF",outFn=NULL,outDir=NULL,dbName=NULL,toSave=T){
	library(mAnnot)
	library(rapid.db)
	print(data(blat_align))
	if(is.null(outDir))outDir<-"C:\\feipan\\manifests\\humanMeth450k"
	align<-blat.align[,c(1,3,4,6)]
	dim(align);names(align)<-c("IlmnID","blat_start","blat_end","blat_strand")
	length(unique(align$IlmnID))
	HumanMethylation450.adf<-createMeth450ADF(viewName,dbName=dbName,limit=F,toSave=F)
	dim(HumanMethylation450.adf)
	HumanMethylation450.adf.ext<-merge(HumanMethylation450.adf,align,by.x=1,by.y=1,all.x=T)
	print(data(meth450lvl3mask))
	lvl3mask<-meth450lvl3mask[,c(2,1)];names(lvl3mask)<-c("IlmnID","MASK_LEVEL3")
	HumanMethylation450.adf.ext<-merge(HumanMethylation450.adf.ext,lvl3mask,by.x=1,by.y=1,all.x=T)
	if(toSave==T){
		if(is.null(outFn))outFn<-"HumanMethylation450.adf.ext"
		save(HumanMethylation450.adf.ext,file=file.path(outDir,paste(outFn,".rdata",sep="")))
		write.csv(HumanMethylation450.adf.ext,file=file.path(outDir,paste(outFn,".csv",sep="")),row.names=F,quote=F)
	}
	return(HumanMethylation450.adf.ext)
}
createMeth450.adf.ext.1.1<-function(){
	library(mAnnot)
	print(data(blat_align))
	outDir<-"C:\\feipan\\manifests\\humanMeth450k"
	align<-blat.align[,c(1,3,4,6)]
	dim(align);names(align)<-c("IlmnID","blat_start","blat_end","blat_strand")
	length(unique(align$IlmnID))
	HumanMethylation450.adf<-read.delim(file=file.path(outDir,"infinium 450 manifest.csv"),sep=",")
	dim(HumanMethylation450.adf)
	HumanMethylation450.adf.ext<-merge(HumanMethylation450.adf,align,by.x=1,by.y=1,all.x=T)
	save(HumanMethylation450.adf.ext,file=file.path(outDir,"HumanMethylation450.adf.ext.rdata"))
}
createMeth450.adf.ext.1<-function(){
	library(rapid.pro)
	data(HumanMethylation450.adf)
	outDir<-"C:\\feipan\\manifests\\humanMeth450k\\alignment"
	align.uiqnue<-read.delim(file=file.path(outDir,"blat_align_unique.csv",sep=",",stringsAsFactors=F,as.is=T))
	align.unique<-align.unique[,c(1,3,4,5,8,9,10,11)]
	names(align.unique)<-c("IlmnID","strand","Start","End","Chr","ucscRefGene_NAME","SOURCESEQ","MapInfo")
	save(align.unique,file=file.path(outDir,"blat_align_unique.rdata"))
	table(is.na(align.unique$Start))
#	FALSE   TRUE 
#	461842  24093
	nm1<-as.character(HumanMethylation450.adf[,1]);nm2<-as.character(align.unique[,1]);
	ind<-is.element(nm2,nm1);table(ind)
	HumanMethylation450.adf.ext<-merge(HumanMethylation450.adf,align.unique[ind,c("IlmnID","Start","End")],by.x=1,by.y=1,all.x=T)
	save(HumanMethylation450.adf.ext,file="C:\\feipan\\manifests\\humanMeth450k\\HumanMethylation450.adf.ext.rdata")
}
create_meth450.lvl3.adf_test<-function(){
	repeatAnnotFn<-"C:\\feipan\\database\\ucsc\\hg19\\repeatMask\\manifest.rmsp2_05072011.rdata"
	SnpAnnotFn<-"C:\\feipan\\manifests\\humanMeth450k\\snp131\\manifest_snp131_05072011.rdata"
	create_meth450.lvl3.adf(repeatAnnotFn,SnpAnnotFn,outPath="c:\\feipan\\manifests\\humanMeth450k")
	print(load(file="meth450lvlmask_all.rdata"))
	table(mani.lvl3$with_close_snp) #33876
	table(mani.lvl3$within_indel) #3415 
	table(mani.lvl3$with_close_repeats) #6560 
	table(mani.lvl3$covered_with_repeats) #77610
	table(mani.lvl3$blat_uniquely_aligned) #140
	table(mani.lvl3$lvl3_mask) #106890
}
create_meth450.lvl3.adf<-function(repeatAnnotFn,SnpAnnotFn,Overlap.ratio=F,outPath=NULL,dis.min=5){
	library(mAnnot)
	data(blat_align)
	dim(blat.align);names(blat.align)
	blat.align<-blat.align[,c("IlmnID","start","end")]
	names(blat.align)<-c("IlmnID","blat_start","blat_end")
	#Repeats
	manifest.new2<-get(print(load(repeatAnnotFn)))
	dim(manifest.new2)
	manifest.new2$with_close_repeats<-manifest.new2$Distance_to_edge_of_the_closest_repeat<=dis.min
	manifest.new2<-manifest.new2[,c("IlmnID","with_close_repeats","covered_with_repeats")]
	if(Overlap.ratio==T){
		manifest.new2<-merge(manifest.new2,blat.align,by.x=1,by.y=1)
		start<-ifelse(manifest.new2$blat_start>manifest.new2$Start_Of_Repeat,manifest.new2$blat_start,manifest.new2$Start_Of_Repeat)
		end<-ifelse(manifest.new2$blat_end>manifest.new2$End_of_Repeat,manifest.new2$End_of_Repeat,manifest.new2$blat_end)
		len<-sapply(manifest.new2$SOURCESEQ,nchar)
		manifest.new2$Repeat_Overlapping_Ratio<-abs(end-start)/len
		manifest.new2<-manifest.new2[,c("IlmnID","with_close_repeats","covered_with_repeats","Repeat_Overlapping_Ratio")]
	}
	#SNP/INDEL
	mani2<-get(print(load(SnpAnnotFn)))
	dim(mani2)
	mani2$with_close_snp<-mani2$distance_to_nearest_snp131<=dis.min
	mani.lvl3<-merge(mani2,manifest.new2,by.x=1,by.y=1)
	mani.lvl3<-merge(mani.lvl3,blat.align,by.x=1,by.y=1,all.x=T)
	mani.lvl3$blat_uniquely_aligned<-!is.na(mani.lvl3$blat_start)
	mani.lvl3$lvl3_mask<-mani.lvl3$with_close_snp | mani.lvl3$within_indel |!mani.lvl3$blat_uniquely_aligned |mani.lvl3$covered_with_repeat|mani.lvl3$with_close_repeats
	table(mani.lvl3$lvl3_mask)
	if(is.null(outPath))outPath<-"c:\\feipan\\manifests\\humanMeth450k"
	setwd(outPath)
	#write.csv(mani.lvl3,file="meth450lvl3mask.csv",quote=F,row.names=F)
	save(mani.lvl3,file="meth450lvlmask_all.rdata")
	lvl3mask<-mani.lvl3[,c("lvl3_mask","TargetID","CHR","MAPINFO")];
	row.names(lvl3mask)<-lvl3mask$TargetID
	names(lvl3mask)<-c("mask_lvl3","IlmnID","Chr","MapInfo")
	lvl3mask$mask_lvl3<-ifelse(lvl3mask$mask_lvl3==T,1,0)
	table(lvl3mask$mask_lvl3)
	meth450lvl3mask<-lvl3mask
	save(meth450lvl3mask,file="meth450lvl3mask.rdata")
}

create_meth450.lvl3.adf.1<-function(){
	library(mAnnot)
	data(blat_align)
	dim(blat.align);names(blat.align)
	blat.align<-blat.align[,c("IlmnID","start","end")]
	names(blat.align)<-c("IlmnID","blat_start","blat_end")
	#Repeats
	setwd("C:/feipan/database/ucsc/hg19/repeatMask")
	print(load(file="manifest.rmsp2.rdata"))
	setwd("C:\\feipan\\manifests\\humanMeth450k\\snp131")
	dim(manifest.new2)
	manifest.new2<-merge(manifest.new2,blat.align,by.x=1,by.y=1)
	start<-ifelse(manifest.new2$blat_start>manifest.new2$Start_Of_Repeat,manifest.new2$blat_start,manifest.new2$Start_Of_Repeat)
	end<-ifelse(manifest.new2$blat_end>manifest.new2$End_of_Repeat,manifest.new2$End_of_Repeat,manifest.new2$blat_end)
	len<-sapply(manifest.new2$SOURCESEQ,nchar)
	manifest.new2$Repeat_Overlapping_Ratio<-abs(end-start)/len
	manifest.new2<-manifest.new2[,c("IlmnID","Overlap_with_at_least_one_type_repeat","Repeat_Overlapping_Ratio")]
	#SNP/INDEL
	print(load(file="manifest_snp131.rdata"))
	dim(mani2)
	mani.lvl3<-merge(mani2,manifest.new2,by.x=1,by.y=1)
	mani.lvl3<-merge(mani.lvl3,blat.align,by.x=1,by.y=1,all.x=T)
	mani.lvl3$blat_uniquely_aligned<-!is.na(mani.lvl3$blat_start)
	mani.lvl3$lvl3_mask<-mani.lvl3$snp_within_10bp | mani.lvl3$within_indel |!mani.lvl3$blat_uniquely_aligned |mani.lvl3$Overlap_with_at_least_one_type_repeat
	table(mani.lvl3$lvl3_mask)
#	FALSE   TRUE 
#	368748 116829 
	setwd("c:\\feipan\\manifests\\humanMeth450k")
	write.csv(mani.lvl3,file="meth450lvl3mask.csv",quote=F,row.names=F)
	#save(mani.lvl3,file="meth450lvlmask.rdata")
	lvl3mask<-mani.lvl3[,c("lvl3_mask","TargetID","CHR","MAPINFO")];
	row.names(lvl3mask)<-lvl3mask$TargetID
	names(lvl3mask)<-c("mask_lvl3","IlmnID","Chr","MapInfo")
	lvl3mask$mask_lvl3<-ifelse(lvl3mask$mask_lvl3==T,1,0)
	table(lvl3mask$mask_lvl3)
#	0      1 
#	368748 116829
	meth450lvl3mask<-lvl3mask
	save(meth450lvl3mask,file="meth450lvl3mask.rdata")
}
update_meth450.adf_test<-function(){
	acc2gidFn<-"c:\\feipan\\manifests\\humanMeth450k\\accession\\meth450Acc2GID.rdata"
	outFn<-"c:\\feipan\\manifests\\humanMeth450k\\meth450.rdata"
	adf_Fn<-"c:\\feipan\\manifests\\humanMeth450k\\HumanMethylation450.adf.rdata"
	met450<-update_meth450.adf(acc2gidFn)
	meth450<-meth450[order(meth450$EntrezGeneID),]
	table(!is.na(meth450$EntrezGeneID)) #332141
	table(!is.na(HumanMethylation450.adf$ENTREZGENEID)) #332141
	meth450.pid<-meth450$IlmnID[!is.na(meth450$EntrezGeneID)]
	#Comp
	library("IlluminaHumanMethylation450k.db")
	gs<-toTable(IlluminaHumanMethylation450kSYMBOL)
	gid<-toTable(IlluminaHumanMethylation450kENTREZID)
	gid<-gid[order(gid$probe_id),]
	table(!is.na(gid$gene_id)) #331594
	table(is.element(gid$gene_id,meth450$EntrezGeneID))
#	FALSE   TRUE 
#	574 331020
	
	dat<-get(load(file="c:\\feipan\\manifests\\humanMeth450k\\infinium_450_manifest.rdata"))
	gs2<-dat$UCSC_REFGENE_NAME
	table(g2!="")  #365860
	table(dat$UCSC_REFGENE_ACCESSION!="") #365860
	table((dat$UCSC_REFGENE_ACCESSION!="")==(dat$UCSC_REFGENE_NAME!="")) #485577
	pid2<-dat$TargetID[dat$UCSC_REFGENE_NAME!=""]
	table(is.element(pid2,meth450.pid))
#	FALSE   TRUE 
#	33719 332141 
	
	entrezGidAnnotFn<-"c:\\feipan\\manifests\\humanMeth450k\\annotTSS\\meth450.all.rdata" #meth450Gene.rdata" #
	dat<-get(load(file=entrezGidAnnotFn))
	table(!is.na(dat$GeneIDbyDis5000)) #315453
	GeneIDbyDis5000<-gsub("GeneID:","",dat$GeneIDbyDis5000);GeneIDbyDis5000<-GeneIDbyDis5000[!is.na(GeneIDbyDis5000)]
	table(is.element(GeneIDbyDis5000,meth450$EntrezGeneID))
	head(dat[!is.element(GeneIDbyDis5000,meth450$EntrezGeneID),])

	adf<-get(load(file="c:\\feipan\\manifests\\humanMeth450k\\HumanMethylation450.adf.rdata"))
	adf2<-get(load(file="c:\\feipan\\manifests\\humanMeth450k\\HumanMethylation450.adf.1.3.rdata"))
	adf3<-merge(adf,adf2,by.x=1,by.y=1)
	table(!is.na(adf2$ENTREZGENEID)) #205761
	table(is.element(adf2$ENTREZGENEID,adf$ENTREZGENEID))
#	FALSE   TRUE 
#	12 485565
	table(adf3$ENTREZGENEID.x==adf3$ENTREZGENEID.y)#205749
	table(is.element(adf2$GENESYMBOL,adf$GENESYMBOL))
#	FALSE   TRUE 
#	822 484755
	table(adf3$GENESYMBOL.x==adf3$GENESYMBOL.y)
#	FALSE   TRUE 
#	810 204939
	head(adf3[,c("GENESYMBOL.x","GENESYMBOL.y","ENTREZGENEID.x","ENTREZGENEID.y")])
	
	table(!is.na(meth450$GeneSymbol))
#	FALSE   TRUE 
#	153436 332141 
	table((meth450$UCSC_REFGENE_NAME!=""))
#	FALSE   TRUE 
#	119717 365860 
	rst<-sapply(meth450$UCSC_REFGENE_NAME,function(x){gn<-strsplit(x,";")[[1]];length(unique(gn))})
	table(rst)
	index<-1:length(meth450$IlmnID)
	names(gs)<-index
	ucsc_refgene_name<-sapply(index,function(x){
				rst<-F
				symbol<-meth450$GeneSymbol[x]
				gs<-unique(strsplit(meth450$UCSC_REFGENE_NAME[x],";")[[1]])
				for(g1 in gs){
					if(!is.na(g1)&!is.na(symbol)){
						if(g1==symbol)rst<-T
					}
				}
				return(rst)
			})
	table(ucsc_refgene_name)
#	FALSE   TRUE 
#	159031 326546
	library(rapid.pro)
	data(HumanMethylation450.adf)
	table(!is.na(HumanMethylation450.adf$GENESYMBOL)) #332141
	table(HumanMethylation450.adf$UCSC_REFGENE_NAME!="") #365860
	write.csv(HumanMethylation450.adf,file="c:\\temp\\HumanMethylation450.adf.csv",quote=F,row.names=F)
}
update_meth450.adf<-function(acc2gidFn,outFn,adf_Fn=NULL){
	library(mAnnot)
	data(meth450)
	annotGid<-get(load(file=acc2gidFn))
	annotGid<-annotGid[order(annotGid$IlmnID),]
	meth450<-meth450[order(meth450$IlmnID),]
	meth450$EntrezGeneID<-annotGid$GeneID
	if(!is.null(adf)){
		library(rapid.pro)
		data(HumanMethylation450.adf)
		HumanMethylation450.adf<-HumanMethylation450.adf[order(HumanMethylation450.adf$ILMNID),]
		HumanMethylation450.adf$ENTREZGENEID<-meth450$EntrezGeneID
		library(rapid.db)
		con<-dbCon()
		gid2gs<-dbQuery(con,"EntrezGene")
		gs<-merge(HumanMethylation450.adf,gid2gs,by.x="ENTREZGENEID",by.y="GeneID",all.x=T)
		gs<-gs[order(gs$ILMNID),]
		#check
		all(HumanMethylation450.adf$ILMNID==meth450$IlmnID)
		all(HumanMethylation450.adf$ILMNID==gs$ILMNID)
		#update
		HumanMethylation450.adf$GENESYMBOL<-gs$Symbol
		HumanMethylation450.adf$UCSC_REFGENE_NAME<-meth450$UCSC_REFGENE_NAME
		meth450$GeneSymbol<-gs$Symbol
		save(HumanMethylation450.adf,file=adf_Fn)
	}
	save(meth450,file=outFn)
	return(meth450)
}
update_meth450.adf.1.1<-function(acc2gidFn,outFn,adf_Fn=NULL){
	library(mAnnot)
	data(meth450)
	annotGid<-get(load(file=acc2gidFn))
	annotGid<-annotGid[order(annotGid$IlmnID),]
	meth450<-meth450[order(meth450$IlmnID),]
	meth450$EntrezGeneID<-annotGid$GeneID
	save(meth450,file=outFn)
	if(!is.null(adf)){
		library(rapid.pro)
		data(HumanMethylation450.adf)
		HumanMethylation450.adf<-HumanMethylation450.adf[order(HumanMethylation450.adf$ILMNID),]
		HumanMethylation450.adf$ENTREZGENEID<-meth450$EntrezGeneID
		library(rapid.db)
		con<-dbCon()
		gid2gs<-dbQuery(con,"EntrezGene")
		gs<-merge(HumanMethylation450.adf,gid2gs,by.x="ENTREZGENEID",by.y="GeneID",all.x=T)
		gs<-gs[order(gs$ILMNID),]
		HumanMethylation450.adf$GENESYMBOL<-gs$Symbol
		save(HumanMethylation450.adf,file=adf_Fn)
	}
	return(meth450)
}
update_meth450.adf.1<-function(acc2gidFn,outFn,adf_Fn=NULL){
	library(mAnnot)
	data(meth450)
	annotGid<-get(load(file=acc2gidFn))
	annotGid<-annotGid[order(annotGid$IlmnID),]
	meth450<-meth450[order(meth450$IlmnID),]
	meth450$EntrezGeneID<-annotGid$GeneID
	save(meth450,file=outFn)
	if(!is.null(adf)){
		library(rapid.pro)
		data(HumanMethylation450.adf)
		HumanMethylation450.adf<-HumanMethylation450.adf[order(HumanMethylation450.adf$ILMNID),]
		HumanMethylation450.adf$ENTREZGENEID<-meth450$EntrezGeneID
		save(HumanMethylation450.adf,file=adf_Fn)
	}
	return(meth450)
}
update_HumanMethylation450.adf_test<-function(){
	datFn<-"C:\\feipan\\manifests\\humanMeth450k\\infinium 450 manifest.csv"
	outFn<-"c:\\temp\\HumanMethylation450.adf.rdata"
	update_HumanMethylation450.adf(datFn,outFn)
}
update_HumanMethylation450.adf<-function(datFn=NULL,outFn=NULL){
	if(is.null(datFn)){
		library(rapid.db)
		con<-dbCon("C:\\Documents and Settings\\feipan\\Desktop\\people\\tejas\\testTab.db")
		meth450<-dbQuery(con,"HumanMethylation450")
		dbDisconnect(con)
	}else{
		meth450<-read.delim(file=datFn,sep=",",stringsAsFactors=F,as.is=T)
	}
	names(meth450)
	require(rapid.pro)
	data(HumanMethylation450.adf);adf<-HumanMethylation450.adf
	adf<-adf[,c("ILMNID","GENESYMBOL","ENTREZGENEID")]
	HumanMethylation450.adf<-merge(adf,meth450,by.x="ILMNID",by.y="ILMNID")
	row.names(HumanMethylation450.adf)<-HumanMethylation450.adf$ILMNID
	save(HumanMethylation450.adf,file=outFn)
}