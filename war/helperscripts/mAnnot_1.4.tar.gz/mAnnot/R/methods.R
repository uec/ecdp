# TODO: Add comment
# 
# Author: feipan
###############################################################################

########################
## Description:
## Argument:
#######################
getSubSet<-function(set,annotType,db="humanMeth27k"){
	if(!exists(db))db<-getData(platform=db)
	if(annotType=="Symbol" ||annotType=="gs"){
		subset(db["GeneSymbol"],set)
	}else if(annotType == "Gid" ||annotType=="Gene_ID"){
		subset(db["Gene_ID"],set)
	}else{
		cat("Unknow annotType, please type help(getSubSet) for more helps.\n")
	}
}
getData <- function(platform="humanMeth27k",toReturn=F,toCheckUpdate=F,version="1.0"){
	db <- NULL;
	if(platform =="humanMeth27k" ||platform=="infinium"){
		require(humanMeth27k)
		if(!exists("humanMeth27k"))data(humanMeth27k)
		ver <- attr(humanMeth27k,"version")
		date <- attr(humanMeth27k,"date")
		cat("The current version of the DNA Methylation humanMeth27k (Infinium) manifest is ",ver,"\n")
		cat("The modification date of the DNA Methylation humanMeth27k (Infinium) manifest is ",date,"\n")
		db <- humanMeth27k;
	}else if(platform=="OMA02" || platform=="GoldenGateOMA02"){
		require(GoldenGateManifest);
		if(!exists("OMA02Manifest")) data(OMA02Manifest)
		ver <- attr(OMA02Manifest,"version")
		date <- attr(OMA02Manifest,"date")
		cat("The current version of the DNA Methylation OMA02 (Illumina GoldenGate) Manifest is ",ver,"\n")
		cat("The modification date of the DNA Methylation OMA02 (Illumina GoldenGate) Manifest is ",date,"\n")
		db <- OMA02Manifest;
	}else if(platform=="OMA03" || platform=="GoldenGateOMA03"){
		require(GoldenGateManifest);
		if(!exists("OMA03Manifest"))data(OMA03Manifest)
		ver <- attr(OMA03Manifest,"version")
		date <- attr(OMA03Manifest,"date")
		cat("The current version of the DNA Methylation OMA03 (Illumina GoldenGate) Manifest is ",ver,"\n")
		cat("The modification date of the DNA Methylation OMA03 (Illumina GoldenGate) Manifest is ",date,"\n")	
		db <- OMA03Manifest;
	}else if(platform=="OMA04" || platform=="GoldenGateOMA04"){
		require(GoldenGateManifest);
		if(!exists("OMA04Manifest"))data(OMA04Manifest)
		ver <- attr(OMA04Manifest,"version")
		date <- attr(OMA04Manifest,"date")
		cat("The current version of the DNA Methylation OMA04 (Illumina GoldenGate) Manifest is ",ver,"\n")
		cat("The modification date of the DNA Methylation OMA04 (Illumina GoldenGate) Manifest is ",date,"\n")	
		db<- OMA04Manifest;
	}else if(platform=="methyLight" | platform=="ML"){
		require(methyLightManifest);
		if(!exists("MethyLightManifest"))data(MethyLightManifest)
		ver <- attr(MethyLightManifest,"version")
		date <- attr(MethyLightManifest,"date")
		cat("The current version of the DNA Methylation methyLight Manifest is ",ver,"\n")
		cat("The modification date of the DNA Methylation methyLight Manifest is ",date,"\n")		
		db<-MethyLightManifest;
	}else{
		cat("type help(getData) for more helps \n")
	}
	if(toCheckUpdate==T) {
		cur_ver<-checkUpdate(platform,db$version)
		if(cur_ver!=db$version){
			msg<-paste("There is a new version of ",platform," available.\n")
			cat(msg)
		}
	}
	if(toReturn==T) return (db);
}
checkUpdate<-function(platform="humanMeth27k",ver){
	
}
getEntrezID<-function(platform="humanMeth27k",is.int = FALSE){
	rst <- NULL;
	if(platform=="humanMeth27k"){
		require(humanMeth27k)
		data(humanMeth27k)
		gids <- humanMeth27k["Gene_ID"];
		ilmn_id <- humanMeth27k["ILmnID"];
		tf<-function(gs)unlist(strsplit(gs,":"))[2]
		if(is.int){
			rst <- apply(gids,1,tf)
			return(data.frame(IlmnID=ilmn_id,EntrezGeneID=rst))
		}
		rst <- data.frame(IlmnID=ilmn_id,EntrezGeneID=gids);
		attr(rst,"platform") <- "humanMeth27k"
	}else if(platform=="OMA02"){
		require(GoldenGateManifest)
		data(OMA02Manifest)
		rst <- data.frame(IlmnID=OMA02Manifest$Probe_ID,
				EntrezGeneID=OMA02Manifest$Gene_ID)
		attr(rst,"platform") <-"OMA02Manifest"
	}else if(platform=="OMA03"){
		require(GoldenGateManifest)
		data(OMA03Manifest)
		rst <- data.frame(IlmnID=OMA03Manifest$TARGET.ID,
				EntrezGeneID=OMA03Manifest$Gene_ID)
		attr(rst,"platform") <-"OMA03Manifest"
	}else if(platform=="OMA04"){
		require(GoldenGateManifest)
		data(OMA04Manifest)
		rst <- data.frame(IlmnID=OMA04Manifest$Target.ID,
				EntrezGeneID=OMA04Manifest$Entrez.Gene.ID)
		attr(rst,"platform") <-"OMA04Manifest"
	}else if(platform=="methyLight" ||"methyLightManifest"){
		require(methyLIghtManifest)
		data(MethyLightManifest)
		rst<-data.frame(ID=MethyLightManifest$`Reaction Number`,
				EntrezGeneID=MethyLightManifest$`GenBank Accession Number`)
	}else{
		cat("no platform was specified, type help(getEntrezID) for more help\n")
	}
	return(rst)
}
getPlatformIDs<-function(platform="humanMeth27k"){
	platformIDs<-NULL
	if(platform=="humanMeth27k"||platform=="Inifinium"){
		if(!exists("humanMeth27k")) getData()
		platformIDs<-humanMeth27k$IlmnID
	}else if(platform=="OMA02"||platform=="OMA02GoldenGate"){
		if(!exists("OMA02Manifest")) getData("OMA02Manifest")
		platformIDs<-OMA02Manifest$Probe_ID
	}else if(platform=="OMA03" ||platform=="OMA03GoldenGate"){
		if(!exists("OMA03Manifest")) getData("OMA03Manifest")
		platformIDs<-OMA03Manifest$TARGET.ID
	}else if(platform=="OMA04"||platform=="OMA03Manifest"){
		if(!exists("OMA04Manifest"))getData("OMA04Manifest")
		platformIDs<-OMA04Manifest$Target.ID
	}else if(platform=="methyLight"){
		if(!exists("MethyLightManifest"))getData("MethyLightManifest")
		platformIDs<-MethyLightManifest$Reaction
	}else{
		cat("please type help(getPlatformIDs) for more information\n")
	}
	return(platformIDs)
}
getAnnot<-function(db="humanMeth27k",type){
	ans<-NULL;
	if(db=="humanMeth27k"||db=="Infinium"){
		if(!exists(db))getData(db)
		if(!exists(humanMeth27k[type])){
			cat("The type annot is unknown to the db specified, please type str(db) for more information")
		}else{
			ans<-humanMeth27k[[type]]
		}
	}else if(db=="OMA02"||db=="OMA02GoldenGate"){
		if(!exists(db))getData(db)
		if(!exists(OMA02Manifest[type])){
			cat("Type is unknown,please type str(db) for more information")
		}else{
			ans<-OMA02Manifest[type]
		}
	}else if(db=="OMA03"||db=="OMA03GoldenGate"){
		if(!exists(db))getData(db)
		if(!exists(OMA03Manifest[type])){
			cat("Type is unknown, please type str(db) for more information")
		}else{
			ans<-OMA03Manifest[type]
		}
	}else if(db=="OMA04"||db=="OMA04GoldenGate"){
		if(!exists(db))getData(db)
		if(!exists(OMA04Manifest[type])){
			cat("Type is unknown, please type str(db) for more information")
		}else{
			ans<-OMA04Manifest[type]
		}
	}else if(db=="methyLight"){
		if(!exists(db))getData(db)
		if(!exist(MethyLightManifest[type])){
			cat("Type is unknown, please type str(db) for more information\n")
		}else{
			ans<-MethyLightManifest[type]
		}
	}else{
		cat("unkown database specified")
	}
}
##TODO: add more input data checks
getFeaure<-function(dlist,db="humanMeth27k",type){
	if(!is.character(type))cat("Type should be a name string known to the db")
	if(!is.list(dlist))cat("dlist should be a vector type")
	typeAnnot<-getAnnot(db,type)
	ans<-subset(typeAnnot,(dlist %in% typeAnnot[type]))
	return(ans)
}
###################
##
## Description:
## Argument:
##################
#subGeneInfo<-function(file=NULL,vect=NULL,platform="humanMeth27k",outfile="outfile.csv"){
#	geneInfo <- getGeneInfo(platform);
#	#browser()
#	if(!is.null(vect)){
#		vect=as.character(vect)
#		return(geneInfo[vect,])
#	}else if(!is.null(file)){
#		dat<-read.csv(file=file)
#		vect=as.character(dat[[1]])
#		rst<-cbind(geneInfo[vect,],dat)
#		write.table(rst,file=outfile,sep=",")
#		cat(paste("pls check out the output file: ",outfile,"\n",sep=""))
#		return(rst)
#	}else{
#		return(geneInfo)
#	}
#}
#####################
#
####################
getMapInfo.2<-function(platform="humanMenth27k"){
	require(IRanges)
	mapinfo<-getMapInfo(platform)
	ir<-IRanges(start=mapinfo$start,end=mapinfo$end)
	mapinfo<-RangedData(ir,name=mapinfo$IlmnID,space=mapinfo$Chr,mapinfo)
	return(mapinfo)
}
#####################
##
## Description:
## Argument:
#######################
getMapInfo<-function(platform="humanMeth27k",is.int=TRUE){
	rst <- NULL;
	if(platform=="humanMeth27k"){
		require(humanMeth27k)
		data(humanMeth27k)
#		gids <- humanMeth27k["Gene_ID"];
#		ilmn_id <- humanMeth27k["IlmnID"];
#		tf<-function(gs)unlist(strsplit(gs,":"))[2]

		rst<-(data.frame(row.names=humanMeth27k$ILmnID,
						IlmnID=humanMeth27k$ILmnID,
						EntrezGeneID=humanMeth27k$GID_Update,
						GeneSymbol=humanMeth27k$Symbol,
						start=humanMeth27k$start_blat_align_source_sequence,
						end=humanMeth27k$end_blat_align_source_sequence,
						Chr=humanMeth27k$Chr,
						mapInfo=humanMeth27k$MapInfo,
						Seq=humanMeth27k$SourceSeq))
		attr(rst,"platform") <- "humanMeth27k"
	}else if(platform=="OMA02"){
		require(GoldenGateManifest)
		data(OMA02Manifest)
		rst <- data.frame(row.names=OMA02Manifest$Probe_ID,
				IlmnID=OMA02Manifest$Probe_ID,
				EntrezGeneID=OMA02Manifest$Gene_ID,
				GeneSymbol =OMA02Manifest$Symbol,
				start=OMA02Manifest$start_blat_align,
				end=OMA02Manifest$end_blat_align,
				mapInfo=OMA02Manifest$CpG.Coordinate,
				Chr=OMA02Manifest$Chromosome,
				Seq=OMA02Manifest$Input_Sequence)
		attr(rst,"platform") <-"OMA02Manifest"
	}else if(platform=="OMA03"){
		require(GoldenGateManifest)
		data(OMA03Manifest)
		rst <- data.frame(row.names=OMA03Manifest$TargetID,
				IlmnID=OMA03Manifest$TargetID,
				EntrezGeneID=OMA03Manifest$Gene_ID,
				GeneSymbol=OMA03Manifest$Symbol,
				mapInfo=OMA03Manifest$CpG.Coordinate,
				start=OMA03Manifest$blat_align_start,
				end=OMA03Manifest$blat_align_end,
				Chr=OMA03Manifest$Chromosome,
				Seq=OMA03Manifest$Input_Sequence)
		attr(rst,"platform") <-"OMA03Manifest"
	}else if(platform=="OMA04"){
		require(GoldenGateManifest)
		data(OMA04Manifest)
		rst <- data.frame(row.names=OMA04Manifest$TargetID,
				IlmnID=OMA04Manifest$TargetID,
				gid=OMA04Manifest$Entrez_Gene_ID_updated ,
				gs=OMA04Manifest$Symbol_updated,
				mapInfo=OMA04Manifest$CpG_Coordinate ,
				start=OMA04Manifest$blat_align_start,
				end=OMA04Manifest$blat_align_end,
				Chr=OMA04Manifest$Chr,
				Seq=OMA04Manifest$Sequence)
		attr(rst,"platform") <-"OMA04Manifest"
	}else if(platform=="MethyLight"){
		require(methyLightManifest)
		data(MethyLightManifest)
		rst<-data.frame(row.names=MethyLightManifest[,1],
				mID=MethyLightManifest[,1],
				gid=MethyLightManifest[,2],
				start=MethyLightManifest$start_genome_coord_blat_aligned,
				end=MethyLightManifest$end_genome_coord_blat_aligned,
				Chr=MethyLightManifest$Chr_blat_aligned,
				Seq=MethyLightManifest[,51])
		rst$mapInfo<-rst$end+(rst$end-rst$start)/2
		
	}else{
		cat("no platform was specified, type help(getEntrezID) for more help\n")
	}
	return(rst)
}
###########################
## Description:
## Argument:
#########################
getCpGIslandInfo<-function(platform="humanMeth27k"){
	rst<-NULL;
	if(platform=="humanMeth27k"){
		require(humanMeth27k)
		data(humanMeth27k)
		rst <- data.frame(row.names=humanMeth27k$IlmnID,
				IlmnID=humanMeth27k["IlmnID"],
				IsCpGIsland=humanMeth27k["CPG_ISLAND"],
				CpGIslandLocation=humanMeth27k["CPG_ISLAND_LOCATIONS"],
				GcContent=humanMeth27k["GC_Content..Without.repeatMasked."],
				LenTakaiJonesCGI=humanMeth27k["length.of.Takai_Jones.CGI"],
				LenGardinerCardenCGI=humanMeth27k["length.of.Gardiner.Garden.CGI"],
				DistToMidOfTakaiJonesCGI=humanMeth27k["Distance.to.the.middle.of.Takai_Jones.CGI"],
				DistToMidOfGardinerGardenCGI=humanMeth27k["Distance.to.the.middle.of.Gardiner.Garden.CGI"]
		)
		attr(rst,"platform") <- "humanMeth27k"
	}else if(platform=="OMA02"){
		require(GoldenGateManifest)
		data(OMA02Manifest)
		rst <- data.frame(row.names=OMA02Manifest$Probe_ID,
				IlmnID=OMA02Manifest["Probe_ID"],
				CpGCoordinate=OMA02Manifest["CpG_Coordinate"],
				CpGNumber=OMA02Manifest["CpG.number"]
		)
		attr(rst,"platform") <- "OMA02Manifest"
		
	}else if(platform=="OMA03"){
		require(GoldenGateManifest)
		data(OMA03Manifest)
		rst <- data.frame(row.names=OMA03Manifest$TARGET.ID,
				IlmnID=OMA03Manifest["TARGET.ID"],
				CpGCoordinate=OMA03Manifest["CpG.Coordinate"],
				CpGNumber=OMA03Manifest["CpG.Number"],
				ObsExpRatioNoRepeats=OMA03Manifest["CpG.O.E..no.repeat.masking."],
				ObsExpRatioRepeats=OMA03Manifest["CpG.O.E..repeat.masked."]
		)
		attr(rst,"platform") <- "OMA03Manifest";	
		
	}else if(platform=="OMA04"){
		require(GoldenGateManifest)
		data(OMA04Manifest)
		rst <- data.frame(row.names=OMA04Manifest$Target.ID,
				IlmnID=OMA04Manifest["Target.ID"],
				isCpGIsland=OMA04Manifest["CpG.Island"]
		)
		attr(rst,"platform") <- "OMA04Manifest"
		
	}else if(platform=="methLight"){
		cat("to come..\n")
	}else{
		cat("woops, no platform was selected, type help(getCpGIslandInfo) for more help\n")
	}
	return(rst)
}

getPolycombInfo<-function(platform="humanMeth27k"){
	rst <- NULL;
	if(platform=="humanMeth27k"|platform=="Meth27"){
		require(humanMeth27k)
		data(humanMeth27k)
		rst<-data.frame(row.names=humanMeth27k$ILmnID,
				IlmnID=humanMeth27k[,"ILmnID"],
				Suze12Occupancy=humanMeth27k[,"Suz12 Occupancy"],
				EedOccupancy=humanMeth27k[,"Eed Occupancy"],
				H3K27me3Occupancy=humanMeth27k[,"H3K27me3 Occupancy"],
				TotalPolycombOccupancy=humanMeth27k[,"TOTAL POLYCOMB"]
		)
		attr(rst,"platform") <- "humanMeth27k";	
	}else if(platform =="OMA02"){
		require(GoldenGateManifest)
		data(OMA02Manifest)
		rst <- data.frame(IlmnID=OMA02Manifest$Probe_ID,
				Suze12Occupancy=OMA02Manifest$Suz12.Occupancy,
				H3K27me3Occupancy=OMA02Manifest$H3K27me3.Occupancy,
				EedOccupancy =OMA02Manifest$Eed.Occupancy,
				totalPlycombOccupancy=OMA02Manifest$PRC2.TOTAL
				)
		attr(rst,"platform") <- "OMA02Manifest"
	}else if(platform == "OMA03"){
		require(GoldenGateManifest)
		data(OMA03Manifest)
		rst<-data.frame(IlmnID=OMA03Manifest$TargetID,
				Suze12Occupancy=OMA03Manifest$Suz12.Occupancy,#EedOccupancy=OMA03Manifest$Eed.Occupancy,
				H3K27me3Occupancy=OMA03Manifest$H3K27me3.Occupancy,
				totalPolyOccupancy=OMA03Manifest$PRC2.TOTAL)
		attr(rst,"platform") <- "OMA03Manifest"
	}else if(platform == "OMA04"){
		require(GoldenGateManifest)
		data(OMA04Manifest)
		rst<-data.frame(row.names=OMA04Manifest$Probe_ID,
				IlmnID=OMA04Manifest$Probe_ID,
				Suze12Occupancy=OMA04Manifest$Suz12.Occupancy,
				EedOccupancy=OMA04Manifest$Eed.Occupancy,
				H3K27me3Occupancy=OMA04Manifest$H3K27me3.Occupancy,
				totalPolycombOccupancy=OMA04Manifest$Total.Polycomb
		)
		attr(rst,"platform") <- "OMA04Manifest"
	}else if(platform=="methLight"){
		cat("to come..\n")
	}else{
		cat("woop, no platform was specifiied, please type help(getPolycombInfo) for more help\n")
	}
	
	return(rst)
}

getProbeInfo<-function(){
	rst <- NULL;
	if(platform=="humanMeth27k"){
		require(humanMeth27k)
		data(humanMeth27k)
		rst<-data.frame(row.names=humanMeth27k$IlmnID,
				IlmnID=humanMeth27k$IlmnID,
				humanMeth27k$IlmnStrand, 
				humanMeth27k$AddressA_ID, 
				humanMeth27k$AlleleA_ProbeSeq,
				humanMeth27k$AddressB_ID, 
				humanMeth27k$AlleleB_ProbeSeq,
				humanMeth27k$GenomeBuild, 
				humanMeth27k$Chr, 
				humanMeth27k$MapInfo.1, 
				humanMeth27k$Ploidy, 
				humanMeth27k$Species, 
				humanMeth27k$Source, 
				humanMeth27k$SourceVersion, 
				humanMeth27k$SourceStrand, 
				humanMeth27k$SourceSeq, 
				humanMeth27k$TopGenomicSeq, 
				humanMeth27k$Next_Base,
				humanMeth27k$Color_Channel, 
				humanMeth27k$TSS_Coordinate.1, 
				humanMeth27k$Gene_Strand
		)
		attr(rst,"platform") <- "humanMeth27k";	
	}else if(platform =="OMA02"){
		require(GoldenGateManifest)
		data(OMA02Manifest)
		rst <- data.frame(row.names=OMA02Manifest$Probe_ID,
				IlmnId=OMA02Manifest$Probe_ID,
				OMA02Manifest$Chromosome,
				OMA02Manifest$CpG_Coordinate, 
				OMA02Manifest$Dist_to_TSS, 
				OMA02Manifest$Input_Sequence
		)
		attr(rst,"platform") <- "OMA02Manifest"
	}else if(platform == "OMA03"){
		require(GoldenGateManifest)
		data(OMA03Manifest)
		rst<-data.frame(row.names=OMA03Manifest$TARGET.ID,
				IlmnId=OMA03Manifest$TARGET.ID,
		)
		attr(rst,"platform") <- "OMA03Manifest"
	}else if(platform == "OMA04"){
		require(GoldenGateManifest)
		data(OMA04Manifest)
		rst<-data.frame(row.names=OMA04Manifest$Target.ID,
				IlmnId=OMA04Manifest$Target.ID
		
		)
		attr(rst,"platform") <- "OMA04Manifest"
	}else if(platform=="methLight"){
		cat("to come..\n")
	}else{
		cat("woop, no platform was specifiied, please type help(getPolycombInfo) for more help\n")
	}
	
	return(rst)
}
#
#getRepeatInfo<-function(){
#	rst <- NULL;
#	if(platform=="humanMeth27k"){
#		require(humanMeth27k)
#		data(humanMeth27k)
#		rst<-data.frame(row.names=humanMeth27k$IlmnID,
#				IlmnID=humanMeth27k$IlmnID,
#				RepeatInProbeSequence=humanMeth27k$Repeat.in.probe.sequence...Yes.No.,
#				RepeatLength=humanMeth27k$Repeat.Length..bp.,
#				EliminateWithRepeatLenGreaterThan10=humanMeth27k$Eliminate.Because.of.Repeat...10.bp...Yes.No.,
#				EliminateWithRepeatLenGreaterThan20=humanMeth27k$Eliminate.Because.of.Repeat...20.bp...Yes.No.,
#		)
#		attr(rst,"platform") <- "humanMeth27k";	
#	}else if(platform =="OMA02"){
#		require(GoldenGateManifest)
#		data(OMA02Manifest)
#		rst <- data.frame(row.names=OMA02Manifest$Probe_ID,
#				IlmnId=OMA02Manifest$Probe_ID,
#				
#		)
#		attr(rst,"platform") <- "OMA02Manifest"
#	}else if(platform == "OMA03"){
#		require(GoldenGateManifest)
#		data(OMA03Manifest)
#		rst<-data.frame(row.names=OMA03Manifest$TARGET.ID,
#				IlmnId=OMA03Manifest$TARGET.ID,
#		)
#		attr(rst,"platform") <- "OMA03Manifest"
#	}else if(platform == "OMA04"){
#		require(GoldenGateManifest)
#		data(OMA04Manifest)
#		rst<-data.frame(row.names=OMA04Manifest$Target.ID,
#				IlmnId=OMA04Manifest$Target.ID
#				
#		)
#		attr(rst,"platform") <- "OMA04Manifest"
#	}else if(platform=="methLight"){
#		cat("to come..\n")
#	}else{
#		cat("woop, no platform was specifiied, please type help(getPolycombInfo) for more help\n")
#	}
#	
#	return(rst)
#}
getNearestOMA02Info<-function(){
	require(humanMeth27k)
	data(humanMeth27k)
	rst<-data.frame(row.names=humanMeth27k$IlmnID,
			IlmnID=humanMeth27k$IlmnID,
			nearestOM02Probe=humanMeth27k$Nearest.probe.on.OMA.002.beadarray
			)
	attr(rst,"platform") <- "humanMeth27k";	
	return(rst)
}
getNearestOMA03Info<-function(){
	require(humanMeth27k)
	data(humanMeth27k)
	rst<-data.frame(row.names=humanMeth27k$IlmnID,
			IlmnID=humanMeth27k$IlmnID,
			nearestOM03Probe=humanMeth27k$nearest.probe.on.OMA.003.beadarray
	)
	attr(rst,"platform") <- "humanMeth27k";	
	return(rst)
}
getNearestOMA04Info<-function(){
	require(humanMeth27k)
	data(humanMeth27k)
	rst<-data.frame(row.names=humanMeth27k$IlmnID,
			IlmnID=humanMeth27k$IlmnID,
			nearestOMA04Probe=humanMeth27k$Nearest.probe.on.OMA.004.beadarray
	)
	attr(rst,"platform") <- "humanMeth27k";	
	return(rst)
}
getNearestMethLightInfo<-function(){
	require(humanMeth27k)
	data(humanMeth27k)
	rst<-data.frame(row.names=humanMeth27k$IlmnID,
			IlmnID=humanMeth27k$IlmnID,
			nearestMethLightProbe=humanMeth27k$MethyLight.HB.Number,
			distanceTonearestMethLightProbe=humanMeth27k$nearest_distance_to.MethyLight
	)
	attr(rst,"platform") <- "humanMeth27k";	
	return(rst)
}
#
#getSNPInfo<-function(){
#	rst <- NULL;
#	if(platform=="humanMeth27k"){
#		require(humanMeth27k)
#		data(humanMeth27k)
#		rst<-data.frame(row.names=humanMeth27k$IlmnID,
#				IlmnID=humanMeth27k$IlmnID,
#				EliminateBecauseOfSNP = humanMeth27k$Eliminate.Because.of.SNP...Yes.No.,
#				CpGLocusSNP = humanMeth27k$CpG.SNP...Yes.No.,
#				SNPinProbeSeq = humanMeth27k$SNP.in.probe.sequence...Yes.No.
#		)
#		attr(rst,"platform") <- "humanMeth27k";	
#	}else if(platform =="OMA02"){
#		require(GoldenGateManifest)
#		data(OMA02Manifest)
#		rst <- data.frame(row.names=OMA02Manifest$Probe_ID,
#				IlmnId=OMA02Manifest$Probe_ID,
#		
#		)
#		attr(rst,"platform") <- "OMA02Manifest"
#	}else if(platform == "OMA03"){
#		require(GoldenGateManifest)
#		data(OMA03Manifest)
#		rst<-data.frame(row.names=OMA03Manifest$TARGET.ID,
#				IlmnId=OMA03Manifest$TARGET.ID,
#		)
#		attr(rst,"platform") <- "OMA03Manifest"
#	}else if(platform == "OMA04"){
#		require(GoldenGateManifest)
#		data(OMA04Manifest)
#		rst<-data.frame(row.names=OMA04Manifest$Target.ID,
#				IlmnId=OMA04Manifest$Target.ID
#		
#		)
#		attr(rst,"platform") <- "OMA04Manifest"
#	}else if(platform=="methLight"){
#		cat("to come..\n")
#	}else{
#		cat("woop, no platform was specifiied, please type help(getPolycombInfo) for more help\n")
#	}
#	
#	return(rst)
#}

getGenomeInfo<-function(platform){
	rst <- NULL;
	if(platform=="humanMeth27k"){
		require(humanMeth27k)
		data(humanMeth27k)
		rst<-data.frame(row.names=humanMeth27k$ILmnID,
				IlmnID=humanMeth27k$ILmnID,
				Chromesome=humanMeth27k$Chr,
				MapInfo=humanMeth27k$MapInfo,
				TSSCoord=humanMeth27k$TSS_Coordinate,
				GenomeBuild=humanMeth27k$GenomeBuild,
				GeneStrand=humanMeth27k$Gene_Strand,
				GeneID=humanMeth27k$GID_Update,
				Symbol=humanMeth27k$Symbol
		)
		attr(rst,"platform") <- "humanMeth27k";	
	}else if(platform =="OMA02"){
		require(GoldenGateManifest)
		data(OMA02Manifest)
		rst <- data.frame(row.names=OMA02Manifest$Probe_ID,
				IlmnID=OMA02Manifest$Probe_ID,
				MapInfo=OMA02Manifest$CpG_Coordinate,
				DistToTSS=OMA02Manifest$Dist_to_TSS,
				GeneID=OMA02Manifest$Gene_ID,
				Symbol=OMA02Manifest$Symbol
		)
		attr(rst,"platform") <- "OMA02Manifest"
	}else if(platform == "OMA03"){
		require(GoldenGateManifest)
		data(OMA03Manifest)
		OMA03Manifest$Dist_to_TSS<-abs(OMA03Manifest$CpG.Coordinate-OMA03Manifest$TSS_Coordinate)
		rst<-data.frame(row.names=OMA03Manifest$TARGET.ID,
				IlmnID=OMA03Manifest$TARGET.ID,
				MapInfo=OMA03Manifest$CpG.Coordinate,
				TSSCoord=OMA03Manifest$TSS_Coordinate,
				DistToTSS=OMA03Manifest$Dist_to_TSS,
				GeneID=OMA03Manifest$Gene_ID,
				Symbol=OMA03Manifest$Symbol
		)
		attr(rst,"platform") <- "OMA03Manifest"
	}else if(platform == "OMA04"){
		require(GoldenGateManifest)
		data(OMA04Manifest)
		OMA04Manifest$Gene_ID<-sapply(OMA04Manifest$Gene_ID,function(x)gsub("GeneID:","",x))
		rst<-data.frame(row.names=OMA04Manifest$Probe_ID,
				IlmnID=OMA04Manifest$Probe_ID,
				MapInfo=OMA04Manifest$CpG_Coordinate,
				GeneStrand=OMA04Manifest$Gene_Strand,
				TSSCoord=OMA04Manifest$TSS_Coordinate,
				GeneID=OMA04Manifest$EntrezGene.ID,
				Symbol=OMA04Manifest$Gene.Name
		)
		attr(rst,"platform") <- "OMA04Manifest"
	}else if(platform=="methLight"){
		cat("to come..\n")
	}else{
		cat("woop, no platform was specifiied, please type help(getPolycombInfo) for more help\n")
	}
	
	return(rst)
}

getMeanColonNormalRatio<-function(){
	require(humanMeth27k)
	data(humanMeth27k)
	rst<-data.frame(row.names=humanMeth27k$IlmnID,
			IlmnID=humanMeth27k$IlmnID,
			MeanColonNormalRatio = humanMeth27k$Mean.Colon.Tumor...Mean.Colon.Normal...0.2.
	)
	attr(rst,"platform") <- "humanMeth27k";	
	return(rst)
}
getMeanBreastNormalRatio<-function(){
	require(humanMeth27k)
	data(humanMeth27k)
	rst<-data.frame(row.names=humanMeth27k$IlmnID,
			IlmnID=humanMeth27k$IlmnID,
			MeanBreastNormalRatio=humanMeth27k$Mean.Breast.Tumor...Mean.Breast.Normal...0.2.
	)
	attr(rst,"platform") <- "humanMeth27k";	
	return(rst)
}

getManifest <- function(platform="humanMeth27k",version="1.0"){
	getData(platform,version)
}

viewReadMe <-function(){
	outdir <- getwd()
	url.show("http://epinexus.usc.edu/manifests/readMe.txt")
}
viewUpdate<-function(){
	url.show("http://epinexus.usc.edu/manifests/update.txt")
}
getVersion<-function(platform="humanMeth27k",version="1.0"){
	getData(platform=platform,version=version)
}
getSeq<-function(db="humanMeth27k"){
	rst<-NULL
	if(db=="humanMeth27k" | db=="Infinium"){
		
	}else if(db=="OMA04"){
	
	}else if(db=="OMA02"){
		
	}else if(db=="OMA03"){
		
	}else if(db=="MethyLight"){
		
	}else{
		cat("unkown platform \n")
	}
}
##################
# Name: batch normalization
# Description: wrapper function of the univariate normalization approach
###################
library(PBR)
#BatchNormalization<-function(data, batch, method="mean",data.new=NULL,batch.new=NULL){
#	data.norm <- NULL
#	if(method=="scale"){
#		data.norm <- fitModel.scale(data,batch)
#		if(!is.null(data.new)){
#			data.norm <- fitModel.scale(data,batch,data.new,batch.new)
#		}
#	}else{
#		data.norm <- fitModel.linear(data,batch)
#		if(!is.null(data.new)){
#			data.norm <- fitModel.linear2(data,batch,data.new,batch.new)
#		}
#	}
#	return(data.norm)
#}
#fitModel.linear <- function(y,x){
#	mod.ln<-function(y1,x){
#		x<-as.factor(x)
#		y1<-as.numeric(y1)
#		mod <- lm(y1~x)
#		mod$residuals+mean(y1)
#	}
#	t(apply(y,1,mod.ln,x))
#}
#fitModel.linear2 <- function(y,x,y.new = NULL,x.new.batch=NULL){
#	mod.ln<-function(y1,x,y.new,y.new.batch){
#		x<-as.factor(x)
#		y1<-as.numeric(y1)
#		mod <- lm(y1~x)
#		y1.norm <- mod$residuals+mean(y1)
#		if(is.null(y.new)){
#			y1.mean.batch <- tapply(y1,x,mean)
#			y1.norm <- y.new-y1.mean.batch[dat.batch]
#		}
#		return(y1.norm)
#	}
#	#t(apply(y,1,mod.ln,x))
#	y.norm <- NULL
#	for(i in 1:nrow(y)){
#		rst <- mod.ln(y[i,],x,y.new[i],y.new.batch)
#		y.norm<-c(y.norm,rst)
#	}
#	return(y.norm)
#}
#fitModel.scale <- function(y,x){
#	mod.ln.scale<-function(y1,x){
#		x <- as.factor(x)
#		y1<-as.numeric(y1)
#		y1.mean <- tapply(y1,x,mean)
#		n.batch <- length(unique(x))
#		y1.mean.rep <- rep(y1.mean,each=n.batch)
#		y1.ovall.mean <- mean(y1)
#		scale <- y1.ovall.mean/y1.mean.rep
#		y1.norm <- scale * y1
#	}
#	t(apply(y,1,mod.ln.scale,x))
#}
#fitModel.scale <- function(y,x,y.new,x.new){
#	if(is.null(y.new)||is.null(x.new)||is.null(y)||is.null(x)){
#		cat ("use: fitModel(dat,batch,dat.new,batch.new) or help(fitModel.scale)")
#	}
#	mod.ln.scale<-function(y1,x,y1.new,x.new){
#		x <- as.factor(x)
#		y1<-as.numeric(y1)
#		y1.mean <- tapply(y1,x,mean)
#		n.batch <- length(unique(x))
#		y1.mean.batch <- tapply(y1,x,mean)
#		y1.ovall.mean <- mean(y1)
#		scale <- y1.ovall.mean/y1.mean.batch[dat.batch]	
#		y1.norm <- y1.new * scale	
#		return(y1.norm)
#	}
#	#t(apply(y,1,mod.ln.scale,x))
#	y.norm <- NULL
#	for(i in 1:nrow(y)){
#		rst <- mod.ln.scale(y[i,],x,y.new[i],x.new)
#		y.norm<-c(y.norm,rst)
#	}
#	return(as.numeric(y.norm))
#}
#
#sim<-function(ype="norm"){
#	dat = c(0.1+rnorm(150)*0.1,0.5+rnorm(150)*0.1,0.2*rnorm(150)*0.1)
#	datm = matrix(dat,50,9)
#	batch <- c(1,1,1,2,2,2,3,3,3)
#	dat.new = 0.1+rnorm(50)*0.1
#	dat.batch = "1"
#	list(data=datm,batch=batch,data.new=dat.new,data.batch=dat.batch)
#}
#autoCheckUpdate<-function(){
#	#TODO
#}


############################
#
##########################
annotBimap_test<-function(){
	dat<-list(objName="",objTarget="",Class="FlatBimap",L2Rchain=list(list(tablename="",Lcolname="",Rcolname="")),data=data.frame())
	abm<-createAnnotBimap(dat)
}
createAnnotBimap<-function(dat){
	require(annotate)
	lkey<-c("A","B")
	rkey<-c("a","b","e")
	colmname<-c("Lkeyname","Rkeyname")
	data<-data.frame(pid=c("A","B","A"),anid=c("a","b","e"))
	bm<-new(dat$Class,Lkeys=lkey,Rkeys=rkey,data=data,colmetanames=colmname)
	class(bm)
#	[1] "FlatBimap"
#	attr(,"package")
#	[1] "AnnotationDbi"
	Rkeyname(bm)
#	Rkeyname 
#	"anid" 
	Rkeys(bm)
#	[1] "a" "b" "e"
	data2<-data.frame(data,tid=c("t1","t2","t3"))
	colmname2=c(colmname,"tagname")
	bm2<-new(dat$Class,Lkeys=lkey,Rkeys=rkey,data=data2,colmetanames=colmname2)
	tagname(bm2)
}
#test_annBimap<-function(){
#	library(hgu95av2.db)
#	ls(2)
#	x=hgu95av2GO #call show
#	summary(hgu95av2GO)
#	hgu95av2GO2PROBE
#	summary()
#	Rkeyname(x)
##	[1] "go_id"
#	colmetanames(x)
##	[1] "Lkeyname" "Rkeyname" "tagname" 
#	tagname(x)
##	[1] "Evidence"
#	class(x)
##	[1] "ProbeGo3AnnDbBimap"
##	attr(,"package")
##	[1] "AnnotationDbi"
#
#	ls("package:hgu95av2.db")
#	qcd=capture.output(hgu95av2())
#	ap<-ls(24)
#	p2<-ap[1:3]
#	hgu95av2ENTREZID[[probes[1]]]
#	hgu95av2ENTREZID$"31882_at"
#	syms<-unlist(mget(p2,hgu95av2ENTREZID))
#	z<-as.list(hgu95av2ENTREZID)
#	toTable(hgu95av2ENTREZID[p2])
#	revmap(hgu95av2ENTREZID)
#	Lkeys(hgu95av2ENTREZID)
#	Rkeys(hgu95av2ENTREZID)
#	links(hgu95av2ENTREZID)
#	Rkeys(hgu95av2CHR)
#	toTable(hgu95av2ENTREZID)[1:10,]
#	
#}

#############
split2<-function(dat,fdat){
	nm<-unique(fdat)
	rst<-NULL
	for(i in 1:length(nm)){
		dat1<-dat[fdat==nm[i],]
		rst<-c(rst,list(dat1))
	}
	names(rst)<-nm
	return(rst)
}
