# TODO: Add comment
# 
# Author: feipan
###############################################################################
rapid.mc<-function(datPath=NULL,figPath=NULL,outFn=NULL){
	require(aroma.light)
	require(R.utils)
	if(is.null(datPath)){
		datPath<-"c:\\temp\\4207113144_test"
	}
	if(is.null(figPath)){
		figPath<-"c:\\temp\\results"
	}
	if(is.null(outFn)){
		outFn<-"Dat.out.rda"
	}
	dat.all<-load_beadlevel_scan_data(datPath)
	pre_calibration_plot(dat.all$datRG,figPath)
	dat.mc<-run_multiScan_calibration(dat.all$datRG,dat.all$datControls)
	dm<-post_calibration_plot(dat.mc$datRG,figPath)
	save_calibrated_data(dm,dat.mc$datRG,dat.mc$datControls,figPath,datFn=outFn)
}

rapid<-function(datPath=NULL,figPath=NULL,outFn=NULL,toMScanCalibrate=F,toNormalize=F,isTCGA=F){
	if(toMScanCalibrate==TRUE){
		rapid.mc(datPath,figPath,outFn)
	}
	if(toNormalizae==TRUE){
		
	}
	if(isTCGA==TRUE){
		
	}
}

rapidGUI<-function(){
	wm<-paste("R(-based) Automated Pipeline for DNA-methylation (RAPiD) Pro 1.0",date())
	require(methPipe)
	methPipeGUI(tit=wm,tcgaMenu=T,mscanMenu=T)
}

