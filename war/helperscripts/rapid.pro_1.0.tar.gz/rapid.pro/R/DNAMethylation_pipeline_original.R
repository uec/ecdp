###############################################################################
# Author: Houtan Noushmehr
# Contact: hnoushme@usc.edu; houtana@gmail.com; +1.310.570.2DNA
# Institute: University of Southern California Epigenome Center (http://epigenome.usc.edu/)
# Date creation: Jun 24, 2010
#
# Project Description: 
#	
# required packages:
#	o R.utils
#	o aroma.light
#	o matrixStats
#	o mSet
###############################################################################
library("aroma.light");
library("R.utils");
#library("aroma.core");
library("matrixStats");
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# beadlevel input
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
beadlevel_input_test<-function(){
	figForce <- FALSE;
	datPath.out<-"c:\\temp"
	figPath.c <-file.path(datPath.out,"/results/calibration",sep="")
	figPath <-file.path(datPath.out,"/results/dna.methylation",sep="")

	datPath<-"C:\\temp\\4207113144_test"
	dat.all<-load_beadlevel_scan_data(datPath=datPath);
	dat.all.calibrated<-run_multiScan_calibration(dat.all$datRG,dat.all$datControls,plot_yn="yes",figPath=figPath) #,figPath.c=figPath.c,figForce=figForce)
	pre_calibration_plot(dat.all$datRG,figPath)
	beta.RAWci<-post_calibration_plot(dat.all.calibrated$datRG,figPath)
	save_calibrated_data(beta.RAWci,dat.all.calibrated$datRG,dat.all.calibrated$datControls,datPath.out,datFn="",calPvale=T)
}

#datPath<-c("/home/houtan/Documents/Projects/Han.Han.Flora_Cancerization_Project/infinium_data/original")
#pdata.m<-read.table(paste("PATH TO FOLDER OF INTEREST/Received.from.Flora","sample.manifest.03.txt",sep="/"),header=T, sep="\t", na.strings="NA")
#pdata.m<-read.table("sample.maifest.03.txt",header=T,sep="\t",na.string="NA")
#dimnames(pdata.m)[[1]]<-pdata.m[,1]

#	figPath.c <- Arguments$getWritablePath(file.path("PATH TO FOLDER OF INTEREST/results","calibration",fsep="/")); #for the calibration plots for each sample and color
#	figPath <- Arguments$getWritablePath(file.path("PATH TO FOLDER OF INTEREST/results","dna.methylation",fsep="/")); #for all other figures
#	verbose <- Arguments$getVerbose(-5, timestamp=TRUE);

#---arguments, functions used
#--Data Classifications ---
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# 1) loading bead-level data directly from scanner.
# at moment, need to move csv files to appropriate folders for each scan
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# Functions to load all scans from beadlevel data
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#---arguments used
#controls
load_beadlevel_scan_data<-function(datPath=NULL){
	data.dir<-"C:\\Documents and Settings\\feipan\\workspace\\RAPiD.pro\\"
	probe.id<-read.csv(file.path(data.dir,"infinium probe id.csv"));
	probe.color<- read.csv (file.path(data.dir,"probe_color.csv"));
	control.probes<-read.table(file.path(data.dir,"control_probes.txt"), sep="\t",header=T);
	
	control.probes[,3]<-as.factor(control.probes[,3]);
	control.probes<-control.probes[,-1];
	qq.neg.rg<-list();
	m.rg.id<-c("Mean.RED","Mean.GRN");
	
	#probes/colors
	probeid.color <- merge(probe.id, probe.color, by.x="TargetID",by.y="TargetID");
	probe.red <- subset(probeid.color,Color_Channel=="Red");
	probe.grn <- subset(probeid.color,Color_Channel=="Grn");
	
	probe<-list(
			red=list(M=NULL,U=NULL),
			green=list(M=NULL,U=NULL)
	)
	probe[["green"]][["M"]]<-probe.grn[,c(1,4)]; probe[["green"]][["M"]][,2]<-as.factor(probe[["green"]][["M"]][,2]);
	probe[["green"]][["U"]]<-probe.grn[,c(1,3)]; probe[["green"]][["U"]][,2]<-as.factor(probe[["green"]][["U"]][,2]);
	probe[["red"]][["M"]]<-probe.red[,c(1,4)]; probe[["red"]][["M"]][,2]<-as.factor(probe[["red"]][["M"]][,2]);
	probe[["red"]][["U"]]<-probe.red[,c(1,3)]; probe[["red"]][["U"]][,2]<-as.factor(probe[["red"]][["U"]][,2]);
	
	datRG<-list(#before calibration
			scan1=list(red=list(M=NULL,U=NULL),green=list(M=NULL,U=NULL)),
			scan2=list(red=list(M=NULL,U=NULL),green=list(M=NULL,U=NULL)),
			scan3=list(red=list(M=NULL,U=NULL),green=list(M=NULL,U=NULL))
	)
	datControls<-list(#before calibration
			scan1=list(red=NULL,green=NULL),
			scan2=list(red=NULL,green=NULL),
			scan3=list(red=NULL,green=NULL)
	)
	datRGi<-datRG;
	datControls.i<-datControls;
	channel<-c("red","green");
	m.u<-c("M","U");
	scans<-list.files(datPath,full=TRUE);
	#---arguments used
	#---begin load of data
	for (a in seq(along=scans)){ #each scan settings within the directory above
		datPath1<-c(scans[a]);
		b<-list.files(datPath1,pattern=".csv",recursive=T);
		ll<-strsplit(b, "\\.");
		ll<-sapply(ll, "[", 1);
		for (x in seq(along=b)) {
			#enter(verbose, " Scan #: ", a, "; Extracting sample #: ", x, " out of ", length(b));
			temp <- read.csv (paste(datPath1,b[x], sep="/"), header = TRUE);
			
			if(x==1){ #this is set as a check to add in the first set of columns and subsequent adds will only add necessary intensities
				for(cc in channel){
					for(mm in m.u){
						if(cc=="red"){
							idcol<-c("Illumicode","Mean.RED");
						}else{
							idcol<-c("Illumicode","Mean.GRN");
						}
						if(mm=="M"){
							a.b<-c("ProbeID_B");
							kk<-c(".METH");
						}else{
							a.b<-c("ProbeID_A");
							kk<-c(".UNMETH");
						}
						datRG[[a]][[cc]][[mm]]<-merge(probe[[cc]][[mm]],temp[,c(idcol)], by.x=a.b,by.y="Illumicode");
						datRG[[a]][[cc]][[mm]] <- as.data.frame(datRG[[a]][[cc]][[mm]]);
						nn <- dim(datRG[[a]][[cc]][[mm]])[2];
						dimnames(datRG[[a]][[cc]][[mm]])[[2]][nn]<-c(paste(ll[x],kk,sep=""));
						dimnames(datRG[[a]][[cc]][[mm]])[[1]]<-datRG[[a]][[cc]][[mm]][,"TargetID"]
						
					}#end mm
					
					#extract controls for each sample
					if(cc=="red"){
						m.rg.id1<-m.rg.id[1];
					}else{
						m.rg.id1<-m.rg.id[2];
					}
					qq<-merge(control.probes,temp,by.x="ProbeID",by.y="Illumicode");
					qq.neg<-qq[qq[,2]=="NEGATIVE",];
					datControls[[a]][[cc]]<-qq.neg[,c("ProbeID","TargetID",m.rg.id1)];
					datControls[[a]][[cc]] <- as.data.frame(datControls[[a]][[cc]]);
					nnc <- dim(datControls[[a]][[cc]])[2];
					dimnames(datControls[[a]][[cc]])[[2]][nnc]<-c(ll[x]);
					dimnames(datControls[[a]][[cc]])[[1]]<-datControls[[a]][[cc]][,"ProbeID"]
				}#ned cc
			}else{
				for(cc in channel){
					for(mm in m.u){
						if(cc=="red"){
							idcol<-c("Illumicode","Mean.RED");
						}else{
							idcol<-c("Illumicode","Mean.GRN");
						}
						if(mm=="M"){
							a.b<-c("ProbeID_B");
							kk<-c(".METH");
						}else{
							a.b<-c("ProbeID_A");
							kk<-c(".UNMETH");
						}
						
						yy<-merge(probe[[cc]][[mm]],temp[,c(idcol)], by.x=a.b,by.y="Illumicode");
						datRG[[a]][[cc]][[mm]]<-merge(datRG[[a]][[cc]][[mm]],yy[,c(2:3)],by.x="TargetID",by.y="TargetID"); #need to create a merge function.  I suspect the probe orders might be screwed up.
						nn <- dim(datRG[[a]][[cc]][[mm]])[2];
						dimnames(datRG[[a]][[cc]][[mm]])[[2]][c(nn)]<-c(paste(ll[x],kk,sep=""));
						dimnames(datRG[[a]][[cc]][[mm]])[[1]]<-datRG[[a]][[cc]][[mm]][,"TargetID"]
					}#end mm
					
					#extract controls for each sample
					if(cc=="red"){
						m.rg.id1<-m.rg.id[1];
					}else{
						m.rg.id1<-m.rg.id[2];
					}
					qq<-merge(control.probes,temp,by.x="ProbeID",by.y="Illumicode");
					qq.neg<-qq[qq[,2]=="NEGATIVE",];
					datControls[[a]][[cc]]<-merge(datControls[[a]][[cc]],qq.neg[,c("ProbeID",m.rg.id1)],by.x="ProbeID",by.y="ProbeID");
					nnc <- dim(datControls[[a]][[cc]])[2];
					dimnames(datControls[[a]][[cc]])[[2]][nnc]<-c(ll[x]);
					dimnames(datControls[[a]][[cc]])[[1]]<-datControls[[a]][[cc]][,"ProbeID"]
				} #ned cc
			}# if of idx
			#verbose && exit(verbose);
		}# end x
	}#end a
	summary(datRG);
	summary(datControls);
	#---end load of data
	return(list(datRG=datRG,datControls=datControls))
}
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# 2.a) multiScan Calibration Function begins
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# calibrateMultiscan() applied to datRG object created when loading in data from csv files (see above).
# post calibration is stored in datRGc
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#---arguments used
run_multiScan_calibration<-function(datRG=NULL,datControls=NULL,plot_yn="no",figPath=NULL){#,figPath.c=NULL,figForce=F){
	fitList <- list();
	datRGc <- list(red=NULL, green=NULL); #create list to store calibrated data.
	datRGc.p<-datRGc
	#datRGci<-list(red=NULL, green=NULL); #list to store samples of interest after calibration
	datControls.c <- list(red=NULL, green=NULL); #create list to store calibrated data.
	datControls.ci<-list(red=NULL, green=NULL); #list to store samples of interest after calibration
	YY.controls<-list();
	YY.m<-list();
	YY.u<-list();
	names<-list();
	fitList.m <- list();
	fitList.u <- list();
	channel<-c("red","green");
	nbrOfScans <- length(datRG);
	nbrOfArrays <- 6; #always 12
	nbrOfSamples <- dim(datRG[[1]][[1]][[1]])[2]; #subtract 2 because you want to remove the first two columns added in when loading the data from the csv
	Constraint<-c("max","diaganol")[1];
	satSignal <- 2^16-1;
	plot_yn <- c("yes", "no")[1];
	scans<-list.files(datPath)
	#---arguments used
	#---begin calibration
	for ( rg in channel ) { #for each color channels
		for( samp in 1:(nbrOfSamples-2) ){
			#enter(verbose," [[", rg, "]] Calibrating sample: ", samp, " out of ", (nbrOfSamples - 2)); #subtract 2 because first two columns are not samples
			#start if
			for( sc in seq(along=(datRG) )){
				datPath1<-c(scans[1]);
				b<-list.files(file.path(datPath,datPath1),pattern="csv");
				ll<-strsplit(b, "\\.");
				chipName<-sapply(ll, "[", 1);
				YY.m[[sc]]<-datRG[[1]][[rg]][["M"]][,c("TargetID",paste(chipName[samp],".METH",sep=""))];
				YY.u[[sc]]<-datRG[[1]][[rg]][["U"]][,c("TargetID",paste(chipName[samp],".UNMETH",sep=""))];
				YY.controls[[sc]]<-datControls[[1]][[rg]][,chipName[samp]];
				names[[sc]]<-chipName[samp];
			} #end sc (each scan setting)
			
			#since we are using three scans, this will be hard coded.  If number of scans changed, need to change this code. (next 3 lines)
			#sanity check
			stopifnot(identical(names[[1]],names[[2]]));
			stopifnot(identical(names[[1]],names[[3]]));
			stopifnot(identical(names[[2]],names[[3]]));
			Y.m <- cbind(YY.m[[1]][,2],YY.m[[2]][,2],YY.m[[3]][,2]); dimnames(Y.m)[[2]]<-c("pmt1.0","pmt1.0","pmt1.0"); dimnames(Y.m)[[1]]<-paste(YY.m[[1]][,1],".METH",sep="");
			Y.u <- cbind(YY.u[[1]][,2],YY.u[[2]][,2],YY.u[[3]][,2]); dimnames(Y.u)[[2]]<-c("pmt1.0","pmt1.0","pmt1.0"); dimnames(Y.u)[[1]]<-paste(YY.u[[1]][,1],".UNMETH",sep="");
			Y.controls <- cbind(YY.controls[[1]],YY.controls[[2]],YY.controls[[3]]); colnames(Y.controls)<-c("pmt1.0","pmt1.0","pmt1.0");
			#for plotting
			#Y.mc <- calibrateMultiscan(Y.m, average=NULL, constraint=Constraint, satSignal=satSignal); #will keep each new modified scan in a separate column for plotting
			#Y.uc <- calibrateMultiscan(Y.u, average=NULL, constraint=Constraint, satSignal=satSignal); #will keep each new modified scan in a separate column for plotting
			#Yc <- rbind(Y.mc,Y.uc);
			Y <- rbind(Y.m,Y.u);
			#storing fit/offset values for each sample
			#fitList.m[[samp]] <- attr(Y.mc, "modelFit");
			#names(fitList.m[[samp]]) <- c(chipName[samp]);
			#fitList.u[[samp]] <- attr(Y.uc, "modelFit");
			#names(fitList.u[[samp]]) <- c(chipName[samp]);
			
			#collapsing multiple scans into one by taking the median value for each probe per sample
			Y.mc.1 <- calibrateMultiscan(Y.m, constraint=Constraint, satSignal=satSignal); #will keep each new modified scan in a separate column for plotting
			Y.uc.1 <- calibrateMultiscan(Y.u, constraint=Constraint, satSignal=satSignal); #will keep each new modified scan in a separate column for plotting
			Y.mc.1 <- as.data.frame(Y.mc.1[,1]);dimnames(Y.mc.1)[[2]]<-chipName[samp]
			y.uc.1 <- as.data.frame(Y.uc.1[,1]);dimnames(Y.uc.1)[[2]]<-chipName[samp]
#			Y.mc.1 <- as.data.frame(Y.m[,1]); dimnames(Y.mc.1)[[2]]<-chipName[samp]
#			Y.uc.1 <- as.data.frame(Y.u[,1]); dimnames(Y.uc.1)[[2]]<-chipName[samp]
			Yc.1 <- rbind(Y.mc.1,Y.uc.1);
			Yc.1 <- as.data.frame(Yc.1)
			#Y.controls.1 <- calibrateMultiscan(Y.controls, constraint=Constraint, satSignal=satSignal); #will keep each new modified scan in a separate column for plotting
			Y.controls.1 <- as.data.frame(Y.controls[,1])
			Y.controls.1 <- as.data.frame(Y.controls.1)
			
			if( samp==1 ){
				datRGc[[rg]]<-Yc.1;
				datRGc[[rg]] <- as.data.frame(datRGc[[rg]]);
				nn <- samp + 1; #ad hoc to force data to accept colnames change on the first column.  need to remove first column when done. (see below, last line of code after for loop done.
				datRGc[[rg]][,nn]<- Yc.1;
				dimnames(datRGc[[rg]])[[2]][samp]<-c(chipName[samp]); #change name of first column because second column 'nn' will be replaced in subsequent samples.
				
				datControls.c[[rg]]<-Y.controls.1;
				datControls.c[[rg]] <- as.data.frame(datControls.c[[rg]]);
				nnc <- samp + 1; #ad hoc to force data to accept colnames change on the first column.  need to remove first column when done. (see below, last line of code after for loop done.
				datControls.c[[rg]][,nnc]<- Y.controls.1;
				dimnames(datControls.c[[rg]])[[2]][samp]<-c(chipName[samp]); #change name of first column because second column 'nn' will be replaced in subsequent samples.
			}else{
				datRGc[[rg]][,samp]<- Yc.1;
				dimnames(datRGc[[rg]])[[2]][samp]<-c(chipName[samp]);
				
				datControls.c[[rg]][,samp]<- Y.controls.1;
				dimnames(datControls.c[[rg]])[[2]][samp]<-c(chipName[samp]);
			}#end if
			
			# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
			# plot? type 'yes' or 'no'
			# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
			if(plot_yn=="yes"){ #decide if plots are necessary
				#Y1 <- calibrateMultiscan(Y, average=NULL, constraint=Constraint, satSignal=satSignal); #Calibrate again to make fit for both M/U for plotting xy
				Y1<-Y
				#fit <- attr(Y1, "modelFit");
				#isSat <- rowAnys(is.na(Yc));
				#print(summary(isSat));
				
				# Scale factors before and after calibration
	#			scale0 <- colMedians(Y[!isSat,], na.rm=TRUE);
	#			scale1 <- colMedians(Yc[!isSat,], na.rm=TRUE);
	#
	#			# Rescale just to fit in the same plot
	#			scale <- max(scale0/scale1);
	#			scale <- satSignal/max(Yc[Y < satSignal], na.rm=TRUE);
	#			Yc <- scale*Yc;
				
				figName <- sprintf("%s,%s,multiscan_1.0_repeat", rg, chipName[samp]);
				filename <- sprintf("%s.png", figName);
				#pathname <- filePath(figPath.c, filename);
				pathname<-file.path(figPath,filename)
#				if (!figForce && isFile(pathname)) {
#					#next;
#				}
				
				width <- 640;
				devNew(png, pathname, width=width, height=1.3*width);
				
				layout(matrix(1:1, ncol=1, byrow=FALSE));
				par(mar=c(3,4,1,1)+0.1, mgp=c(1.8,0.8,0));
				
				
				lim <- c(0,satSignal);
				llim <- log2(lim+1);
				
	#			YList <- list(Y=Y, Yc=Yc);
	#			for (pp in seq(along=YList)) {
	#				Ypp <- YList[[pp]];
				
	#				# Plot (x,y) pairs
	#				xlab <- expression(y[i]);
	#				ylab <- expression(y[j]);
	#				plot(NA, xlim=lim, ylim=lim, xlab=xlab, ylab=ylab);
	#				stext(side=3,pos=0, sprintf("Chip: %s", chipName[samp]));
	#				stext(side=3,pos=1, names(YList)[pp]);
	#				abline(a=0, b=1, lty=3);
	#				col <- 1;
	#				# Plot all possible pairs
	#				for (ii in 1:(nbrOfScans-1)) {
	#					for (jj in (ii+1):nbrOfScans) {
	#						cc <- c(ii,jj);
	#						Ycc <- Ypp[,cc];
	#						points(Ycc, pch=".", col=col);
	#
	#						if (pp == 1) {
	#							a <- fit$a[cc];
	#							b <- fit$b[cc];
	#							xy <- cbind(x=a[1]+b[1]*c(0,lim[2]), y=a[2]+b[2]*c(0,lim[2]));
	#							lines(xy, col="white", lwd=3);
	#							lines(xy, col=col, lwd=2, lty=2);
	#						}
	#						col <- col + 1;
	#					}
	#				}
	#				box(col=rg, lwd=3);
	#
	#				# Plot (a,m) pairs
	#				plotMvsAPairs(Ypp, xlim=llim);
	#				abline(h=0, lty=3);
	#				stext(side=3,pos=0, sprintf("Chip: %s", chipName[samp]));
	#				stext(side=3,pos=1, names(YList)[pp]);
	#				box(col=rg, lwd=3);
				
				
					# Plot log2(x) densities
					#plotDensity(log2(Y1), xlim=llim, lwd=2);
					plot(density(log2(Y1)),xlim=llim,lwd=2,main=sprintf("Chip: %s",chipName[samp]))
				
					legend("topleft",colnames(Y1), col=1:nbrOfScans, lwd=2) #added in legend for density plots
					#stext(side=3,pos=0, sprintf("Chip: %s", chipName[samp]));
					#text(x=0,labels=sprintf("Chip: %s",chipName[samp]))
					#stext(side=3,pos=1, names(YList)[pp]);
					box(col=rg, lwd=3);
					
		#			} # for (pp ...)
					
					devDone();
				
			} # for (plot_yn ...)
			
			#verbose && exit(verbose);
			#print(fitList.m[[samp]][[adiag]]);
			#print(fitList.m[[samp]][[b]]);
			#print(fitList.u[[samp]][[adiag]]);
			#print(fitList.u[[samp]][[b]]);
			
		}#end of samples
		
		if(plot_yn=="yes"){
			print(paste("Done with MULTICALIBRATION for the ", rg, " channel. You can check folder for plots: ", figPath.c));
		}else{
			print(paste("Done with MULTICALIBRATION for the ", rg, " channel."));
		} #ifelse
		
	}# for (rg ..), each color (red and green).
	print(paste(paste("Done calibrating both RED (M/U) & GREEN (M/U) for ", (nbrOfSamples-2)/12," chips or ", c(nbrOfSamples-2)," # of samples.")));
	summary(datRGc);
	summary(datControls.c);
	return(list(datRG=datRGc,datControls=datControls.c))
	#---end calibration
}

#####################################
#
#
######################################
save_calibrated_data<-function(dat.calibrated,datRGc,datControls,datPath,datFn="cDat.rda",calPvalue=T){
	dat<-create_calibrated_level_data(dat.calibrated,datPath)
	dat.p<-NULL
	if(calPvalue==TRUE){
		dat.p<-calculate_pvalue_calibrated(datRGc,datControls)
	}
	rst<-c(dat,Pvalue=list(as.data.frame(dat.p)))
	save(rst,file=file.path(datPath,datFn))
}
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# 2.b) calculate detection pvalues using calibrated controls (16 probes)
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#---arguments used
calculate_pvalue_calibrated<-function(datRGc,datControls.c,toCheck=F){
	channel<-c("red","green")
	datRGc.p<-list(red=NULL,green=NULL)
	p.val<-c(0.01, 0.05)[2]
	z_score<-list(red=list(M=NULL, U=NULL),green=list(M=NULL, U=NULL))
	#pNorm<-list(red=list(M=NULL, U=NULL),green=list(M=NULL, U=NULL))
	pValue<-list(red=list(M=NULL, U=NULL),green=list(M=NULL, U=NULL))
	i<-list(M=list(red=1,green=1),U=list(red=1,green=1))
	mubc<-list(M=NULL, U=NULL)
	#---arguments used
	#---detection pvalue script
	for(rg in channel){
		
		#enter(verbose," [[", rg, "]] Setting up Controls and Analytical data");
		dim.r <- dim(datRGc[[rg]])[1];
		dim.r1 <- dim.r/2;
		dim.r2 <- dim.r1+1;
		mubc[["M"]] <- datRGc[[rg]][1:dim.r1,]; #extracting out meths
		mubc[["U"]] <- datRGc[[rg]][dim.r2:dim.r,]; #extracting out unmeths
		#verbose && exit(verbose);
		
		#enter(verbose," [[", rg, "]] Averaging MS, Us and Controls");
		#AB <-(mb+mc)/2; #taking average meth and unmeth
		ctr_avg <- apply(datControls.c[[rg]],2,mean,na.rm=T); #average controls per sample
		ctr_sd <- apply(datControls.c[[rg]],2,sd,na.rm=T); #sd controls per sample
		ctr_avg1 <- matrix(ctr_avg, dim.r1, dim(datRGc[[rg]])[2], byrow=TRUE);
		ctr_sd1 <- matrix(ctr_sd, dim.r1, dim(datRGc[[rg]])[2], byrow=TRUE);
		#verbose && exit(verbose);
		
		for (mu in c("M","U")){
			#enter(verbose," [[", rg, "]] ", mu, ": Calculating Z-Scores and P-Values");
			z_score[[rg]][[mu]] <- (mubc[[mu]]-ctr_avg1)/ctr_sd1; #calculating z_score for each probe per sample
			pValue[[rg]][[mu]] <- apply(z_score[[rg]][[mu]],c(1,2),pnorm, lower.tail=FALSE);  #calculating pnormal distribution for each probe per sample
	#		pValue[[rg]][[mu]] <- 1-pNorm[[rg]][[mu]]; #calculating pvalues for each probe per sample
			#verbose && exit(verbose);
		}
		#enter(verbose," [[", rg, "]] Masking (NA) values with high pvalues");
		dat<-datRGc
		pv<-pValue
		
		datRGc.p[[rg]]<-ifelse(pv[[rg]][["M"]]>pv[[rg]][["U"]],pv[[rg]][["M"]],pv[[rg]][["U"]])
		
		if(toCheck==TRUE){
			color<-rg
			dim.rp<-dim(dat[[color]])[1];
			dim.rp1<-dim.rp/2;
			dim.rp2 <- dim.rp1+1;
			dat.m<-(dat[[color]][1:dim.rp1,]) #extracting out meths
			dat.u<-(dat[[color]][dim.rp2:dim.rp,]) #extracting out unmeths
			
			pv[[color]][["M"]][pv[[color]][["M"]]>p.val]<-NA #METH
			pv[[color]][["U"]][pv[[color]][["U"]]>p.val]<-NA #UNMETH
			
			#sanity - create two random matrix for m and u.  if they are identical, recreate a new random matrix.  chances of this happening twice for the same position is very unlikely.
			dat.m1<-matrix(rnorm(1:dim(dat.m)[1]*dim(dat.m)[2]),nrow=dim(dat.m)[1],ncol=dim(dat.m)[2], byrow=TRUE)
			dat.m2<-matrix(rnorm(1:dim(dat.m)[1]*dim(dat.m)[2]),nrow=dim(dat.m)[1],ncol=dim(dat.m)[2], byrow=FALSE)
			if(sum(apply(dat.m1==dat.m2,2,sum)>0)>=1){
				dat.m1<-matrix(rnorm(1:dim(dat.m)[1]*dim(dat.m)[2]),nrow=dim(dat.m)[1],ncol=dim(dat.m)[2], byrow=TRUE)
				dat.m2<-matrix(rnorm(1:dim(dat.m)[1]*dim(dat.m)[2]),nrow=dim(dat.m)[1],ncol=dim(dat.m)[2], byrow=FALSE)
				i[["M"]][[color]]<-i[["M"]][[color]]+1
			}
			if(sum(apply(dat.m1==dat.m2,2,sum)>0)>=1){
				dat.m1<-matrix(rnorm(1:dim(dat.m)[1]*dim(dat.m)[2]),nrow=dim(dat.m)[1],ncol=dim(dat.m)[2], byrow=TRUE)
				dat.m2<-matrix(rnorm(1:dim(dat.m)[1]*dim(dat.m)[2]),nrow=dim(dat.m)[1],ncol=dim(dat.m)[2], byrow=FALSE)
				i[["M"]][[color]]<-i[["M"]][[color]]+1
			}
			
			dat.u1<-matrix(rnorm(1:dim(dat.u)[1]*dim(dat.u)[2]),nrow=dim(dat.u)[1],ncol=dim(dat.u)[2], byrow=FALSE)
			dat.u2<-matrix(rnorm(1:dim(dat.u)[1]*dim(dat.u)[2]),nrow=dim(dat.u)[1],ncol=dim(dat.u)[2], byrow=TRUE)
			if(sum(apply(dat.m1==dat.m2,2,sum)>0)>=1){
				dat.u1<-matrix(rnorm(1:dim(dat.u)[1]*dim(dat.u)[2]),nrow=dim(dat.u)[1],ncol=dim(dat.u)[2], byrow=FALSE)
				dat.u2<-matrix(rnorm(1:dim(dat.u)[1]*dim(dat.u)[2]),nrow=dim(dat.u)[1],ncol=dim(dat.u)[2], byrow=TRUE)
				i[["U"]][[color]]<-i[["U"]][[color]]+1
			}
			if(sum(apply(dat.m1==dat.m2,2,sum)>0)>=1){
				dat.u1<-matrix(rnorm(1:dim(dat.u)[1]*dim(dat.u)[2]),nrow=dim(dat.u)[1],ncol=dim(dat.u)[2], byrow=FALSE)
				dat.u2<-matrix(rnorm(1:dim(dat.u)[1]*dim(dat.u)[2]),nrow=dim(dat.u)[1],ncol=dim(dat.u)[2], byrow=TRUE)
				i[["U"]][[color]]<-i[["U"]][[color]]+1
			}
			
			dat.m1[is.na(pv[[color]][["M"]])]<-75000 #setting all insignificant probes to 75000 (higher than true saturation)
			dat.m2[is.na(pv[[color]][["U"]])]<-75000 #setting all insignificant probes to 75000 (higher than true saturation)
			dat.u1[is.na(pv[[color]][["M"]])]<-75000 #setting all insignificant probes to 75000 (higher than true saturation)
			dat.u2[is.na(pv[[color]][["U"]])]<-75000 #setting all insignificant probes to 75000 (higher than true saturation)
			
			
			
			dat.m3<-dat.m1==dat.m2
			dat.m3[dat.m3==TRUE]<-NA
			dat.m3[dat.m3==FALSE]<-0
			dat.m<-dat.m+dat.m3
			
			dat.u3<-dat.u1==dat.u2
			dat.u3[dat.u3==TRUE]<-NA
			dat.u3[dat.u3==FALSE]<-0
			dat.u<-dat.u+dat.u3
		}
		
		#datRGc.p[[rg]]<-rbind(dat.m,dat.u)
		#datRGc.p[[rg]] <- getPvalue(datRGc,pValue,color=rg);
		
		#verbose && exit(verbose);
	} #end rg
	datRG.p<-rbind(datRGc.p[["red"]],datRGc.p[["green"]])
	#---detection pvalue script
	summary(datRGc)
	summary(datRGc.p)
	#i
	return(datRG.p)
}

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# 2.c) PLOTTING PRE AND POST CALIBRATION - METHOD OF EVALUATION
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
pre_calibration_plot<-function(datRG,figPath){
	#datRGc.original<-datRGc #store before masking
	#datRGc<-datRGc.p #creates masking of data file.  This is the working file.
	#---arguments, functions used
	beta.RAWi<-list( #pre
			scan1=list(red=list(M=NULL,U=NULL,BETA.V=NULL), green=list(M=NULL,U=NULL,BETA.V=NULL)),
			scan2=list(red=list(M=NULL,U=NULL,BETA.V=NULL), green=list(M=NULL,U=NULL,BETA.V=NULL)),
			scan3=list(red=list(M=NULL,U=NULL,BETA.V=NULL), green=list(M=NULL,U=NULL,BETA.V=NULL))
	);
	
	getBeta <- function(dat, color) {
		dat[[color]][["M"]][dat[[color]][["M"]]<0]<-0
		dat[[color]][["U"]][dat[[color]][["U"]]<0]<-0
		dat[[color]][["M"]]/(dat[[color]][["M"]]+dat[[color]][["U"]])
	}

	# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	#  PRE CALIBRATION PLOTS:
	#  calculating betavalues and plotting each sample for each scan settings before calibration
	# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	#---arguments used
	set<-c("1.0","1.25","1.5");
	v<-1
	channel<-c("red","green")
	#---arguments used
	#---begin preC plots
	
	#for (v in seq(along=datRGi)) {#for each scan
	for(v in 1:length(beta.RAWi)){
		if(is.null(datRG[[v]][["red"]][["M"]])) next
		#enter(verbose, "Plotting Scan setting");
		figName <- sprintf("2_rep_PRE-pvalue");
		filename <- sprintf("%s.png", figName);
		pathname <- file.path(figPath, filename);
		#		if (!figForce && isFile(pathname)) {
		#			next;
		#		}
		width <- 640;
		devNew(png, pathname, width=width, height=1.3*width);
		layout(matrix(1:4, ncol=2, byrow=TRUE));
		par(mar=c(3,4,1,1)+0.1, mgp=c(1.8,0.8,0));
		for (rg in channel) {
			beta.RAWi[[v]][[rg]][["M"]] <- datRG[[v]][[rg]][["M"]];
			beta.RAWi[[v]][[rg]][["U"]] <- datRG[[v]][[rg]][["U"]];
			beta.RAWi[[v]][[rg]][["BETA.V"]] <- getBeta(beta.RAWi[[v]], color=rg);
			
			len<-ncol(beta.RAWi[[v]][[rg]][["BETA.V"]])
			#boxplots
			boxplot(beta.RAWi[[v]][[rg]][["BETA.V"]][,3:len],pch=".", col=rg, ylab="beta value",main=paste("PMT:",set[v]," PRE-pvalue"));
			#stext(side=3,pos=0, paste("PMT:",set[v]," PRE-pvalue"));
			box(col=rg, lwd=3);
			
			#density plots
			plotDensity(beta.RAWi[[v]][[rg]][["BETA.V"]][,3:len],xlab=paste("PMT:",set[v],"PRE-pvalue"));
			#stext(side=3,pos=0, paste("PMT:",set[v]," PRE-pvalue"));
			#plot(density(beta.RAWi[[v]][[rg]][["BETA.V"]][,3:len]),main=paste("PMT:",set[v]," PRE-pvalue"))
			box(col=rg, lwd=3);
			
		}#end rg
		devDone();
		#verbose && exit(verbose);
	
	} #end v
	#---end preC plots
}
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#  POST CALIBRATION PLOTS:
#  plotting and calculating betavalues for post calibration using samples of interest (datRGci)
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#---begin extraction
post_calibration_plot<-function(datRGc,figPath){
	datRGci<-list(red=NULL, green=NULL); #list to store samples of interest after calibration
	getBeta <- function(dat, color) {
		dat[[color]][["M"]][dat[[color]][["M"]]<0]<-0
		dat[[color]][["U"]][dat[[color]][["U"]]<0]<-0
		dat[[color]][["M"]]/(dat[[color]][["M"]]+dat[[color]][["U"]])
	}
	
	channel<-c("red","green")
	beta.RAWci<-list( #post
			red=list(M=NULL,U=NULL,BETA.V=NULL),
			green=list(M=NULL,U=NULL,BETA.V=NULL)
	);
	
	for (rg in channel) {
		datRGci[[rg]]<-datRGc[[rg]]; #includes normals, tumors and controls (WGA/SssI) if dealing with TCGA
	}
	summary(datRGci);
	#---end extraction
	#---begin plotting postC
	for (rg in channel) {
		dim.r<-dim(datRGci[[rg]])[1];
		dim.r2<-dim.r/2;
		beta.RAWci[[rg]][["M"]] <- datRGci[[rg]][1:dim.r2,];
		dim.r2 <- dim.r2+1;
		beta.RAWci[[rg]][["U"]]  <- datRGci[[rg]][dim.r2:dim.r,];
		beta.RAWci[[rg]][["BETA.V"]] <- getBeta(beta.RAWci, color=rg);
	}
	
	#enter(verbose, "Plotting data");
	figName <- sprintf("2_rep_Post-pvalue");
	filename <- sprintf("%s.png", figName);
	pathname <- filePath(figPath, filename);
	#	if (!figForce && isFile(pathname)) {
	#		next;
	#	}
	width <- 640;
	devNew(png, pathname, width=width, height=1.3*width);
	layout(matrix(1:4, ncol=2, byrow=TRUE));
	par(mar=c(3,4,1,1)+0.1, mgp=c(1.8,0.8,0));
	for (rg in channel) {
		
		#boxplots
		boxplot(beta.RAWci[[rg]][["BETA.V"]],pch=".", col=rg, ylab="beta value",main=paste("POST-pvlue"));
		#stext(side=3,pos=0, paste("POST-pvalue"));
		box(col=rg, lwd=3);
		
		#density plots
		plotDensity(beta.RAWci[[rg]][["BETA.V"]],xlab=paste("POST-pvalue"));
		#stext(side=3,pos=0, paste("POST-pvalue"));
		#plot(density(as.numeric(beta.RAWci[[rg]][["BETA.V"]]),main=paste("POST-pvalue")))
		box(col=rg, lwd=3);
		
	}
	
	devDone();
	#verbose && exit(verbose);
	
	#---end plotting postC
	return(beta.RAWci)
}
#####################################################
# Level 1 and Level 2 data (Pre and Post Calibration):

# pre - stores all 3 scans individually
####################################################
create_calibrated_level_data<-function(beta.RAWci,datPath){
	channel<-c("red","green")
#	summary(beta.RAWi); #M/U for each red/green + betavalue calculations
#	summary(datRGi); #all samples of interest
#	summary(datRG); #all samples
#	summary(datControls); #all control probes for each scan, not calibrated.
#	
	# post - calibrated from 3 scans
	# 27,578xN (N=number of samples of interest, e.g. tumors, normals, controls).
	summary(beta.RAWci); #M/U for each red/green + betavalue calculations
#	summary(datRGci); #all samples of interest
#	summary(datRGc); #all samples after masking insignificant probes
#	summary(datRGc.original) #all samples before masking insignificant probes
#	summary(datControls.c); #calibrated controls for all samples
	
	#clean up rownames, strip out .METH created during loading of data to streamline and separate out meth/unmeth.
	for (rg in channel){
		#betaV
		ll<-dimnames(beta.RAWci[[rg]][["BETA.V"]])[[1]];
		ll<-strsplit(ll, "\\.");
		ll<-sapply(ll, "[", 1);
		dimnames(beta.RAWci[[rg]][["BETA.V"]])[[1]]<-ll;
		#M
		ll<-dimnames(beta.RAWci[[rg]][["M"]])[[1]];
		ll<-strsplit(ll, "\\.");
		ll<-sapply(ll, "[", 1);
		dimnames(beta.RAWci[[rg]][["M"]])[[1]]<-ll;
		#U
		ll<-dimnames(beta.RAWci[[rg]][["U"]])[[1]];
		ll<-strsplit(ll, "\\.");
		ll<-sapply(ll, "[", 1);
		dimnames(beta.RAWci[[rg]][["U"]])[[1]]<-ll;
	}
	
	dna.m<-rbind(beta.RAWci[["red"]][["BETA.V"]],beta.RAWci[["green"]][["BETA.V"]])
	dna.u<-rbind(beta.RAWci[["red"]][["U"]],beta.RAWci[["green"]][["U"]])
	dna.mm<-rbind(beta.RAWci[["red"]][["M"]],beta.RAWci[["green"]][["M"]])
	
	require(aroma.light)
	#x11();plotDensity(dna.m[,rownames(subset(pdata.m, TUMOR=="N"))],xlab="BETA VALUES",main="Density Distribution of all 27,578 CpG probes")
	
	#dropouts
	drop.outs<-as.data.frame(round((apply(is.na(dna.m),2,sum)/27578)*100, digits=0))
	drop.outs$SampleID<-as.character(dimnames(drop.outs)[[1]])
	ll<-as.character(dimnames(drop.outs)[[1]])
	ll<-strsplit(ll, "\\_");
	ll<-sapply(ll, "[", 1);
	drop.outs$ChipID<-ll
	dimnames(drop.outs)[[2]]<-c("PercentDropOut","SampleID","ChipID")
	require(ggplot2)
	qplot(drop.outs[,"SampleID"],drop.outs[,"PercentDropOut"], data=drop.outs, colour= PercentDropOut>5) +
			geom_point(size=2) +
			facet_wrap(~ ChipID)	+
			scale_colour_manual(values = c("FALSE"="BLACK","TRUE"="RED"),  "Greater than\n5%?")  +
			scale_y_continuous("Percent of Probes that Failed", limits=c(0,100)) +
			#scale_x_manual("Sample ID") +
			geom_hline(yintercept = 5, colour="black", size=0.5, linetype=2) +
			opts(axis.text.x = theme_text(angle=90, hjust=1))
	# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	#
	#	loading manifest
	# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#	manifest<-read.delim(
#			file="/home/houtan/Documents/Projects/Infinium_Data_QC/Infinium.methylation.manifest.20090723.with.gene.expression.ids.fixed.primary.txt",
#			sep="\t",
#			header=T
#	)
	require(mAnnot)
	manifest<-getData()
	#dna.m$ID<-dimnames(dna.m)[[1]]
	
	
	#dna.m1<-merge(dna.m,manifest,by.x="ID",by.y="IlmnID")
	dna.m1<-merge(dna.m,manifest,by.x=0,by.y="ILmnID")
	#save(list=c("dna.m","dna.m1","pdata.m"),file="PATH TO FOLDER OF INTEREST/results/dna.methylation.rda")
	save(list=c("dna.m","dna.m1"),file=file.path(datPath,"dna.methylation.rda"))
	#load(file="PATH TO FOLDER OF INTEREST/results/dna.methylation.rda")
	#sd.all<-apply(dna.m1[,rownames(subset(pdata.m, TUMOR=="Y"))],1,sd,na.rm=T) #sd across tumors only
	sd.all<-apply(dna.m,1,sd,na.rm=T)
	dna.m$SD.all<-sd.all
	#plot SD
	m <- ggplot(dna.m, aes(x=SD.all))  +
			opts(title = "Density Plot\nSD across all samples Tumor Samples")
	#x11()
	m + geom_histogram(aes(y=..density..), binwidth=0.004, fill="red", colour="black") +
			#facet_grid(. ~ Illumina.CpG.Island)	+
			geom_density(fill=NA, colour="black", size=1, alpha=0.2) +
			opts(plot.title = theme_text(size=15, vjust= 0.25, colour="black", face = "bold")) +
			scale_y_continuous("Density") +
			#geom_vline(xintercept= 0.12, colour="Black", linetype=2, size=1) +
			scale_x_continuous("Standard Deviation", limits=c(0,max(dna.m[,"SD.all"])))
	
	temp<-subset(dna.m, SD.all>0.2)
	#temp1<-temp[,rownames(pdata.m)]
	temp1<-temp[,1:(ncol(temp)-1)]
	#png(filename = "PATH TO FOLDER OF INTEREST/results/dna.methylationHeatmap.png", bg="white", res=300, width=3000, height=3000)
	png(filename=file.path(datPath,"dna.methylationHeatmap.png"),bg="white",res=300,width=3000,height=3000)
	require(gplots)
	require(matlab)
	hv1<-heatmap.2(
			as.matrix(temp1),
			na.rm=TRUE,
			scale="none",
			#RowSideColor=probe.cc,
			#ColSideColors=cc.col,
			col=jet.colors(75),
			#col=redgreen(75),
			key=T,
			symkey=FALSE,
			density.info="none",
			trace="none",
			Rowv=T,
			Colv=F,
			cexRow=1,
			cexCol=1,
			keysize=1,
			dendrogram=c("row"),
			main = paste("Genes Significantly Up regulated in NC and SRCAP\nHeatmap of DNA methylation values for respective CpG probes")
	#labCol=NULL,
	#labRow=NULL
	)
	dev.off()
	return(list(beta=dna.m,M=dna.mm,U=dna.u))
}


############################################################################
# HISTORY:
# Jun 7, 2010
# o Created. by houtan
############################################################################