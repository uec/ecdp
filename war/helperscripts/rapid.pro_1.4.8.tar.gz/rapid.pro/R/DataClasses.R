# TODO: Add comment
# 
# Author: feipan
#meth: annot, norm, meth_expr, QC,statDif,
#methGUI
# History:
#
###############################################################################

library(Biobase)
setClass("CnvSet",contains="SnpSet")
setClass("gSet",contains="eSet")
if(is.null(getGeneric("getRowName")))setGeneric("getRowName",function(object,...)standardGeneric("getRowName"))
if(is.null(getGeneric("subSetByLoc")))setGeneric("subSetByLoc",function(object,start,end,chr,...)standardGeneric("subSetByLoc"))
if(is.null(getGeneric("SubSet")))setGeneric("subSet",function(object,start,end,chr,...)standardGeneric("subSet"))
if(is.null(getGeneric("subSetByChr")))setGeneric("subSetByChr",function(object,chr,...)standardGeneric("subSetByChr"))
if(is.null(getGeneric("getgData"))) setGeneric("getgData",function(object,...)standardGeneric("getgData"))
if(is.null(getGeneric("getChr"))) setGeneric("getChr",function(object,...)standardGeneric("getChr"))
if(is.null(getGeneric("getStart"))) setGeneric("getStart",function(object,...)standardGeneric("getStart"))
if(is.null(getGeneric("getEnd"))) setGeneric("getEnd",function(object,...)standardGeneric("getEnd"))
setMethod("getgData","gSet",function(object,...){ 
			return(object@assayData$gData)
		}
)
setMethod("getChr","gSet",function(object,...){
			return(object@featureData$Chr)
		}
)
setMethod("getStart","gSet",function(object,...){
			return(object@featureData$Start)
		}
)
setMethod("getEnd","gSet",function(object,...){
			return(object@featureData$End)
		})
setMethod("subSet","gSet",function(object,start,end,chr,...){
			start2<-object@featureData$Start
			end2<-object@featureData$End
			chr2<-object@featureData$Chr
			ind1<-start2<start&end2>=start
			ind2<-start2<=end & end2>end
			ind3<-start2>=start & end2<=end
			ind<-(ind1 |ind2|ind3) &chr2==chr
			rst<-object@assayData$gData[ind,]
			if(length(which(ind))==1) rst<-matrix(rst,nrow=1,dimnames=list(rst[1],names(rst)))
			return(rst)
		})
setMethod("subSetByLoc","gSet",function(object,start,end=NULL,chr=NULL,...){
			ind <-object@featureData$Start>=start
			if(!is.null(end)) ind <-ind & object@featureData$End<=end
			if(!is.null(chr)) ind <-ind & (object@featureData$Chr==chr)
			gData<-object@assayData$gData[ind,]
			return(gData)
		})
setMethod("subSetByChr","gSet",function(object,chr,...){
			ind<-object@featureData$Chr==chr
			gData<-object@assayData$gData[ind,]
			return(gData)
		})
setMethod("getRowName","gSet",function(object,...){
			return(dimnames(object@assayData$gData)[[1]])
		})
setMethod("initialize","gSet",
		function(.Object,
				gData=new("matrix"),...){
			callNextMethod(.Object,gData=gData,...)
		}
)
#setMethod("initialize","gSet",
#		function(.Object,assayData=assayDataNew(gData=gData,gData=new("matrix")),...){
#			callNextMethod(.Object,assayData=assayData,...)
#		}
#)
setMethod("initialize","gSet",
		function(.Object,assayData=assayDataNew(gData=gData),
				featureData=new("AnnotatedDataFrame",data=data.frame(Chr=Chr,Start=Start,End=End)),
				gData=new("matrix"),Chr=new("character"),Start=new("numeric"),End=new("numeric"),
				...){
			callNextMethod(.Object,assayData=assayData,featureData=featureData,...)
		}
)
gSet_Test<-function(){
	sc<-matrix(1:100,nrow=10)
	chr<-rep("1",10)
	start<-1:10
	end<-3:12
#	dat<-new("gSet",gData=sc)
	dat2<-new("gSet",gData=sc,Chr=chr,Start=start,End=end)
	sc1<-subSetByChr(dat2,"1")
	sc2<-subSetByLoc(dat2,4,8,"1")
	sc3<-subSetByLoc(dat2,4,NULL,NULL)
	#sc4<-subSetByLoc(dat2,4)
	getValidity(getClass("gSet"))
}

##########################
# class methDataQC 
#############
setClass("methQCData",representation(cData="list",cNegData="list"),prototype=prototype(cData=NULL,cNegData=NULL))#,contains="eSet")
if(is.null(getGeneric("getNegData")))setGeneric("getNegData",function(object,...)standardGeneric("getNegData"))
if(is.null(getGeneric("getCData")))setGeneric("getCData",function(object,...)standardGeneric("getCData"))
if(is.null(getGeneric("setNegData<-")))setGeneric("setNegData<-",function(object,...)standardGeneric("setNegData<-"))
if(is.null(getGeneric("setCData<-")))setGeneric("setCData<-",function(object,...)standardGeneric("setCData<-"))
if(is.null(getGeneric("lenQCData")))setGeneric("lenQCData",function(object,...)standardGeneric("lenQCData"))
if(is.null(getGeneric("lenNegData")))setGeneric("lenNegData",function(object,...)standardGeneric("lenNegData"))

setMethod("initialize","methQCData",
		function(.Object,
				cData=new("list"),
				cNegData=new("list"),
				...){
			callNextMethod(.Object,
					cData=cData,
					cNegData=cNegData,
					...)
		}
)

setMethod("getNegData","methQCData",function(object,...){
			return(object@cNegData)
		})
setMethod("getCData","methQCData",function(object,...){
			return(object@cData)
		})
setMethod("setNegData<-","methQCData",function(object,value,...){
			object@cNegData<-value
			return(object)
		})
setMethod("setCData<-","methQCData",function(object,value,...){
			object@cData<-value
			return(object)
		})
setMethod("lenQCData","methQCData",function(object,...){
			return(length(object@cData))
		})
setMethod("lenNegData","methQCData",function(object,...){
			return(length(object@cNegData))
		})


test_QCData<-function(){
	dat<-list(qc1=c(1:200),qc2=c(1:10))
	qc.test<-new("methQCData",cData=dat,cNegData=list(1:5))
	slotNames(qc.test)
	qc.test@cData
	rr<-getCData(qc.test)
	c1<-getNegData(qc.test)
	setNegData(qc.test)<-list(1:10)
	c2<-getNegData(qc.test)
}
#################
# class mSet
#################
setClass("mSet",contains="eSet",representation=representation(QC="methQCData"))
if(is.null(getGeneric("getBeta")))setGeneric("getBeta",function(object,...) standardGeneric("getBeta"))

setMethod("getBeta","mSet",function(object,...){
			return(assayData(object)$BetaValue)
		})
setMethod("initialize","mSet",function(.Object,BetaValue=new("matrix"),phenoData=new("AnnotatedDataFrame"),featureData=new("AnnotatedDataFrame"),...){
			callNextMethod(.Object,BetaValue=BetaValue,...)
		})
methSet_Test<-function(){
	bv<-matrix(1:100,nrow=10)
	mset<-new("mSet",BetaValue=bv,QC=new("methQCData",cData=list()))
	dat1<-getBeta(mset)
}
#############################################
# class methData
############################################

setClass("methData",contains=c("eSet"),representation=representation(QC="methQCData"),
		prototype=prototype(QC=new("methQCData",cData=list(),cNegData=list())))
if(is.null(getGeneric("getM")))setGeneric("getM",function(object,...) standardGeneric("getM"))
if(is.null(getGeneric("getU")))setGeneric("getU",function(object,...) standardGeneric("getU"))
if(is.null(getGeneric("getBeta")))setGeneric("getBeta",function(object,...) standardGeneric("getBeta"))
if(is.null(getGeneric("getPvalue")))setGeneric("getPvalue",function(object,...) standardGeneric("getPvalue"))
if(is.null(getGeneric("getColorChannel")))setGeneric("getColorChannel",function(object,...) standardGeneric("getColorChannel"))
if(is.null(getGeneric("getBaseChannel")))setGeneric("getBaseChannel",function(object,...) standardGeneric("getBaseChannel"))
if(is.null(getGeneric("getID")))setGeneric("getID",function(object,...)standardGeneric("getID"))
if(is.null(getGeneric("getProbeID")))setGeneric("getProbeID",function(object,...)standardGeneric("getProbeID"))
if(is.null(getGeneric("getPhenoData")))setGeneric("getPhenoData",function(object,...)standardGeneric("getPhenoData"))
if(is.null(getGeneric("getMn")))setGeneric("getMn",function(object,...)standardGeneric("getMn"))
if(is.null(getGeneric("getUn")))setGeneric("getUn",function(object,...)standardGeneric("getUn"))
if(is.null(getGeneric("getMe")))setGeneric("getMe",function(object,...)standardGeneric("getMe"))
if(is.null(getGeneric("getUe")))setGeneric("getUe",function(object,...)standardGeneric("getUe"))
if(is.null(getGeneric("getCol")))setGeneric("getCol",function(object,...)standardGeneric("getCol"))
if(is.null(getGeneric("getRow")))setGeneric("getRow",function(object,...)standardGeneric("getRow"))
if(is.null(getGeneric("getQC")))setGeneric("getQC",function(object,...)standardGeneric("getQC"))
if(is.null(getGeneric("getSampID")))setGeneric("getSampID",function(object,...)standardGeneric("getSampID"))
setMethod("getProbeID","methData",function(object,...){
			return(dimnames(object@assayData$M)[[1]])
		})
setMethod("initialize", "methData",
		function(.Object,
				M = new("matrix"),
				U = new("matrix"),
				BetaValue = new("matrix"),
				Pvalue = new("matrix"),
				...) {
			callNextMethod(.Object,
					M=M, U=U, BetaValue = BetaValue,Pvalue=Pvalue,
					...)
		})
# add validator to dim(bv)=dim(pv)
setMethod("getPhenoData","methData",function(object,...){
			return(pData(object@phenoData))
		})
setMethod("getID","methData",function(object,...){
			return(dimnames(object@assayData$M)[[2]])
		})
setMethod("getM","methData",function(object,...){
			return(as.data.frame(object@assayData$M))
		})
setMethod("getU","methData",function(object,...){
			return(as.data.frame(object@assayData$U))
		})
setMethod("getBeta","methData",function(object,...){
			return (as.data.frame(object@assayData$BetaValue))
		})
setMethod("getPvalue","methData",function(object,...){
			return(as.data.frame(object@assayData$Pvalue))
		})
setMethod("getMn","methData",function(object,...){
			return (as.data.frame(object@assayData$Mnumber))
		})
setMethod("getUn","methData",function(object,...){
			return (as.data.frame(object@assayData$Unumber))
		})
setMethod("getMe","methData",function(object,...){
			return (as.data.frame(object@assayData$Mstderr))
		})
setMethod("getUe","methData",function(object,...){
			return (as.data.frame(object@assayData$Ustderr))
		})
setMethod("getCol","methData",function(object,...){
			return (ncol(object@assayData$BetaValue))
		})
setMethod("getRow","methData",function(object,...){
			return (nrow(object@assayData$BetaValue))
		})
setMethod("getQC","methData",function(object,...){
			return(object@QC)
		})
setMethod("getCData","methData",function(object,...){
			return(getCData(object@QC))
		})
setMethod("getNegData","methData",function(object,...){
			return(getNegData(object@QC))
		})
setMethod("setNegData<-","methData",function(object,value,...){
			setNegData(object@QC)<-value 
			return(object)
		})
setMethod("setCData<-","methData",function(object,value,...){
			setCData(object@QC)<-value 
			return(object)
		})
setMethod("lenQCData","methData",function(object,...){
			return(lenQCData(object@QC))
		})
setMethod("lenNegData","methData",function(object,...){
			return(lenNegData(object@QC))
		})
setMethod("getSampID","methData",function(object,...){
			return(dimnames(object@assayData$BetaValue)[[2]])
		})
setMethod("getColorChannel","methData",function(object,...){
			return(object@assayData$colorChannel)
		})
setMethod("getBaseChannel","methData",function(object,...){
			return(object@assayData$baseChannel)
		})


methData_test<-function(){
	data.dir<-system.file("extdata",package="Biobase")
	dat<-as.matrix(read.delim(file.path(data.dir,"exprsData.txt"),sep="\t",header=T,as.is=T,row.names=1))
	dim(dat)
	names(dat)
	mdata<-new("methData",M=dat,U=dat,BetaValue=dat,Pvalue=dat)
	pdat<-read.delim(file.path(data.dir,"pData.txt"),sep="\t",as.is=T,header=F,row.names=1)
	dim(pdat)
	pdat<-pdat[1:26,]
	vmdata<-data.frame(labelDescription=c("A","B","C"),row.names=c("E","F","G"))
	phenodata<-new("AnnotatedDataFrame",data=pdat,varMetadata=vmdata)
	head(pData(phenodata))
	phenoData(mdata)<-phenodata
	slotNames(mdata)
	mp<-mdata@phenoData
	pd<-pData(phenodata)
	dim(pd)
	dim(getBeta(mdata))
	getNegData(mdata)
	setNegData(mdata)<-list(1:3)
	getCData(mdata)
	setCData(mdata)<-list(1:10)
}
methData_test.2<-function(){
	fdat<-dat[,1:5]
	vfdata<-data.frame(labelDescription=rownames(fdat),row.names=rownames(fdat))
	fdat<-new("AnnotatedDataFrame",data=as.data.frame(t(fdat)),varMetadata=vfdata)
	featureData(mdata)<-fdat
	pData(mdata@featureData)
	getSlots("methData")
	getClass("methData")
}

#################################
# class methDataSet
###########################
setClass("methDataSet",contains="eSet"
)
setMethod("initialize", "methDataSet",
		function(.Object,
				M = new("matrix"),
				U = new("matrix"),
				Beta = new("matrix"),
				Pvalue = new("matrix"),
				#IsRed = new("matrix"),
				...) {
			callNextMethod(.Object,
					M=M, U=U, Beta=Beta, Pvalue=Pvalue,#IsRed=IsRed,
					...)
		})

#####
setClass("foo", representation(a = "character", b = "numeric"))
setClass("bar", representation(d = "numeric", c = "numeric",e="list"))
setClass("baz", contains = c("foo", "bar"))

if (is.null(getGeneric("pfoo")))setGeneric("pfoo", function(object,...)
				standardGeneric("pfoo"))

setMethod("pfoo", "character",
		function(object) print(object))
setMethod("pfoo", "foo",
		function(object) {
			print(object@b)
			t= object@b+20
			print(t)
		}
)
if (is.null(getGeneric("pbaz")))setGeneric("pbaz",function(o,...)
				standardGeneric("pbaz"))
setMethod("pbaz","baz",function(o){ #o has to be same as in generic 'o'
			print(o@a)
		})
baz_test<-function(){
	bz<-new("baz",a="a1",b=100,c=299,d=323,e=list(f="abc"))
	slotNames(bz)
	str(bz)
}
.initFoo <- function(where) {
	setClass("foo", representation(a="character", b="numeric"),where=where)
	setClass("bar", representation(d="numeric", c="numeric"), where=where)
	setClass("baz", contains=c("foo", "bar"), where=where)
}
#if(!exists("methData")) .Load_lib()
#.Load_lib<-function(){
###########################
###############################
