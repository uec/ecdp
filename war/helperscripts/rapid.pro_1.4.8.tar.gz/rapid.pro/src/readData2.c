#include <stdio.h>

extern int strcmp(char *, char *);

void readData(char *datFn,char *outFn){
  FILE *pf = fopen(datFn,"r");
  FILE *pf2 = fopen(outFn,"w+");
  char data[1000];
  char buf[1000];
  if(pf==NULL){
        perror("can't open the input file");
  }else{
        while(!feof(pf)){
                fscanf(pf,"%s\n",buf);
                if(strcmp(buf,"9606")==0){
                        char dat1[500];
                        char dat2[500];
                        fscanf(pf,"%s\t%s",dat1,dat2);
                        sprintf(data,"%s\t%s",dat1,dat2);
			fprintf(pf2,"%s\n",data);
			//printf("data: %s\n",data);
                }
        }
  }
  fclose(pf);
  fclose(pf2);
}
void readData2(){
	char *datFn="dat.txt";
	char *outFn="out.txt";
	readData(datFn,outFn);
}
void readData3(char **dat){
	readData(dat[0],dat[1]);
}
void testData(int * dat, int *ndat, int *dat2){
	int i;
	for(i=0;i<*ndat;i++){
		//printf("data is: %d",dat[i]);
		dat2[i] = dat[i]*2;
	}
}

int main(int argc,char **argv){
  char * datFn = "dat.txt";
  char * outFn = "out.txt";
  if(argc>=2) datFn=argv[1];
  if(argc>=3) outFn=argv[2];
  readData(datFn,outFn);
}

