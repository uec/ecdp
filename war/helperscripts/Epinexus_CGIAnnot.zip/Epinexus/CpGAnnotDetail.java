package Epinexus;
import java.util.Vector;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.NumberAxis;

import java.io.File;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileNotFoundException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CpGAnnotDetail extends HttpServlet {

	//read in the seq, create and return the data vector
	public static void runSlidingWind(Vector GCCDataVect,Vector OERDataVect, String seq){
		//for the current cgi, read seq from the file
		//seq = "GCAGGGAACATAAAACTTTATTCACTGCAAGAGCTGCGGTCCTGAGGGAAGAATCCTCTGAACTGAGTCAGCACTGAGCTGAGCGATGGAGCCTCAGGGATGAAAGAATAAAGCAGAGAGCCTGGCGTCCAGGCACAGCGAGACCCAAGGGGCCCTCCCAGTGACAGGAAGAGGTGAGACAGAGGCTGCTGCTTGCTCAGAGGCCCCAGAGCAGCTCCACTGCGCACCCAAGGACTCACCACCTTTACCACTAACAAGCTCTGCCAGTTTAATGTACAGTTACTCTGTACCACGTCCTGGGCTGGGCACTGCAGTTCCTGGGAAAATGACGCAGTCCAGGCCCTTTAGGGGAAGCCTGGGAAGAGGGAACTCAGGGGGATTGGGAGGATGGGGTGGGTGAGGCTCACTCCCTGTCAAGCTGGGCAAAGCGCCGTGTCTGAGAGGCAGGCAGCTAACCGCGAGCCGGCGGCGTTCCATTTACAATCTGGTGAGCCTGTATTGGTATAACTCGTATTGTGAGGCTTTTGAGATATCTTGTGACCTTGTGATTTTCCCCGTCTTTGGTGCTTTTGCCCCCTGTAGTGACAAGCAGTTAAAAAAACAAAAACAGAAAACACTCAGAAGGGCAGTGCTTGCTCAGGGATCTGCAGACAGGGCAGATGTCAAGCTCTCACCCAGTTCTGCTGTCGAATGGGGTGCAGGGAGGGGAAGAGGGACCAGGGCCTAGCAGGACAGGGGCAGCTGCAAGCCCCACCTAGAAGTACCCTGGTATGATAGGCTCTGGCTAGGAGCGCTGCAGTGTCACGAAGGCCCCCAGGGAGAGCTGGATCCCTTTGCCCTGATCCTCAGTCCCAGTCTGGAGCAACCTACAGGCCCTGGAGGAGGGGGCAGGACTCCAGTGCCCTTCCCACGAGGCCCTGCTGTACTGACCTCGAATCTGCAGGTTGGAGAAGGTCTGCACGGGAATGGTGATCCTGAAAGAAAGCAGAGGGAGAGGGCTGCCCGGGCTGCCTGGGACACCCCTAGGCTGGGTCTTGGTGCGGGGCCATCATGACAACTTGAACGCCCTTTTCCTTGCCAGGAAAGTCTAACTCCATCTCCTAGCTTTTTCCCCAGCAGCCAACGTGCTATCTGGAGTTCCAAACGTCTGCAAGGGGCTTGAGTGTTATCTGGGAGGGGCGCATGTCTATCTGAAGGAAGATGGAAAAGGGAGGGGAAAGTGGTGAAGAAAGTTCCAAGGAGGCAGAAGAGATGGGTGAGGTGAGGAGTCCAATCTTGGCTGGGAAGATGGGGAGTATGCCTCTTAGTTTGGAGGGTGACCCAAGTCCTTGGCCTTGAGGCCTAATCAATATTGGTTGAATCCATCCatccattcagtcatcaaacatctagtgactgcctgctatgtgtgaggcaggcactgtgctgggcattgaggtgggaagggatctgcacacaaggctgaaaaagactcagtccctgAAGGGAGCAAGATGAGCTCTACCGTGAGGCAGCAGGGAGACTTCCCCAGGGGCTGTGATGAGGGCTCACCGGTTCTCCTCGCCCTCTAGCAGCTTCCTGTAGGTGGCGATCTCGATGTCCAGGGCCAGCTTGACATTGAGCAGGTCCTGGTACTCCTGCAAGTGGCGGGCCATCTCGTCCTTGAGGCTCTGCCCCTCTTCCTCCAGCCGCGCCAGCGCCTCCTGATAACTGGCCGCCTCCCGCACGTGCCGCTCCTCCTGCTCGCGCATCTGCCTCTCCAGGGACTCGTTCTGTGGGATGGAGCCGGCCGGTCCCGCGGAGCCCCGACCCGACTTGGGGAGGTTTCGAggcccggcccccggccccaggccccgccTCTAGCCCGGGGGTAACGTTCAGGCCCCGCCCTCGACCCAGGTCCTCGTCCCTGGCCCTTCTCCCCTGGCATCTCCTGGGGTGGCCGTCCCTGCTCCGCCCGTCCCCGTCCTGCCCTGGCCGCGCTCACCGTGCCGCGCAGAGACTCCAGGTCGCAGGTCAAGGACTGCAACTGGCGCCGGTAGTCGTTGGCTTCGTGCTTGGCCTGGCGGAGCAGCTCCGCGTTGCGGGCAGCAGCGTCTGTCAGGTCTGCAAACTAGGTGGGGGACACATATGGGGGGCTGTGTGGGCCCATGGGCAGGCACGGGCTCTGGGAAATCAGGGAGGTGAGCAGCACCCCAGTTAACCCCAGGACGTTGGCCCTGGCTGGGACTTTTCCCAACAACTGTGACCCATGGATGCGGGCAGGGTAGCGGGCTGCCAGACCTCAGCACCTAGCACAACACCTGGTCAGCAAGCGAATGAATGAACAGTGCCACAGAATCCAGAACCTTCCACACTGACAGCTGCATCTGCGGGACTGAACGCTGTCGTCTTAGGCGAGCGGAGGCCTGGGTGTTTTGTGTGTTtttgtttttttgttttttttgttttattttgagacagagtcttgctcttgtcgcccaggttggaagtcagtggcacaatcccgggtcactgcaacctctgcctcccaggttcaagcaattctcctgccccagccacctgagtagctgggattacaggcatgcgccactacacccggctgattttgtatttttagtagagacggggtttcaccatgttgaccaggctagtcttgaactgctgacctcaggtgatccgcatgcctcggcctcccaaagtgctgggattacaggtgtgagccacctcgcctggccTCACCCTGGGTTCTAATAGCCCTTTCTCCCCTGCCTGCAGGGAGGTCCTCCCAGCCCCATCGGGCCCTCACCCTGCTCAGACACCAGTGGCTTCTGCCACTCACACTCCTCAGCTAGGTGCCCTGGCTAGGCTAGCATCTTGGGGCCCTGCCTCTCTGTGCTTTTCTGCCTCCAGGCTCTGTCCTCCACTAGGAATGGCCCTCCCTTCTTCTCTTCCTGTCCACAGCGTGCCTGTCCTGCCTAGCCCAAATGCCCCCTCTACAGTGTCTTTCCTGGCTCCCACACTACATATAAGCTCTGAGCTGTGGTGTTCTCTACGGGCACTATGTTTGGGTGCACGTCAATATCACACCTTCCAGGTCAGACACCTCTCTGTGTCCTGGGGGGTGCCTGGCATATGGTAGAGGCTCAG";
		char [] seqArray = seq.toCharArray();
		// take care of repeatmasked or not
		int seqSize = seqArray.length;
		int slidingWinSize = 10;
		/*int graphXSize = 50;
				if(seqSize>graphXSize){
			slidingWinSize = (int) (seqSize/graphXSize);
		}*/
		int gapSize = 0;
		String chr = "";
		int startCurPos = 0;
		CgiRegion cgiRG = new CgiRegion(startCurPos,chr,slidingWinSize,gapSize);
		int i =0;
		for(i =0;i<seqSize;i++){
			cgiRG.add(seqArray[i]);
			if(((i+1)%slidingWinSize) ==0){
				GCCDataVect.add(new Float(cgiRG.getGCC()));
				OERDataVect.add(new Float(cgiRG.getOER()));
			}
		}
		//add the last slidingwin
		if((i%slidingWinSize) !=0){
				GCCDataVect.add(new Float(cgiRG.getGCC()));
				OERDataVect.add(new Float(cgiRG.getOER()));
			}		
	}
	public static void plot(String graphFileName, String header, String filename, int start, int end) {
		
		Vector GCCDataVect = new Vector();
		Vector OERDataVect = new Vector();
		String seq = "";
		
		try {
			int startCurPos = start;
			int len = end - start;
			len = len + (len - 50 + start % 50)/50 + 2;
			start = start + ((int)start/50) + header.length();
			end = start + len;
			char[] bufit = new char[len];
			BufferedReader brd = new BufferedReader(new FileReader(filename));
			brd.skip(start);
			brd.read(bufit,0,len);
			brd.close();
			seq = new String(bufit);
		} catch(FileNotFoundException fex) {
			System.out.println("File not found.");
		} catch(IOException iex) {
			System.out.println("IO Exception occurred.");
		}
		
		runSlidingWind(GCCDataVect,OERDataVect, seq);
		
		XYSeries GCCLine = new XYSeries("GC Ccontent (%)");
		int index = 0;
		for(index=0;index<GCCDataVect.size();index++){
			float y = ((Float)GCCDataVect.get(index)).floatValue();
			GCCLine.add(start+index,y);
		}
		
        XYSeries OERLine = new XYSeries("CpG Observed/Expeced Ratio");
		for(index=0;index<OERDataVect.size();index++){
			float y = ((Float)OERDataVect.get(index)).floatValue();
			OERLine.add(start+index,y);
		}
		
		XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(GCCLine);
        dataset.addSeries(OERLine);
        JFreeChart chart = ChartFactory.createXYLineChart("CpG Plot", // Title
                "", // x-axis Label
                "", // y-axis Label
                dataset, // Dataset
                PlotOrientation.VERTICAL, // Plot Orientation
                true, // Show Legend
                true, // Use tooltips
                false // Configure chart to generate URLs?
         );
         XYPlot xyplot = chart.getXYPlot();
         NumberAxis domainAxis = new NumberAxis("Genomic Coordinate (bp)");
         domainAxis.setRange(start, start+index);
         //domainAxis.setTickLabelsVisible(false);
         xyplot.setDomainAxis(domainAxis);
        
        try {
            ChartUtilities.saveChartAsJPEG(new File(graphFileName), chart, 500,
                300);
        } catch (IOException e) {
            System.err.println("Problem occurred creating chart.");
        }         
	}
    public static void plotExample(String cfn) {
        //         Create a simple XY chart
        XYSeries series = new XYSeries("XYGraph");
        series.add(1, 1);
        series.add(1, 2);
        series.add(2, 1);
        series.add(3, 9);
        series.add(4, 10);
        //         Add the series to your data set
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);
        //         Generate the graph
        JFreeChart chart = ChartFactory.createXYLineChart("XY Chart", // Title
                "x-axis", // x-axis Label
                "y-axis", // y-axis Label
                dataset, // Dataset
                PlotOrientation.VERTICAL, // Plot Orientation
                true, // Show Legend
                true, // Use tooltips
                false // Configure chart to generate URLs?
            );
        try {
            ChartUtilities.saveChartAsJPEG(new File(cfn), chart, 500,
                300);
        } catch (IOException e) {
            System.err.println("Problem occurred creating chart.");
        }
    }
    public static String getPagePart(String FileName){
		
		StringBuffer buf = new StringBuffer();
		try{		
			BufferedReader in = new BufferedReader(new FileReader(new File(FileName)));
			String readin = in.readLine();
			while(readin != null) {
				buf.append(readin);
				//outnow.println(readin);
				readin = in.readLine();
			}
			in.close();
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
		return buf.toString();
	}
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException {
	    // Use "request" to read incoming HTTP headers (e.g. cookies)
	    // and HTML form data (e.g. data the user entered and submitted)
	    
	    // Use "response" to specify the HTTP response line and headers
	    // (e.g. specifying the content type, setting cookies).
	    
	    //PrintWriter out = response.getWriter();
	    // Use "out" to send content to browser
	  }
     public void runCpGAnnotDetail(HttpServletRequest request,HttpServletResponse response){
        try {
            doGet(request, response);
        } catch (ServletException ex) {
            Logger.getLogger(CpGAnnotDetail.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
     public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException {
		//String Constants.fileRoot1 = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/data/";
		//String Constants.fileRoot2 = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/cgidata/";
		//String Constants.fileRoot1 =  "/Users/epigenome/software/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/data/";
		//String Constants.fileRoot2 =  "/Users/epigenome/data/chromFa/";
                //String Constants.fileRoot1 = "/home/feipan/apache-tomcat-6.0.20/webapps/ROOT/tmp/";
                //String Constants.fileRoot1 =  "/home/feipan/apache-tomcat-6.0.20/webapps/ROOT/Epinexus/data/";
		//String Constants.fileRoot2 =  "/home/feipan/data/chromFa/";
                //String Constants.fileRoot3 =  "/home/feipan/data/chromFa/hs_ref_";
		
		String filename = new Long(System.currentTimeMillis() + new java.util.Random().nextLong()).toString();
		String inputFileName = Constants.outFolder + filename + "-in.txt";
		String outputChartName = Constants.outFolder + filename + ".jpg";
		String part1 = Constants.fileRoot2 + "cpgserp1annot_new.txt";
		String part2 = Constants.fileRoot2 + "cpgserp2annot.txt";

		response.setContentType("text/html");
		try {
			PrintWriter outnow = response.getWriter();
			outnow.println(getPagePart(part1));
			String st = "<center><H3>Details of the CpG Island Search Results <p></H3></center>";;
			outnow.println(st);
			
			String header = ">" + request.getParameter("filename");
			String infile = Constants.fileRoot3 + request.getParameter("filename") + ".fa";
			int start = Integer.parseInt(request.getParameter("start"));
			int end = Integer.parseInt(request.getParameter("end"));
			
			plot(outputChartName, header, infile, start, end);
			String img = "<div style=\"text-align: center;\"><img border=0 align=\"center\" src=\""+Constants.httplink + filename + ".jpg\"></div><p>";
			outnow.println(img);
			
			String dynamic = "<div style=\"text-align:center;\">";
			dynamic = dynamic + "<input type=\"text\" id=\"zin\"><input type=\"button\" value=\"Zoom In\" onclick=\"javascript:return zoomin('" + start + "','" + end + "','" + request.getParameter("filename") + "')\">";
			dynamic = dynamic + "<input type=\"text\" id=\"zout\"><input type=\"button\" value=\"Zoom Out\" onclick=\"javascript:return zoomout('" + start + "','" + end + "','" + request.getParameter("filename") + "')\">";
			dynamic = dynamic + "<input type=\"text\" id=\"zfwd\"><input type=\"button\" value=\"Forward\" onclick=\"javascript:return forward('" + start + "','" + end + "','" + request.getParameter("filename") + "')\">";
			dynamic = dynamic + "<input type=\"text\" id=\"zbck\"><input type=\"button\" value=\"Backward\" onclick=\"javascript:return backward('" + start + "','" + end + "','" + request.getParameter("filename") + "')\">";
			dynamic = dynamic + "</div>";
			
			outnow.println(dynamic);
			outnow.println(getPagePart(part2));
			outnow.close();
		}catch(IOException ioe){			
			ioe.printStackTrace();
		}
     }
}
