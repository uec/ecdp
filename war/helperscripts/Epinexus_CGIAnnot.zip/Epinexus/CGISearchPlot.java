package Epinexus;
import java.util.Vector;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.chart.renderer.xy.DefaultXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.annotations.XYLineAnnotation;
import org.jfree.chart.annotations.XYTextAnnotation;
import org.jfree.chart.plot.IntervalMarker;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.event.AxisChangeEvent;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.ui.Layer;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.renderer.category.CategoryStepRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.plot.CategoryPlot;

import java.io.File;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileNotFoundException;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CGISearchPlot {
	private XYItemRenderer render;
	private final JFreeChart chart;
	private int xSeqLength = 800;
	private int ySeqLength;
	private int leftSeqLength;
	private char[] seqChar;
	
	public CGISearchPlot(char[] seqChar){
		this.seqChar = seqChar;
		int totalSeqSize = seqChar.length;
		ySeqLength = (totalSeqSize/xSeqLength)+1;
		leftSeqLength = totalSeqSize%xSeqLength;
		NumberAxis rangeAxis = new NumberAxis("Base Pair (bp)");
        rangeAxis.setRange(1, xSeqLength+200);
        rangeAxis.setTickLabelsVisible(false);

        final NumberAxis domainAxis = new NumberAxis("");
        domainAxis.setInverted(true);
        domainAxis.setRange(0, ySeqLength+1);
        domainAxis.setTickLabelsVisible(false);
       
        render = new StandardXYItemRenderer();
		final XYDataset dataset = new XYSeriesCollection();
        final XYPlot plot = new XYPlot(dataset, domainAxis, rangeAxis, render);
        plot.setOrientation(PlotOrientation.HORIZONTAL);
        chart = new JFreeChart("CpG Island Detail Plot", JFreeChart.DEFAULT_TITLE_FONT,plot,false);

         render = plot.getRenderer();		
	}
	
	public void saveChart(String graphFileName){
        try {
            ChartUtilities.saveChartAsJPEG(new File(graphFileName), chart, 640,ySeqLength*50);
        } catch (IOException e) {
            System.err.println("Problem occurred creating chart.");
        } 		
	}
	public void plotCGI(int id, int start, int end){
		int startPos = start%xSeqLength+100;
		int startLine = start/xSeqLength+1;
		int endPos = end%xSeqLength+100;
		int endLine = end/xSeqLength+1;
		if(startLine==endLine){
			XYLineAnnotation annotcgi = new XYLineAnnotation(startLine-0.3,startPos,startLine-0.3,endPos,new BasicStroke(5.0f),Color.blue);
			XYTextAnnotation tannotcgi = new XYTextAnnotation(""+id+". CpG Island",startLine-0.5,startPos);
			tannotcgi.setTextAnchor(TextAnchor.BASELINE_LEFT);
			render.addAnnotation(annotcgi);
			render.addAnnotation(tannotcgi);
		}else{
			XYLineAnnotation annotcgi = new XYLineAnnotation(startLine-0.3,startPos,startLine-0.3,xSeqLength+100,new BasicStroke(5.0f),Color.blue);
			XYTextAnnotation tannotcgi = new XYTextAnnotation(""+id+". CpG Island ",startLine-0.5,startPos);
			tannotcgi.setTextAnchor(TextAnchor.BASELINE_LEFT);
			render.addAnnotation(annotcgi);
			render.addAnnotation(tannotcgi);
			for(int i=startLine+1;i<=endLine;i++){
				if(i!=endLine){
					annotcgi = new XYLineAnnotation(i-0.3,100,i-0.3,xSeqLength+100,new BasicStroke(5.0f),Color.blue);
				}else{
					annotcgi = new XYLineAnnotation(i-0.3,100,i-0.3,endPos,new BasicStroke(5.0f),Color.blue);
				}
				render.addAnnotation(annotcgi);
			}
			
		}
		
	}
	public void plotCpG(boolean isMasked){
		
		for(int i=1;i<=ySeqLength;i++){
			int startLable = 1+(i-1)*xSeqLength;
			int endLable = i*xSeqLength;
			XYLineAnnotation annot;
			if(i!=ySeqLength){
				 annot= new XYLineAnnotation(i,100,i,xSeqLength+100,new BasicStroke(1.0f),Color.green);
			}else{
				 annot = new XYLineAnnotation(i,100,i,leftSeqLength+100,new BasicStroke(1.0f),Color.green);
			}
			XYTextAnnotation tannot = new XYTextAnnotation(""+startLable,i,50);
			XYTextAnnotation tannot2 = new XYTextAnnotation(""+endLable,i,950);
			for(int j=1;j<xSeqLength;j++){
				int pos = (i-1)*xSeqLength+j;
				if (pos>=seqChar.length)break;
				char cur_bp = seqChar[pos];
				char pre_bp = seqChar[pos-1];
				int relative_pos = pos %xSeqLength +100;
				if(!isMasked){
					if((cur_bp =='G' || cur_bp=='g')&&(pre_bp=='C' || pre_bp=='c')){
						XYTextAnnotation tannot3 = new XYTextAnnotation("|",i,relative_pos);
						tannot3.setPaint(Color.red);
						render.addAnnotation(tannot3);
					}					
				}else{
					if(cur_bp =='G'&&pre_bp=='C'){
						XYTextAnnotation tannot3 = new XYTextAnnotation("|",i,relative_pos);
						tannot3.setPaint(Color.red);
						render.addAnnotation(tannot3);
					}					
				}

			}
			render.addAnnotation(tannot);
			render.addAnnotation(tannot2);
			render.addAnnotation(annot);
		}		
	}	
   public static void main(String [] args){
   		System.out.println("Hello");
   	 String seq = "GCAGGGAACATAAAACTTTATTCACTGCAAGAGCTGCGGTCCTGAGGGAAGAATCCTCTGAACTGAGTCAGCACTGAGCTGAGCGATGGAGCCTCAGGGATGAAAGAATAAAGCAGAGAGCCTGGCGTCCAGGCACAGCGAGACCCAAGGGGCCCTCCCAGTGACAGGAAGAGGTGAGACAGAGGCTGCTGCTTGCTCAGAGGCCCCAGAGCAGCTCCACTGCGCACCCAAGGACTCACCACCTTTACCACTAACAAGCTCTGCCAGTTTAATGTACAGTTACTCTGTACCACGTCCTGGGCTGGGCACTGCAGTTCCTGGGAAAATGACGCAGTCCAGGCCCTTTAGGGGAAGCCTGGGAAGAGGGAACTCAGGGGGATTGGGAGGATGGGGTGGGTGAGGCTCACTCCCTGTCAAGCTGGGCAAAGCGCCGTGTCTGAGAGGCAGGCAGCTAACCGCGAGCCGGCGGCGTTCCATTTACAATCTGGTGAGCCTGTATTGGTATAACTCGTATTGTGAGGCTTTTGAGATATCTTGTGACCTTGTGATTTTCCCCGTCTTTGGTGCTTTTGCCCCCTGTAGTGACAAGCAGTTAAAAAAACAAAAACAGAAAACACTCAGAAGGGCAGTGCTTGCTCAGGGATCTGCAGACAGGGCAGATGTCAAGCTCTCACCCAGTTCTGCTGTCGAATGGGGTGCAGGGAGGGGAAGAGGGACCAGGGCCTAGCAGGACAGGGGCAGCTGCAAGCCCCACCTAGAAGTACCCTGGTATGATAGGCTCTGGCTAGGAGCGCTGCAGTGTCACGAAGGCCCCCAGGGAGAGCTGGATCCCTTTGCCCTGATCCTCAGTCCCAGTCTGGAGCAACCTACAGGCCCTGGAGGAGGGGGCAGGACTCCAGTGCCCTTCCCACGAGGCCCTGCTGTACTGACCTCGAATCTGCAGGTTGGAGAAGGTCTGCACGGGAATGGTGATCCTGAAAGAAAGCAGAGGGAGAGGGCTGCCCGGGCTGCCTGGGACACCCCTAGGCTGGGTCTTGGTGCGGGGCCATCATGACAACTTGAACGCCCTTTTCCTTGCCAGGAAAGTCTAACTCCATCTCCTAGCTTTTTCCCCAGCAGCCAACGTGCTATCTGGAGTTCCAAACGTCTGCAAGGGGCTTGAGTGTTATCTGGGAGGGGCGCATGTCTATCTGAAGGAAGATGGAAAAGGGAGGGGAAAGTGGTGAAGAAAGTTCCAAGGAGGCAGAAGAGATGGGTGAGGTGAGGAGTCCAATCTTGGCTGGGAAGATGGGGAGTATGCCTCTTAGTTTGGAGGGTGACCCAAGTCCTTGGCCTTGAGGCCTAATCAATATTGGTTGAATCCATCCatccattcagtcatcaaacatctagtgactgcctgctatgtgtgaggcaggcactgtgctgggcattgaggtgggaagggatctgcacacaaggctgaaaaagactcagtccctgAAGGGAGCAAGATGAGCTCTACCGTGAGGCAGCAGGGAGACTTCCCCAGGGGCTGTGATGAGGGCTCACCGGTTCTCCTCGCCCTCTAGCAGCTTCCTGTAGGTGGCGATCTCGATGTCCAGGGCCAGCTTGACATTGAGCAGGTCCTGGTACTCCTGCAAGTGGCGGGCCATCTCGTCCTTGAGGCTCTGCCCCTCTTCCTCCAGCCGCGCCAGCGCCTCCTGATAACTGGCCGCCTCCCGCACGTGCCGCTCCTCCTGCTCGCGCATCTGCCTCTCCAGGGACTCGTTCTGTGGGATGGAGCCGGCCGGTCCCGCGGAGCCCCGACCCGACTTGGGGAGGTTTCGAggcccggcccccggccccaggccccgccTCTAGCCCGGGGGTAACGTTCAGGCCCCGCCCTCGACCCAGGTCCTCGTCCCTGGCCCTTCTCCCCTGGCATCTCCTGGGGTGGCCGTCCCTGCTCCGCCCGTCCCCGTCCTGCCCTGGCCGCGCTCACCGTGCCGCGCAGAGACTCCAGGTCGCAGGTCAAGGACTGCAACTGGCGCCGGTAGTCGTTGGCTTCGTGCTTGGCCTGGCGGAGCAGCTCCGCGTTGCGGGCAGCAGCGTCTGTCAGGTCTGCAAACTAGGTGGGGGACACATATGGGGGGCTGTGTGGGCCCATGGGCAGGCACGGGCTCTGGGAAATCAGGGAGGTGAGCAGCACCCCAGTTAACCCCAGGACGTTGGCCCTGGCTGGGACTTTTCCCAACAACTGTGACCCATGGATGCGGGCAGGGTAGCGGGCTGCCAGACCTCAGCACCTAGCACAACACCTGGTCAGCAAGCGAATGAATGAACAGTGCCACAGAATCCAGAACCTTCCACACTGACAGCTGCATCTGCGGGACTGAACGCTGTCGTCTTAGGCGAGCGGAGGCCTGGGTGTTTTGTGTGTTtttgtttttttgttttttttgttttattttgagacagagtcttgctcttgtcgcccaggttggaagtcagtggcacaatcccgggtcactgcaacctctgcctcccaggttcaagcaattctcctgccccagccacctgagtagctgggattacaggcatgcgccactacacccggctgattttgtatttttagtagagacggggtttcaccatgttgaccaggctagtcttgaactgctgacctcaggtgatccgcatgcctcggcctcccaaagtgctgggattacaggtgtgagccacctcgcctggccTCACCCTGGGTTCTAATAGCCCTTTCTCCCCTGCCTGCAGGGAGGTCCTCCCAGCCCCATCGGGCCCTCACCCTGCTCAGACACCAGTGGCTTCTGCCACTCACACTCCTCAGCTAGGTGCCCTGGCTAGGCTAGCATCTTGGGGCCCTGCCTCTCTGTGCTTTTCTGCCTCCAGGCTCTGTCCTCCACTAGGAATGGCCCTCCCTTCTTCTCTTCCTGTCCACAGCGTGCCTGTCCTGCCTAGCCCAAATGCCCCCTCTACAGTGTCTTTCCTGGCTCCCACACTACATATAAGCTCTGAGCTGTGGTGTTCTCTACGGGCACTATGTTTGGGTGCACGTCAATATCACACCTTCCAGGTCAGACACCTCTCTGTGTCCTGGGGGGTGCCTGGCATATGGTAGAGGCTCAG";
   		char seqch[] = seq.toCharArray();
   		String cfn = "c:\\temp\\testPlot.jpg";
   		CGISearchPlot cgiplot = new CGISearchPlot(seqch);
   		cgiplot.plotCpG(true);
   		cgiplot.plotCGI(1,400,1620);
   		cgiplot.saveChart(cfn);
   }
}
