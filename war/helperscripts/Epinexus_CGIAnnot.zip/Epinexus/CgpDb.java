package Epinexus;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Creates a database connection, fires queries and returns results.
 */
public class CgpDb extends HttpServlet {

	/**
	 * Runs the program and retrieves the results.
	 *
	 * @param request The servlet request parameters.
	 * @param response The servlet response parameters.
	 */
    public void doPost(HttpServletRequest request, HttpServletResponse response) 
    	throws ServletException {

		String fileRoot = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/data/";
		String filename = new Long(System.currentTimeMillis() + new java.util.Random().nextLong()).toString();
		String resultFileName = fileRoot + filename + "-CgpResult.html";
		
		String part1 = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/polydata/polyp1.txt";
		String part2 = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/polydata/polyp2.txt";

    	response.setContentType("text/html");
    	
		try {
			PrintWriter out = response.getWriter();
			
			out.println(getPagePart(part1));
			
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql:///", "root", "passw0rd");
			
			//File resultFile = new File(resultFileName);
			//BufferedWriter resultFileWriter = new BufferedWriter(new FileWriter(resultFile));
			
			String database = request.getParameter("database");
			String parameters = request.getParameter("params");
	   		if(parameters.indexOf(";") == -1) {
    			parameters = parameters + ";";
    		}

			int unitCount = 0;
			String tempParameters = parameters;
			int index = tempParameters.indexOf(";");
			
			while(index != -1) {
				unitCount ++;
				tempParameters = tempParameters.substring(index + 1);
				index = tempParameters.indexOf(";");
			}
			
			String[] chrom = new String[unitCount];
			String[] start = new String[unitCount];
			String[] end = new String[unitCount];
			String[] query = new String[unitCount];
			
			unitCount = -1;
			tempParameters = parameters;
			index = tempParameters.indexOf(";");
			while(index != -1 && parameters.length() > 1) {
				unitCount++;
				String tempUnit = tempParameters.substring(0, index);
				
				int tempIndex = tempUnit.indexOf(":");
				chrom[unitCount] = tempUnit.substring(0, tempIndex);
				tempUnit = tempUnit.substring(tempIndex + 1);
				
				tempIndex = tempUnit.indexOf("-");
				start[unitCount] = tempUnit.substring(0, tempIndex);
				
				end[unitCount] = tempUnit.substring(tempIndex + 1);
				
				tempParameters = tempParameters.substring(index + 1);
				index = tempParameters.indexOf(";");
			}
			
			for(int i = 0; i <= unitCount; i++) {
				if(database.equals("cpgislandext")) {
					query[i] = "SELECT * FROM epinexus." + database + " WHERE chrom=\"chr" + 
						chrom[i] + "\" AND (chromStart>=\"" + start[i] + 
						"\" AND chromEnd<=\"" + end[i] + "\");";					
				} else {
					query[i] = "SELECT * FROM epinexus." + database + " WHERE chrom=\"" + 
						chrom[i] + "\" AND (chromStart>=\"" + start[i] + 
						"\" AND chromEnd<=\"" + end[i] + "\");";
				}
			}
			
			if(!con.isClosed()) {
				if(database.equals("cpgislandext")) {
					out.println("<table border=\"1\"><tr><th>chrom</th><th>chromStart</th>" + 
						"<th>chromEnd</th><th>name</th><th>length</th><th>cpgNum</th>" + 
						"<th>gcNum</th><th>perCpg</th><th>perGc</th><th>obsExp</th></tr>");
				} else {
					out.println("<table border=\"1\"><tr><th>tax_id</th><th>chrom</th>" + 
						"<th>chromStart</th><th>chromEnd</th><th>name</th><th>ctg_start</th>" + 
						"<th>ctg_stop</th><th>groupLabel</th><th>weight</th></tr>");
				}
				for(int q = 0; q <= unitCount; q++) {
					String stmtString = query[q];
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery(stmtString);
					while(rs.next()) {
						int colCount;
						if(database.equals("cpgislandext")) {
							colCount = 10;
						} else {
							colCount = 9;
						}
						String record = "<tr>";
						for(int i = 1; i <= colCount; i++) {
							record = record + "<td>" + rs.getString(i) + "</td>";
						}
						record = record + "</tr>";
						out.println(record);
					}
				}
				out.println("</table>");
			}
			
			out.println(getPagePart(part2));
			con.close();
			out.close();
		} catch (ClassNotFoundException ex) {
			System.out.println(ex.getMessage());
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());			
		} catch (InstantiationException ex) {
			System.out.println(ex.getMessage());			
		} catch (IllegalAccessException ex) {
			System.out.println(ex.getMessage());			
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
	}
	public static String getPagePart(String FileName){
		
		StringBuffer buf = new StringBuffer();
		try{		
			BufferedReader in = new BufferedReader(new FileReader(new File(FileName)));
			String readin = in.readLine();
			while(readin != null) {
				buf.append(readin);
				//outnow.println(readin);
				readin = in.readLine();
			}
			in.close();
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
		return buf.toString();
	}

}
