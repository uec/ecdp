/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Epinexus;

/**
 *
 * @author feipan
 */
public class Constants {
        public static final String outFolder = "/home/feipan/apache-tomcat-6.0.20/webapps/ROOT/tmp/";
        //String fileRoot1 =  "/home/feipan/apache-tomcat-6.0.20/webapps/ROOT/Epinexus/data/";
        public static final String fileRoot2 =  "/home/feipan/data/chromFa/";
        public static final String fileRoot3 =  "/home/feipan/data/chromFa/hs_ref_";
        public static final String httplink = "http://epinexus.usc.edu/tmp/";
}
