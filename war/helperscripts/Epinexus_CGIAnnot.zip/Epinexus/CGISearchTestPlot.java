package Epinexus;
import java.util.Vector;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.chart.renderer.xy.DefaultXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.annotations.XYLineAnnotation;
import org.jfree.chart.annotations.XYTextAnnotation;
import org.jfree.chart.plot.IntervalMarker;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.event.AxisChangeEvent;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.ui.Layer;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.ValueAxis;

import java.io.File;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileNotFoundException;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CGISearchTestPlot {

	
	public static void plot(String graphFileName, String header, String filename, int start, int end) {
		
		Vector GCCDataVect = new Vector();
		Vector OERDataVect = new Vector();
		String seq = "";
		
		try {
			int startCurPos = start;
			int len = end - start;
			len = len + (len - 50 + start % 50)/50 + 2;
			start = start + ((int)start/50) + header.length();
			end = start + len;
			char[] bufit = new char[len];
			BufferedReader brd = new BufferedReader(new FileReader(filename));
			brd.skip(start);
			brd.read(bufit,0,len);
			brd.close();
			seq = new String(bufit);
		} catch(FileNotFoundException fex) {
			System.out.println("File not found.");
		} catch(IOException iex) {
			System.out.println("IO Exception occurred.");
		}
		
		//runSlidingWind(GCCDataVect,OERDataVect, seq);
		
		XYSeries GCCLine = new XYSeries("GCCGraph");
		for(int i=0;i<GCCDataVect.size();i++){
			float y = ((Float)GCCDataVect.get(i)).floatValue();
			GCCLine.add(i,y);
		}
		
        XYSeries OERLine = new XYSeries("OERGraph");
		for(int i=0;i<OERDataVect.size();i++){
			float y = ((Float)OERDataVect.get(i)).floatValue();
			OERLine.add(i,y);
		}
		
		XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(GCCLine);
        dataset.addSeries(OERLine);
        JFreeChart chart = ChartFactory.createXYLineChart("CpG Plot", // Title
                "x-axis", // x-axis Label
                "y-axis", // y-axis Label
                dataset, // Dataset
                PlotOrientation.VERTICAL, // Plot Orientation
                true, // Show Legend
                true, // Use tooltips
                false // Configure chart to generate URLs?
         );
        try {
            ChartUtilities.saveChartAsJPEG(new File(graphFileName), chart, 500,
                300);
        } catch (IOException e) {
            System.err.println("Problem occurred creating chart.");
        }         
	}
    public static void plotExample(String cfn) {
        //         Create a simple XY chart
        XYSeries series = new XYSeries("XYGraph");
        series.add(1, 1);
        series.add(10, 1);
		XYSeries series2 = new XYSeries("XYGraph");
        series2.add(1, 4);
        series2.add(10, 4);
        XYSeries series3 = new XYSeries("XYGraph");
        series3.add(1, 8);
        series3.add(10, 8);        
        //         Add the series to your data set
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);
        dataset.addSeries(series2);
        dataset.addSeries(series3);
        //         Generate the graph
        JFreeChart chart = ChartFactory.createXYLineChart("XY Chart", // Title
                "Genomic Coordinate (bp)", // x-axis Label
                "", // y-axis Label
                dataset, // Dataset
                PlotOrientation.VERTICAL, // Plot Orientation
                true, // Show Legend
                true, // Use tooltips
                false // Configure chart to generate URLs?
            );
         XYPlot xyplot = chart.getXYPlot();
         //xyplot.addRangeMarker(new IntervalMarker(10,15));
         
         final IntervalMarker target = new IntervalMarker(7.0, 7.5);
        target.setLabel("Target Range");
        target.setLabelFont(new Font("SansSerif", Font.ITALIC, 11));
        target.setLabelAnchor(RectangleAnchor.LEFT);
        target.setLabelTextAnchor(TextAnchor.CENTER_LEFT);
        target.setPaint(Color.blue);
        xyplot.addRangeMarker(target, Layer.BACKGROUND);
        
        ValueMarker vm = new ValueMarker(5.0,Color.green,new BasicStroke(2.5f));
        vm.setLabel("value maker");
        xyplot.addRangeMarker(vm,Layer.BACKGROUND);

		ValueMarker vm1 = new ValueMarker(5.0,Color.green,new BasicStroke(2.5f));
        vm1.setLabel("domainr");
        xyplot.addDomainMarker(vm1,Layer.BACKGROUND);
         
         //xyplot.clearDomainAxes();
         xyplot.clearDomainMarkers();
         
         /*AxisLocation daxis=xyplot.getDomainAxisLocation();
         xyplot.setDomainAxisLocation(0,daxis.getOpposite());
         
         AxisLocation raxis=xyplot.getRangeAxisLocation();
         xyplot.setRangeAxisLocation(0,raxis.getOpposite());*/
         
         ValueAxis da = xyplot.getDomainAxis();
         da.setTickLabelsVisible(false);
         //setAxisLineVisible(boolean visible)
        /* NumberAxis naxis = new NumberAxis();
         naxis.setLowerBound(5);
         naxis.setUpperBound(50);
         AxisChangeEvent aevent = new AxisChangeEvent(naxis);
         xyplot.axisChanged(aevent);
         chart.plotChanged(new PlotChangeEvent(xyplot));*/
         
         XYItemRenderer render = xyplot.getRenderer();
         render.setBaseStroke(new BasicStroke(5.5f));
         XYLineAnnotation annot = new XYLineAnnotation(2,2,10,2,new BasicStroke(5.5f),Color.red);
         XYTextAnnotation tannot = new XYTextAnnotation("Hello, CGI1",4,3);
         render.addAnnotation(tannot);
         render.addAnnotation(annot);
         
         
         
        try {
            ChartUtilities.saveChartAsJPEG(new File(cfn), chart, 500,
                300);
        } catch (IOException e) {
            System.err.println("Problem occurred creating chart.");
        }
    }
   public static void main(String [] args){
   		System.out.println("Hello");
   		String cfn = "./testPlot1.jpg";
   		plotExample(cfn);
   }
}
