/**
 * @(#)annot.java
 *
 *
 * @author Fei Pan
 * @version 1.00 2007/10/25
 */

package Epinexus;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Annot extends HttpServlet {
	private static final long TIMEOUT = 60000;
	
    public void doPost(HttpServletRequest request, HttpServletResponse response) 
    	throws ServletException {

        String fileRoot = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/data/";
		String filename = new Long(System.currentTimeMillis() + new java.util.Random().nextLong()).toString();
		String outFileName = fileRoot + filename + "-AnnotResult.html";

		String geneVector = request.getParameter("geneVector");
		String geneSet = request.getParameter("geneSet");
		String goLevel = request.getParameter("goLevel");
		String bp = request.getParameter("bp");
		String mf = request.getParameter("mf");
		String cc = request.getParameter("cc");
		String kegg = request.getParameter("kegg");
		String useRank = request.getParameter("useRank");
		String pr = request.getParameter("pr");
		double threshold = 1.0;
		/*try{
			PrintWriter writer = new PrintWriter(new FileWriter("c:\\out.txt"));
							
			writer.println("genevect:"+geneVector+"\tgeneset:"+geneSet+"\tgoLevel:"+goLevel+"\tbp:"+bp+"\tmf:"+mf+"\tcc"+cc+"\tkegg:"+kegg+"\tuseRank:"+useRank+"\tpr"+pr);
			writer.close();
		}catch(IOException ioe){
			ioe.printStackTrace();
		}*/
		AnnotAnalyzer myAnnot = new AnnotAnalyzer(geneVector, geneSet,goLevel,bp,mf,cc,kegg,useRank,pr,threshold,outFileName);
		Thread programThread = new Thread(myAnnot);
		programThread.start();
		
		long startTime = System.currentTimeMillis();
		long endTime = startTime + TIMEOUT;
		long currentTime = System.currentTimeMillis();
		while(programThread.isAlive() && currentTime < endTime) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException ex) {
				// Do nothing.
			}
			currentTime = System.currentTimeMillis();
		}
		
		boolean success;
		if(programThread.isAlive()) {
			programThread.stop();
			success = false;
		} else {
			//success = myAnnot.getResult();
			success = true;
		}

		response.setContentType("text/plain");
		try {
			PrintWriter out = response.getWriter();
			if(success){
				out.println("SUCCESS");
				out.println(outFileName);
			}else{
				out.println("FAILURE");
			}
			out.close();
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
			
    }
}
