/**
 * @(#)CGISearch.java
 *
 *
 * @author Fei Pan
 * @version 1.00 2007/11/15
 */
 /*Dec. 2007 add CGISearchPlot.java
  *
  */
package Epinexus;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Stack;
import java.util.Comparator;
import java.util.Collections;
import java.math.BigDecimal;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CpGAnnot{ // extends HttpServlet {
	private static Stack cgiStk;// = new Stack();
	//public static int sldWinCurSize;
	//private static final int winSize = 200;
	//private static final int gapSize = 100;
	//private static int winSize;
	//private static int gapSize;
	private static String pastedSeq;
	private static boolean isMasked;
	private static boolean isOnExtension;

	private static float GC_content_cut;
	private static float obs_exp_ratio_cut;
        public CpGAnnot(){
            this.cgiStk = new Stack();
            this.pastedSeq = null;
            this.isMasked = false;
            this.isOnExtension = false;
            this.GC_content_cut = (float)0.5;
            this.obs_exp_ratio_cut = (float)0.5;
        }
	public static double getValue(double doubleValue) {
		int decimalPlaces = 2;
		BigDecimal bigDecimal = new BigDecimal(doubleValue);
		bigDecimal = bigDecimal.setScale(decimalPlaces,
			BigDecimal.ROUND_HALF_UP);
		doubleValue = bigDecimal.doubleValue();
		return doubleValue;
	}

	public static float getValue(float floatValue) {
		int decimalPlaces = 2;
		BigDecimal bigDecimal = new BigDecimal(floatValue);
		bigDecimal = bigDecimal.setScale(decimalPlaces,
			BigDecimal.ROUND_HALF_UP);
		floatValue = bigDecimal.floatValue();
		return floatValue;
	}

	public static float getGC_content_cut(){
		return GC_content_cut;
	}
	public static float getObs_exp_ratio_cut(){
		return obs_exp_ratio_cut;
	}


	public static void trimCRG_Center(CgiRegion cr){
	//double center trim, it's possible to cause error, i.e., no cgi found after trim; right trim doesnot have this possiblity
		//System.out.println("before trim: "+cr.getCursorPos()+"\t"+cr.size()+"\t"+cr.getNumC()+"\t"+cr.getNumG()+"\t"+cr.getNumCG()+"\t"+cr.size()+"\t"+cr.print());

		while(!cr.isCGI(GC_content_cut, obs_exp_ratio_cut)){
			cr.polllast();
			cr.poll();
		}
		//System.out.println("after trim: "+cr.getCursorPos()+"\t"+cr.size()+"\t"+cr.getNumC()+"\t"+cr.getNumG()+"\t"+cr.getNumCG()+"\t"+cr.size()+"\t"+cr.print());
	}
	public static void trimCRG(CgiRegion cr){
	//refined trim
		/*while(!cr.isTopCpG(isMasked)){
			cr.poll();
		}*/
		while(!cr.isCGI(GC_content_cut, obs_exp_ratio_cut)||!cr.isLastCpG(isMasked)){
			cr.polllast();
		}
		//System.out.println("---------"+cr.print()+"\n"+cr.getCursorPos()+"\t"+cr.size());
	}	
	public static void trimCRG_Right(CgiRegion cr){
	//right trim
		//System.out.println("before trim: "+cr.getCursorPos()+"\t"+cr.size()+"\t"+cr.getNumC()+"\t"+cr.getNumG()+"\t"+cr.getNumCG()+"\t"+cr.size()+"\t"+cr.print());

		while(!cr.isCGI(GC_content_cut, obs_exp_ratio_cut)){
			cr.polllast();
			//System.out.println("trim: " + cr.numC + ":" + cr.numG + ":" + cr.numCG + ":" + cr.size());
			//System.out.println(cr.print());
			//if(cr.size() < 200) System.exit(0);
		}
		//System.out.println("after trim: "+cr.getCursorPos()+"\t"+cr.size()+"\t"+cr.getNumC()+"\t"+cr.getNumG()+"\t"+cr.getNumCG()+"\t"+cr.size()+"\t"+cr.print());
	}
	public static void runSearch(String inputFileName, String chr, int startCurPos, int winSize, int gapSize, boolean cgskip){
		long stttt = System.currentTimeMillis()/1000;
		CgiRegion cgiRG = new CgiRegion(startCurPos,chr,winSize,gapSize);
		//cgiRG.test();
		//read seq input file
		final int bufsize = 10240;
		char [] seqChar = new char[bufsize];
		int slen=0;
		int pos_cur = startCurPos;
		try{
			//inputFileName = "/Users/epigenome/software/apache-tomcat-6.0.14/webapps/Epinexus/cgidata/chr22.fa";
			BufferedReader brd = new BufferedReader(new FileReader(inputFileName));
			int extLength = 0;
			while((slen=brd.read(seqChar,0,bufsize))!=-1){
				//start search
				for(int i=0;i<slen;i++){
					char ch = seqChar[i];
					if(!cgskip) {
						if(ch == 'c') ch = 'C';
						if(ch == 'g') ch = 'G';
					}
					if(ch=='\n' ||ch=='\r'){
						continue;
					}
					pos_cur++;
					//System.out.println("1 calling add at " + pos_cur + "  input: "+ch);
					if(cgiRG.add(ch)&& cgiRG.isTopCpG(isMasked)){
							isOnExtension = true;
							extLength = 0;
							//System.out.println("---before found new cgi------"+cgiRG.print()+"\n"+cgiRG.getCursorPos()+"\t"+cgiRG.size()+"\t"+pos_cur);
							cgiRG = runMerge(cgiRG, pos_cur, chr, winSize, gapSize);
							//System.out.println("---after found new cgi------"+cgiRG.print()+"\n"+cgiRG.getCursorPos()+"\t"+cgiRG.size()+"\t"+pos_cur);
					}
					/*	if(isOnExtension = true){
						extLength++;
						if(extLength==winSize &&!cgiStk.empty()){						
							CgiRegion cigRG_previous=(CgiRegion)cgiStk.pop();
							cgiRG = mergeCgiRG(cgiRG,cigRG_previous,gapSize);
							trimCRG(cgiRG);
							cgiStk.push(cgiRG);
							cgiRG = new CgiRegion(pos_cur,chr,winSize,gapSize);
							isOnExtension = false;
							extLength = 0;
						}
					}*/						
				}
			}
			brd.close();
			//take care of the not full filled CGIRegion
			 if(cgiRG.getElemFilled()<winSize){
			 	runMerge(cgiRG, pos_cur, chr, winSize, gapSize);
			 }
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
	}
	
	private static CgiRegion runMerge(CgiRegion cgiRG, int pos_cur, String chr, int winSize, int gapSize){
		//System.out.println("2 calling add at " + pos_cur + "  input: "+ch);
		if(!cgiStk.empty()){
			CgiRegion cigRG_previous = (CgiRegion)cgiStk.peek();
			int pos_pre = cigRG_previous.getCursorPos();
			int size_pre = cigRG_previous.size();
			//System.out.println("2.1 pospre:"+pos_pre+"\tsize_pre:"+size_pre+"\tpos_cur:"+pos_cur);
			if(pos_cur-cgiRG.size()-pos_pre-size_pre<=gapSize &&cgiRG.getChr().equals(cigRG_previous.getChr())){
				//System.out.println("3 calling add at " + pos_cur + "  input: "+ch);
				cgiStk.pop();
				//System.out.println("current cgiRG: "+cgiRG.print());
				//System.out.println("current cgiRG: "+cigRG_previous.print());
				cgiRG = mergeCgiRG(cgiRG,cigRG_previous,gapSize);
				//System.out.println("end merge");
				//
			}
		}
		trimCRG(cgiRG);
		cgiStk.push(cgiRG);
		cgiRG = new CgiRegion(pos_cur,chr,winSize,gapSize);
		return cgiRG;
	}
	public static CgiRegion mergeCgiRG(CgiRegion CgiRG1, CgiRegion CgiRG_prev,int gapSize){
		int sizeMerged = CgiRG1.getCursorPos()-CgiRG_prev.getCursorPos()+CgiRG1.size();
		int start_pos = CgiRG_prev.getCursorPos();
		CgiRegion cr = new CgiRegion(start_pos,CgiRG1.getChr(),sizeMerged,gapSize);
		for(int i=0;i<CgiRG_prev.size();i++){
			cr.add(CgiRG_prev.getTop(i));
		}
		int relativeNegPos = CgiRG_prev.getCursorPos()+CgiRG_prev.size()-CgiRG1.getCursorPos();
		for(int i=relativeNegPos;i<CgiRG1.size();i++){
			cr.add(CgiRG1.getTop(i));
		}
		//System.out.println("merge: "+CgiRG1.getCursorPos()+"\t"+CgiRG1.size()+"\t"+CgiRG1.getNumC()+"\t"+CgiRG1.getNumG()+"\t"+CgiRG1.getNumCG()+"\t"+CgiRG1.print());
		//System.out.println("merge: "+CgiRG_prev.getCursorPos()+"\t"+CgiRG_prev.size()+"\t"+CgiRG_prev.getNumC()+"\t"+CgiRG_prev.getNumG()+"\t"+CgiRG_prev.getNumCG()+"\t"+CgiRG_prev.size()+"\t"+CgiRG_prev.print());
		//System.out.println("merag: "+cr.getCursorPos()+"\t"+cr.size()+"\t"+cr.getNumC()+"\t"+cr.getNumG()+"\t"+cr.getNumCG()+"\t"+cr.size()+"\t"+cr.print());
	return cr;
	}	
	public static String getPagePart(String FileName){

		StringBuffer buf = new StringBuffer();
		try{
			BufferedReader in = new BufferedReader(new FileReader(new File(FileName)));
			String readin = in.readLine();
			while(readin != null) {
				buf.append(readin);
				//outnow.println(readin);
				readin = in.readLine();
			}
			in.close();
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
		return buf.toString();
	}
	//also clear the cgistk since using pop()
	public static String printCgiStk(String outputFileName){
		StringBuffer buf = new StringBuffer();
		try{
			BufferedWriter outputFileWriter = new BufferedWriter(new FileWriter(new File(outputFileName)));
			while(!cgiStk.empty()){
				CgiRegion cgi = (CgiRegion)cgiStk.pop();
				String st = ">len="+cgi.size()+"\tcoor="+cgi.getCursorPos()+"\tC="+cgi.getNumC()+"\tG="+cgi.getNumG()+"\tCG="+cgi.getNumCG()+"\tGCcontent="+cgi.getGCC()+"\tratio="+cgi.getOER()+"\n";
				buf.append(st);
				StringBuffer tbf = new StringBuffer(cgi.print());
				int lineSize = 50;
				int newline = (int) (tbf.length()/lineSize);
				int i = 0;
				for(i=0;i<newline;i++){
					buf.append(tbf.substring(i*lineSize,(i+1)*lineSize)+"\n");
				}
				buf.append(tbf.substring(i*lineSize)+"\n");
			}
			outputFileWriter.write(buf.toString());
			outputFileWriter.close();
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
		return buf.toString();
	}
	public static String printCgiStkTable(String outputFileName){
		StringBuffer buf = new StringBuffer();
		try{
			BufferedWriter outputFileWriter = new BufferedWriter(new FileWriter(new File(outputFileName)));
			String title = "<center><H3>CpG Island Search Results ( "+cgiStk.size()+" )<p></H3>";
			buf.append(title);
			String header = "<table class=\"datatable\"><tr><th class=\"tableHeader\">Score</th><th class=\"tableHeader\">Chromosome</th><th class=\"tableHeader\">Start</th><th class=\"tableHeader\">End</th><th class=\"tableHeader\">Length</th><th class=\"tableHeader\">GC Content</th><th class=\"tableHeader\">Obs/Exp Ratio</th><th class=\"tableHeader\">More</th></tr>";
			buf.append(header);
			int i =1;
			//String detailsLink = "./Epinexus.CpGAnnotDetail";
                        String detailsLink = "processCpGAnnotDetail.jsp";
                        
			Collections.sort(cgiStk, new Sortit());

			while(!cgiStk.empty()){
				CgiRegion cgi = (CgiRegion)cgiStk.pop();
				String paramforserv = "?filename=" + cgi.getChr() + "&start=" + cgi.getCursorPos() + "&end=" + (cgi.getCursorPos()+ cgi.size());
				String st="";
				if((i%2)==1){
					st = "<tr class=\"evenRow\"><td>"+CpGAnnot.getValue(cgi.getScore())+"</td><td>"+cgi.getChr()+"</td><td>"+cgi.getCursorPos()+"</td><td>"+(cgi.getCursorPos()+cgi.size())+"</td><td>"+cgi.size()+"</td><td>"+CpGAnnot.getValue(cgi.getGCC())+"</td><td>"+CpGAnnot.getValue(cgi.getOER())+"</td><td><a href=\""+detailsLink+paramforserv+"\">more details</a></td>";
				}else{
					st = "<tr class=\"oddRow\"><td>"+CpGAnnot.getValue(cgi.getScore())+"</td><td>"+cgi.getChr()+"</td><td>"+cgi.getCursorPos()+"</td><td>"+(cgi.getCursorPos()+cgi.size())+"</td><td>"+cgi.size()+"</td><td>"+CpGAnnot.getValue(cgi.getGCC())+"</td><td>"+CpGAnnot.getValue(cgi.getOER())+"</td><td><a href=\""+detailsLink+paramforserv+"\">more details</a></td>";
				}
				i++;				
				buf.append(st);
			}
			buf.append("</table></center>");
			outputFileWriter.write(buf.toString());
			outputFileWriter.close();
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
		return buf.toString();
	}
	public static String runCGISearchPlot(String outputImageName,String filename){		
		char seqch[] = pastedSeq.toCharArray();
	   	CGISearchPlot cgiplot = new CGISearchPlot(seqch);
	   	cgiplot.plotCpG(isMasked);
		StringBuffer buf = new StringBuffer();
		String title = "<center><H3>CpG Island Search Results ( "+cgiStk.size()+" )<p></H3>";
		buf.append(title);
		String header = "<table class=\"datatable\"><tr><th class=\"tableHeader\">Id</th><th class=\"tableHeader\">Score</th><th class=\"tableHeader\">Start</th><th class=\"tableHeader\">End</th><th class=\"tableHeader\">Length</th><th class=\"tableHeader\">GC Content</th><th class=\"tableHeader\">Obs/Exp Ratio</th></tr>";
		buf.append(header);
		int i =1;
		Collections.sort(cgiStk, new Sortit());

		while(!cgiStk.empty()){
			CgiRegion cgi = (CgiRegion)cgiStk.pop();
			
   			cgiplot.plotCGI(i,cgi.getCursorPos(),cgi.getCursorPos()+ cgi.size());
   			
			//String paramforserv = "?filename=" + cgi.getChr() + "&start=" + cgi.getCursorPos() + "&end=" + (cgi.getCursorPos()+ cgi.size());
			String st="";
			if((i%2)==1){
				st = "<tr class=\"evenRow\"><td>"+i+".</td><td>"+CpGAnnot.getValue(cgi.getScore())+"</td><td>"+cgi.getCursorPos()+"</td><td>"+(cgi.getCursorPos()+cgi.size())+"</td><td>"+cgi.size()+"</td><td>"+CpGAnnot.getValue(cgi.getGCC())+"</td><td>"+CpGAnnot.getValue(cgi.getOER())+"</td>";
			}else{
				st = "<tr class=\"oddRow\"><td>"+i+".</td><td>"+CpGAnnot.getValue(cgi.getScore())+"</td><td>"+cgi.getCursorPos()+"</td><td>"+(cgi.getCursorPos()+cgi.size())+"</td><td>"+cgi.size()+"</td><td>"+CpGAnnot.getValue(cgi.getGCC())+"</td><td>"+CpGAnnot.getValue(cgi.getOER())+"</td>";
			}
			i++;				
			buf.append(st);
		}
		buf.append("</table></center>");
		
   		cgiplot.saveChart(outputImageName);
   		String img = "<p><div style=\"text-align: center;\"><img border=0 align=\"center\" src=\""+Constants.httplink + filename + ".jpg\"></div><p>";
		buf.append(img);
		
		return buf.toString();
	}
        public void runCpGAnnot(HttpServletRequest request,HttpServletResponse response){
            try{
                doPost(request,response);
            }catch(ServletException se){
                se.printStackTrace();
            }
        }
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException {
       		//String Constants.fileRoot1 =  "/Users/epigenome/software/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/data/";
		//String Constants.fileRoot2 =  "/Users/epigenome/data/chromFa/";
                //String Constants.fileRoot1 = "C:\\webtemp\\data\\";
                //String Constants.fileRoot1 = "/home/feipan/apache-tomcat-6.0.20/webapps/ROOT/tmp/";
                //String Constants.fileRoot1 =  "/home/feipan/apache-tomcat-6.0.20/webapps/ROOT/Epinexus/data";
		//String Constants.fileRoot2 =  "/home/feipan/data/chromFa/";
                //String fileRoot3 =  "/home/feipan/data/chromFa/hs_ref_";

		String filename = new Long(System.currentTimeMillis() + new java.util.Random().nextLong()).toString();
		String inputFileName = Constants.outFolder + filename + "-in.txt";
		String outputFileName = Constants.outFolder + filename + "-out.txt";
		String outputImageName = Constants.outFolder+filename+".jpg";
		String part1 = Constants.fileRoot2 + "cpgserp1annot.txt";
		String part2 = Constants.fileRoot2 + "cpgserp2annot.txt";
		int startCurPos = 0;
		isOnExtension = false;
		String chromsome = "";
		response.setContentType("text/html");
		try {
			PrintWriter outnow = response.getWriter();
			int winSize = Integer.parseInt(request.getParameter("winSize"));
			int gapSize = Integer.parseInt(request.getParameter("gapSize"));
			GC_content_cut = Float.parseFloat(request.getParameter("gccontentcut"))/100;
			obs_exp_ratio_cut = Float.parseFloat(request.getParameter("obsexpratiocut"))/100;

			String repeatMask = request.getParameter("repeatmask");
			boolean cgskip = repeatMask.equals("masked");
			isMasked = cgskip;
			String inputregion = request.getParameter("inputregion");
			String dnaSeq = request.getParameter("dnasequence");

			File inputFile = new File(inputFileName);
			BufferedWriter inputFileWriter = new BufferedWriter(new FileWriter(inputFile));
			outnow.println(getPagePart(part1));
			if(dnaSeq.equals("")) {
				String[] files = inputregion.split(";");
				for(int i = 0; i < files.length; i++) {
					String[] temp = files[i].split(":");
					chromsome = temp[0];
					String tmpname = Constants.fileRoot3 + chromsome + ".fa";
					System.out.println(tmpname);
					String[] tmp = temp[1].split("-");
					int start = Integer.parseInt(tmp[0]);
					startCurPos = start;
					int end = Integer.parseInt(tmp[1]);
					int len = end - start;
					//inputFileWriter.write(">chr: "+chromsome+"\tstart: "+start+"\tend: "+end+"\n");
					len = len + (len - 50 + start % 50)/50 + 2;
					String header = ">"+temp[0];
					start = start + ((int)start/50) + header.length();
					end = start + len;
					//outnow.println("start: " + start + " end: " + end + " length: " + len);
					char[] bufit = new char[len];
					BufferedReader brd = new BufferedReader(new FileReader(tmpname));
					brd.skip(start);
					brd.read(bufit,0,len);
					brd.close();
					inputFileWriter.write(bufit);
				}
			} else {
				//remove \n \r from pastedSeq
				dnaSeq=dnaSeq.trim();
				dnaSeq = dnaSeq.replaceAll("[\n\r]","");
				pastedSeq = dnaSeq;
				inputFileWriter.write(dnaSeq);
				startCurPos = 0;
			}
			inputFileWriter.close();
			//outnow.println(bufit);
			runSearch(inputFileName,chromsome, startCurPos,winSize,gapSize,cgskip);

			for(int i=0;i<cgiStk.size();i++){
				CgiRegion cgiR = (CgiRegion)cgiStk.get(i);
				String seq = cgiR.print();
				double value = new CGIScore().calCGIScore(seq);
				cgiR.setScore(value);
			}

			String st = "";
			if(dnaSeq.equals("")){
				st = printCgiStkTable(outputFileName);
			}else{
				st = runCGISearchPlot(outputImageName,filename);
			}
			outnow.println(st);
			outnow.println(getPagePart(part2));

			long entttt = System.currentTimeMillis()/1000;
			//System.out.println(entttt - stttt);
			outnow.close();
		} catch(IOException ioe){
			ioe.printStackTrace();
		}
	}
     public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {

	    // Use "request" to read incoming HTTP headers (e.g. cookies)
	    // and HTML form data (e.g. data the user entered and submitted)

	    // Use "response" to specify the HTTP response line and headers
	    // (e.g. specifying the content type, setting cookies).

	    PrintWriter out = response.getWriter();
	    // Use "out" to send content to browser
	  }
	/*public static void main(String args[]){
		System.out.println();
	}*/
	//final static String seq = "CGCCGCCCCCCAtttGCCGCCCCCGAGAGAGAGACCCCCGGGGCCCCCGGCCCCGCAATTTTCCCCCGGGGG";
	//final static String seq = "GCAGGGAACATAAAACTTTATTCACTGCAAGAGCTGCGGTCCTGAGGGAAGAATCCTCTGAACTGAGTCAGCACTGAGCTGAGCGATGGAGCCTCAGGGATGAAAGAATAAAGCAGAGAGCCTGGCGTCCAGGCACAGCGAGACCCAAGGGGCCCTCCCAGTGACAGGAAGAGGTGAGACAGAGGCTGCTGCTTGCTCAGAGGCCCCAGAGCAGCTCCACTGCGCACCCAAGGACTCACCACCTTTACCACTAACAAGCTCTGCCAGTTTAATGTACAGTTACTCTGTACCACGTCCTGGGCTGGGCACTGCAGTTCCTGGGAAAATGACGCAGTCCAGGCCCTTTAGGGGAAGCCTGGGAAGAGGGAACTCAGGGGGATTGGGAGGATGGGGTGGGTGAGGCTCACTCCCTGTCAAGCTGGGCAAAGCGCCGTGTCTGAGAGGCAGGCAGCTAACCGCGAGCCGGCGGCGTTCCATTTACAATCTGGTGAGCCTGTATTGGTATAACTCGTATTGTGAGGCTTTTGAGATATCTTGTGACCTTGTGATTTTCCCCGTCTTTGGTGCTTTTGCCCCCTGTAGTGACAAGCAGTTAAAAAAACAAAAACAGAAAACACTCAGAAGGGCAGTGCTTGCTCAGGGATCTGCAGACAGGGCAGATGTCAAGCTCTCACCCAGTTCTGCTGTCGAATGGGGTGCAGGGAGGGGAAGAGGGACCAGGGCCTAGCAGGACAGGGGCAGCTGCAAGCCCCACCTAGAAGTACCCTGGTATGATAGGCTCTGGCTAGGAGCGCTGCAGTGTCACGAAGGCCCCCAGGGAGAGCTGGATCCCTTTGCCCTGATCCTCAGTCCCAGTCTGGAGCAACCTACAGGCCCTGGAGGAGGGGGCAGGACTCCAGTGCCCTTCCCACGAGGCCCTGCTGTACTGACCTCGAATCTGCAGGTTGGAGAAGGTCTGCACGGGAATGGTGATCCTGAAAGAAAGCAGAGGGAGAGGGCTGCCCGGGCTGCCTGGGACACCCCTAGGCTGGGTCTTGGTGCGGGGCCATCATGACAACTTGAACGCCCTTTTCCTTGCCAGGAAAGTCTAACTCCATCTCCTAGCTTTTTCCCCAGCAGCCAACGTGCTATCTGGAGTTCCAAACGTCTGCAAGGGGCTTGAGTGTTATCTGGGAGGGGCGCATGTCTATCTGAAGGAAGATGGAAAAGGGAGGGGAAAGTGGTGAAGAAAGTTCCAAGGAGGCAGAAGAGATGGGTGAGGTGAGGAGTCCAATCTTGGCTGGGAAGATGGGGAGTATGCCTCTTAGTTTGGAGGGTGACCCAAGTCCTTGGCCTTGAGGCCTAATCAATATTGGTTGAATCCATCCatccattcagtcatcaaacatctagtgactgcctgctatgtgtgaggcaggcactgtgctgggcattgaggtgggaagggatctgcacacaaggctgaaaaagactcagtccctgAAGGGAGCAAGATGAGCTCTACCGTGAGGCAGCAGGGAGACTTCCCCAGGGGCTGTGATGAGGGCTCACCGGTTCTCCTCGCCCTCTAGCAGCTTCCTGTAGGTGGCGATCTCGATGTCCAGGGCCAGCTTGACATTGAGCAGGTCCTGGTACTCCTGCAAGTGGCGGGCCATCTCGTCCTTGAGGCTCTGCCCCTCTTCCTCCAGCCGCGCCAGCGCCTCCTGATAACTGGCCGCCTCCCGCACGTGCCGCTCCTCCTGCTCGCGCATCTGCCTCTCCAGGGACTCGTTCTGTGGGATGGAGCCGGCCGGTCCCGCGGAGCCCCGACCCGACTTGGGGAGGTTTCGAggcccggcccccggccccaggccccgccTCTAGCCCGGGGGTAACGTTCAGGCCCCGCCCTCGACCCAGGTCCTCGTCCCTGGCCCTTCTCCCCTGGCATCTCCTGGGGTGGCCGTCCCTGCTCCGCCCGTCCCCGTCCTGCCCTGGCCGCGCTCACCGTGCCGCGCAGAGACTCCAGGTCGCAGGTCAAGGACTGCAACTGGCGCCGGTAGTCGTTGGCTTCGTGCTTGGCCTGGCGGAGCAGCTCCGCGTTGCGGGCAGCAGCGTCTGTCAGGTCTGCAAACTAGGTGGGGGACACATATGGGGGGCTGTGTGGGCCCATGGGCAGGCACGGGCTCTGGGAAATCAGGGAGGTGAGCAGCACCCCAGTTAACCCCAGGACGTTGGCCCTGGCTGGGACTTTTCCCAACAACTGTGACCCATGGATGCGGGCAGGGTAGCGGGCTGCCAGACCTCAGCACCTAGCACAACACCTGGTCAGCAAGCGAATGAATGAACAGTGCCACAGAATCCAGAACCTTCCACACTGACAGCTGCATCTGCGGGACTGAACGCTGTCGTCTTAGGCGAGCGGAGGCCTGGGTGTTTTGTGTGTTtttgtttttttgttttttttgttttattttgagacagagtcttgctcttgtcgcccaggttggaagtcagtggcacaatcccgggtcactgcaacctctgcctcccaggttcaagcaattctcctgccccagccacctgagtagctgggattacaggcatgcgccactacacccggctgattttgtatttttagtagagacggggtttcaccatgttgaccaggctagtcttgaactgctgacctcaggtgatccgcatgcctcggcctcccaaagtgctgggattacaggtgtgagccacctcgcctggccTCACCCTGGGTTCTAATAGCCCTTTCTCCCCTGCCTGCAGGGAGGTCCTCCCAGCCCCATCGGGCCCTCACCCTGCTCAGACACCAGTGGCTTCTGCCACTCACACTCCTCAGCTAGGTGCCCTGGCTAGGCTAGCATCTTGGGGCCCTGCCTCTCTGTGCTTTTCTGCCTCCAGGCTCTGTCCTCCACTAGGAATGGCCCTCCCTTCTTCTCTTCCTGTCCACAGCGTGCCTGTCCTGCCTAGCCCAAATGCCCCCTCTACAGTGTCTTTCCTGGCTCCCACACTACATATAAGCTCTGAGCTGTGGTGTTCTCTACGGGCACTATGTTTGGGTGCACGTCAATATCACACCTTCCAGGTCAGACACCTCTCTGTGTCCTGGGGGGTGCCTGGCATATGGTAGAGGCTCAG";
	//final static String seq = "ATGAGCCCCTACGGGCTTAACCTGAGCCTAGTGGATGAGGCAACAACGTGTGTAACACCCAGGGTCCCCAATACATCTGTGGTGCTGCCAACAGGCGGTAACGGCACATCACCAGCGCTGCCTATCTTCTCCATGACGCTGGGTGCTGTGTCCAACGTGCTGGCGCTGGCGCTGCTGGCCCAGGTTGCAGGCAGACTGCGGCGCCGCCGCTCGACTGCCACCTTCCTGTTGTTCGTCGCCAGCCTGCTTGCCATCGACCTAGCAGGCCATGTGATCCCGGGCGCCTTGGTGCTTCGCCTGTATACTGCAGGACGTGCGCCCGCTGGCGGGGCCTGTCATTTCCTGGGCGGCTGTATGGTCTTCTTTGGCCTGTGCCCACTTTTGCTTGGCTGTGGCATGGCCGTGGAGCGCTGCGTGGGTGTCACGCAGCCGCTGATCCACGCGGCGCGCGTGTCCGTAGCCCGCGCACGCCTGGCACTAGCCCTGCTGGCCGCCATGGCTTTGGCAGTGGCGCTGCTGCCACTAGTGCACGTGGGTCACTACGAGCTACAGTACCCTGGCACTTGGTGTTTCATTAGCCTTGGGCCTCCTGGAGGTTGGCGCCAGGCGTTGCTTGCGGGCCTCTTCGCCGGCCTTGGCCTGGCTGCGCTCCTTGCCGCACTAGTGTGTAATACGCTCAGCGGCCTGGCGCTCCTTCGTGCCCGCTGGAGGCGGCGTCGCTCTCGACGTTTCCGAGAGAACGCAGGTCCCGATGATCGCCGGCGCTGGGGGTCCCGTGGA";
}

class CgiRegion extends CharQueue{
	//serve as sliding window
	private int numC;
	private int numG;
	private int numCG;
	private int pos;  //current moving coordinate cursor position
	private String chr;
	//private int pos_start;
	private int elemFilled; //used in add() for filling the sldwin to full before testing it;

	private int winMaxSize;
	private double score;

	public void setScore(double value) {
		this.score = value;
	}
	public int getElemFilled(){
		return elemFilled;
	}
	public double getScore() {
		return score;
	}
	public CgiRegion(int pos, String chr,int winMaxSize,int gapSize){
		super(winMaxSize+gapSize);
		numC = 0;
		numG = 0;
		numCG = 0;
		elemFilled = 0;
		this.pos = pos;		
		this.chr = chr;
		this.winMaxSize = winMaxSize;
		for(int i=0;i<winMaxSize;i++){
			super.add('N');
		}
	}
	public int getCursorPos(){
		//return the start of cgiRG
		return pos-size(); //note: potential bug, if size() chaged, will change the start. 
							//so make sure change pos if change size(), like in polllast()
	}
	public String getChr(){
		return chr;
	}
	public int getNumC(){
		return numC;
	}
	public int getNumG(){
		return numG;
	}
	public int getNumCG(){
		return numCG;
	}
	/*public int getCoord(){
		return pos-size();
	}*/
	public boolean add(char ch){
		boolean found_cgr = false;
		if(elemFilled<winMaxSize){
			elemFilled++;
		}
		pos++;
		if(ch=='C')numC++;
		if(ch=='G'){
			numG++;
			char fch = getLast();
			//System.out.println("get:"+fch+"at"+pos);
			if(fch =='C')numCG++;
		}
		char outch = super.poll();
		if(outch == 'C')
		{
			numC--;
			char fc = getFirst();
			if(fc=='G')numCG--;
		}
		if(outch=='G')numG--;
		if(!super.add(ch)){
			System.out.println("Queue is full, not adding element correctly");
		}
		//System.out.println("add " + ch);
		if(isCGI(CpGAnnot.getGC_content_cut(), CpGAnnot.getObs_exp_ratio_cut()) && elemFilled>=winMaxSize)
		{
			//System.out.println("hi"+pos);
			found_cgr = true;
			//System.out.println("findout:"+coordinate+"::"+print());
			//System.out.println(""+pos+"\t"+size()+"\t"+numC+"\t"+numG+"\t"+numCG+"\t"+size()+"\t"+print());

		}
		return found_cgr;
	}
	public float getGCC(){
		return (float) (numC+numG)/size();
	}
	public float getOER(){
		if(numC*numG ==0) return 0;
		return (float) (numCG*size())/(numC*numG);
	}
	//public boolean isCGI(){
	public boolean isCGI(float GC_content_cut, float obs_exp_ratio_cut){
		boolean ans = false;
		//float GC_content_cut = (float) 0.5;
		//float obs_exp_ratio_cut = (float) 0.6;
		float GC_content = (float) (numC+numG)/size();
		float obs_exp_ratio = (float) (numCG*size())/(numC*numG);
		//System.out.println("[numC: " + numC + "] [numG: " + numG + "] [numCG: " + numCG + "] [size: " + size() + "] [GC_content: " + GC_content + "] [obs_exp_ratio: " + obs_exp_ratio + "]");
		if(obs_exp_ratio>=obs_exp_ratio_cut && GC_content>=GC_content_cut){
			ans = true;
		}
		return ans;
	}
	public char poll() {
		System.out.println(numC + ":" + numG + ":" + numCG);
		char ch=super.poll();
		if(ch=='C')numC--;
		if(ch=='G'){
			numG--;
			char fch = getLast();
			System.out.println(print());
			//System.out.println("get:"+fch+"at"+pos);
			if(fch =='C')numCG--;
		}
		System.out.println(numC + ":" + numG + ":" + numCG);
		return ch;
	}
	public char polllast() {
		//System.out.println(numC + ":" + numG + ":" + numCG);
		pos--;
		
		char ch=super.polllast();
		if(ch=='C')numC--;
		if(ch=='G'){
			numG--;
			char fch = getLast();
			//System.out.println(print());
			//System.out.println("get:"+fch+"at"+pos);
			if(fch =='C')numCG--;
		}
		//System.out.println(numC + ":" + numG + ":" + numCG);
		return ch;
	}

}

class CharQueue{
	private char[] charQue;
	private int top;
	private int rear;
	private int maxQue;
	private int elemCount;

	public  CharQueue(int maxSize){
		 // This extra space added will allow us to distinguish between
  		// the Beginning and the End locations.
		charQue = new char[maxSize];
		maxQue = maxSize;
		rear = -1;
		top = 0;
		elemCount = 0;
	}
	public int size(){
		return elemCount;
	}
	char getLast(){
		//if(rear==0)return charQue[maxQue];
		return charQue[rear];
	}
	char getLast(int pos){
		return charQue[(rear-1+maxQue)%maxQue];
	}
	char getFirst(){
		//	if(top==0)return charQue[maxQue];
		return charQue[top];
	}
	//The additional maxQue ensures that the pos can be negative
	char getTop(int pos){
		return charQue[(maxQue+top+pos)%maxQue];
	}
	public boolean add(char ch){
		if(elemCount>=maxQue){
			System.out.println("Queue is full,"+ch+" is not added.");
			return false;
		}
		rear++;
		elemCount++;
		rear= rear%maxQue;
		charQue [rear] = ch;
		return true;
	}
	public char poll(){
		if(elemCount<=0)return '0';
		char ch = charQue[top];
		top++;
		elemCount--;
		top=top%maxQue;
		return ch;
	}
	public char polllast() {
		if(elemCount<=0)throw new RuntimeException("Queue is empty");
		char ch = charQue[rear];
		rear--;
		elemCount--;
		rear=(rear+maxQue)%maxQue; //add +maxQue on Dec27/07
		return ch;
	}
	
	boolean isEmpty(){
		if(elemCount ==0){
			return true;
		}else{
			return false;
		}
	}
	public boolean isTopCpG(boolean isMasked){
		boolean rs = false;
		int topSecondPos = (top+1)%maxQue;
		if(isMasked){
			if(charQue[top]=='C'&&charQue[topSecondPos]=='G'){
				rs = true;
			}
		}else{
			if((charQue[top]=='C'||charQue[top]=='c')&&(charQue[topSecondPos]=='G'||charQue[topSecondPos]=='g')){
				rs = true;
			}
		}
		return rs;
	}
	public boolean isLastCpG(boolean isMasked){
		boolean rs = false;
		int lastSecondPos = (rear-1+maxQue)%maxQue;
		if(isMasked){
			if(charQue[lastSecondPos]=='C'&&charQue[rear]=='G'){
				rs = true;
			}
		}else{
			if((charQue[lastSecondPos]=='C'||charQue[lastSecondPos]=='c')&&(charQue[rear]=='G'||charQue[rear]=='g')){
				rs = true;
			}
		}
		return rs;
	}	
	public String print(){
		char [] out = new char[elemCount];
		for(int i=0;i<elemCount;i++){
			int temp = top+i;
			int index = temp%maxQue;
			out[i]=charQue[index];
		}
		return new String(out);
	}
	public void test(){
		CharQueue chque = new CharQueue(6);
		chque.add('T');
		chque.add('h');
		chque.add('i');
		chque.add('s');
		chque.poll();
		chque.add('w');
		chque.add('o');
		chque.add('r');
		chque.add('d');
		System.out.println("test:"+chque.print());
		while(!chque.isEmpty()){
			char ch = chque.poll();
			System.out.println("get is:"+ch);
		}
	}
}

class Sortit implements Comparator {

	public int compare(Object obj1, Object obj2) {
		CgiRegion reg1 = (CgiRegion)obj1;
		CgiRegion reg2 = (CgiRegion)obj2;
		if(reg1.getScore() < reg2.getScore())
			return -1;
		else if(reg1.getScore() == reg2.getScore())
			return 0;
		else
			return 1;
	}

	public boolean equals(Object comp) {
		return this.equals(comp);
	}
}
