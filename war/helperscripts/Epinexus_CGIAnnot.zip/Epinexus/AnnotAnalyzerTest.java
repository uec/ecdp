package Epinexus;
import java.util.Vector;
import java.util.Set;
import java.util.HashSet;

public class AnnotAnalyzerTest{
	public static void main(String[] args){
		String outFileName = "c:\\AnnotResult.html";
		//String gid2AnotFileName = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/genelib/Homo_sapiens_GeneIDToGO.txt";
		
					
		Vector geneVectOfVect = new Vector();
		// populate geneVectOfVect
		String geneClusters1[] = { "3429", "4599", "10346" };
		String geneClusters3[] = { "3115", "10346" };
		String geneClusters2[] ={"3429", "4599", "10346","3115", "3123", "3127", "3113", "3119", "3122", "3108"};
		
		Vector geneVect = new Vector();
		for (int i = 0; i < geneClusters1.length; i++) {
			geneVect.add(geneClusters1[i]);
		}	
		geneVectOfVect.add(geneVect);
		Vector geneVect1 = new Vector();
		for (int i = 0; i < geneClusters3.length; i++) {
			geneVect1.add(geneClusters3[i]);
		}
		geneVectOfVect.add(geneVect1);
		
		Set  totalGidSet = new HashSet();
		for (int i = 0; i < geneClusters2.length; i++) {
			totalGidSet.add(geneClusters2[i]);
		}
//		AnnotAnalyzer myAnnot = new AnnotAnalyzer(geneVect,totalGidSet,1.0,outFileName);
//		Thread programThread = new Thread(myAnnot);
//		programThread.start();
	}
}