package Epinexus;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Creates a database connection, fires queries and returns results.
 */
public class PolycombDb extends HttpServlet {

	/**
	 * Runs the program and retrieves the results.
	 *
	 * @param request The servlet request parameters.
	 * @param response The servlet response parameters.
	 */
    public void doPost(HttpServletRequest request, HttpServletResponse response) 
    	throws ServletException {

		String fileRoot = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/data/";
		String filename = new Long(System.currentTimeMillis() + new java.util.Random().nextLong()).toString();
		String resultFileName = fileRoot + filename + "-PolyResult.html";
		
    	response.setContentType("text/plain");
    	
		try {
			PrintWriter out = response.getWriter();
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql:///", "root", "passw0rd");
			
			File resultFile = new File(resultFileName);
			BufferedWriter resultFileWriter = new BufferedWriter(new FileWriter(resultFile));
			
			if(!con.isClosed()) {
				String stmtString = request.getParameter("query");
				
				resultFileWriter.write("<table border=\"1\"><tr><th>gid</th><th>gs</th>");
				if(stmtString.indexOf(", suz12") != -1) {
					resultFileWriter.write("<th>suz12</th>");
				}
				if(stmtString.indexOf(", eed") != -1) {
					resultFileWriter.write("<th>eed</th>");
				}
				if(stmtString.indexOf(", h3k27me3") != -1) {
					resultFileWriter.write("<th>h3k27me3</th>");
				}
				resultFileWriter.write("</tr>");
				
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(stmtString);
				while(rs.next()) {
					int colCount = Integer.parseInt(request.getParameter("colCount"));
					String record = "<tr>";
					for(int i = 1; i <=colCount; i++) {
						record = record + "<td>" + rs.getString(i) + "</td>";
					}
					record = record + "</tr>";
					resultFileWriter.write(record);
				}
				resultFileWriter.write("</table>");
				out.println("SUCCESS");
			}
			out.println(resultFileName);
			System.out.println(resultFileName);
			resultFileWriter.close();
			con.close();
			out.close();
		} catch (ClassNotFoundException ex) {
			System.out.println(ex.getMessage());
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());			
		} catch (InstantiationException ex) {
			System.out.println(ex.getMessage());			
		} catch (IllegalAccessException ex) {
			System.out.println(ex.getMessage());			
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
	}
}
