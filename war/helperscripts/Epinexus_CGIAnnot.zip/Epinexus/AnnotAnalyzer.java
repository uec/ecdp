	/**
	 * @(#)annot.java
	 *
	 *
	 * @author Fei Pan
	 * @version 1.00 2007/10/25
	 */

	package Epinexus;

	import java.util.Vector;
	import java.util.Map;
	import java.util.HashMap;
	import java.util.Set;
	import java.util.HashSet;
	import java.util.Iterator;
	import java.io.IOException;
	import java.io.BufferedReader;
	import java.io.File;
	import java.io.FileReader;
	import java.io.PrintWriter;
	import java.io.FileWriter;
	import java.util.StringTokenizer;
	import java.math.BigDecimal;
	import java.util.ArrayList;
	import java.util.Collections;

	import org.pub.math.statlib.dist.HyperGeometricDistribution;

	public class AnnotAnalyzer implements Runnable {
	    private Map annotID2Term;
		private Map globalGid2AnnotIDMap;
		private String goURL;
		private Set globalTotalGidSet;
		private Vector geneVect;
		private double minPvalue;
		private String outFileName;
		private String gid2AnotFileName;
		private String goID2GotermFN;
		
		
		public AnnotAnalyzer(){
			annotID2Term = new HashMap();
			globalGid2AnnotIDMap = new HashMap();
			globalTotalGidSet  = new HashSet();
			geneVect = new Vector();
			//GOGeneStrVect = new Vector();
			goURL = "http://www.godatabase.org/cgi-bin/amigo/go.cgi?view=details&show_associations=list&search_constraint=terms&depth=0&query=";
			gid2AnotFileName = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/genelib/Homo_sapiens_GeneIDToGO.txt";
			goID2GotermFN = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/genelib/goid2goterm_hs.txt";
		}
		/*public AnnotAnalyzer(Vector geneVect, Set totalGidSet, double minPvalue,String outFileName){
			this();
			
			this.geneVect = geneVect;
			this.minPvalue = minPvalue;			
			this.outFileName = outFileName;
			try{
				readAnnotFile(gid2AnotFileName);
			}catch(IOException ioe){
				ioe.printStackTrace();
			}
			globalTotalGidSet = totalGidSet;
		}*/
		
		public AnnotAnalyzer (String geneVectString, String geneSetStrng,String goLevel,String bp,String mf,String cc,String kegg,String useRank,String pr,double minPvalue,String outFileName){
			this();
			//System.out.println("hi:"+geneSetStrng);
			String geneClusters1[] = geneVectString.split(":");
			//Vector geneVect = new Vector();
			for (int i = 0; i < geneClusters1.length; i++) {
				String str = geneClusters1[i].trim();
				if(str.length()>0){
					geneVect.add(str);
				}
			}		
			
			//Set  totalGidSet = new HashSet();
//			initilize globalGid2AnnotIDMap,annotID2Term, and globalTotalGidSet
			try{
				readAnnotFile(gid2AnotFileName,goLevel,bp,mf,cc,kegg);
				readKey2StringValue(goID2GotermFN,annotID2Term);
			}catch(IOException ioe){
				ioe.printStackTrace();
			}
			
			if(geneSetStrng!=null){
				String geneClusters2[] = geneSetStrng.split(":");
				for (int i = 0; i < geneClusters1.length; i++) {
					String str = geneClusters2[i].trim();
					if(str.length()>0){
						globalTotalGidSet.add(str);
					}
				}
			}		
			//globalTotalGidSet = totalGidSet;
			//this.geneVect = geneVect;
			this.minPvalue = minPvalue;			
			this.outFileName = outFileName;
		}
		public void run(){
			// TODO Auto-generated method stub
			//AnnotAnalyzer AnnotTest = new AnnotAnalyzer(geneVect, globalTotalGidSet,minPvalue, outFileName);
			Vector GOGeneStrVect = new Vector();
			ArrayList annotResultList = new ArrayList();
			try {				   
		    	GO_annot(geneVect, globalTotalGidSet, annotResultList);
		    	filteringResult(minPvalue, true,true, annotResultList,GOGeneStrVect);
	    		writer2Html(outFileName, GOGeneStrVect);
	    		
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}		
		}

	    public void GO_annot(Vector geneVect, Set totalGidSet,ArrayList annotResultList) throws IOException{
			double x, m, n, k;
			// populate globalGO2GidCount
			Map globalAnnotID2GidCount = new HashMap();
			Iterator itr = totalGidSet.iterator();
			while (itr.hasNext()) {
				Object aGid = itr.next();
				Set annotIDSet = (Set) globalGid2AnnotIDMap.get(aGid);
				if (annotIDSet != null) {
					Iterator itr1 = annotIDSet.iterator();
					while (itr1.hasNext()) {
						Object aAnnotId = itr1.next();
						if (globalAnnotID2GidCount.containsKey(aAnnotId)) {
							Integer integer = (Integer) globalAnnotID2GidCount
									.get(aAnnotId);
							globalAnnotID2GidCount.put(aAnnotId, new Integer(
									integer.intValue() + 1));
						} else {
							globalAnnotID2GidCount.put(aAnnotId, new Integer(1));
						}
					}
				}
			}
			//(int j = 0; j < geneVectOfVect.size(); j++) {
				//Vector geneVect = (Vector) geneVectOfVect.get(j);
				k = geneVect.size();
				// build local GO2gidset
				Map localAnnotID2GidSet = new HashMap();
				for (int i = 0; i < geneVect.size(); i++) {
					Object gid = geneVect.get(i);
					Set annotIdSet = (Set) globalGid2AnnotIDMap.get(gid);
					if (annotIdSet == null) {
						continue;
					}
					itr = annotIdSet.iterator();
					while (itr.hasNext()) {
						Object aAnnotID = itr.next();
						if (localAnnotID2GidSet.containsKey(aAnnotID)) {
							Set gidSet = (Set) localAnnotID2GidSet.get(aAnnotID);
							gidSet.add(gid);
							localAnnotID2GidSet.put(aAnnotID, gidSet);
						} else {
							Set gidSet = new HashSet();
							gidSet.add(gid);
							localAnnotID2GidSet.put(aAnnotID, gidSet);
						}
					}

				}
				// let's evaluate the p-value for each GO
				Set annotKeySet = localAnnotID2GidSet.keySet();
				itr = annotKeySet.iterator();
				//StringBuffer resultStringBuf = new StringBuffer();
				while (itr.hasNext()) {
					String aAnnot = (String) itr.next();
					Set gidSet = (Set) localAnnotID2GidSet.get(aAnnot);
					x = gidSet.size();
					Integer integer = (Integer) globalAnnotID2GidCount.get(aAnnot);
					if (integer == null) {
						continue;
					}
					m = (double) integer.intValue(); // correct since all gid
														// here is from gids
														// contained in files
					n = totalGidSet.size() - m;
//					System.out.println("term is: " + aAnnot);
//					System.out.println("x: " + x + ", m:" + m + ", n:" + n + ", "
//							+ k);
					double p_value = 1 - HyperGeometricDistribution.cumulative(
							x - 1, m, n, k);
					AnnotResult annotRst = new AnnotResult();
					annotRst.localGidSet = gidSet;
					annotRst.globalGidSetCount = integer.intValue();
					annotRst.pValue = p_value;
					annotRst.annotID = aAnnot;
					annotResultList.add(annotRst);
				}
				//annotTermPvalueStringVect.add(resultStringBuf);
			//}
			/*
			if(annotTermPvalueStringVect.size()!=geneVectofVect.size()){
				throw new RuntimeException("inconsistency error from Annotation method");
			}
			*/
			}
	    public void filteringResult(double minPvalue, boolean useTerm,boolean addURL, ArrayList annotResultList,
	    		Vector annotTermPvalueStringVect){
	    	Collections.sort(annotResultList);
			//Iterator itr = annotResultList.iterator();
			StringBuffer resultStringBuf = new StringBuffer();
			//resultStringBuf.append("");
			//while (itr.hasNext()) {
			for(int i=0;i<annotResultList.size();i++){
				AnnotResult annotRst = (AnnotResult)annotResultList.get(i); //(AnnotResult) itr.next();
				double p_value = annotRst.pValue;
				String aAnnot = annotRst.annotID;
				if (p_value <= minPvalue) {					
					BigDecimal decimal = new BigDecimal(p_value);
					BigDecimal mydcPvalue = decimal.setScale(4,
							BigDecimal.ROUND_DOWN);
					if (useTerm) {
						String annotTerm = (String) annotID2Term.get(aAnnot);
						if (annotTerm != null) {
							if (addURL) {
								aAnnot = "<a href =\"" + goURL + "GO:" + aAnnot
										+ "\">" + annotTerm + "</a>";
							} else {
								aAnnot = annotTerm;
							}
						} else {
							if (addURL) {
								aAnnot = "<a href =\"" + goURL + "GO:" + aAnnot
										+ "\">" + aAnnot + "</a>";
							}
						}
					}
					resultStringBuf.append("" + aAnnot + "</td><td>(p value="
							+ mydcPvalue.toString() + "</td><td>; global hits= "+annotRst.globalGidSetCount+"</td><td>local hits= "+annotRst.localGidSet.size()
								+"</td><td>; local set: "+annotRst.localGidSet.toString()+") </td></tr><tr><td>");
				}
			}
			annotTermPvalueStringVect.add(resultStringBuf);
	    }
			
			public void readAnnotFile(String fileName,String goLevel,String bp,String mf,String cc,String kegg)
				throws IOException {
			String line = "";
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			while ((line = reader.readLine()) != null) {
				if (line.trim().length() == 0) {
					continue;
				}
				if (line.startsWith("#")) {
					continue;
				}
				StringTokenizer stz = new StringTokenizer(line);
				String gid = stz.nextToken();
				String annotID = stz.nextToken();			
				//String annotTerm = "tocome";//stz.nextToken();
				String annotCategory = stz.nextToken();
				String annotLevel = stz.nextToken();
				boolean trueCategory = false;
				if(annotCategory.equals("biological_process")){
					if(bp.equals("1")){
						trueCategory = true;
					}
				}else if(annotCategory.equals("cellular_component")){
					if(cc.equals("1")){
						trueCategory = true;
					}
					
				}else if (annotCategory.equals("molecular_function")){
					if(mf.equals("1")){
						trueCategory = true;
					}
				}else if(annotCategory.equals("kegg")){
					if(kegg.equals("1")){
						trueCategory = true;
					}
				}
				int antLevel = Integer.parseInt(annotLevel);
				int goLvl = Integer.parseInt(goLevel);
				if(antLevel>=goLvl && trueCategory){
					globalTotalGidSet.add(gid);
					//annotID2Term.put(annotID,annotTerm);				
					if (globalGid2AnnotIDMap.containsKey(gid)) {
						Set annotIDSet = (Set) globalGid2AnnotIDMap.get(gid);
						annotIDSet.add(annotID);
						globalGid2AnnotIDMap.put(gid, annotIDSet);
					} else {
						Set annotIDSet = new HashSet();
						annotIDSet.add(annotID);
						globalGid2AnnotIDMap.put(gid, annotIDSet);
					}		
				}
			}
			reader.close();
		}
			
	    	public static void writer2Html(String outputFileName, Vector StringVect)
				throws IOException {
				PrintWriter writer = new PrintWriter(new FileWriter(outputFileName));
				writer.println("<html><body><table border = \"1\">");
				for (int i = 0; i < StringVect.size(); i++) {
					writer.println("<tr><td>" + StringVect.get(i) + "</td></tr>");
				}
				writer.println("</table></body></html>");
				writer.close();
			}
		
	    	public static void readKey2ValueSet(String fileName, Map gid2AnnotIDMap) {
			try {
				String line = "";
				BufferedReader reader = new BufferedReader(new FileReader(fileName));
				while ((line = reader.readLine()) != null) {
					if (line.trim().length() == 0) {
						continue;
					}
					if (line.startsWith("#")) {
						continue;
					}
					StringTokenizer stz = new StringTokenizer(line, ",; \t\r");
					String gid = stz.nextToken();
					String annotID = stz.nextToken();
					if (gid2AnnotIDMap.containsKey(gid)) {
						Set annotIDSet = (Set) gid2AnnotIDMap.get(gid);
						annotIDSet.add(annotID);
						gid2AnnotIDMap.put(gid, annotIDSet);
					} else {
						Set annotIDSet = new HashSet();
						annotIDSet.add(annotID);
						gid2AnnotIDMap.put(gid, annotIDSet);
					}
				}
				reader.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
    	public static void readKey2StringValue(String fileName, Map key2ValueMap) {
			try {
				String line = "";
				BufferedReader reader = new BufferedReader(new FileReader(fileName));
				while ((line = reader.readLine()) != null) {
					if (line.trim().length() == 0) {
						continue;
					}
					if (line.startsWith("#")) {
						continue;
					}
					StringTokenizer stz = new StringTokenizer(line, ",; \t\r");
					String key = stz.nextToken();
					String value = stz.nextToken();			
					key2ValueMap.put(key, value);					
				}
				reader.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}	
	    
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String gid2AnotFileName = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/genelib/Homo_sapiens_GeneIDToGO.txt";		
		String outFileName = "c:\\AnnotResult.html";
		AnnotAnalyzer AnnotTest = new AnnotAnalyzer();
		
		Vector geneVectOfVect = new Vector();
		// populate geneVectOfVect
		String geneClusters1[] = { "3429", "4599", "10346" };
		String geneClusters3[] = { "3115", "10346" };
		String geneClusters2[] ={"3429", "4599", "10346","3115", "3123", "3127", "3113", "3119", "3122", "3108"};
		
		Vector geneVect = new Vector();
		for (int i = 0; i < geneClusters1.length; i++) {
			geneVect.add(geneClusters1[i]);
		}	
		geneVectOfVect.add(geneVect);
		Vector geneVect1 = new Vector();
		for (int i = 0; i < geneClusters3.length; i++) {
			geneVect1.add(geneClusters3[i]);
		}
		geneVectOfVect.add(geneVect1);
		
		Set  totalGidSet = new HashSet();
		for (int i = 0; i < geneClusters2.length; i++) {
			totalGidSet.add(geneClusters2[i]);
		}
		
		try {			
			Vector GOGeneStrVect = new Vector(); //to store results
			double minPvalue = 1;
		    
    		//initilize globalGid2AnnotIDMap,annotID2Term, and globalTotalGidSet
    		//AnnotTest.readAnnotFile(gid2AnotFileName);
			ArrayList annotResultList = new ArrayList();
	    	AnnotTest.GO_annot(geneVect, totalGidSet, annotResultList);	    	
	    	AnnotTest.filteringResult(minPvalue, true,true, annotResultList,GOGeneStrVect);
    		writer2Html(outFileName, GOGeneStrVect);
    		
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}		
	

	}
	class AnnotResult implements Comparable{
		public Set localGidSet;
		public int globalGidSetCount;
		public double pValue;	
		public String annotID;
		
		 public final int compareTo( Object annotRst )
		  {
			 if((this.pValue - ( (AnnotResult)annotRst).pValue)>=0){
				 return 1;				 
			 }else{
				 return -1;
			 }
		  }

	}

}
