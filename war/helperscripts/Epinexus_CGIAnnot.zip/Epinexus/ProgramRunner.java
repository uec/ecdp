package Epinexus;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.FileReader;

/**
 * Runs the external program and retrieves the result. 
 */
public class ProgramRunner implements Runnable {
	boolean successful = false;
	String externalProgram;
	int successfulExitCode;
	
	/**
	 * Constructor that accepts the program to run and the 
	 * successful exitr code as the input.
	 * 
	 * @param statusMessage The status message area object.
	 * @param successfulExitCode The successful exit code.
	 */
	public ProgramRunner(String externalProgram, int successfulExitCode) {
		this.externalProgram = externalProgram;
		this.successfulExitCode = successfulExitCode;
	}
	    	
	/**
	 * Runs the servlet and retrieves the result.
	 */
	public void run() {

		try {
			
			// Create a new process to run the external program.
		    Runtime run = Runtime.getRuntime();
		    Process process = run.exec(externalProgram);
		    
		    BufferedReader processStream = new BufferedReader(new 
		    	InputStreamReader(process.getErrorStream()));
	        String processLine;
	        while ((processLine = processStream.readLine()) != null) {
	        	// Clear the buffer.
	        }
			
			int exitCode = process.waitFor();
			successful = (exitCode == successfulExitCode);
			
		} catch (IOException ex) {
			successful = false;
		} catch (InterruptedException ex) {
			successful = false;
		}
	}
	
	/**
	 * Verifies if the external process was successful or not.
	 *
	 * @return <code>true</code> if the external process was successful
	 *         <code>false</code> otherwise.
	 */
	boolean getResult() {
		return successful;
	}
}
