package Epinexus;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Runs the server side analyser and returns the result.
 */
public class Analyze extends HttpServlet {
	private static final long TIMEOUT = 260000;

	/**
	 * Runs the program and retrieves the results.
	 *
	 * @param request The servlet request parameters.
	 * @param response The servlet response parameters.
	 */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
    	throws ServletException, IOException {

		//int successfulExitCode = 2;
		int successfulExitCode = 0;

		//String fileRoot1 = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/data/";
		//String fileRoot2 = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/script/";
		//String fileRoot1 = "/usr/share/tomcat6/webapps/ROOT/Epinexus/data/";
		//String fileRoot2 = "/usr/share/tomcat6/webapps/ROOT/Epinexus/script/";
                String fileRoot1 = "/home/feipan/apache-tomcat-6.0.20/webapps/ROOT/Epinexus/data/";
		String fileRoot2 = "/home/feipan/apache-tomcat-6.0.20/webapps/ROOT/Epinexus/script/";
		String filename = new Long(System.currentTimeMillis() + new java.util.Random().nextLong()).toString();
		String parameterFileName = fileRoot1 + filename + "-Parameter.txt";
		String inputFileName = fileRoot1 + filename + "-In.txt";
		String resultFileName = fileRoot1 + filename + "-Result.html";
		String graphFileName = fileRoot1 + filename + "-Graph.html";
		String graphImage = filename + ".jpg";

		//String externalProgram = "C:\\Program Files\\Java\\jdk1.6.0_02\\bin\\javac";
		//String externalProgram = "\"C:\\Program Files\\R\\R-2.3.1\\bin\\Rcmd.exe\" BATCH \"" + parameterFileName + "\"";
		String externalProgram = "Rscript " + parameterFileName;

    	response.setContentType("text/plain");
	    PrintWriter out = response.getWriter();

		// Create a parameter file.
		File parameterFile = new File(parameterFileName);
		BufferedWriter parameterFileWriter
			= new BufferedWriter(new FileWriter(parameterFile));
		String command = "";
		if(request.getParameter("type").equals("mann")) {
			parameterFileWriter.write("source(\"" + fileRoot2 + "mw.r\")");
			parameterFileWriter.write(System.getProperty("line.separator"));
			/*command = "mw(\"" + inputFileName + "\",\""
				+ resultFileName + "\"," + request.getParameter("case") + ","
				+ request.getParameter("control") + ","
				+ request.getParameter("direction") + ","
				+ request.getParameter("paired") + ","
				+ request.getParameter("correction") + ")";*/
			command = "mw(\"" + inputFileName + "\",\""
				+ resultFileName + "\"," + request.getParameter("caseSize") + ","
				+ request.getParameter("direction") + ","
				+ request.getParameter("paired") + ","
				+ request.getParameter("correction") + ")";
		} else if(request.getParameter("type").equals("auc")) {
			parameterFileWriter.write("source(\"" + fileRoot2 + "auc.r\")");
			parameterFileWriter.write(System.getProperty("line.separator"));
			//command = "auc(\"" + inputFileName + "\",\""
			//	+ resultFileName + "\"," + request.getParameter("case") + ","
			//	+ request.getParameter("control") + ")";
			command = "auc(\"" + inputFileName + "\",\""
				+ resultFileName + "\"," + request.getParameter("caseSize")  + ")";
		} else if(request.getParameter("type").equals("volc")) {
			parameterFileWriter.write("source(\"" + fileRoot2 + "volcano_plot.r\")");
			parameterFileWriter.write(System.getProperty("line.separator"));
			command = "volcano_plot(\"" + inputFileName + "\",\""
				+ fileRoot1 + graphImage + "\"," + request.getParameter("title") + ","
				+ request.getParameter("xlabel") + ","
				+ request.getParameter("ylabel") + ")";
		} else if(request.getParameter("type").equals("heat")) {
			parameterFileWriter.write("source(\"" + fileRoot2 + "heatmap_plot.r\")");
			parameterFileWriter.write(System.getProperty("line.separator"));
			command = "heatmap_plot(\"" + inputFileName + "\",\""
				+ fileRoot1 + graphImage + "\"," + request.getParameter("title") + ","
				+ request.getParameter("xlabel") + ","
				+ request.getParameter("ylabel") + ","
				+ request.getParameter("xsize") + ","
				+ request.getParameter("ysize") + ")";
		} else if(request.getParameter("type").equals("geno")) {
			parameterFileWriter.write("source(\"" + fileRoot2 + "gmplot.r\")");
			parameterFileWriter.write(System.getProperty("line.separator"));
			command = "gmplot(\"" + inputFileName + "\",\""
				+ fileRoot1 + graphImage + "\"," + request.getParameter("threshold") + ","
				+ request.getParameter("xsize") + ","
				+ request.getParameter("ysize") + ")";
		}
		parameterFileWriter.write(command);
		parameterFileWriter.close();

		/*
		// TODO: This is a hack to create the appropriate output file.
		//       Delete this once the external program is ready.
		File outFile = new File(resultFileName);
		BufferedWriter outFileWriter
			= new BufferedWriter(new FileWriter(outFile));
		outFileWriter.write(command);
		outFileWriter.close();
		*/

		// Write the input data to a file.
		File inputFile = new File(inputFileName);
		BufferedWriter fileWriter
			= new BufferedWriter(new FileWriter(inputFile));
		fileWriter.write(request.getParameter("fileInput"));
		fileWriter.close();

		// Create a new process to run the external program.
		ProgramRunner programRunner = new ProgramRunner(externalProgram,
			successfulExitCode);
		Thread programThread = new Thread(programRunner);
		programThread.start();

		long startTime = System.currentTimeMillis();
		long endTime = startTime + TIMEOUT;
		long currentTime = System.currentTimeMillis();
		while(programThread.isAlive() && currentTime < endTime) {
			try {
				Thread.sleep(100);
				/*if(currentTime%10000==0){
					out.println("WAIT");
				}*/

			} catch (InterruptedException ex) {
				// Do nothing.
			}
			currentTime = System.currentTimeMillis();
		}
		//out.println("WAIT");
		boolean success;
		boolean timeout = false;
		if(programThread.isAlive()) {
			programThread.stop();
			success = false;
			timeout = true;
		} else {
			success = programRunner.getResult();
		}

	    if(success) {
	    	out.println("SUCCESS");
			if(request.getParameter("type").equals("mann")
				|| request.getParameter("type").equals("auc")) {
				out.println(resultFileName);
			} else if(request.getParameter("type").equals("volc") ||
					  request.getParameter("type").equals("heat") ||
					  request.getParameter("type").equals("geno")) {
				File graphFile = new File(graphFileName);
				BufferedWriter graphFileWriter
					= new BufferedWriter(new FileWriter(graphFile));
				graphFileWriter.write("<html><head><title>Graph</title></head>" +
					"<body><img src=\"" + graphImage + "\" /></body></html>");
				graphFileWriter.close();
		    	out.println(graphFileName);
			}
	    } else if(timeout){
	    	out.println("TIMEOUT");
	    } else{
	    	out.println("FAILURE");
	    }
	    out.close();
    }
}
