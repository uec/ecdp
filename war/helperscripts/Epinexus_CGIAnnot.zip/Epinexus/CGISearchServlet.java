/**
 * @(#)CGISearch.java
 *
 *
 * @author Fei Pan
 * @version 1.00 2007/11/15
 */
package Epinexus;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Stack;
import java.util.Comparator;
import java.util.Collections;
import java.math.BigDecimal;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

		
public class CGISearchServlet extends HttpServlet {
	private static Stack cgiStk = new Stack();
	//public static int sldWinCurSize;
	//private static final int winSize = 200;
	//private static final int gapSize = 100;
	private static int winSize;
	private static int gapSize;
		
	private static float GC_content_cut;
	private static float obs_exp_ratio_cut;
	
	public static double getValue(double doubleValue) {
		int decimalPlaces = 2;
		BigDecimal bigDecimal = new BigDecimal(doubleValue);
		bigDecimal = bigDecimal.setScale(decimalPlaces, 
			BigDecimal.ROUND_HALF_UP);
		doubleValue = bigDecimal.doubleValue();
		return doubleValue;
	}
	
	public static float getValue(float floatValue) {
		int decimalPlaces = 2;
		BigDecimal bigDecimal = new BigDecimal(floatValue);
		bigDecimal = bigDecimal.setScale(decimalPlaces, 
			BigDecimal.ROUND_HALF_UP);
		floatValue = bigDecimal.floatValue();
		return floatValue;
	}

	public static float getGC_content_cut(){
		return GC_content_cut;
	}
	public static float getObs_exp_ratio_cut(){
		return obs_exp_ratio_cut;
	}

	public static CgiRegion mergeCgiRG(CgiRegion CgiRG1, CgiRegion CgiRG_prev){
		int sizeMerged = CgiRG1.getCursorPos()-CgiRG_prev.getCursorPos()+CgiRG1.size();
		int start_pos = CgiRG_prev.getCursorPos();
		CgiRegion cr = new CgiRegion(start_pos,CgiRG1.getChr(),sizeMerged,gapSize);		
		for(int i=0;i<CgiRG_prev.size();i++){
			cr.add(CgiRG_prev.getTop(i));	
		}
		int relativeNegPos = CgiRG_prev.getCursorPos()+CgiRG_prev.size()-CgiRG1.getCursorPos();
		for(int i=relativeNegPos;i<CgiRG1.size();i++){
			cr.add(CgiRG1.getTop(i));
		}
		//System.out.println("merge: "+CgiRG1.getCursorPos()+"\t"+CgiRG1.size()+"\t"+CgiRG1.getNumC()+"\t"+CgiRG1.getNumG()+"\t"+CgiRG1.getNumCG()+"\t"+CgiRG1.print());
		//System.out.println("merge: "+CgiRG_prev.getCursorPos()+"\t"+CgiRG_prev.size()+"\t"+CgiRG_prev.getNumC()+"\t"+CgiRG_prev.getNumG()+"\t"+CgiRG_prev.getNumCG()+"\t"+CgiRG_prev.size()+"\t"+CgiRG_prev.print());
		//System.out.println("merag: "+cr.getCursorPos()+"\t"+cr.size()+"\t"+cr.getNumC()+"\t"+cr.getNumG()+"\t"+cr.getNumCG()+"\t"+cr.size()+"\t"+cr.print());
	return cr;
	}
	public static void trimCRG(CgiRegion cr){
	//right trim
		//System.out.println("before trim: "+cr.getCursorPos()+"\t"+cr.size()+"\t"+cr.getNumC()+"\t"+cr.getNumG()+"\t"+cr.getNumCG()+"\t"+cr.size()+"\t"+cr.print());
	
		while(!cr.isCGI(GC_content_cut, obs_exp_ratio_cut)){
			cr.polllast();
			//System.out.println("trim: " + cr.numC + ":" + cr.numG + ":" + cr.numCG + ":" + cr.size());
			//System.out.println(cr.print());
			//if(cr.size() < 200) System.exit(0);
		}
		//System.out.println("after trim: "+cr.getCursorPos()+"\t"+cr.size()+"\t"+cr.getNumC()+"\t"+cr.getNumG()+"\t"+cr.getNumCG()+"\t"+cr.size()+"\t"+cr.print());
	}
	public static void runSearch(String inputFileName, String chr, int startCurPos, int winSize, int gapSize, boolean cgskip){
		long stttt = System.currentTimeMillis()/1000;
		CgiRegion cgiRG = new CgiRegion(startCurPos,chr,winSize,gapSize);
		//cgiRG.test();
		//read seq input file
		final int bufsize = 10240;
		char [] seqChar = new char[bufsize];
		int slen=0;
		int pos_cur = startCurPos;
		try{
			//inputFileName = "/Users/epigenome/software/apache-tomcat-6.0.14/webapps/Epinexus/cgidata/chr22.fa";
			BufferedReader brd = new BufferedReader(new FileReader(inputFileName));
			while((slen=brd.read(seqChar,0,bufsize))!=-1){
				//start search
				for(int i=0;i<slen;i++){
					char ch = seqChar[i];
					if(!cgskip) {
						if(ch == 'c') ch = 'C';
						if(ch == 'g') ch = 'G';
					}
					if(ch==0x0a){
						continue;
					}					
					pos_cur++;
					//System.out.println("1 calling add at " + pos_cur + "  input: "+ch);
					if(cgiRG.add(ch)){
						//System.out.println("2 calling add at " + pos_cur + "  input: "+ch);	
						if(!cgiStk.empty()){
							CgiRegion cigRG_previous = (CgiRegion)cgiStk.peek();
							int pos_pre = cigRG_previous.getCursorPos();
							int size_pre = cigRG_previous.size();
							//System.out.println("2.1 pospre:"+pos_pre+"\tsize_pre:"+size_pre+"\tpos_cur:"+pos_cur);
							if(pos_cur-cgiRG.size()-pos_pre-size_pre<=gapSize &&cgiRG.getChr().equals(cigRG_previous.getChr())){
								//System.out.println("3 calling add at " + pos_cur + "  input: "+ch);
								cgiStk.pop();
								//System.out.println("current cgiRG: "+cgiRG.print());
								//System.out.println("current cgiRG: "+cigRG_previous.print());
								cgiRG = mergeCgiRG(cgiRG,cigRG_previous);
								//System.out.println("end merge");
								trimCRG(cgiRG);
							}
						}
						cgiStk.push(cgiRG);
						cgiRG = new CgiRegion(pos_cur,chr,winSize,gapSize);
						}
					}
				}
			brd.close();
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
	}
	public static String getPagePart(String FileName){
		
		StringBuffer buf = new StringBuffer();
		try{		
			BufferedReader in = new BufferedReader(new FileReader(new File(FileName)));
			String readin = in.readLine();
			while(readin != null) {
				buf.append(readin);
				//outnow.println(readin);
				readin = in.readLine();
			}
			in.close();
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
		return buf.toString();
	}
	//also clear the cgistk since using pop()
	public static String printCgiStk(String outputFileName){
		StringBuffer buf = new StringBuffer();
		try{
			BufferedWriter outputFileWriter = new BufferedWriter(new FileWriter(new File(outputFileName)));
			while(!cgiStk.empty()){
				CgiRegion cgi = (CgiRegion)cgiStk.pop();
				String st = ">len="+cgi.size()+"\tcoor="+cgi.getCursorPos()+"\tC="+cgi.getNumC()+"\tG="+cgi.getNumG()+"\tCG="+cgi.getNumCG()+"\tGCcontent="+cgi.getGCC()+"\tratio="+cgi.getOER()+"\n";
				buf.append(st);
				StringBuffer tbf = new StringBuffer(cgi.print());
				int lineSize = 50;
				int newline = (int) (tbf.length()/lineSize);
				int i = 0;
				for(i=0;i<newline;i++){
					buf.append(tbf.substring(i*lineSize,(i+1)*lineSize)+"\n");
				}
				buf.append(tbf.substring(i*lineSize)+"\n");				
			}
			outputFileWriter.write(buf.toString());
			outputFileWriter.close();		
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
		return buf.toString();
	}
	public static String printCgiStkTable(String outputFileName){
		StringBuffer buf = new StringBuffer();
		try{
			BufferedWriter outputFileWriter = new BufferedWriter(new FileWriter(new File(outputFileName)));
			String title = "<center><H3>CpG Island Search Results ( "+cgiStk.size()+" )<p></H3>";
			buf.append(title);
			String header = "<table class=\"datatable\"><tr><th class=\"tableHeader\">Score</th><th class=\"tableHeader\">Chromosome</th><th class=\"tableHeader\">Start</th><th class=\"tableHeader\">End</th><th class=\"tableHeader\">Length</th><th class=\"tableHeader\">GC Content</th><th class=\"tableHeader\">Obs/Exp Ratio</th><th class=\"tableHeader\">More</th></tr>";
			buf.append(header);
			int i =1;
			String detailsLink = "./Epinexus.CGISearchDetail";
			
			Collections.sort(cgiStk, new Sortit());
			
			while(!cgiStk.empty()){
				CgiRegion cgi = (CgiRegion)cgiStk.pop();
				String paramforserv = "?filename=" + cgi.getChr() + "&start=" + cgi.getCursorPos() + "&end=" + (cgi.getCursorPos()+ cgi.size());
				String st="";
				if((i%2)==1){
					st = "<tr class=\"evenRow\"><td>"+CGISearchServlet.getValue(cgi.getScore())+"</td><td>"+cgi.getChr()+"</td><td>"+cgi.getCursorPos()+"</td><td>"+(cgi.getCursorPos()+cgi.size())+"</td><td>"+cgi.size()+"</td><td>"+CGISearchServlet.getValue(cgi.getGCC())+"</td><td>"+CGISearchServlet.getValue(cgi.getOER())+"</td><td><a href=\""+detailsLink+paramforserv+"\">more details</a></td>";
				}else{
					st = "<tr class=\"oddRow\"><td>"+CGISearchServlet.getValue(cgi.getScore())+"</td><td>"+cgi.getChr()+"</td><td>"+cgi.getCursorPos()+"</td><td>"+(cgi.getCursorPos()+cgi.size())+"</td><td>"+cgi.size()+"</td><td>"+CGISearchServlet.getValue(cgi.getGCC())+"</td><td>"+CGISearchServlet.getValue(cgi.getOER())+"</td><td><a href=\""+detailsLink+paramforserv+"\">more details</a></td>";
				}
				i++;
				//String st="+cgi.size()+"\tcoor="+cgi.getCursorPos()+"\tC="+cgi.getNumC()+"\tG="+cgi.getNumG()+"\tCG="+cgi.getNumCG()+"\tGCcontent="+cgi.getGCC()+"\tratio="+cgi.getOER()+"\n";
				buf.append(st);
				/*StringBuffer tbf = new StringBuffer(cgi.print());
				int lineSize = 50;
				int newline = (int) (tbf.length()/lineSize);
				int i = 0;
				for(i=0;i<newline;i++){
					buf.append(tbf.substring(i*lineSize,(i+1)*lineSize)+"\n");
				}
				buf.append(tbf.substring(i*lineSize)+"\n");	*/			
			}
			buf.append("</table></center>");
			outputFileWriter.write(buf.toString());
			outputFileWriter.close();		
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
		return buf.toString();
	}	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException {

		String fileRoot1 = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/data/";
		String fileRoot2 = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/cgidata/";

		String filename = new Long(System.currentTimeMillis() + new java.util.Random().nextLong()).toString();
		String inputFileName = fileRoot1 + filename + "-in.txt";
		String outputFileName = fileRoot1 + filename + "-out.txt";
		String part1 = fileRoot2 + "cpgserp1.txt";
		String part2 = fileRoot2 + "cpgserp2.txt";
		int startCurPos = 0;
		String chromsome = "";
		response.setContentType("text/html");
		try {
			PrintWriter outnow = response.getWriter();
			int winSize = Integer.parseInt(request.getParameter("winSize"));
			int gapSize = Integer.parseInt(request.getParameter("gapSize"));
			GC_content_cut = Float.parseFloat(request.getParameter("gccontentcut"))/100;
			obs_exp_ratio_cut = Float.parseFloat(request.getParameter("obsexpratiocut"))/100;
			
			String repeatMask = request.getParameter("repeatmask");
			boolean cgskip = repeatMask.equals("masked");
			String inputregion = request.getParameter("inputregion");
			String dnaSeq = request.getParameter("dnasequence");
	
			File inputFile = new File(inputFileName);
			BufferedWriter inputFileWriter = new BufferedWriter(new FileWriter(inputFile));
			outnow.println(getPagePart(part1));
			if(dnaSeq.equals("")) {
				String[] files = inputregion.split(";");
				for(int i = 0; i < files.length; i++) {
					String[] temp = files[i].split(":");
					chromsome = temp[0];
					String tmpname = fileRoot2 + chromsome + ".fa";
					System.out.println(tmpname);
					String[] tmp = temp[1].split("-");
					int start = Integer.parseInt(tmp[0]);
					startCurPos = start;
					int end = Integer.parseInt(tmp[1]);
					int len = end - start;
					//inputFileWriter.write(">chr: "+chromsome+"\tstart: "+start+"\tend: "+end+"\n");
					len = len + (len - 50 + start % 50)/50 + 2;
					String header = ">"+temp[0];
					start = start + ((int)start/50) + header.length();
					end = start + len;
					//outnow.println("start: " + start + " end: " + end + " length: " + len);
					char[] bufit = new char[len];
					BufferedReader brd = new BufferedReader(new FileReader(tmpname));
					brd.skip(start);
					brd.read(bufit,0,len);
					brd.close();
					inputFileWriter.write(bufit);
				}
			} else {
				//inputFileWriter.write(">\n");
				inputFileWriter.write(dnaSeq);
				startCurPos = 0;
			}
			inputFileWriter.close();
			//outnow.println(bufit);
			runSearch(inputFileName,chromsome, startCurPos,winSize,gapSize,cgskip);
			
			for(int i=0;i<cgiStk.size();i++){
				CgiRegion cgiR = (CgiRegion)cgiStk.get(i);
				String seq = cgiR.print();
				double value = new CGIScore().calCGIScore(seq);
				cgiR.setScore(value);
			}
			
			String st = printCgiStkTable(outputFileName);
			outnow.println(st);
			outnow.println(getPagePart(part2));
		
			long entttt = System.currentTimeMillis()/1000;
			//System.out.println(entttt - stttt);
			outnow.close();
		} catch(IOException ioe){			
			ioe.printStackTrace();
		}		
	}
     public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
      
	    // Use "request" to read incoming HTTP headers (e.g. cookies)
	    // and HTML form data (e.g. data the user entered and submitted)
	    
	    // Use "response" to specify the HTTP response line and headers
	    // (e.g. specifying the content type, setting cookies).
	    
	    PrintWriter out = response.getWriter();
	    // Use "out" to send content to browser
	  }	
	/*public static void main(String args[]){
		System.out.println();
	}*/
	//final static String seq = "CGCCGCCCCCCAtttGCCGCCCCCGAGAGAGAGACCCCCGGGGCCCCCGGCCCCGCAATTTTCCCCCGGGGG";
	//final static String seq = "GCAGGGAACATAAAACTTTATTCACTGCAAGAGCTGCGGTCCTGAGGGAAGAATCCTCTGAACTGAGTCAGCACTGAGCTGAGCGATGGAGCCTCAGGGATGAAAGAATAAAGCAGAGAGCCTGGCGTCCAGGCACAGCGAGACCCAAGGGGCCCTCCCAGTGACAGGAAGAGGTGAGACAGAGGCTGCTGCTTGCTCAGAGGCCCCAGAGCAGCTCCACTGCGCACCCAAGGACTCACCACCTTTACCACTAACAAGCTCTGCCAGTTTAATGTACAGTTACTCTGTACCACGTCCTGGGCTGGGCACTGCAGTTCCTGGGAAAATGACGCAGTCCAGGCCCTTTAGGGGAAGCCTGGGAAGAGGGAACTCAGGGGGATTGGGAGGATGGGGTGGGTGAGGCTCACTCCCTGTCAAGCTGGGCAAAGCGCCGTGTCTGAGAGGCAGGCAGCTAACCGCGAGCCGGCGGCGTTCCATTTACAATCTGGTGAGCCTGTATTGGTATAACTCGTATTGTGAGGCTTTTGAGATATCTTGTGACCTTGTGATTTTCCCCGTCTTTGGTGCTTTTGCCCCCTGTAGTGACAAGCAGTTAAAAAAACAAAAACAGAAAACACTCAGAAGGGCAGTGCTTGCTCAGGGATCTGCAGACAGGGCAGATGTCAAGCTCTCACCCAGTTCTGCTGTCGAATGGGGTGCAGGGAGGGGAAGAGGGACCAGGGCCTAGCAGGACAGGGGCAGCTGCAAGCCCCACCTAGAAGTACCCTGGTATGATAGGCTCTGGCTAGGAGCGCTGCAGTGTCACGAAGGCCCCCAGGGAGAGCTGGATCCCTTTGCCCTGATCCTCAGTCCCAGTCTGGAGCAACCTACAGGCCCTGGAGGAGGGGGCAGGACTCCAGTGCCCTTCCCACGAGGCCCTGCTGTACTGACCTCGAATCTGCAGGTTGGAGAAGGTCTGCACGGGAATGGTGATCCTGAAAGAAAGCAGAGGGAGAGGGCTGCCCGGGCTGCCTGGGACACCCCTAGGCTGGGTCTTGGTGCGGGGCCATCATGACAACTTGAACGCCCTTTTCCTTGCCAGGAAAGTCTAACTCCATCTCCTAGCTTTTTCCCCAGCAGCCAACGTGCTATCTGGAGTTCCAAACGTCTGCAAGGGGCTTGAGTGTTATCTGGGAGGGGCGCATGTCTATCTGAAGGAAGATGGAAAAGGGAGGGGAAAGTGGTGAAGAAAGTTCCAAGGAGGCAGAAGAGATGGGTGAGGTGAGGAGTCCAATCTTGGCTGGGAAGATGGGGAGTATGCCTCTTAGTTTGGAGGGTGACCCAAGTCCTTGGCCTTGAGGCCTAATCAATATTGGTTGAATCCATCCatccattcagtcatcaaacatctagtgactgcctgctatgtgtgaggcaggcactgtgctgggcattgaggtgggaagggatctgcacacaaggctgaaaaagactcagtccctgAAGGGAGCAAGATGAGCTCTACCGTGAGGCAGCAGGGAGACTTCCCCAGGGGCTGTGATGAGGGCTCACCGGTTCTCCTCGCCCTCTAGCAGCTTCCTGTAGGTGGCGATCTCGATGTCCAGGGCCAGCTTGACATTGAGCAGGTCCTGGTACTCCTGCAAGTGGCGGGCCATCTCGTCCTTGAGGCTCTGCCCCTCTTCCTCCAGCCGCGCCAGCGCCTCCTGATAACTGGCCGCCTCCCGCACGTGCCGCTCCTCCTGCTCGCGCATCTGCCTCTCCAGGGACTCGTTCTGTGGGATGGAGCCGGCCGGTCCCGCGGAGCCCCGACCCGACTTGGGGAGGTTTCGAggcccggcccccggccccaggccccgccTCTAGCCCGGGGGTAACGTTCAGGCCCCGCCCTCGACCCAGGTCCTCGTCCCTGGCCCTTCTCCCCTGGCATCTCCTGGGGTGGCCGTCCCTGCTCCGCCCGTCCCCGTCCTGCCCTGGCCGCGCTCACCGTGCCGCGCAGAGACTCCAGGTCGCAGGTCAAGGACTGCAACTGGCGCCGGTAGTCGTTGGCTTCGTGCTTGGCCTGGCGGAGCAGCTCCGCGTTGCGGGCAGCAGCGTCTGTCAGGTCTGCAAACTAGGTGGGGGACACATATGGGGGGCTGTGTGGGCCCATGGGCAGGCACGGGCTCTGGGAAATCAGGGAGGTGAGCAGCACCCCAGTTAACCCCAGGACGTTGGCCCTGGCTGGGACTTTTCCCAACAACTGTGACCCATGGATGCGGGCAGGGTAGCGGGCTGCCAGACCTCAGCACCTAGCACAACACCTGGTCAGCAAGCGAATGAATGAACAGTGCCACAGAATCCAGAACCTTCCACACTGACAGCTGCATCTGCGGGACTGAACGCTGTCGTCTTAGGCGAGCGGAGGCCTGGGTGTTTTGTGTGTTtttgtttttttgttttttttgttttattttgagacagagtcttgctcttgtcgcccaggttggaagtcagtggcacaatcccgggtcactgcaacctctgcctcccaggttcaagcaattctcctgccccagccacctgagtagctgggattacaggcatgcgccactacacccggctgattttgtatttttagtagagacggggtttcaccatgttgaccaggctagtcttgaactgctgacctcaggtgatccgcatgcctcggcctcccaaagtgctgggattacaggtgtgagccacctcgcctggccTCACCCTGGGTTCTAATAGCCCTTTCTCCCCTGCCTGCAGGGAGGTCCTCCCAGCCCCATCGGGCCCTCACCCTGCTCAGACACCAGTGGCTTCTGCCACTCACACTCCTCAGCTAGGTGCCCTGGCTAGGCTAGCATCTTGGGGCCCTGCCTCTCTGTGCTTTTCTGCCTCCAGGCTCTGTCCTCCACTAGGAATGGCCCTCCCTTCTTCTCTTCCTGTCCACAGCGTGCCTGTCCTGCCTAGCCCAAATGCCCCCTCTACAGTGTCTTTCCTGGCTCCCACACTACATATAAGCTCTGAGCTGTGGTGTTCTCTACGGGCACTATGTTTGGGTGCACGTCAATATCACACCTTCCAGGTCAGACACCTCTCTGTGTCCTGGGGGGTGCCTGGCATATGGTAGAGGCTCAG";
	//final static String seq = "ATGAGCCCCTACGGGCTTAACCTGAGCCTAGTGGATGAGGCAACAACGTGTGTAACACCCAGGGTCCCCAATACATCTGTGGTGCTGCCAACAGGCGGTAACGGCACATCACCAGCGCTGCCTATCTTCTCCATGACGCTGGGTGCTGTGTCCAACGTGCTGGCGCTGGCGCTGCTGGCCCAGGTTGCAGGCAGACTGCGGCGCCGCCGCTCGACTGCCACCTTCCTGTTGTTCGTCGCCAGCCTGCTTGCCATCGACCTAGCAGGCCATGTGATCCCGGGCGCCTTGGTGCTTCGCCTGTATACTGCAGGACGTGCGCCCGCTGGCGGGGCCTGTCATTTCCTGGGCGGCTGTATGGTCTTCTTTGGCCTGTGCCCACTTTTGCTTGGCTGTGGCATGGCCGTGGAGCGCTGCGTGGGTGTCACGCAGCCGCTGATCCACGCGGCGCGCGTGTCCGTAGCCCGCGCACGCCTGGCACTAGCCCTGCTGGCCGCCATGGCTTTGGCAGTGGCGCTGCTGCCACTAGTGCACGTGGGTCACTACGAGCTACAGTACCCTGGCACTTGGTGTTTCATTAGCCTTGGGCCTCCTGGAGGTTGGCGCCAGGCGTTGCTTGCGGGCCTCTTCGCCGGCCTTGGCCTGGCTGCGCTCCTTGCCGCACTAGTGTGTAATACGCTCAGCGGCCTGGCGCTCCTTCGTGCCCGCTGGAGGCGGCGTCGCTCTCGACGTTTCCGAGAGAACGCAGGTCCCGATGATCGCCGGCGCTGGGGGTCCCGTGGA";
}


