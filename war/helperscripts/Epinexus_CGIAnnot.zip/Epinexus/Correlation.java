package Epinexus;

import java.io.*;
import java.util.*;
import java.math.BigDecimal;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

// class of methods for calculating Jackknife correlation
 public class Correlation extends HttpServlet {
    // this way is just to prevent memory allocation for increasing speed
    private static final int maxElementNum = 400;
    private static double[] xs = new double[maxElementNum];
    private static double[] ys = new double[maxElementNum];
    private static final long TIMEOUT = 60000;

    private static final double minPositiveVal = 1e-5;

    // main function for calculating Jack Knife correlation
    // input minMissingValSampleNum: minimum number of samples that have missing value,
    // if the number of samples that don't have missing value is less than minCorrSampleNum
    // the function will just return NaN
    // calculation is same as matlab code jacknife_corr.m

    public static float jacknife(float[] exp1, float[] exp2, int minCorrSampleNum) {

        if(exp1.length != exp2.length)
            throw new RuntimeException("Wrong input for JackKnifeCorrelation.");

        if(exp1.length > maxElementNum)
            throw new RuntimeException("Input vector too long for JackKnifeCorrelation.");

        double sx = 0.0;
        double sy = 0.0;
        double sxy = 0.0;
        double sxq = 0.0;
        double syq = 0.0;

        int n = 0;
        for(int i=0; i<exp1.length; i++)
            if(!Float.isNaN(exp1[i]) && !Float.isNaN(exp2[i])) {
                double x = exp1[i];
                double y = exp2[i];

                xs[n] = x;
                ys[n] = y;

                sx += x;
                sy += y;

                sxy += x*y;

                sxq += x*x;
                syq += y*y;

                n ++;
            }

        if(n<minCorrSampleNum)
            return Float.NaN;

        double minAbsCor = 1.0;
        double signedJCor = 1.0;

        int np = n - 1;     // np is the number of samples for pearson correlation calculation

        for(int i=0; i<n; i++) {
            double x = xs[i];
            double y = ys[i];

            double cx = sx - x;
            double cy = sy - y;
            double cxy = sxy - x*y;
            double cxq = sxq - x*x;
            double cyq = syq - y*y;

            double vx = cxq - cx*cx / np;
            double vy = cyq - cy*cy / np;

            double cor = (vx > minPositiveVal && vy > minPositiveVal)? (cxy - cx*cy/np) / Math.sqrt(vx * vy) : 0.0;

            double absCor = Math.abs(cor);

            if(absCor < minAbsCor) {
                minAbsCor = absCor;
                signedJCor = cor;
            }

            if(minAbsCor == 0.0)
                break;
        }

        if(minAbsCor > 1.0 + minPositiveVal)
            throw new RuntimeException("Wrong calculation.");

        return  (float) signedJCor;
    }

    public float pearson(float[] exp1, float[] exp2, int minCorrSampleNum)
    {

        if(exp1.length != exp2.length)
            throw new RuntimeException("Wrong input for	PearsonCorrelation.");

        if(exp1.length > maxElementNum)
            throw new RuntimeException("Input vector too long for PearsonCorrelation.");

        double sx = 0.0;
        double sy = 0.0;
        double sxy = 0.0;
        double sxq = 0.0;
        double syq = 0.0;

        int n = 0;
        for(int i=0; i<exp1.length; i++)
        {
            if(!Float.isNaN(exp1[i]) && !Float.isNaN(exp2[i]))
            {
                double x = exp1[i];
                double y = exp2[i];

                xs[n] = x;
                ys[n] = y;

                sx += x;
                sy += y;

                sxy += x*y;

                sxq += x*x;
                syq += y*y;

                n ++;
            }
        }

        if(n<minCorrSampleNum)
        {
            return Float.NaN;
        }
        double vx = sxq - sx*sx / n;
        double vy = syq - sy*sy / n;

        double cor = (vx > minPositiveVal && vy > minPositiveVal)? (sxy - sx*sy/n) / Math.sqrt(vx * vy) : 0.0;

        //double absCor = Math.abs(cor);

  
        return  (float) cor;
    }

	public static float getValue(float floatValue) {
		int decimalPlaces = 2;
		BigDecimal bigDecimal = new BigDecimal(floatValue);
		bigDecimal = bigDecimal.setScale(decimalPlaces, 
			BigDecimal.ROUND_HALF_UP);
		floatValue = bigDecimal.floatValue();
		return floatValue;
	}

    public void doPost(HttpServletRequest request, HttpServletResponse response) 
    	throws ServletException {

		//int successfulExitCode = 2;
		int successfulExitCode = 0;

		String fileRoot1 = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/data/";
		String fileRoot2 = "C:/Program Files/Tomcat/apache-tomcat-6.0.14/webapps/ROOT/Epinexus/script/";
		String filename = new Long(System.currentTimeMillis() + new java.util.Random().nextLong()).toString();
		String resultFileName = fileRoot1 + filename + "-Result.html";
		String graphFileName = fileRoot1 + filename + "-Graph.html";
		String workFileName = fileRoot1 + filename + "-Worksheet.html";
		String heatFileName = fileRoot1 + filename + "-Heatmap.txt";
		String parameterFileName = fileRoot1 + filename + "-Parameter.txt";
		String graphImage = filename + ".jpg";

		//String externalProgram = "C:\\Program Files\\Java\\jdk1.6.0_02\\bin\\javac";
		String externalProgram = "\"C:\\Program Files\\R\\R-2.3.1\\bin\\Rcmd.exe\" BATCH \"" + parameterFileName + "\"";

		String aInput = request.getParameter("ainput");
		String bInput = request.getParameter("binput");
		int related = Integer.parseInt(request.getParameter("related"));
		String plot = request.getParameter("plot");
		String corr = request.getParameter("corr");
		int rowCount = Integer.parseInt(request.getParameter("rows"));
		int astart = Integer.parseInt(request.getParameter("astart"));
		int aend = Integer.parseInt(request.getParameter("aend"));
		int bstart = Integer.parseInt(request.getParameter("bstart"));
		int bend = Integer.parseInt(request.getParameter("bend"));
				
		String[] rowtemp = aInput.split(";");
		int aRows = rowtemp.length;
		String[] coltemp = rowtemp[0].split(":");
		int aCols = coltemp.length;
		
		rowtemp = bInput.split(";");
		int bRows = rowtemp.length;
		coltemp = rowtemp[0].split(":");
		int bCols = coltemp.length;
		
		float aValues[][] = new float[aRows][aCols];
		float bValues[][] = new float[bRows][bCols];
		
		rowtemp = aInput.split(";");
		for(int i = 0; i < aRows; i++) {
			coltemp = rowtemp[i].split(":");
			for(int j = 0; j < aCols; j++) {
				aValues[i][j] = Float.parseFloat(coltemp[j]);
			}
		}
		
		rowtemp = bInput.split(";");
		for(int i = 0; i < bRows; i++) {
			coltemp = rowtemp[i].split(":");
			for(int j = 0; j < bCols; j++) {
				bValues[i][j] = Float.parseFloat(coltemp[j]);
			}
		}

		float[][] result = new float[aRows][bRows];
		float[][] transResult = new float[bRows][aRows];
		for(int i = 0; i < aRows; i++) {
			for(int j = 0; j < bRows; j++) {
				if(corr.equals("pear")) {
					result[i][j] = getValue(pearson(aValues[i], bValues[j], 3));
				} else {
					result[i][j] = getValue(jacknife(aValues[i], bValues[j], 5));
				}
			}
		}

		for(int i = 0; i < bRows; i++) {
			for(int j = 0; j < aRows; j++) {
				transResult[i][j] = result[j][i];
			}
		}

		float[][] relatedVal = new float[aRows + bRows][related];
		String[][] relVal = new String[rowCount][related];
		for(int i = 0; i < rowCount; i++) {
			for(int j = 0; j < related; j++) {
				relVal[i][j] = "   ";
			}
		}
		
		for(int i = 0; i < aRows; i++) {
			float[] temp = new float[result[i].length];
			for(int j = 0; j < temp.length; j++) {
				temp[j] = result[i][j];
			}
			Arrays.sort(temp);
			for(int j = 0; j < related; j++) {
				relatedVal[i][j] = temp[temp.length - j - 1];
				relVal[i + astart][j] = Float.toString(relatedVal[i][j]);
			}
		}
		
		for(int i = aRows; i < aRows + bRows; i++) {
			float[] temp = new float[transResult[i - aRows].length];
			for(int j = 0; j < temp.length; j++) {
				temp[j] = transResult[i - aRows][j];
			}			
			Arrays.sort(temp);
			for(int j = 0; j < related; j++) {
				relatedVal[i][j] = temp[temp.length - j - 1];
				relVal[i - aRows + bstart][j] = Float.toString(relatedVal[i][j]);
			}
		}
		
		try {
			String[] rowHeaders = request.getParameter("rowhead").split(":");
			PrintWriter writer = new PrintWriter(new FileWriter(resultFileName));
			writer.print("<table border=\"1\">");
			writer.print("<tr><td>-</td>");
			for(int i = 0; i < bRows; i++) {
				writer.print("<td>" + rowHeaders[i] + "</td>");
			}
			writer.print("</tr>");
			for(int i = 0; i < aRows; i++) {
				writer.print("<tr>");
				writer.print("<td>" + rowHeaders[bRows + i] + "</td>");
				for(int j = 0; j < bRows; j++) {
					writer.print("<td>" + result[i][j] + "</td>");
				}
				writer.print("</tr>");
			}
			writer.print("</table>");
			writer.close();

			PrintWriter heatWriter = new PrintWriter(new FileWriter(heatFileName));
			heatWriter.print("Row Header");
			for(int i = 0; i < bRows; i++) {
				heatWriter.print("\t" + rowHeaders[i]);
			}
			heatWriter.print("\n");
			for(int i = 0; i < aRows; i++) {
				heatWriter.print(rowHeaders[bRows + i]);
				for(int j = 0; j < bRows; j++) {
					heatWriter.print("\t" + result[i][j]);
				}
				if(i != aRows-1) {
					heatWriter.print("\n");
				}
			}
			heatWriter.close();
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
		
		try {
			PrintWriter writer = new PrintWriter(new FileWriter(workFileName));
			for(int i = 0; i < rowCount; i++) {
				for(int j = 0; j < related; j++) {
					writer.print(relVal[i][j]);
					if(j != related - 1) {
						writer.print("\t");
					}
				}
				if(i != rowCount - 1) {
					writer.print("\n");
				}
			}
			writer.close();
		
			if(plot.equals("0")) {
				graphFileName = "noplot";
				response.setContentType("text/plain");
				PrintWriter out = response.getWriter();
		    	out.println("SUCCESS");
				out.println(resultFileName);
				out.println(workFileName);
				out.println(graphFileName);	
				out.close();			
			} else {
				File parameterFile = new File(parameterFileName);
				BufferedWriter parameterFileWriter = new BufferedWriter(new FileWriter(parameterFile));
				String command = "";
				parameterFileWriter.write("source(\"" + fileRoot2 + "heatmap_plot.r\")");
				parameterFileWriter.write(System.getProperty("line.separator"));
				command = "heatmap_plot(\"" + heatFileName + "\",\"" 
					+ fileRoot1 + graphImage + "\",\"\",\"\",\"\",800,600)";
				parameterFileWriter.write(command);
				parameterFileWriter.close();
					
				File graphFile = new File(graphFileName);
				BufferedWriter graphFileWriter 
					= new BufferedWriter(new FileWriter(graphFile));
				graphFileWriter.write("<html><head><title>Graph</title></head>" + 
					"<body><img src=\"" + graphImage + "\" /></body></html>");
				graphFileWriter.close();			


				// Create a new process to run the external program.
				ProgramRunner programRunner = new ProgramRunner(externalProgram, 
					successfulExitCode);
				Thread programThread = new Thread(programRunner);
				programThread.start();
				
				long startTime = System.currentTimeMillis();
				long endTime = startTime + TIMEOUT;
				long currentTime = System.currentTimeMillis();
				while(programThread.isAlive() && currentTime < endTime) {
					try {
						Thread.sleep(100);
					} catch (InterruptedException ex) {
						// Do nothing.
					}
					currentTime = System.currentTimeMillis();
				}
				
				boolean success;
				if(programThread.isAlive()) {
					programThread.stop();
					success = false;
				} else {
					success = programRunner.getResult();
				}
				response.setContentType("text/plain");
				PrintWriter out = response.getWriter();
			    if(success) {
			    	out.println("SUCCESS");
					out.println(resultFileName);
					out.println(workFileName);
					out.println(graphFileName);
			    } else {
			    	out.println("FAILURE");
			    }
			    out.close();
			}
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}

		/*
		//TODO: Only for verifying input. Delete this part.
		try {
			PrintWriter writer = new PrintWriter(new FileWriter("C:/parameterFile.txt"));
			writer.println(aInput);
			writer.println(bInput);
			writer.println(related);
			writer.println(plot);
			writer.println(corr);
			writer.close();
		} catch (IOException ex) {
		}
		*/
		
    }
}
